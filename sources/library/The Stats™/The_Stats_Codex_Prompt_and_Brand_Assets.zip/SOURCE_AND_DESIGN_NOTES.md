# Source and design notes

Prepared for Lewis on October 22, 2026 (America/New_York).

## Verified artwork

The couch illustration and bracketed [REDACTED] lettering are present in both the clean sticker artwork and the supplied flyers. The flyer references use stark black and white and bold condensed display text.

The original SVG contains black and white fills. The original clean PNG uses grayscale plus alpha and is 4800 x 2118 pixels. Its vector companion uses a 2048 x 904 viewBox. Preserve both original variants and choose a rendering that remains legible against the application background.

The raw photographed redacted_sticker.png is a reference, not the preferred UI asset. All packaged artwork bytes are unchanged from their Drive downloads.

The band's 00_ADMIN / Brand Assets folder returned no files during this inspection. The usable assets were found in 04_MERCH / Print Files and Designs; flyer references were in the band master folder. This does not establish that no other branding files exist elsewhere.

## Design decisions rather than official standards

The proposed dark interface palette, heading/body font pairing, panel styles and bracketed navigation treatment are implementation suggestions inspired by the supplied artwork. No formal color or typography standards were found in the inspected sources. Do not call the suggested hex values official brand colors.

Do not copy the flyers' event address, time or QR code into dashboard navigation. The separate Battle Plan image was inspected and excluded because it is an annotated festival map, not a brand asset.

## Application/data provenance

The application handoff was read. It reports an existing Python/Streamlit app and historical passing tests; no application code was run or modified for this prompt-writing task.

The live workbook and collection queue were read. Their latest status was 36 complete / 5 partial / 2 blocked. The latest coverage report described 70 completed recording/metric histories. Historical tests and all workbook checks were not independently rerun in this task.

Application, analysis, recovery and continuation archives were identified by metadata and accompanying documentation; their internal contents must be reconciled by Codex. The application handoff explicitly distinguishes an October 20 reporting endpoint from verified original-baseline membership. The prompt preserves that distinction.

## Framework references checked

- https://docs.streamlit.io/develop/concepts/configuration/theming
- https://docs.streamlit.io/develop/api-reference/media/st.logo

Use the documentation matching the recovered application's installed version.
