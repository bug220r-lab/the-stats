# Start here — The Stats™️ Codex handoff

This pack contains the complete Codex prompt and five original [REDACTED] artwork files retrieved from your Google Drive. It is a build brief and branding pack, not the Python application itself.

## Use it on your Windows PC

1. Keep your current project if you already have it locally. Otherwise download the existing application recovery archive:
   https://drive.google.com/file/d/1kr_9x3cQbfRfCzrRJMVKaNzEhCc_d5f4/view?usp=drivesdk
2. Extract the application into a new folder. Do not overwrite a running project or database.
3. Extract this branding pack into a separate subfolder alongside or inside that project, then open the project folder in Codex.
4. Paste the entire contents of CODEX_PROMPT.md into Codex. You can instead ask Codex to read that file and carry out its instructions.
5. If Codex cannot access Drive, download the additional data archives linked in the prompt into a sources folder. Codex should reconcile the manifests before importing them.

The program should launch locally on Windows and display through your browser. The brief prepares for future hosting for Lewis, Brandon, and Samman; it does not request public deployment.

## Contents

- CODEX_PROMPT.md — complete, ready-to-paste build instructions.
- assets/brand/originals/ — unmodified logo/sticker SVG and PNG files.
- assets/brand/references/ — unmodified horizontal and vertical flyer PDFs.
- ASSET_SOURCES.json — source filenames, Drive IDs/links, file sizes and SHA-256 hashes.
- SOURCE_AND_DESIGN_NOTES.md — what was verified and which design choices are proposed.

The application archive, analytics datasets, dependency files and database are linked in the prompt and are not duplicated in this pack.
