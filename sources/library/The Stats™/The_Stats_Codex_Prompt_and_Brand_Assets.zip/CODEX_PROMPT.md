# Codex build prompt: [REDACTED] — The Stats™️

You are my Python application developer and analytics engineer. Build and finish **The Stats™️**, a useful music and marketing analytics dashboard for my band, **[REDACTED]**.

My name is Lewis. I will use the program on my **Windows PC**. Brandon and Samman may use a hosted version later. Deliver a working application with our actual branding, real imported data, understandable charts, and reliable calculations. Execute the work in the workspace; do not stop at a plan or a mockup.

## 1. Inspect and resume the existing work first

A saved handoff describes an existing Python 3.12 / Streamlit application with SQLite storage, snapshot/provenance handling, pinned dependencies, and tests. Find the current project in this workspace before creating a new app. If needed, recover it from the application archive below into a new project directory.

Read the repository instructions and handoff documents. Verify archive checksums where supplied, inspect the code and database schema, back up the database consistently, install the existing compatible dependencies, and establish what currently runs. Preserve existing functionality and data.

The handoff's **127 passing tests** are historical results; rerun applicable tests and report your own results. Its original Mac path is not my Windows project path. Use the current workspace and portable paths.

Keep the existing Streamlit/SQLite architecture if it is sound. Make focused improvements. If the archive is genuinely unavailable, explain that specific gap, continue with accessible assets/data, and ask for the exact missing file only when necessary. Never silently replace an existing database with a newly generated one.

### Verified project sources

Use connected Google Drive if available in your environment. Otherwise use downloaded files in the workspace. A link does not imply you have authenticated access. Do not assume you inherit another chat's files, browser sessions, credentials, or connectors.

- Project/data folder: https://drive.google.com/drive/folders/1sE3oczZadl04Ro2HDf0GQ51oxuNxiLdR
- Application handoff: https://drive.google.com/file/d/1EZMMStzyDj8TLxn4_wF8p5ekSuMclKoH/view
- Existing application archive, `The_Stats_Handoff_2026-10-22.zip`: https://drive.google.com/file/d/1kr_9x3cQbfRfCzrRJMVKaNzEhCc_d5f4/view
- Live collection workbook: https://docs.google.com/spreadsheets/d/1gfPLM_kj8mT1bNn0e3sv2udEU3644PR5z_20QMfl3Yc/edit
- Cleaned analysis archive, `The_Stats_Cleaned_Analysis_2026-10-22.zip`: https://drive.google.com/file/d/1Y21nrKj5ARqyCE9im36Ekg19XJndrmM7/view
- Analysis/data-contract handoff: https://drive.google.com/file/d/1t7hsEQQFkR-SxDjemIjIkMxVfFGP3T45/view
- Original source package, `The_Stats_Source_Data.zip`: https://drive.google.com/file/d/1T7ZsJq-iyR3IMoc4hQOqXnzOdTidtbJx/view
- Collection supplement: https://drive.google.com/file/d/1l-We_MiUPK7nbXDO955kKwR_f_K7qb0F/view
- Collection recovery: https://drive.google.com/file/d/1k63vp8Tgjt7QjaBWnwPmrSI1BCeKCMAe/view
- Collection continuation, `The_Stats_Collection_Continuation_2026-10-23.zip`: https://drive.google.com/file/d/1qsvqB2W-4i8FpHHpC6tT9Bx7342jpfzz/view

These packages represent different states. Inventory their contents, manifests, timestamps, schemas, and checksums before deciding which records to ingest. Newer filenames do not establish that every earlier source was integrated.

## 2. Use our actual [REDACTED] branding

The accompanying branding pack contains unchanged originals in `assets/brand/originals/`, reference flyers in `assets/brand/references/`, and a source manifest.

Primary artwork:

- `couch_sticker.svg` — original `COUCH STICKER.svg`, 2048 × 904 viewBox:
  https://drive.google.com/file/d/1sNIlWgRKw2roGJepe0nCHz6RQ19flPCs/view
- `couch_sticker.png` — original `COUCH STICKER.png`, 4800 × 2118:
  https://drive.google.com/file/d/1bG_KQYyHeBIrL1HcSpZlro6P8pBWQmLo/view
- `redacted_sticker.png` — photographed/hand-drawn artwork reference:
  https://drive.google.com/file/d/1Qc2qkbjxt9mC6zTi-WqW3FuX5lSuEkdz/view
- Horizontal and vertical flyer references:
  https://drive.google.com/file/d/1c5PSUbyfGz586kcMuO_nCrOj8kfVxGof/view
  https://drive.google.com/file/d/1uhbcAzlwHBsbn2UdW_AT_7xw09lWFA4V/view

The verified artwork features the couch, the bracketed [REDACTED] wordmark, stark black and white, irregular handmade lettering, and bold condensed flyer typography.

Create a polished interpretation of that style:

- Display the real couch logo prominently in the sidebar/header, with **THE STATS™️** as the application title and **Music & Audience Analytics** as the explanatory subtitle.
- Preserve the logo's shape, proportions, lettering, and source appearance. Prefer the clean original SVG/PNG over the photographed reference. Inspect each variant against its background before choosing it. Keep original files unchanged; document any technical derivatives.
- Default to a near-black background, charcoal panels, off-white text, restrained borders, and strong spacing. Suggested interface tokens are `#0B0B0C`, `#171719`, `#F4F1E9`, `#A7A4A0`, and `#343438`. These are proposed UI choices, not an official brand palette.
- Use bold condensed headings, readable sans-serif body text, and tabular numerals. Choose a locally available or properly licensed font; document it. Do not fake our logo by typing the name in a similar font.
- Carry the flyer character through bracketed section labels, strong rules, and subtle texture in decorative areas. Keep plots, tables, controls, and numeric text crisp.
- Use accessible chart colors, direct labels, and line/marker differences where necessary. Color must not be the only way to understand a result.
- Make the layout work on normal Windows laptop screens and smaller screens. Keep the first screen useful, with visible metrics and a primary chart.
- Keep source credits/technical details in a data-information area. Flyer addresses, event times, and QR codes are reference material, not dashboard navigation.
- No animations that obscure information. No invented brand manual or replacement logo.

Use supported Streamlit theme settings and logo components first, with limited maintainable CSS where needed. Check the installed version's documentation before using newer APIs.

## 3. Reconcile data without losing history

Preserve original files and distinguish:

- Event/activity date.
- Reporting period start and end.
- Retrieval/capture timestamp and timezone.
- Measurement cutoff, including unknown lifetime cutoffs.
- Snapshot/source version.
- Membership in an independently verified original reporting baseline.

The intended historical reporting endpoint is **October 20, 2026**. However, the application handoff explicitly marks its archived Spotify snapshot as **unverified original-baseline membership**. Preserve that uncertainty. Do not label later-collected October 20 data as the original baseline merely because its reporting endpoint matches.

Keep archived Spotify, subsequent recovery/supplement data, and Meta captures identifiable. Create a transparent default selection rule for overlapping versions, with an explicit snapshot/history selector. Preserve conflicting values with their evidence instead of silently averaging or overwriting them.

The last inspected live workbook reports **36 complete, 5 partial, and 2 blocked collection items**. It reports **70 completed recording/metric histories**, representing 14 recordings × streams, listeners, streams per listener, saves, and playlist adds, through October 20. The continuation reports 765 added source comparisons and 25,633 added daily source rows. These are reconciliation checkpoints, not constants to hardcode.

Older analysis documents contain stale collection counts and fewer complete histories. Conversely, the cleaned analysis package describes richer social content than the application archive, including valid Stories records and quarantined malformed rows. Reconcile the actual manifests and source vintages. Do not discard valid later records just because an earlier handoff said collection was blocked.

Ingestion must provide:

- File inventory, checksum and schema validation, stable identifiers, and source lineage.
- Preview/validation before import, a transaction for committed changes, and useful error messages.
- Idempotent repeated imports. Reimporting a source must not duplicate observations.
- Separate raw evidence, validated/cleaned data, and derived analysis.
- Logged quarantines and unresolved conflicts, with a reason and source reference.
- Correct handling of sheet title bands: do not assume the tabular header is row 1.
- Dataset/snapshot/import-aware cache invalidation.
- Read-only treatment of the source Google workbook and Drive files.

## 4. Enforce the metric definitions

Build or preserve a metric registry that records units, grain, population, allowed aggregation, denominator, period, and missing-value semantics.

These requirements are essential:

1. **Unique listeners, reach, and viewers are not additive.** Never sum daily, song, country, or source audiences into unique period people. Use an exact matching source aggregate when available; otherwise show unavailable.
2. **Followers are balances.** Differentiate current balance, net change, and new follows.
3. **Ratios need matching scopes and periods.** Recompute from valid numerators/denominators where possible; do not average daily ratios into a period ratio.
4. **Source groups can overlap.** Avoid adding parent aggregates to children or treating overlapping listener groups as mutually exclusive.
5. **Keep observed zero, missing, suppressed, unavailable, rounded, and malformed distinct.** Never fill an unavailable metric with zero merely to populate a chart.
6. **Keep daily flows, rolling windows, period snapshots, and lifetime content measurements distinct.** A post's lifetime views do not belong on its publication day as daily views.
7. **Preserve timezone semantics.** Spotify UTC and Meta's reported Pacific dates must remain explicit. Weekly alignment does not magically remove their mismatch.
8. **Join on verified IDs and enforce cardinality.** Different recordings with the same title stay separate. Joining posts/tracks must not multiply account/artist totals.
9. **Separate Meta combined-platform Views from Instagram-only and Facebook-only components.** Preserve collaborator and account identity distinctions.
10. **Show scope limits.** Top lists can be capped; “complete” collection status does not prove complete market, playlist, or country coverage.

Verify platform identities from retained evidence. The known Spotify artist ID is `6X14XfGTmB560PF063wXDk`; Facebook and Instagram use `@redactedbandoh`. These display names are not sufficient join keys.

TikTok account analytics and TikTok for Artists remain unavailable until actual verified files are imported. Provide an honest unavailable state and a future adapter boundary. Do not invent TikTok results or treat public catalog metadata as private artist analytics.

## 5. Deliver these usable dashboard sections

Reuse existing pages and controls where they work. Every displayed result must come from the selected imported data.

**Overview**
Show available, correctly scoped streams, listeners, saves, playlist adds, followers/net change, and social measures. Include a main trend chart, a comparable-period change where valid, clear reporting dates, source freshness, and coverage. Default to the latest available data in the selected dataset, not the current calendar date when no current data exists.

**Music**
Provide recording/release selection, performance tables, daily or weekly trends, and comparisons over equal-length or equal-age windows. Show streams per listener and save/playlist-add rates only with valid definitions. Keep different recording versions distinct.

**Audience**
Show available demographics, audience segments, countries, and cities with window and population labels. Explain whether each view is exhaustive or a top list. Respect nonadditive unique audiences.

**Sources & Playlists**
Show source mix, changes across comparable windows, retained playlist evidence, and available source histories. Label partial coverage and platform errors visibly. Preserve the distinction between native downloads and chart-derived extracts.

**Social & Content**
Separate Facebook and Instagram account trends from lifetime post/Story performance. Offer platform, content-type, publication-date, and snapshot filters. Show content measurement timing and unknown cutoffs. Handle quarantined records explicitly and display TikTok's actual availability.

**Relationships**
Provide exploratory comparisons between comparable Spotify and social series when data is sufficient. Show aligned observations, scatterplots, lag definitions, sample size, missingness, and effect sizes. Explain findings in plain English and link back to evidence.

**Data Center**
Provide file import and validation, snapshot selection, source inventory, definitions, freshness, collection queue/statuses, missing coverage, quarantine/conflict reports, and exports of filtered tables with their scope/provenance. Make it possible to understand why a number is unavailable.

Apply global date, platform, recording, and snapshot filters only where semantically valid. Show relevant filters and denominators on exports as well as charts.

## 6. Make statistics useful and defensible

First finish trustworthy descriptive analytics. Do not make advanced modeling a prerequisite for a working app.

For supported statistical exploration:

- Examine matched observed periods and complete weeks where appropriate; report how many observations were excluded and why.
- Explain correlation direction and lag direction. Predefine a small set of questions and lags before testing; retain all tested results.
- Treat Pearson/Spearman correlations as associations. Account for trend, autocorrelation, outliers, release timing, seasonality, and different content ages where the data allows.
- Calculate confidence intervals and p-values only with defensible assumptions and adequate data. Otherwise show descriptive effect sizes and a clear limitation.
- Correct across the declared family of multiple tests when inferential tests are justified. Do not report only the strongest result.
- Do not claim social-to-Spotify conversion, causal lift, or an “average artist” benchmark without suitable evidence.
- Any forecasts must be explicitly exploratory, validated against a simple baseline using time-ordered evaluation, and omitted if evidence is inadequate.
- Recompute results after ingestion. Historical analysis outputs are not values to hardcode.

## 7. Make it easy to run on Windows and portable later

Use Python 3.12 if it remains compatible with the recovered project. Preserve and validate its dependency lock; change dependencies deliberately.

- Use `pathlib`, project-relative paths, and configurable data/database directories.
- Provide a documented PowerShell setup and a convenient `start_dashboard.ps1` or `.bat` launcher using the local virtual environment. Do not require global security-policy changes.
- Explain in the README that Python runs the app and the browser displays the local interface.
- Bind the development app to loopback by default.
- Keep parsing, storage, metric logic, and presentation separable. Reuse existing modules; avoid adding another frontend/backend framework without a concrete need.
- Keep assets and fonts local where practical so the app does not need public Drive image links at runtime.
- Keep private data, databases, backups, exports, and secrets out of source control. Use example configuration files without credentials.
- Provide a Dockerfile and a concise future-hosting guide covering persistent storage, controlled imports, backups, and authentication for Lewis, Brandon, and Samman. Explain SQLite's deployment constraints rather than assuming an ephemeral or multiwriter setup is safe.
- Deliver locally. Public deployment, account invitations, and live service authentication are separate tasks.

## 8. Work to completion and verify the result

Inspect first, then implement in manageable steps: restore/run, reconcile/import, calculate, brand, verify, document. Make reasonable implementation choices and proceed. Ask only for a missing file, credential access, or a genuinely consequential unresolved decision.

Use the existing meaningful tests. Add focused checks for changed ingestion/aggregation behavior and data preservation. Verify:

- The app launches with the documented Windows procedure, or explicitly identify any Windows-specific step you could not execute in your environment.
- At least one actual supplied dataset imports and renders correctly.
- Reimporting the same source is idempotent.
- Existing snapshots and original evidence remain intact.
- Representative KPIs reconcile to matching source windows, scopes, and precision.
- Missing values, overlapping populations, and same-title recordings do not produce misleading totals.
- Logo assets render correctly; navigation, filters, charts, tables, downloads, and empty states work.
- The interface remains readable at common desktop and narrower widths.
- Any relevant workbook checks are reproduced or their unverified status is documented. Do not describe historical test/check counts as newly passed.

Deliver the working code, local branding assets, dependency/setup files, launcher, import/validation workflow, README, and a concise completion report. State what changed, how to launch, what data is loaded, what you actually tested, and remaining gaps.

Finish with a working, branded application using the data available. Do not stop after producing a design proposal.
