# The Stats continuation — October 23, 2026 UTC

Correct artist session verified: [REDACTED] (6X14XfGTmB560PF063wXDk); no sign-in needed.

The October 20, 2026 reporting baseline is unchanged. This continuation adds 765 source comparisons and 25,633 daily source rows with nine source values per row. All new source windows end October 20. Newer snapshots from earlier passes remain separately labelled. No missing values were filled with zero. Error pages do not establish zero activity or removal from the catalog.

Seven additional song-source queue tasks are complete. All seven releases now have 12-month worldwide and US source tables and daily chart histories for all three supported source metrics. Queue outcomes: {'Complete': 36, 'Partial': 5, 'Blocked': 2} across 43 items. Remaining work is explicitly listed in updated_queue.json; native exports remain blocked and four original native exports are unchanged.

The source CSVs are cumulative masters including prior successful passes, followed by this continuation. Do not append them to previous masters without deduplication. Files prefixed added_ contain only this continuation's rows. Original daily-song baseline of 71,680 observations and all previous period totals remain in the prior recovery archive. This archive contains raw current captures, validated cumulative source tables, changes, queue outcomes, and build code. Prior raw evidence remains in the previous recovery archive at https://drive.google.com/file/d/1k63vp8Tgjt7QjaBWnwPmrSI1BCeKCMAe/view?usp=drivesdk.

All duplicate historical values match the earlier retained values. Every captured streams source reconciles to its daily chart sum, with 297 checks. Dashes remain unavailable even where chart points explicitly show zero. Active/programmed aggregates overlap their detail rows; never sum both. Daily or source listeners cannot be summed into unique period listeners. Ratios must not be summed. Displayed change may omit a sign; calculated signed change is separate. Country, window, metric, capture time and evidence are explicit.

The remaining playlist retries returned Spotify errors; earlier successful snapshots remain retained. Exact playlist bounds are blank when not exposed. Browser-rendered chart data and generated CSVs are not native Spotify exports.
