import csv,json,re,shutil,hashlib,zipfile
from pathlib import Path
from datetime import datetime,date,timedelta
from urllib.parse import urlparse,parse_qs
from collections import Counter

ROOT=Path(__file__).parent
OUT=ROOT/'The_Stats_Collection_Continuation_2026-10-23'
for sub in ['raw','normalized']:(OUT/sub).mkdir(parents=True,exist_ok=True)
prior=json.loads((ROOT/'retry_workbook_payload.json').read_text())
datasets={d['file']:d for d in prior['datasets']}
captures=json.loads((ROOT/'continue_checkpoint.json').read_text())
catalog=list(csv.DictReader(open(ROOT/'baseline/normalized/song_catalog.csv')))
names={r['song_id']:r['recording_label'] for r in catalog}
releases={r['release_id']:r['release_title'] for r in csv.DictReader(open(ROOT/'baseline/normalized/release_catalog.csv'))}
artist='6X14XfGTmB560PF063wXDk'
sources=['All active sources','Artist profile and catalog',"Listener's own playlists and library",'Listener’s queue','All programmed sources','Editorial and personalized editorial playlists','Personalized playlists, autoplay and mixes','Other listeners’ playlists','Other']
def num(s):
 if s in ('','—','-',None):return None
 x=float(str(s).replace(',','').replace('%',''));return int(x) if x.is_integer() else x
def chartdate(s):
 m=re.match(r'^([A-Za-z]+) (\d{1,2}),? (\d{4})',s);assert m,s
 return datetime.strptime(f'{m[1][:3]} {m[2]} {m[3]}','%b %d %Y').date().isoformat()
def pk(r):return tuple(r[i] for i in (0,2,3,5,6,9,10))
def dk(r):return tuple(r[i] for i in (0,2,3,5,6,7,8))
period=datasets['source_collection.csv'];daily=datasets['source_daily_collection.csv']
pr={pk(r):r for r in period['rows']};sd={dk(r):r for r in daily['rows']}
newp=[];newd=[];recon=[];excluded=[];dup=Counter();valid=[]
for c in captures:
 if 'sources' not in c['label']:continue
 if not c['tables'] or len(c['tables'][0])!=10 or not c['chartLabels']:
  excluded.append([c['label'],'No complete nine-category source table and chart']);continue
 q=parse_qs(urlparse(c['url']).query);metric=q.get('metric',['streams'])[0]
 expected={'streams':'Streams','listeners':'Listeners','streams_per_listener':'Streams / Listener'}[metric]
 assert c['tables'][0][0][0].startswith(expected+' ·'),(c['label'],'metric mismatch')
 ds=[chartdate(s) for s in c['chartLabels']];start,end=min(ds),max(ds)
 days=(date.fromisoformat(end)-date.fromisoformat(start)).days+1
 assert len(ds)==len(set(ds))==days
 assert q.get('fromDate',[start])[0]==start and q.get('toDate',[end])[0]==end
 assert end=='2026-10-20'
 scope='release' if '/release/' in c['url'] else 'song' if '/song/' in c['url'] else 'artist'
 sid=re.search('/'+scope+r'/([^/?]+)',c['url'])[1] if scope!='artist' else artist
 name=names[sid] if scope=='song' else releases[sid] if scope=='release' else '[REDACTED]'
 country=q.get('country',['Worldwide'])[0];country='United States' if country=='US' else country
 previous_end=(date.fromisoformat(start)-timedelta(days=1)).isoformat()
 previous_start=(date.fromisoformat(start)-timedelta(days=days)).isoformat()
 currents={}
 for raw in c['tables'][0][1:]:
  src=next((s for s in sources if raw[0].startswith(s)),None);assert src,raw
  a,b=num(raw[1]),num(raw[2]);currents[src]=b
  row=[scope,name,sid,country,'baseline supplement',start,end,previous_start,previous_end,metric,src,'aggregate' if src.startswith('All ') else 'standalone' if src=='Other' else 'detail',b,a,raw[3],(b-a)/a if a not in (None,0) and b is not None else None,c['collected_at'],c['label'],c['url']]
  k=pk(row)
  if k in pr:
   assert row[12:14]==pr[k][12:14],('conflicting baseline source',k,row[12:14],pr[k][12:14]);dup['period_matches']+=1
  else:pr[k]=row;newp.append(row)
 totals=Counter()
 for raw,d in zip(c['chartLabels'],ds):
  vals=[]
  for src in sources:
   m=re.search(re.escape(src)+r' ([\d,.]+) '+re.escape(metric)+r'(?:,|\s|$)',raw);assert m,(c['label'],src,raw)
   v=num(m[1]);vals.append(v);totals[src]+=v
  row=[scope,name,sid,country,'baseline supplement',start,end,d,metric,*vals,c['collected_at'],c['label']];k=dk(row)
  if k in sd:
   assert row[9:18]==sd[k][9:18],('conflicting baseline daily sources',k);dup['daily_matches']+=1
  else:sd[k]=row;newd.append(row)
 if metric=='streams':
  for src in sources:
   assert currents[src]==totals[src] or (currents[src] is None and totals[src]==0),(c['label'],src,currents[src],totals[src])
   recon.append([scope,sid,country,start,end,src,currents[src],totals[src],'match' if currents[src] is not None else 'table unavailable; chart explicitly zero',c['label']])
 valid.append([scope,name,sid,country,start,end,metric,len(ds),c['label']])

period['append_rows']=newp;period['old_count']=len(period['rows']);period['rows']+=newp
daily['append_rows']=newd;daily['old_count']=len(daily['rows']);daily['rows']+=newd
# Playlist snapshots are point-in-time and never assigned invented exact bounds.
sn=datasets['newer_snapshots.csv'];co=datasets['content_event_reporting.csv']
sn['append_rows']=[];sn['old_count']=len(sn['rows']);co['append_rows']=[];co['old_count']=len(co['rows'])
playlist_ok={}
for c in captures:
 if 'playlists_latest' not in c['label']:continue
 sid=re.search(r'/song/([^/]+)/',c['url'])[1];window='Last 12 months' if 'latest12' in c['label'] else 'Last 28 days'
 tables=[t for t in c['tables'] if t and len(t[0])==5]
 if tables:
  playlist_ok[(sid,window)]=True
  for t in tables:
   for rank,title,creator,streams,added in t[1:]:
    top=re.search(r'Top \d+ of [\d,]+ playlists for this song',c['snapshot'])
    note=(top[0] if top else 'Displayed rows only')+'; exact bounds not exposed; not an exhaustive playlist list'
    sn['append_rows'].append(['playlist',names[sid],sid,'newer snapshot; bounds unexposed','','',window,num(rank),title,'streams',num(streams),creator,added,c['collected_at'],note,c['label'],c['url']])
  observation='Displayed playlist rows retained' if any(len(t)>1 for t in tables) else 'No displayed stats'
 else:observation='Error or unresolved page'
 co['append_rows'].append(['playlist',names[sid],sid,window,observation,None,'Current retry evidence; error or empty table does not mean zero song activity',c['collected_at'],c['label'],c['url']])
sn['rows']+=sn['append_rows'];co['rows']+=co['append_rows']

queue=json.loads((ROOT/'continue_queue_start.json').read_text());changed=[]
def update(row,status,evidence,next_action):
 q=next(q for q in queue if q['row']==row);v=q['values'];v[5]=status;v[6]=next_action
 v[8]+=' | Continuation 2026-10-23 UTC: '+evidence
 changed.append(row)
for q in queue:
 row=q['row']
 if row not in [8,9,10,11,12,14,17,18]:continue
 sid=q['values'][3]
 coverage={p:sorted({r[9] for r in period['rows'] if r[0]=='song' and r[2]==sid and r[3]=='Worldwide' and r[5]==start and r[6]=='2026-10-20'}) for p,start in [('28-day','2026-09-23'),('12-month','2025-10-21')]}
 ev='; '.join(p+': '+(', '.join(ms) if ms else 'not retained') for p,ms in coverage.items())+'. Retained comparisons and daily source points validated.'
 if all(len(ms)==3 for ms in coverage.values()):update(row,'Complete — available scope',ev,'Baseline 28-day and 12-month source windows complete. Country extensions tracked in row 43.')
 elif any(coverage.values()):update(row,'Partial — source metrics collected',ev+' Remaining metrics returned error or unresolved pages.','Retry missing metrics only: 28-day listeners and streams/listener, plus all three 12-month metrics. Spotify intermittently reports not in catalog; no removal or zero inferred.')
for row in [19,21,28,29]:
 q=next(q for q in queue if q['row']==row);sid=q['values'][3]
 attempted=[c['label'] for c in captures if 'playlists_latest' in c['label'] and '/song/'+sid+'/' in c['url']]
 update(row,q['values'][5],'Outstanding playlist windows retried; '+('new displayed data retained.' if any(k[0]==sid for k in playlist_ok) else 'Spotify returned a problem-on-our-end page; no new numeric playlist rows retained.')+' Evidence: '+', '.join(attempted)+'.',q['values'][6])
release_scopes={(r[2],r[3],r[9]) for r in period['rows'] if r[0]=='release' and r[5]=='2025-10-21' and r[6]=='2026-10-20'}
assert len(release_scopes)==42,(len(release_scopes),release_scopes)
update(43,'Partial — expanded source scope','All seven releases now have baseline 12-month worldwide and US source tables and daily histories for streams, listeners and streams/listener. Artist worldwide/US scope retained from previous pass. Additional song source gaps recovered.','US 12-month song sources complete for The Cut, Funny Guy, The Devil Wears Docs, Crawl and GOOMH!. The other nine song-country views failed or remained unresolved. Other countries and periods are outside retained coverage. Remaining worldwide Lab Tapes metrics tracked in row 17.')
update(47,'Blocked — native download failed','The Cut full baseline report resolved, but clicking its enabled native CSV download button returned no file and the download wait timed out after 10 seconds. No new native CSV retained. Four original native files preserved; rendered-chart CSVs remain separately identified.','Retry native exports after report/download handling recovers; retain chart-derived evidence and do not call generated CSVs native exports.')
counts=Counter(q['values'][5].split(' — ')[0] for q in queue if q['row']>=6)
log=datasets['collection_log_retry.csv'];logby={r[0]:r for r in log['rows']}
for q in queue:
 if q['row'] in changed:
  v=q['values'];logby[q['row']]=[q['row'],v[1],v[2],v[3],v[5],v[8].split(' | Continuation 2026-10-23 UTC: ')[-1],v[6],v[7]]
log['rows']=[logby[r] for r in sorted(logby)]

def writecsv(name,headers,rows):
 with open(OUT/'normalized'/name,'w',newline='') as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(rows)
for fn in ['source_collection.csv','source_daily_collection.csv','newer_snapshots.csv','content_event_reporting.csv','collection_log_retry.csv']:
 d=datasets[fn];writecsv(fn,d['headers'],d['rows'])
 if d.get('append_rows'):writecsv('added_'+fn,d['headers'],d['append_rows'])
writecsv('source_stream_reconciliation.csv',['scope','id','population','start','end','source','table_streams','daily_stream_sum','result','evidence'],recon)
writecsv('source_capture_coverage.csv',['scope','recording','id','population','start','end','metric','days','evidence'],valid)
writecsv('excluded_source_captures.csv',['evidence','reason'],excluded)
shutil.copy2(ROOT/'continue_checkpoint.json',OUT/'raw/browser_captures.json')
shutil.copy2(ROOT/'continue_queue_start.json',OUT/'raw/queue_before_continuation.json')
shutil.copy2(ROOT/'baseline/normalized/release_catalog.csv',OUT/'raw/release_catalog.csv')
(OUT/'updated_queue.json').write_text(json.dumps(queue,ensure_ascii=False,indent=2))
manifest={'baseline_end':'2026-10-20','captured_utc_date':'2026-10-23','artist_id':artist,'artist_name':'[REDACTED]','sign_in_needed':False,'raw_captures':len(captures),'added_source_comparisons':len(newp),'added_source_daily_rows':len(newd),'source_comparisons_total':len(period['rows']),'source_daily_rows_total':len(daily['rows']),'release_12month_scopes':len(release_scopes),'native_exports_added':0,'status_counts':dict(counts),'overlapping_values_verified':dict(dup),'stream_reconciliation_checks':len(recon),'excluded_source_captures':len(excluded),'changed_queue_rows':changed,'prior_archive':'https://drive.google.com/file/d/1k63vp8Tgjt7QjaBWnwPmrSI1BCeKCMAe/view?usp=drivesdk'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
(OUT/'README.md').write_text(f'''# The Stats continuation — October 23, 2026 UTC

Correct artist session verified: [REDACTED] ({artist}); no sign-in needed.

The October 20, 2026 reporting baseline is unchanged. This continuation adds {len(newp):,} source comparisons and {len(newd):,} daily source rows with nine source values per row. All new source windows end October 20. Newer snapshots from earlier passes remain separately labelled. No missing values were filled with zero. Error pages do not establish zero activity or removal from the catalog.

Seven additional song-source queue tasks are complete. All seven releases now have 12-month worldwide and US source tables and daily chart histories for all three supported source metrics. Queue outcomes: {dict(counts)} across 43 items. Remaining work is explicitly listed in updated_queue.json; native exports remain blocked and four original native exports are unchanged.

The source CSVs are cumulative masters including prior successful passes, followed by this continuation. Do not append them to previous masters without deduplication. Files prefixed added_ contain only this continuation's rows. Original daily-song baseline of 71,680 observations and all previous period totals remain in the prior recovery archive. This archive contains raw current captures, validated cumulative source tables, changes, queue outcomes, and build code. Prior raw evidence remains in the previous recovery archive at {manifest['prior_archive']}.

All duplicate historical values match the earlier retained values. Every captured streams source reconciles to its daily chart sum, with {len(recon)} checks. Dashes remain unavailable even where chart points explicitly show zero. Active/programmed aggregates overlap their detail rows; never sum both. Daily or source listeners cannot be summed into unique period listeners. Ratios must not be summed. Displayed change may omit a sign; calculated signed change is separate. Country, window, metric, capture time and evidence are explicit.

The remaining playlist retries returned Spotify errors; earlier successful snapshots remain retained. Exact playlist bounds are blank when not exposed. Browser-rendered chart data and generated CSVs are not native Spotify exports.
''')
shutil.copy2(__file__,OUT/'build_continuation.py')
(ROOT/'continue_workbook_payload.json').write_text(json.dumps({'datasets':list(datasets.values()),'queue':queue,'manifest':manifest},ensure_ascii=False))
hashes={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file() and p.name!='sha256.json'}
(OUT/'sha256.json').write_text(json.dumps(hashes,indent=2))
with zipfile.ZipFile(ROOT/(OUT.name+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(ROOT))
print(json.dumps(manifest,indent=2))
