"""Inventory immutable inputs and snapshot the current collection workbook."""
from pathlib import Path
import csv, hashlib, json
import pandas as pd
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]

def main():
    out = ROOT / 'audit'
    out.mkdir(exist_ok=True)
    rows=[]
    for p in sorted((ROOT/'raw').rglob('*')):
        if not p.is_file():
            continue
        rel=str(p.relative_to(ROOT))
        record={'path':rel,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'file_type':p.suffix,'platform':'Meta' if '/meta/' in rel else 'Spotify','role':'original_evidence'}
        if '/normalized/' in rel or '/analysis/' in rel or '/charts/' in rel:
            record['role']='previously_derived_supporting_material'
        if p.suffix.lower()=='.csv':
            for encoding in ('utf-8-sig','utf-16','cp1252'):
                try:
                    with p.open(encoding=encoding,newline='') as f:
                        records=list(csv.reader(f))
                    record['physical_csv_records']=len(records)
                    record['encoding_read']=encoding
                    break
                except UnicodeError:
                    continue
        rows.append(record)
    inventory=pd.DataFrame(rows)
    inventory.to_csv(out/'input_file_inventory.csv',index=False)
    inventory[inventory.duplicated('sha256',keep=False)].to_csv(out/'duplicate_files.csv',index=False)
    w=load_workbook(ROOT/'raw/current_workbook.xlsx',read_only=True,data_only=True)
    values=list(w['Collection queue'].values)
    header=next(i for i,r in enumerate(values) if r and r[0]=='Priority')
    queue=pd.DataFrame([r[:9] for r in values[header+1:] if r and r[0]],columns=values[header][:9])
    queue.insert(0,'source_excel_row',range(header+2,header+2+len(queue)))
    queue.to_csv(out/'current_collection_queue.csv',index=False)
    counts=queue['Status'].str.split(' — ').str[0].value_counts().to_dict()
    sheets=[]
    for s in w:
        values=[r for r in s.values if any(x is not None for x in r)]
        sheets.append({'sheet':s.title,'nonempty_rows':len(values),'columns_max':max(map(len,values),default=0)})
    pd.DataFrame(sheets).to_csv(out/'workbook_sheet_inventory.csv',index=False)
    expected=json.loads((ROOT/'raw_sha256.json').read_text())
    lookup={r['path']:r['sha256'] for r in rows}
    bad=[r['path'] for r in expected if lookup.get(r['path'])!=r['sha256']]
    validation={'preserved_source_files':len(expected),'raw_checksum_mismatches':bad,'current_queue_items':len(queue),'queue_status_counts':counts,'workbook_sheet_count':len(sheets),'duplicate_file_instances':int(inventory.duplicated('sha256',keep=False).sum()),'queue_source':'https://docs.google.com/spreadsheets/d/1gfPLM_kj8mT1bNn0e3sv2udEU3644PR5z_20QMfl3Yc/edit#gid=82074406','workbook_retrieved_at':'2026-10-23','retrieval_time_precision':'UTC date only; exact connector call timestamp not retained','baseline_reporting_end':'2026-10-20','analysis_local_date':'2026-10-22'}
    (out/'input_validation.json').write_text(json.dumps(validation,indent=2))
    assert not bad, f'Raw inputs changed: {bad}'
    print(json.dumps(validation,indent=2))

if __name__=='__main__':
    main()
