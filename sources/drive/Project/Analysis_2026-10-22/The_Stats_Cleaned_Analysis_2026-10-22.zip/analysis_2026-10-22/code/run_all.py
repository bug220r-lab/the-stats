"""Reproduce the analysis locally, including checks and consolidated exports."""
from pathlib import Path
import subprocess, sys

ROOT=Path(__file__).resolve().parents[1]

def main():
    for name in ['audit_inputs.py','spotify_pipeline.py','social_pipeline.py','cross_platform.py','assemble_outputs.py']:
        script=ROOT/'code'/name
        if not script.is_file():
            raise FileNotFoundError(f'Required analysis script missing: {script}')
        print(f'Running {name}',flush=True)
        subprocess.run([sys.executable,str(script)],cwd=ROOT,check=True)
    print('Analysis regenerated. Read audit/final_validation.json and statistical_results.csv.')

if __name__=='__main__':main()
