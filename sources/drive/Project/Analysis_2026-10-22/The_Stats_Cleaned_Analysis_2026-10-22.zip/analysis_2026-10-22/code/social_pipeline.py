"""Reproduce social cleaning and descriptive results from the preserved Meta package.

Run: python code/social_pipeline.py [--source raw/meta] [--output social]
No network, credentials, source writes, zero-filling, or inferred short-row repair.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, re
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
ACCOUNT_IDS = {'Facebook': '100091779409539', 'Instagram': '17841454335424545'}
METRICS = {'views':'views', 'viewers':'viewers', 'reach':'reach', 'content interactions':'interactions',
           'facebook link clicks':'link_clicks', 'instagram link clicks':'link_clicks', 'link clicks':'link_clicks',
           'facebook visits':'visits', 'instagram profile visits':'visits', 'visits':'visits',
           'facebook follows':'follows', 'instagram follows':'follows', 'follows':'follows'}
NONADDITIVE = {'reach','viewers'}
META_FIELDS = {'Post ID','Page ID','Page name','Account ID','Account username','Account name',
               'Title','Description','Publish time','Caption type','Permalink','Post type',
               'Languages','Custom labels','Funded content status','Data comment','Date'}

def clean_number(raw):
    text = str(raw).strip()
    if not text: return np.nan, 'missing_blank'
    if text in ('N/A','NA','n/a'): return np.nan, 'not_applicable_or_unavailable_source_unspecified'
    if text in ('—','–','-'): return np.nan, 'unavailable_or_suppressed_source_unspecified'
    if re.search(r'\d[KMBkmb]$', text): return np.nan, 'rounded_display'
    try: return float(text.replace(',','')), 'observed_zero' if float(text.replace(',','')) == 0 else 'observed'
    except ValueError: return np.nan, 'unparsed'

def rows_from_file(path):
    raw = path.read_bytes()
    encoding = 'utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig'
    return raw, encoding, list(csv.reader(io.StringIO(raw.decode(encoding))))

def dump_json(path, obj):
    def convert(x):
        if isinstance(x, dict): return {str(k):convert(v) for k,v in x.items()}
        if isinstance(x, list): return [convert(v) for v in x]
        if isinstance(x,(np.integer,)):return int(x)
        if isinstance(x,(np.floating,float)):return None if not np.isfinite(x) else float(x)
        if pd.isna(x):return None
        return x
    path.write_text(json.dumps(convert(obj), ensure_ascii=False, indent=2), encoding='utf-8')

def main(source, out):
    out.mkdir(parents=True, exist_ok=True)
    logs=[];excluded=[];inventory=[];daily=[];posts=[];postmetrics=[];audience=[];dictionary=[]
    overlap=[];checks=[];period_rows=[];manual_status=[]
    def save(name, rows, columns=None):
        df = rows.copy() if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows)
        if columns and not len(df): df=pd.DataFrame(columns=columns)
        df.to_csv(out/name,index=False)
        return df
    def log(operation,n,why,table='',source_file=''):
        logs.append({'operation':operation,'records_affected':int(n),'reason':why,'table':table,'source_file':source_file})
    manifests=[]
    for platform in ACCOUNT_IDS:
        entries=json.loads((source/platform/'native/native_export_manifest.json').read_text())['native_files']
        manifests.extend((platform,e) for e in entries)
    verified_collabs = {r['post_id'] for r in json.loads((source/'Instagram/manual/instagram_collaboration_scope_verification.json').read_text())['records']}
    for platform,m in manifests:
        path=source/m['filename'];raw,enc,rows=rows_from_file(path)
        sourcefile=m['filename'];stamp=m.get('collection_timestamp',m.get('download_mtime_utc'))
        scope=m.get('metric_platform_scope',platform)
        base={'platform_selected':platform,'selected_account_id':ACCOUNT_IDS[platform],
              'account_handle':m.get('account_handle','redactedbandoh'), 'metric_platform_scope':scope,
              'source_file':sourcefile,'source_url':m.get('source_url'), 'snapshot_timestamp':stamp,
              'reporting_window_start':m.get('selected_start'), 'reporting_window_end':m.get('selected_end'),
              'reporting_timezone':m.get('reporting_timezone'),
              'snapshot_class':'collected_2026-10-22_supplement_not_original_baseline'}
        sha=hashlib.sha256(raw).hexdigest();expected=m.get('sha256')
        checks.append({'check':'native_sha256','source_file':sourcefile,'actual':sha,'expected':expected,'pass':sha==expected})
        if expected and sha!=expected: raise ValueError(f'Source hash mismatch: {path}')
        inv={**base,'account_name':m.get('account_name'),'bytes':len(raw),'sha256':sha,'encoding':enc,
             'grain':m.get('granularity'),'measurement_type':m.get('measurement_scope'),
             'source_data_rows':m.get('data_row_count'),'csv_records_including_header_preamble_and_blank':len(rows),
             'limitations':' | '.join(m.get('limitations',[])),
             'valid_rows':0,'quarantined_rows':0,'missing_calendar_dates':0}
        if '/90d/' in sourcefile or '/ytd/' in sourcefile:
            header_idx=next(i for i,r in enumerate(rows) if r==['Date','Primary'])
            metric=METRICS[rows[header_idx-1][0].lower()]
            found=[]
            for idx,r in enumerate(rows[header_idx+1:],header_idx+2):
                if not r:continue
                if len(r)!=2:
                    excluded.append({**base,'source_record':idx,'reason':'daily_row_width','raw_record_json':json.dumps(r)});continue
                try: date=pd.to_datetime(r[0],format='%Y-%m-%dT%H:%M:%S').date().isoformat()
                except Exception:
                    excluded.append({**base,'source_record':idx,'reason':'invalid_date','raw_record_json':json.dumps(r)});continue
                value,status=clean_number(r[1]);found.append(date)
                if value<0:status='negative_requires_review'
                daily.append({**base,'metric':metric,'date':date,'value':value,'value_raw':r[1],
                              'value_status':status,'source_record':idx,
                              'partial_day':date==m.get('partial_day_date'),
                              'activity_baseline_relation':'after_2026-10-20' if date>'2026-10-20' else 'through_2026-10-20',
                              'measurement_type':'daily_unique_count' if metric in NONADDITIVE else 'daily_interval_count'})
            missing=set(pd.date_range(m['selected_start'],m['selected_end']).strftime('%Y-%m-%d'))-set(found)
            inv.update(valid_rows=len(found),missing_calendar_dates=len(missing),metrics=metric,
                       dimensions='date',activity_start=min(found),activity_end=max(found))
            log('decode_and_parse_daily',len(found),'Strip export preamble; retain raw values, row numbers and snapshot',source_file=sourcefile)
            if missing:log('record_calendar_missingness',len(missing),'Dates absent from native export; values stay null',source_file=sourcefile)
        elif '/content_' in sourcefile or '/stories_' in sourcefile:
            header=rows[0];valid=0;quar=0
            for h in header:
                dictionary.append({'table':'post_metrics_all_snapshots','field':h,'source_file':sourcefile,
                                   'unit':'native field; units as named','definition':'Native '+h,
                                   'aggregation_rule':'Never sum across snapshots; do not sum unique people across posts or assign lifetime total to publication day',
                                   'caveat':'Retention/country/age breakdowns are components; use only compatible scope. Missing values are not zero.'})
            for idx,r in enumerate(rows[1:],2):
                if not r:continue
                if len(r)!=len(header):
                    quar+=1;excluded.append({**base,'source_record':idx,'reason':f'field_count_{len(r)}_expected_{len(header)}_alignment_unverified',
                                             'post_id':r[0] if r else '', 'raw_record_json':json.dumps(r,ensure_ascii=False)})
                    continue
                d=dict(zip(header,r));author=d.get('Account ID',d.get('Page ID'))
                try:
                    pub=pd.to_datetime(d['Publish time'],format='%m/%d/%Y %H:%M')
                    # Publication timestamps may be localized; daily aggregates are never shifted.
                    pubaware=pub.tz_localize('America/Los_Angeles',ambiguous='NaT',nonexistent='NaT')
                except Exception:
                    excluded.append({**base,'source_record':idx,'post_id':d.get('Post ID'),'reason':'invalid_publication_time','raw_record_json':json.dumps(r)});quar+=1;continue
                postid=d['Post ID'];valid+=1
                rec={**base,'source_record':idx,'post_id':postid,'author_account_id':author,
                     'author_username':d.get('Account username','redactedbandoh'), 'author_name':d.get('Account name',d.get('Page name')),
                     'author_scope':'band_authored' if author==ACCOUNT_IDS[platform] else ('verified_collaboration' if postid in verified_collabs else 'other_author_association_unverified'),
                     'published_local':pub.isoformat(),'publication_date':pub.date().isoformat(),
                     'published_utc':pubaware.tz_convert('UTC').isoformat() if not pd.isna(pubaware) else '',
                     'post_type':d['Post type'],'permalink':d['Permalink'],'description':d.get('Description',''),
                     'measurement_type':'lifetime_content_snapshot','native_scope':d['Date'],
                     'post_age_days':(pd.Timestamp(stamp).tz_convert('America/Los_Angeles')-pubaware).total_seconds()/86400 if not pd.isna(pubaware) else np.nan,
                     'snapshot_class':'newer_lifetime_snapshot_not_2026-10-20_activity'}
                mapping={'Views':'views','Reach':'reach','Likes':'likes','Reactions':'reactions','Comments':'comments','Shares':'shares','Saves':'saves','Follows':'follows',
                         'Duration (sec)':'duration_seconds','Reactions, Comments and Shares':'fb_interactions','Profile visits':'profile_visits',
                         'Replies':'replies','Navigation':'navigation','Sticker taps':'sticker_taps','Total clicks':'total_clicks',
                         'Views from Organic posts':'organic_views','Views from Boosted posts':'boosted_views'}
                for h,name in mapping.items():
                    value,status=clean_number(d[h]) if h in d else (np.nan,'metric_not_in_export')
                    rec[name]=value;rec[name+'_status']=status
                for h,v in d.items():
                    if h in META_FIELDS:continue
                    val,status=clean_number(v)
                    postmetrics.append({**base,'source_record':idx,'post_id':postid,'author_account_id':author,
                                        'metric_native':h,'value':val,'value_raw':v,'value_status':status,
                                        'measurement_type':'lifetime_content_snapshot'})
                if platform=='Instagram' and d['Post type']!='IG story':
                    rec['engagement_actions']=sum(rec[k] for k in ['likes','comments','shares','saves'])
                    rec['engagement_definition']='likes + comments + shares + saves'
                elif platform=='Facebook':
                    rec['engagement_actions']=rec['fb_interactions'];rec['engagement_definition']='reactions + comments + shares'
                else:rec['engagement_actions']=np.nan;rec['engagement_definition']='not calculated for Stories'
                rec['engagement_per_reach']=rec['engagement_actions']/rec['reach'] if rec['reach']>0 else np.nan
                posts.append(rec)
            pubdates=[r['publication_date'] for r in posts if r['source_file']==sourcefile]
            inv.update(valid_rows=valid,quarantined_rows=quar,metrics=' | '.join(header),dimensions='post ID, native author, publication time, post type',
                       activity_start=min(pubdates) if pubdates else '',activity_end=max(pubdates) if pubdates else '')
            if quar: log('quarantine_structural_rows',quar,'Header/record width mismatch; no padding or inferred alignment',source_file=sourcefile)
            log('parse_content_snapshot',valid,'Strict width and dates; IDs preserved as strings; lifetime totals separated from activity',source_file=sourcefile)
        elif '/audience/' in sourcefile:
            section=None;i=0;count=0
            while i<len(rows):
                r=rows[i]
                if r and len(r)==1 and r[0] in ('Top countries','Top cities','Age & gender','Follows'):section=r[0];i+=1;continue
                if section in ('Top countries','Top cities') and r and i+1<len(rows):
                    vals=rows[i+1]
                    for cat,v in zip(r,vals):
                        n,status=clean_number(v);audience.append({**base,'source_record':i+2,'dimension':section,'category':cat,'subgroup':'',
                            'value':n,'value_raw':v,'value_status':status,'unit':'percent','precision':'source_display_percentage',
                            'population':'followers_lifetime_labelled_snapshot','measurement_type':'snapshot_distribution_percentage'})
                        count+=1
                    i+=2;section=None;continue
                if section=='Age & gender' and len(r)==3 and r[0] and r[1]!='Men':
                    for sex,v in zip(['Men','Women'],r[1:]):
                        n,status=clean_number(v);audience.append({**base,'source_record':i+1,'dimension':'age_gender','category':r[0],
                            'subgroup':sex,'value':n,'value_raw':v,'value_status':status,'unit':'percent','precision':'source_display_percentage',
                            'population':'followers_lifetime_labelled_snapshot','measurement_type':'snapshot_distribution_percentage'});count+=1
                if section=='Follows' and len(r)==2 and r[0]!='Date':
                    value,status=clean_number(r[1]);date=pd.to_datetime(r[0],format='%Y-%m-%dT%H:%M:%S').date().isoformat()
                    daily.append({**base,'metric':'follows','date':date,'value':value,'value_raw':r[1],'value_status':status,
                                  'source_record':i+1,'partial_day':False,'activity_baseline_relation':'through_2026-10-20','measurement_type':'daily_interval_count'})
                i+=1
            follows_count=sum(1 for r in daily if r['source_file']==sourcefile)
            inv.update(valid_rows=count+follows_count,source_data_rows=np.nan,
                       metrics='follower distribution percentages; Facebook also daily Follows',dimensions='country/city/age/gender; date for Facebook Follows')
        inventory.append(inv)
    ds=save('account_daily_snapshots.csv',daily)
    keys=['platform_selected','selected_account_id','metric_platform_scope','metric','date']
    assert not ds.duplicated(keys+['source_file']).any()
    for key,g in ds.groupby(keys,dropna=False):
        if len(g)>1:
            overlap.append(dict(zip(keys,key))|{'snapshot_rows':len(g),'distinct_values':g.value.nunique(dropna=False),
                       'source_files':' | '.join(g.source_file),'values':' | '.join(g.value.astype(str)),
                       'conflict':g.value.nunique(dropna=False)>1})
    canonical=ds.sort_values(['snapshot_timestamp','source_file']).drop_duplicates(keys,keep='last').copy()
    log('choose_latest_daily_snapshot',len(ds)-len(canonical),'One row per selected account/scope/metric/date; all versions retained in snapshots','account_daily')
    for _,g in canonical.groupby(keys[:-1],dropna=False):
        span=pd.date_range('2026-01-01','2026-10-21').strftime('%Y-%m-%d');missing=set(span)-set(g.date)
        if missing:
            template=g.sort_values('snapshot_timestamp').iloc[-1].to_dict()
            added=[]
            for date in sorted(missing):
                added.append(template|{'date':date,'value':np.nan,'value_raw':'','value_status':'missing_date_in_native_export',
                    'source_record':np.nan,'partial_day':date=='2026-10-21',
                    'activity_baseline_relation':'after_2026-10-20' if date>'2026-10-20' else 'through_2026-10-20'})
            canonical=pd.concat([canonical,pd.DataFrame(added)],ignore_index=True)
            log('add_explicit_missing_calendar_rows',len(added),'Unobserved dates represented by null, not zero','account_daily',template['source_file'])
    canonical=canonical.sort_values(keys)
    assert not canonical.duplicated(keys).any()
    save('account_daily.csv',canonical)
    save('daily_overlap_audit.csv',overlap)
    ps=save('post_snapshots.csv',posts)
    pm=save('post_metrics_all_snapshots.csv',postmetrics)
    pk=['platform_selected','post_id']
    assert not ps.duplicated(pk+['source_file']).any()
    postlatest=ps.sort_values(['snapshot_timestamp','source_file']).drop_duplicates(pk,keep='last')
    log('choose_latest_valid_post_snapshot',len(ps)-len(postlatest),'Keep all snapshot rows; one latest valid record per platform/post ID','posts_latest')
    save('posts_latest.csv',postlatest)
    # Reconcile overlapping post snapshots on shared comparable fields, without interpreting elapsed minutes as growth.
    postoverlap=[]
    for key,g in ps.groupby(pk):
        if len(g)>1:
            for field in ['views','reach','engagement_actions','likes','shares','comments','saves','follows']:
                gg=g[g[field].notna()]
                if len(gg)>1:
                    postoverlap.append(dict(zip(pk,key))|{'metric':field,'snapshots':len(gg),'distinct_values':gg[field].nunique(),
                        'values':' | '.join(gg[field].astype(str)),'conflict':gg[field].nunique()>1})
    save('post_overlap_audit.csv',postoverlap)
    save('audience_snapshots.csv',audience)
    # Manual period and follower observations remain distinct from daily facts and lifetime posts.
    for path in sorted(source.rglob('*.json')):
        if '/native/' in str(path):continue
        obj=json.loads(path.read_text());rel=str(path.relative_to(source))
        if not isinstance(obj,dict):continue
        manual_status.append({'source_file':rel,'status':obj.get('status'),'platform':obj.get('platform',obj.get('platform_selected')),
                              'source_url':obj.get('source_url'),'limitations':' | '.join(obj.get('limitations',[]))})
        if 'records' not in obj or not any('metric_name' in r for r in obj['records'] if isinstance(r,dict)):continue
        for idx,r in enumerate(obj['records']):
            if not isinstance(r,dict) or 'metric_name' not in r:continue
            p=obj.get('platform',obj.get('platform_selected'))
            scope=r.get('metric_platform_scope',p);name=METRICS.get(r['metric_name'].lower(),r['metric_name'].lower())
            period_rows.append({'platform_selected':p,'metric_platform_scope':scope,'metric':name,
                'value':r.get('numeric_value'),'value_raw':r.get('value_display',r.get('display_value')),
                'value_status':r.get('value_status','observed' if r.get('numeric_value') is not None else 'not_numeric'),
                'reporting_window_start':obj.get('start',obj.get('selected_start')),
                'reporting_window_end':obj.get('end',obj.get('selected_end')),
                'snapshot_timestamp':obj.get('collected_at',obj.get('collection_timestamp')),
                'snapshot_timestamp_interval':json.dumps(obj.get('collection_timestamp_interval_utc')),
                'reporting_timezone':obj.get('reporting_timezone'),
                'measurement_type':r.get('measurement_scope',r.get('scope',r.get('period_label'))),
                'section':r.get('section'),'source_file':rel,'source_record':idx+1,'source_url':obj.get('source_url'),
                'notes':r.get('notes'),'limitations':' | '.join(obj.get('limitations',[])),
                'snapshot_class':'newer_manual_snapshot_preserved_separately'})
    manual=save('manual_period_and_current_snapshots.csv',period_rows)
    save('manual_access_inventory.csv',manual_status)
    # Descriptive non-overlapping windows. Period totals only for additive measures.
    windows={'ytd_complete':('2026-01-01','2026-10-20'),'latest90':('2026-07-23','2026-10-20'),
             'prior90':('2026-04-24','2026-07-22'),'latest28':('2026-09-23','2026-10-20'),
             'prior28':('2026-08-26','2026-09-22')}
    summaries=[]
    for key,g in canonical.groupby(['platform_selected','metric_platform_scope','metric']):
        for label,(start,end) in windows.items():
            q=g[(g.date>=start)&(g.date<=end)];x=q.value.dropna();add=key[-1] not in NONADDITIVE
            summaries.append(dict(zip(['platform_selected','metric_platform_scope','metric'],key))|
                {'window':label,'start_date':start,'end_date':end,'calendar_days':len(q),'observed_days':len(x),'missing_days':q.value.isna().sum(),
                 'observed_value_sum':x.sum() if len(x) else np.nan,
                 'period_total':x.sum() if add and not q.value.isna().any() else np.nan,
                 'sum_interpretation':'interval activity' if add else 'person-days, not unique period people',
                 'median_daily':x.median(),'mean_daily':x.mean(),'p90_daily':x.quantile(.9),
                 'daily_summary_population':'observed dates only; missing dates excluded, never zero-filled',
                 'maximum_daily':x.max(),'zero_days':int((x==0).sum()),
                 'top_day_share_of_observed_sum':x.max()/x.sum() if x.sum()>0 and add else np.nan})
    summary=save('account_period_summary.csv',summaries)
    comparisons=[]
    for key,g in summary.groupby(['platform_selected','metric_platform_scope','metric']):
        gg=g.set_index('window')
        for a,b in [('latest90','prior90'),('latest28','prior28')]:
            va=gg.loc[a,'period_total'];vb=gg.loc[b,'period_total']
            comparisons.append(dict(zip(['platform_selected','metric_platform_scope','metric'],key))|
                {'current_window':a,'previous_window':b,'current_total':va,'previous_total':vb,
                 'current_start':windows[a][0],'current_end':windows[a][1],
                 'previous_start':windows[b][0],'previous_end':windows[b][1],
                 'current_calendar_days':gg.loc[a,'calendar_days'],'current_observed_days':gg.loc[a,'observed_days'],
                 'previous_calendar_days':gg.loc[b,'calendar_days'],'previous_observed_days':gg.loc[b,'observed_days'],
                 'absolute_change':va-vb,'percent_change':(va/vb-1)*100 if vb>0 else np.nan,
                 'current_median_daily':gg.loc[a,'median_daily'],'previous_median_daily':gg.loc[b,'median_daily'],
                 'method':'descriptive exact observed totals; no sampling inference','ci_low':np.nan,'ci_high':np.nan,'p_value':np.nan,'adjusted_p_value':np.nan,
                 'limitations':'Dates are dependent; no causal attribution. Daily medians use observed dates only. Missing follows/unique people do not receive interval totals.'})
    comp=save('account_period_comparisons.csv',comparisons)
    months=[]
    for key,g in canonical.groupby(['platform_selected','metric_platform_scope','metric']):
        for month,q in g[g.date<='2026-10-20'].groupby(g.date.str[:7]):
            x=q.value.dropna();date=pd.Timestamp(month+'-01');complete=len(q)==date.days_in_month
            months.append(dict(zip(['platform_selected','metric_platform_scope','metric'],key))|{'month':month,'observed_days':len(x),
                'calendar_days':len(q),'complete_calendar_month':complete,'missing_days':q.value.isna().sum(),
                'period_total':x.sum() if key[-1] not in NONADDITIVE and not q.value.isna().any() else np.nan,
                'median_daily':x.median(),'maximum_daily':x.max()})
    monthly=save('account_monthly.csv',months)
    # Content distributions are snapshots at unequal ages, not exposure-adjusted effects.
    content_summary=[]
    for key,g in postlatest.groupby(['platform_selected','post_type','author_scope']):
        complete=g[g.engagement_actions.notna() & (g.reach>0)]
        content_summary.append(dict(zip(['platform_selected','post_type','author_scope'],key))|{'posts':len(g),
            'median_age_days':g.post_age_days.median(),'min_age_days':g.post_age_days.min(),'max_age_days':g.post_age_days.max(),
            'median_views':g.views.median(),'median_reach':g.reach.median(),'median_engagement_actions':g.engagement_actions.median(),
            'sum_lifetime_views':g.views.sum(min_count=1),'sum_post_reach_not_unique_audience':g.reach.sum(min_count=1),
            'aggregate_engagement_per_post_reach':complete.engagement_actions.sum()/complete.reach.sum() if len(complete) and complete.reach.sum()>0 else np.nan,
            'median_post_engagement_per_reach':g.engagement_per_reach.median(),'rate_eligible_posts':len(complete),
            'caveat':'Lifetime snapshots at different ages. Format, author, time and paid activity confounded; post reach sums are not unique audience.'})
    cs=save('content_format_summary.csv',content_summary)
    publication=postlatest.assign(month=postlatest.publication_date.str[:7]).groupby(['platform_selected','post_type','author_scope','month']).size().rename('published_posts').reset_index()
    save('publication_counts.csv',publication)
    publication_periods=[]
    feeds=postlatest[postlatest.post_type!='IG story']
    for (platform,author),g in feeds.groupby(['platform_selected','author_scope']):
        for label,start,end in [('Jan-May','2026-01-01','2026-05-31'),('Jun-Oct20','2026-06-01','2026-10-20')]:
            q=g[(g.publication_date>=start)&(g.publication_date<=end)]
            days=(pd.Timestamp(end)-pd.Timestamp(start)).days+1
            publication_periods.append({'platform_selected':platform,'author_scope':author,'period':label,'start_date':start,'end_date':end,
                'calendar_days':days,'published_feed_posts_in_export':len(q),'posts_per_30_days':len(q)/days*30,
                'source_files':' | '.join(sorted(g.source_file.unique())),
                'filter':'posts_latest; post_type != IG story; publication_date within inclusive bounds; platform and author scope as shown',
                'caveat':'Counts describe retained exported feed inventory, not all content ever published; deleted or omitted items are not recoverable. Stories excluded due to structural missingness. No engagement assigned to publication day.'})
    pubsummary=save('publication_period_summary.csv',publication_periods)
    top=postlatest[postlatest.post_type!='IG story'].sort_values(['platform_selected','views'],ascending=[True,False]).groupby('platform_selected').head(10)
    save('top_posts_by_lifetime_views.csv',top)
    # Native source vs manual UI totals, only where additive and scope match.
    reconciliation=[]
    for _,r in manual.iterrows():
        if r.metric in NONADDITIVE or not r.reporting_window_start or pd.isna(r.reporting_window_start):continue
        q=canonical[(canonical.platform_selected==r.platform_selected)&(canonical.metric_platform_scope==r.metric_platform_scope)&
                    (canonical.metric==r.metric)&(canonical.date>=r.reporting_window_start)&(canonical.date<=r.reporting_window_end)]
        if q.empty:continue
        total=q.value.sum(min_count=1)
        reconciliation.append({'source_file':r.source_file,'platform_selected':r.platform_selected,'metric':r.metric,
            'metric_platform_scope':r.metric_platform_scope,'start_date':r.reporting_window_start,'end_date':r.reporting_window_end,
            'manual_value':r.value,'manual_display':r.value_raw,'daily_observed_sum':total,'missing_days':q.value.isna().sum(),
            'difference':total-r.value if pd.notna(r.value) else np.nan,
            'comparison_status':'rounded_display_no_exact_reconciliation' if pd.isna(r.value) else ('observed_dates_sum_only' if q.value.isna().any() else 'exact_scope_match')})
    recon=save('manual_daily_reconciliation.csv',reconciliation)
    # Explicit combined-view component reconciliation. Components cannot reconstruct an IG-only daily series.
    for start,end in [('2026-01-01','2026-10-21'),('2026-07-23','2026-10-20')]:
        q=manual[(manual.platform_selected=='Instagram')&(manual.metric=='views')&(manual.section=='Views platform breakdown')&(manual.reporting_window_start==start)]
        d=canonical[(canonical.platform_selected=='Instagram')&(canonical.metric=='views')&(canonical.date>=start)&(canonical.date<=end)]
        checks.append({'check':'combined_view_components','source_file':'Instagram manual Results breakdown vs native Views',
                       'actual':d.value.sum(),'expected':q.value.sum(),'pass':d.value.sum()==q.value.sum()})
    log('exclude_partial_day_from_comparisons',int((canonical.date=='2026-10-21').sum()),'October 21 still current Pacific day at collection; retained in clean data, excluded from complete-period results','account_period_summary')
    log('aggregate_comparable_daily_windows',len(summaries),'Five documented windows; additive complete sums only, daily unique summaries never period unique totals','account_period_summary')
    log('aggregate_calendar_months',len(months),'October flagged incomplete; missing follows cannot yield complete-period sums','account_monthly')
    log('summarize_content_groups',len(content_summary),'Lifetime snapshots grouped by native format and author scope; no same-age causal comparison','content_format_summary')
    log('aggregate_publication_events',len(publication),'Count unique valid post IDs by publication month; no lifetime metrics assigned to publication dates','publication_counts')
    log('compare_publication_frequency',len(publication_periods),'Jan-May151 days vs Jun-Oct20 142 days; feed-only retained export inventory, distinct author scope','publication_period_summary')
    save('source_inventory.csv',inventory);save('cleaning_log.csv',logs)
    save('excluded_records.csv',excluded,['source_file','source_record','reason','raw_record_json'])
    save('validation_checks.csv',checks)
    # Core dictionary supplements exact native field catalogue.
    for metric in sorted(set(canonical.metric)):
        dictionary.append({'table':'account_daily','field':metric,'unit':'count',
            'definition':{'reach':'Distinct Instagram accounts reached within each source day','viewers':'Facebook viewers within each source day',
                          'views':'Native views; Instagram-selected Results Views scope is Facebook+Instagram combined',
                          'interactions':'Native content interactions','visits':'Native Page/profile visits','link_clicks':'Native platform-recorded link clicks, destinations not provided',
                          'follows':'Native follows event count on observed days; not net follower change'}[metric],
            'aggregation_rule':'Do not sum to period unique people; daily descriptive summaries only' if metric in NONADDITIVE else 'Sum complete non-overlapping dates at matching account/metric scope',
            'caveat':'Pacific reporting day; unavailable dates null; October 21 partial. Metric-specific platform scope must remain visible.'})
    for field,definition,unit,rule in [
        ('engagement_actions','Instagram posts: likes+comments+shares+saves. Facebook: reactions+comments+shares. No Story ratio.','actions','Sum only posts in one snapshot, never across snapshots'),
        ('engagement_per_reach','Post engagement_actions / same-post reach; NaN for missing/zero denominator','ratio','Aggregate ratio is sum(actions)/sum(post reach) over the same eligible posts; distinct from median post ratio'),
        ('post_age_days','Elapsed time from observed publish timestamp to source download timestamp','days','Descriptive covariate; not a constant-age performance window'),
        ('value_status','Observed, zero, blank, omitted date, source-unavailable, or other explicit state','category','Never convert missing states to zero'),
        ('snapshot_timestamp','Source retrieval/download UTC time, not activity date','ISO8601 UTC','Keep distinct from publication and reporting dates'),
        ('selected_account_id','Verified band account selected in UI; Facebook Page100091779409539 or Instagram17841454335424545','string identifier','Join one selected account per platform; never replace with original author ID'),
        ('author_account_id','Native original-author account on each post; may differ for collaborations','string identifier','Do not merge distinct authors or treat their full accounts as band accounts'),
        ('post_id','Native content identifier, kept as text to preserve precision','string identifier','Canonical key platform_selected + post_id; raw snapshot key also includes source_file'),
        ('platform_selected','Platform filter selected in Meta export UI','category','Does not alone establish actual metric scope'),
        ('metric_platform_scope','Actual platform population measured by the exported metric','category','Must match before aggregation; Instagram-selected Results Views are combined Facebook and Instagram'),
        ('date','Native daily activity calendar date on Pacific reporting basis','YYYY-MM-DD','Do not shift aggregated daily bins to UTC'),
        ('reporting_window_start/end','Date selector defining export inclusion; for posts this selects publication dates, not engagement accumulation dates','YYYY-MM-DD inclusive','Retain separate from activity date and source retrieval time'),
        ('publication_date/published_local','Native content publication date/time; Pacific interpretation documented by source UI','YYYY-MM-DD / ISO8601 local','Counts can describe publishing events; lifetime metrics must not be assigned to these dates'),
        ('published_utc','Publication instant converted from America/Los_Angeles where unambiguous','ISO8601 UTC','Event timestamp conversion only; never use to shift aggregate daily metrics'),
        ('partial_day','True on Oct21 account-day records because collection preceded Pacific midnight','boolean','Exclude from comparisons requiring complete periods'),
        ('activity_baseline_relation','Whether native activity is through or after the preserved Oct20 reporting cutoff','category','Does not change retrieval date or make later snapshots original-baseline data'),
        ('snapshot_class','Labels collected social supplements or newer lifetime snapshots distinctly from original Spotify baseline','category','Do not overwrite the original baseline'),
        ('value/value_raw','Parsed numeric value and unmodified native display token','native units / string','Numeric blank for omitted, rounded, invalid or unavailable values; explicit zero retained'),
        ('source_file/source_record','Relative raw input file and 1-based CSV record number including headers/preamble','string / integer','Use to trace each canonical value; missing generated dates have no source record'),
        ('author_scope','band_authored, independently verified collaboration, or other-author association unverified','category','Keep populations separate in format comparisons'),
        ('median_daily/current_median_daily','Median across observed dates only, excluding missing native dates','native units','IG follows median is conditional on recorded days; it is not a full-calendar median')]:
        dictionary.append({'table':'shared/post tables','field':field,'definition':definition,'unit':unit,'aggregation_rule':rule,'caveat':'No person-level conversion or attribution'})
    save('data_dictionary.csv',dictionary)
    readiness=[
        {'question':'FB/IG account activity trend','status':'Supported descriptively','unit':'account-day','period':'2026-01-01 to 2026-10-20',
         'usable_observations':'293 dates per metric except IG follows','missingness':'IG follows 128 missing dates across Jan1-Oct21; all missing dates explicitly null',
         'dependence':'Daily observations temporally dependent; no independent-sample significance tests','smallest_additional_data':'Daily paid/organic split and documented events for explanations'},
        {'question':'Unique period social audience','status':'Exploratory','unit':'period unique','period':'Selected 90-day UI windows',
         'usable_observations':'One recent 90-day UI total per platform; IG reach rounded','missingness':'No exact multi-period unique reach series',
         'dependence':'Daily unique reach is not additive','smallest_additional_data':'Native period unique audience exports for matched windows'},
        {'question':'Which post format performs better','status':'Exploratory','unit':'post lifetime snapshot','period':'Posts published 2026, captured Oct22 UTC',
         'usable_observations':str(len(postlatest[postlatest.post_type!='IG story']))+' posts; '+str(len(postlatest[postlatest.post_type=='IG story']))+' valid Stories',
         'missingness':'183 malformed Story rows quarantined; author verification incomplete for 10 other-author posts',
         'dependence':'Different ages, repeat audiences, common campaigns and release timing; no causal format effect',
         'smallest_additional_data':'Snapshot each post at 24h and 7 complete days; format, subject, paid exposure and song ID'},
        {'question':'TikTok performance','status':'Blocked','unit':'unavailable','period':'none','usable_observations':'0','missingness':'No analytics collected and account unverified',
         'dependence':'Not assessable','smallest_additional_data':'Authenticated TikTok daily and post exports, identity and timezone'},
        {'question':'Attributable streaming conversion','status':'Blocked','unit':'attributed journey','period':'none','usable_observations':'0','missingness':'Link destinations, campaign IDs and streaming attribution missing',
         'dependence':'Aggregate platform activity cannot match people','smallest_additional_data':'Tagged smart-link campaigns and attributed streaming outcomes where available'},
        {'question':'Same-age first-seven-day post outcomes','status':'Blocked','unit':'post age-window','period':'none','usable_observations':'0','missingness':'Only lifetime snapshots',
         'dependence':'Unequal post age cannot be repaired by assigning lifetime totals to publication dates','smallest_additional_data':'Fixed-age repeated post snapshots or daily per-post activity'}]
    save('analysis_readiness.csv',readiness)
    stats=[]
    for _,r in comp.iterrows():
        stats.append({'question':'How did '+r.metric+' change?','platform':r.platform_selected,'metric_scope':r.metric_platform_scope,
            'comparison':r.current_window+' vs '+r.previous_window,'unit':'account-day','method':r.method,
            'current_start':r.current_start,'current_end':r.current_end,'previous_start':r.previous_start,'previous_end':r.previous_end,
            'current_observed_days':r.current_observed_days,'previous_observed_days':r.previous_observed_days,
            'current_calendar_days':r.current_calendar_days,'previous_calendar_days':r.previous_calendar_days,
            'current_value':r.current_total,'previous_value':r.previous_total,
            'current_median_observed_day':r.current_median_daily,'previous_median_observed_day':r.previous_median_daily,
            'analysis_row_filter':f'account_daily: platform_selected={r.platform_selected}; metric_platform_scope={r.metric_platform_scope}; metric={r.metric}; dates between each listed start/end inclusive; partial_day=False',
            'source_files':' | '.join(sorted(set(canonical[(canonical.platform_selected==r.platform_selected)&(canonical.metric==r.metric)].source_file))),
            'source_url':' | '.join(sorted(set(canonical[(canonical.platform_selected==r.platform_selected)&(canonical.metric==r.metric)].source_url.dropna()))),
            'effect_absolute':r.absolute_change,'effect_percent':r.percent_change,'ci_low':np.nan,'ci_high':np.nan,
            'p_value':np.nan,'adjusted_p_value':np.nan,'status':'Supported descriptive' if pd.notna(r.current_total) else 'Exploratory daily summaries only',
            'limitations':r.limitations})
    save('statistical_results.csv',stats)
    quality={'native_files':len(inventory),'native_hash_checks_passed':sum(c['pass'] for c in checks if c['check']=='native_sha256'),
             'daily_snapshot_rows':len(ds),'canonical_calendar_rows':len(canonical),'missing_canonical_values':int(canonical.value.isna().sum()),
             'daily_overlap_groups':len(overlap),'daily_overlap_conflicts':sum(x['conflict'] for x in overlap),
             'valid_post_snapshot_rows':len(ps),'canonical_post_rows':len(postlatest),'quarantined_rows':len(excluded),
             'post_overlap_value_conflicts':sum(x['conflict'] for x in postoverlap),'negative_daily_values':int((canonical.value<0).sum()),
             'identities':json.loads((source/'meta_account_identity_evidence.json').read_text()),
             'tiktok_data_rows':0,'raw_inputs_unchanged':True,
             'notes':['Canonical source dates retained in Pacific time; no synthetic UTC re-binning.',
                      'All 183 short Story records quarantined; valid rows remain a selected subset, not all Stories.',
                      'IG-selected daily Views is a combined-platform measure; period components retained separately.',
                      'Missing Instagram Follows dates are not zero even if observed sums match a UI period total.',
                      'Lifetime post performance excludes malformed records and retains native author IDs. No guessed song/topic mapping.']}
    dump_json(out/'data_quality.json',quality)
    findings={'quality':quality,'latest90_vs_prior90':comp[comp.current_window=='latest90'].to_dict('records'),
              'content_formats':cs.to_dict('records'),'latest90':summary[summary.window=='latest90'].to_dict('records'),
              'top_posts':top[['platform_selected','post_id','author_scope','post_type','publication_date','views','reach','engagement_actions','engagement_per_reach','permalink','description']].to_dict('records'),
              'manual_snapshots':manual.to_dict('records'),'monthly':monthly.to_dict('records'),
              'publication_periods':pubsummary.to_dict('records')}
    dump_json(out/'findings.json',findings)
    # Charts express account-day activity, never sum unique reach or lifetime outcomes by publication date.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(2,1,figsize=(11,6),sharex=True,layout='constrained')
    for ax,metric in zip(axes,['interactions','visits']):
        for platform,color in [('Instagram','#7c3aed'),('Facebook','#147d92')]:
            q=canonical[(canonical.platform_selected==platform)&(canonical.metric==metric)&(canonical.date<='2026-10-20')]
            ax.plot(pd.to_datetime(q.date),q.value.rolling(7,min_periods=7).mean(),label=platform,color=color)
        ax.set_ylabel('Daily '+metric+'\n7-day mean');ax.grid(axis='y',alpha=.2);ax.legend(frameon=False)
    fig.suptitle('Social activity is concentrated earlier in 2026',fontsize=16,weight='bold')
    axes[-1].set_xlabel('Native Pacific reporting dates · Jan 1–Oct 20, 2026 · smoothing is descriptive')
    fig.savefig(out/'social_activity.png',dpi=170);plt.close(fig)
    print(json.dumps({k:v for k,v in quality.items() if k not in ['identities','notes']},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=ROOT/'raw/meta');p.add_argument('--output',type=Path,default=ROOT/'social')
    a=p.parse_args();main(a.source,a.output)
