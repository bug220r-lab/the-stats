"""Rebuild and audit Spotify analytical tables from preserved captures; no API calls."""
from pathlib import Path
import argparse, hashlib, json, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ARTIST='6X14XfGTmB560PF063wXDk'
BASELINE='2026-10-20'
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[1]/'raw/spotify_baseline');p.add_argument('--supplement',type=Path,default=Path(__file__).resolve().parents[1]/'raw/spotify_supplement');p.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'spotify');args=p.parse_args()
S=args.source; U=args.supplement; O=args.out; C=O/'cleaned'; C.mkdir(parents=True,exist_ok=True);(O/'charts').mkdir(exist_ok=True)
logs=[];issues=[];checks=[];excluded=[]
def save(d,name):
 d.to_csv(C/name,index=False)
def log(action,affected,why):logs.append(dict(action=action,records_affected=int(affected),reason=why))
def check(name,passed,details):checks.append(dict(check=name,passed=bool(passed),details=str(details)))
def issue(severity,title,details,action):issues.append(dict(severity=severity,title=title,details=details,action=action))
def normalized(n):return pd.read_csv(S/'normalized'/f'{n}.csv',keep_default_na=True)
def meta(d,source,status='original_baseline',retrieved='2026-10-22'):
 d=d.copy();
 if 'source_file' in d:d=d.rename(columns={'source_file':'evidence_source_file'})
 d['artist_id']=ARTIST;d['source_file']=source;d['source_row']=np.arange(2,len(d)+2);d['reporting_timezone']='UTC';d['retrieved_at']=retrieved;d['retrieval_precision']='date';d['snapshot_class']=status;d['baseline_endpoint']=BASELINE;return d
# This plan is written before any numerical findings or correlations are inspected.
plan='''# Spotify analysis plan\n\nRecorded before this script computes results. Preserve the Oct 20 activity endpoint and the Oct 22 collection vintage; late-collected supplemental baseline observations remain a separate vintage.\n\n1. Describe artist additive totals in latest 7/28/90 days, matched preceding windows, and matched Jan 1–Oct 20 year-to-date windows. Use period UI unique listeners only, never daily sums. Compare follower stocks and net changes.\n2. Rank track contributions over latest 28 days and prior 28; calculate top-one/top-three share, HHI, numbers of growing/falling tracks, and contribution to artist net change, only with complete daily coverage.\n3. Compare original-release first 7/28/90 days only when all days are observed. No significance test across different releases: release cohort, song identity, catalog size, promotion and calendar are confounded.\n4. Inspect top daily spikes, median daily activity, and concentration; retain spikes. Sensitivity: compare 28, 90 and matched YTD windows and remove the largest single day from each paired 28-day window as an explicitly exploratory diagnostic.\n5. Describe period unique-listener, source and geography measures with compatible windows. Do not sum hierarchical sources or unique people.\n\nCounts are the observed platform population in fixed windows, so descriptive period changes receive no sampling confidence intervals/p-values. This work does not estimate a causal treatment effect. Source inconsistencies and incomplete song histories are explicit limitations. Cross-platform correlation testing is owned by the separate planned cross-platform script.\n'''
(O/'analysis_plan.md').write_text(plan)
# Byte inventory and preservation checks.
files=[]
for package,root in [('original',S),('supplement',U)]:
 for f in sorted(root.rglob('*')):
  if not f.is_file():continue
  n=None;cols='';start=end='';missing='';grain='evidence/artifact';metrics='';dimensions=''
  if f.suffix=='.csv':
   try:
    d=pd.read_csv(f);n=len(d);cols='|'.join(d.columns);missing=int(d.isna().sum().sum())
    for col in ['date','Date','start_date','period_start','Period start','Window start']:
     if col in d:
      dt=pd.to_datetime(d[col],errors='coerce');start=str(dt.min().date()) if dt.notna().any() else '';break
    for col in ['date','Date','end_date','period_end','Period end','Window end']:
     if col in d:
      dt=pd.to_datetime(d[col],errors='coerce');end=str(dt.max().date()) if dt.notna().any() else '';break
    if 'song_id' in d and 'date' in d and 'metric' in d:grain='recording-day-metric'
    elif 'song_id' in d and 'period' in d:grain='recording-period; inspect metric column'
    elif 'date' in d:grain='date plus dimensions in schema; do not assume one account-day'
    elif 'period' in d:grain='period plus dimensions'
    metrics='|'.join(str(x) for x in d['metric'].unique()) if 'metric' in d else ''
    dimensions='|'.join(x for x in ['song_id','release_id','country','city','segment','period','source'] if x in d)
   except Exception as e:missing='parse failed: '+type(e).__name__
  files.append(dict(package=package,platform='Spotify',account_name='[REDACTED]',account_id=ARTIST,file=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),rows=n,columns=cols,activity_start=start,activity_end=end,reporting_timezone='UTC' if f.suffix=='.csv' else 'see source',retrieval_date='2026-10-22' if package=='original' else '2026-10-23 UTC / 2026-10-22 Eastern',grain=grain,metrics=metrics,dimensions=dimensions,missing_cells=missing,source_link='https://drive.google.com/file/d/1T7ZsJq-iyR3IMoc4hQOqXnzOdTidtbJx/view' if package=='original' else 'https://drive.google.com/file/d/1l-We_MiUPK7nbXDO955kKwR_f_K7qb0F/view',limitation='Original archive may contain redundant analyses and overlapping capture windows; analytical tables selected below.'))
pd.DataFrame(files).to_csv(O/'source_file_inventory.csv',index=False)
m=pd.read_csv(S/'file_manifest.csv');bad=[]
for r in m.itertuples():
 f=S/r.path
 if f.exists() and hashlib.sha256(f.read_bytes()).hexdigest()!=r.sha256:bad.append(r.path)
check('original_archive_manifest_hashes',not bad,f'{len(m)} manifest entries; {len(bad)} mismatches')
# Artist baseline native source.
raw='raw/artist_timeline_2024-01-01_2026-10-20.csv';a=pd.read_csv(S/raw)
check('artist_native_vs_previous_normalized',a.equals(normalized('artist_daily')),f'{len(a)} rows compared')
assert a['date'].is_unique and pd.to_datetime(a.date).diff().dropna().eq(pd.Timedelta(days=1)).all()
assert a.drop(columns='date').notna().all().all() and a.drop(columns='date').ge(0).all().all()
a=a.rename(columns={'streams':'daily_streams','listeners':'daily_listeners','saves':'daily_saves','playlist adds':'daily_playlist_adds','followers':'followers_stock','monthly listeners':'rolling28_listeners','monthly active listeners':'rolling28_active_listeners','super listeners':'rolling28_super_listeners'})
a=meta(a,raw);a['activity_date']=a.date;a['period_start']=a.date;a['period_end']=a.date
# Keep rolling windows explicit through dictionary; not converted to interval counts.
a['rolling_window_start']=(pd.to_datetime(a.date)-pd.Timedelta(days=27)).dt.strftime('%Y-%m-%d');a['rolling_window_end']=a.date;a['stock_as_of_date']=a.date;a['daily_period_scope']='period_start/end apply only to daily_* measures';a['follower_net_change']=a.followers_stock.diff();a['value_status']='observed';save(a,'artist_daily.csv')
log('Column names normalized and native artist date/row lineage retained',len(a),'No values imputed; follower difference labelled net change.')
check('artist_unique_contiguous_nonnegative',True,f'{len(a)} dates {a.date.min()}–{a.date.max()}')
# Rebuild every selected song metric directly from original native/chart evidence.
old=normalized('song_daily_long');rows=[]
metric_labels={'Streams':'streams','Listeners':'listeners','Playlist Adds':'playlist_adds','Playlist adds':'playlist_adds','Saves':'saves','Streams / Listener':'streams_per_listener'}
for (sid,metric,source,origin),g in old.groupby(['song_id','metric','source','origin'],sort=False):
 if origin=='native_export':
  d=pd.read_csv(S/'raw'/source)
  seq=[(r.date,float(r.streams),str(r.streams),i+2) for i,r in enumerate(d.itertuples())]
 else:
  labels=json.loads((S/'captured'/source).read_text());seq=[]
  for i,label in enumerate(labels):
   match=re.match(r'^([A-Za-z]{3} \d{1,2}, \d{4}), ([\d,.]+) (.+)$',label)
   if not match:raise ValueError(f'Unparseable label {source}:{i+1}: {label}')
   dt=pd.to_datetime(match[1],format='%b %d, %Y').strftime('%Y-%m-%d');val=float(match[2].replace(',',''))
   assert metric_labels[match[3]]==metric,(source,match[3],metric)
   seq.append((dt,val,match[2],i+1))
 wanted=set(g.date)
 for dt,val,reported,pos in seq:
  if dt in wanted:rows.append(dict(song_id=sid,date=dt,metric=metric,value=val,reported_value=reported,precision='displayed_3_decimal_or_less' if metric=='streams_per_listener' else 'integer',source_file=('raw/' if origin=='native_export' else 'captured/')+source,source_row=pos,source_row_type='csv_line' if origin=='native_export' else 'json_array_1based',origin=origin))
song=pd.DataFrame(rows)
check('song_source_values_match_prior_normalization',len(song)==len(old),len(song))
merged=song.merge(old,on=['song_id','date','metric'],validate='one_to_one',suffixes=('','_old'))
assert np.allclose(merged.value,merged.value_old,rtol=0,atol=1e-9)
check('all_song_values_verified_against_raw_capture',True,f'{len(song)} rows; exact numeric values, one-to-one keys')
cat=normalized('song_catalog');cat['title']=cat.title.str.strip();cat['recording_label']=cat.recording_label.str.strip();cat=meta(cat,'normalized/song_catalog.csv');save(cat,'recordings.csv')
# Join labels is many-to-one and cannot inflate fact rows.
song=song.merge(cat[['song_id','recording_label','first_released']],on='song_id',validate='many_to_one');assert len(song)==len(old)
song['artist_id']=ARTIST;song['reporting_timezone']='UTC';song['retrieved_at']='2026-10-22';song['retrieval_precision']='date';song['snapshot_class']='original_baseline';song['baseline_endpoint']=BASELINE;song['activity_date']=song.date;song['period_start']=song.date;song['period_end']=song.date;song['value_status']='observed'
# Source ratios reported as zero with zero listeners are not a meaningful zero ratio.
lis=song[song.metric.eq('listeners')][['song_id','date','value']].rename(columns={'value':'listener_denominator'})
song=song.merge(lis,on=['song_id','date'],how='left',validate='many_to_one')
undef=song.metric.eq('streams_per_listener') & song.listener_denominator.eq(0)
song.loc[undef,'value_status']='undefined_zero_denominator_reported_zero'
log('Preserved reported zero ratios but marked undefined denominator',undef.sum(),'No ratio should be interpreted when daily listeners equal zero.')
save(song,'track_daily_long.csv')
coverage=song.groupby(['song_id','recording_label','metric']).agg(observed_days=('date','nunique'),activity_start=('date','min'),activity_end=('date','max')).reset_index();coverage['expected_history_days']=1024;coverage['missing_dates_in_history']=1024-coverage.observed_days
allkeys=pd.MultiIndex.from_product([cat.song_id,sorted(old.metric.unique())],names=['song_id','metric']).to_frame(index=False);coverage=allkeys.merge(coverage,on=['song_id','metric'],how='left',validate='one_to_one');coverage['observed_days']=coverage.observed_days.fillna(0).astype(int);coverage['missing_dates_in_history']=1024-coverage.observed_days;coverage['complete']=coverage.observed_days.eq(1024);save(coverage,'track_coverage.csv')
# More period-level and dimension-level source tables, kept separate by grain.
keep=['artist_period_dashboard','song_period_canonical','song_alltime_counters','release_metadata','release_periods','audience_segment_snapshot','audience_active_subsegments','audience_top_countries','audience_demographics_age','audience_demographics_age_gender','audience_demographics_gender','audience_top_cities','artist_sources_28day','song_sources','song_locations','song_playlists','artist_playlists']
for n in keep:
 f=S/'normalized'/f'{n}.csv'
 if f.exists():
  d=meta(normalized(n),'normalized/'+n+'.csv');save(d,n+'.csv')
events=meta(normalized('release_metadata')[['release_id','release_title','release_type','release_date']],'normalized/release_metadata.csv');events=events.rename(columns={'release_date':'date'});save(events,'release_events.csv')
# Preserve invalid source records explicitly rather than silently losing them.
periodraw=normalized('song_period_dashboard');invalid=periodraw[~periodraw.capture_valid.astype(bool)].copy()
invalid['exclusion_reason']=invalid.invalid_reason;invalid.to_csv(O/'excluded_records.csv',index=False)
log('Excluded invalid song period captures from canonical period analysis',len(invalid),'Source marks capture invalid; retained in excluded_records.csv.')
# Supplements are additional source vintages, never appended to native baseline as replacements.
for n in ['source_daily_supplement','recovered_source_periods','resume_snapshots','recovered_artist_metrics']:
 d=pd.read_csv(U/'normalized'/f'{n}.csv');d['source_file']='supplement/normalized/'+n+'.csv';d['source_row']=np.arange(2,len(d)+2);d['reporting_timezone']='UTC';d['baseline_endpoint']=BASELINE
 d['snapshot_class']=d['Reporting basis'].map(lambda x:'baseline_supplement' if 'baseline' in str(x).lower() else 'newer_snapshot');save(d,n+'.csv')
log('Preserved supplemental and newer observations as distinct tables/vintages',sum(len(pd.read_csv(U/'normalized'/f'{x}.csv')) for x in ['source_daily_supplement','recovered_source_periods','resume_snapshots','recovered_artist_metrics']),'Original Oct20 records untouched. Baseline supplement retrieved Oct23 UTC does not prove original-vintage equivalence.')
# Count reconciliation on all dates with all 14 recordings observed.
streams=song[song.metric.eq('streams')];g=streams.groupby('date').agg(catalog_streams=('value','sum'),recordings=('song_id','nunique')).reset_index();g=g.merge(a[['date','daily_streams']],on='date',validate='one_to_one');g['difference']=g.catalog_streams-g.daily_streams;g['comparable']=g.recordings.eq(14);save(g,'catalog_artist_daily_reconciliation.csv');good=g[g.comparable];check('complete_catalog_daily_totals',good.difference.eq(0).all(),f'{len(good)} complete days; max absolute difference {good.difference.abs().max()}')
# Verified artist period comparisons, exact inclusive dates.
def window(start,end):return a[a.date.between(start,end)]
comparisons=[]
for label,start,end,pstart,pend in [('7day','2026-10-14',BASELINE,'2026-10-07','2026-10-13'),('28day','2026-09-23',BASELINE,'2026-08-26','2026-09-22'),('90day','2026-07-23',BASELINE,'2026-04-24','2026-07-22'),('YTD2026_vs_2025','2026-01-01',BASELINE,'2025-01-01','2025-10-20')]:
 cur=window(start,end);prev=window(pstart,pend)
 for metric in ['daily_streams','daily_saves','daily_playlist_adds']:
  x=int(cur[metric].sum());y=int(prev[metric].sum());comparisons.append(dict(comparison=label,metric=metric,current_start=start,current_end=end,previous_start=pstart,previous_end=pend,current=x,previous=y,absolute_change=x-y,percent_change=(x/y-1)*100 if y else None,n_current=len(cur),n_previous=len(prev),method='sum of nonoverlapping additive daily observations',source_file=raw,source_rows_current=f'{int(cur.source_row.min())}:{int(cur.source_row.max())}',source_rows_previous=f'{int(prev.source_row.min())}:{int(prev.source_row.max())}'))
comp=pd.DataFrame(comparisons);save(comp,'artist_comparisons.csv')
period=normalized('artist_period_dashboard');p28=period[period.period.eq('28day')]
# Exact period unique counts and displayed ratios rechecked from preserved visible tables.
rawperiod=json.loads((S/'captured/period_metrics.json').read_text());pchecks=[]
for item in rawperiod:
 match=re.search(r'Worldwide\t([^\t]+)\t([^\t]+)',item['table'])
 assert match,item
 rr=period[(period.period.eq(item['period'])) & period.metric.eq(item['metric'])].iloc[0]
 for pos,col in [(1,'previous_value'),(2,'current_value')]:
  v=match[pos].strip();v=float(v.replace(',','')) if v not in ['—','-',''] else np.nan
  pchecks.append((pd.isna(v) and pd.isna(rr[col])) or np.isclose(v,rr[col]))
check('artist_period_values_match_raw_tables',all(pchecks),f'{len(pchecks)} current/previous cells including unique listeners')
for r in p28.itertuples():
 if r.metric in ['streams','saves','playlist_adds']:
  c=comp[(comp.comparison=='28day')&(comp.metric=='daily_'+r.metric)].iloc[0]
  check('artist_28day_'+r.metric,c.current==r.current_value and c.previous==r.previous_value,f'daily {c.current}/{c.previous}, UI {r.current_value}/{r.previous_value}')
# Recording concentration and direction, all records must have both full 28-day windows.
track=[]
for r in cat.itertuples():
 z=streams[streams.song_id.eq(r.song_id)];x=z[z.date.between('2026-09-23',BASELINE)];y=z[z.date.between('2026-08-26','2026-09-22')]
 if len(x)!=28 or len(y)!=28:continue
 track.append(dict(song_id=r.song_id,recording_label=r.recording_label,current_streams=int(x.value.sum()),previous_streams=int(y.value.sum()),change=int(x.value.sum()-y.value.sum()),current_days=len(x),previous_days=len(y),current_start='2026-09-23',current_end=BASELINE,previous_start='2026-08-26',previous_end='2026-09-22'))
t=pd.DataFrame(track).sort_values('current_streams',ascending=False);t['share_pct']=t.current_streams/t.current_streams.sum()*100;t['change_pct']=np.where(t.previous_streams.ne(0),(t.current_streams/t.previous_streams-1)*100,np.nan);save(t,'track_28day_comparison.csv');check('latest_catalog_period_total',t.current_streams.sum()==4246 and t.previous_streams.sum()==4011,f'{t.current_streams.sum()} vs {t.previous_streams.sum()}')
# True original-release-age comparisons, censor incomplete observations.
launch=[]
for r in cat.itertuples():
 z=streams[streams.song_id.eq(r.song_id)];release=pd.Timestamp(r.first_released)
 for days in [7,28,90]:
  end=(release+pd.Timedelta(days=days-1)).strftime('%Y-%m-%d');w=z[z.date.between(r.first_released,end)];complete=len(w)==days
  launch.append(dict(song_id=r.song_id,recording_label=r.recording_label,release_date=r.first_released,days_since_release=days,window_end=end,observed_days=len(w),complete=complete,streams=int(w.value.sum()) if complete else None,limitation='' if complete else 'missing source dates; no imputation',source_file='cleaned/track_daily_long.csv + cleaned/recordings.csv'))
launch=pd.DataFrame(launch);save(launch,'recording_launch_windows.csv')
# All-time counters remain distinct, reconcile only available-history count as an audit.
history=streams.groupby('song_id').agg(history_streams=('value','sum'),observed_days=('date','nunique')).reset_index().merge(normalized('song_alltime_counters'),on='song_id',validate='one_to_one');history['history_minus_alltime']=history.history_streams-history.all_time_streams;save(history,'history_counter_comparison.csv')
conflict=history[history.history_minus_alltime.gt(0)]
issue('high','Available-history count exceeds all-time header for some recordings',conflict[['recording_label','history_streams','all_time_streams','history_minus_alltime']].to_dict('records'),'Retain both values; use date-bounded native/chart totals for trend analysis, never label them lifetime.')
issue('high','Six recording-metric histories incomplete',coverage.loc[~coverage.complete,['song_id','metric','observed_days','missing_dates_in_history']].to_dict('records'),'Do not use full-history catalog totals or impute missing stream days; latest 365 catalog days reconcile.')
issue('medium','Displayed audience demographic counts do not reconcile','Original evidence reports gender 1064, age 1063, artist period listeners 1062; no adjustment applied.','Use verified artist unique listeners as total; show demographic counts with discrepancy caveat.')
issue('medium','No stable person-level attribution or external matched benchmark','Platform aggregates cannot identify repeat individuals or conversion; source categories and playlist unique listeners overlap.','Describe streams per period listener as an activity ratio; no conversion or causal claims.')
# Monthly streams and median distribution, partial months flagged.
aa=a.copy();aa['month']=aa.date.str[:7];monthly=aa.groupby('month').agg(streams=('daily_streams','sum'),saves=('daily_saves','sum'),playlist_adds=('daily_playlist_adds','sum'),observed_days=('date','size'),median_daily_streams=('daily_streams','median'),max_daily_streams=('daily_streams','max')).reset_index();monthly['complete_month']=monthly.observed_days.eq(pd.to_datetime(monthly.month+'-01').dt.days_in_month);save(monthly,'artist_monthly_additive.csv')
peak=a.nlargest(10,'daily_streams')[['date','daily_streams','daily_listeners','source_file','source_row']];save(peak,'artist_top_days.csv')
latest=window('2026-09-23',BASELINE);prior=window('2026-08-26','2026-09-22');trim_current=int(latest.daily_streams.sum()-latest.daily_streams.max());trim_prior=int(prior.daily_streams.sum()-prior.daily_streams.max())
followers_start=int(a.loc[a.date.eq('2026-09-22'),'followers_stock'].iloc[0]);followers_end=int(a.iloc[-1].followers_stock)
# Rates only compatible period denominator, explicitly not unique-person conversion.
rate=normalized('song_period_canonical');rate=rate[rate.period.eq('28day')].copy();rate['save_actions_per_100_period_listeners']=100*rate.saves/rate.listeners.replace(0,np.nan);rate['playlist_add_actions_per_100_period_listeners']=100*rate.playlist_adds/rate.listeners.replace(0,np.nan);rate['streams_per_period_listener_exact']=rate.streams/rate.listeners.replace(0,np.nan);rate['rate_caveat']='Actions divided by period unique listeners; not unique savers or conversion probability; undefined at zero denominator.';save(rate,'track_28day_activity_ratios.csv')
readiness=[dict(question='Artist additive trends',status='Supported',period='2024-01-01 to 2026-10-20',unit='artist UTC day',usable_observations=len(a),missingness='0 missing dates or values',dependence='Repeated daily observations; descriptive comparisons, no independent-observation test',smallest_next_data='None for observed interval totals'),dict(question='Recent catalog concentration',status='Supported',period='2025-10-21 to 2026-10-20',unit='recording UTC day',usable_observations=len(good)*14,missingness='0 for all 14 streams in the shared final 365 days',dependence='Tracks share artist/day and totals; descriptive only',smallest_next_data='None for recent concentration'),dict(question='Full-history catalog composition',status='Blocked',period='2024-01-01 to 2026-10-20',unit='recording UTC day',usable_observations=len(streams),missingness='GOOMH streams 365 days, Son streams 730, all other stream histories 1024',dependence='Cannot sum incomplete catalog as full artist history',smallest_next_data='GOOMH missing 659 stream days and Son missing 294 stream days'),dict(question='Equal-age release ranking',status='Exploratory',period='Original release date through days 7/28/90',unit='recording release window',usable_observations=int(launch[launch.days_since_release.eq(28)].complete.sum()),missingness='Old 2023 starts unavailable and any gap-censored launch marked incomplete',dependence='Song, calendar and promotion confounded; release families overlap',smallest_next_data='Comparable planned promotion and daily exposure for future releases'),dict(question='Distinct listener retention and marketing conversion',status='Blocked',period='All available',unit='person/cohort',usable_observations=0,missingness='No listener identity or attributed link-to-stream events',dependence='Aggregate activity ratios cannot infer individual behavior',smallest_next_data='Prospective campaign attribution/controlled promotion design; eligible cohort outcome')]
pd.DataFrame(readiness).to_csv(O/'analysis_readiness.csv',index=False)
results=[]
for r in comp.itertuples():
 results.append(dict(question='Did artist '+r.metric.replace('daily_','')+' change?',status='Supported descriptive',variables=r.metric,periods=f'{r.previous_start}/{r.previous_end} vs {r.current_start}/{r.current_end}',n=r.n_current+r.n_previous,unit='artist UTC day',method=r.method,effect_size=r.absolute_change,percent_change=r.percent_change,previous=r.previous,current=r.current,ci95_low=None,ci95_high=None,p_value=None,adjusted_p_value=None,uncertainty='Observed fixed-window platform totals; no sampling CI/p-value estimated',limitations='Different calendar/event conditions; not a causal effect; daily observations dependent',source_file=r.source_file,source_rows=f'{r.source_rows_previous};{r.source_rows_current}'))
for metric in ['listeners','streams_per_listener','followers']:
 r=p28[p28.metric.eq(metric)].iloc[0];results.append(dict(question='Did '+metric+' change over the latest 28-day comparison?',status='Supported descriptive',variables=metric,periods='2026-08-26/2026-09-22 vs 2026-09-23/2026-10-20',n=2,unit='period unique count / ratio / endpoint stock',method='Visible period table; followers endpoint stock comparison',effect_size=r.current_value-r.previous_value,percent_change=(r.current_value/r.previous_value-1)*100,previous=r.previous_value,current=r.current_value,uncertainty='No CI; full observed period summary, ratios rounded as reported',limitations='No person-level retention inference; follower change is net',source_file='captured/period_metrics.json',source_rows=f'JSON element {int(r.name)+1}'))
for item in readiness:
 if item['status']=='Blocked':results.append(dict(question=item['question'],status='Blocked',method='Not run',n=item['usable_observations'],limitations=item['missingness'],uncertainty='Insufficient evidence; not evidence of no relationship'))
pd.DataFrame(results).to_csv(O/'statistical_results.csv',index=False)
# Reviewed audience and stream-source evidence; never mix aggregate and detail levels.
src=normalized('artist_sources_28day');agg=src[(src.level.eq('aggregate')) & src.metric.eq('streams')].copy()
source_text=(S/'captured/artist_sources_28day_streams.txt').read_text()
for r in agg.itertuples():
 assert f'{int(r.previous_value):,}' in source_text and f'{int(r.current_value):,}' in source_text
check('source_aggregate_counts_reconcile',agg.current_value.sum()==4246 and agg.previous_value.sum()==4011,'Only aggregate rows: active + programmed + other; detailed rows not added again')
geo=normalized('audience_top_countries');subsegments=normalized('audience_active_subsegments')
check('active_subsegments_partition',subsegments.listeners.sum()==791,'47 super + 230 moderate + 514 light = 791 monthly active listeners')
geo_text=(S/'captured/audience_locations_all_available.txt').read_text()
assert '777' in geo_text and '637' in geo_text
# Store source/segment/country figures with caveats alongside chart tables.
audience_findings={'period_start':'2026-09-23','period_end':BASELINE,'timezone':'UTC','source_aggregates':agg.fillna('').to_dict('records'),'top_countries':geo.head(5).fillna('').to_dict('records'),'active_subsegments':subsegments.to_dict('records'),'us_share_pct':777/1062*100,'active_share_of_period_listeners_pct':791/1062*100,'active_source_share_pct':3746/4246*100,'active_source_change':325,'programmed_source_change':-88,'other_source_change':-2,'caveats':['Source aggregate streams partition the total; source listeners overlap.','Monthly active segment differs from active-source streams; 91% segment stream share is rounded.','Country snapshot is a top table, not a complete census of all geographic behavior.','Segments: super, moderate and light are nested within monthly active; never add them to the parent.'],'source_files':['captured/artist_sources_28day_streams.txt','captured/audience_segments_active.txt','captured/audience_locations_all_available.txt','normalized/audience_top_countries.csv','normalized/audience_active_subsegments.csv']}
(O/'audience_findings.json').write_text(json.dumps(audience_findings,indent=2))

# Output dictionary: every field with source-specific definitions and aggregation protection.
defn={
 'daily_streams':('count','Streams during the stated UTC calendar day','Sum across nonoverlapping days at same scope','Native reported count'),
 'daily_listeners':('distinct accounts','Unique listeners within each UTC day','Never sum into weekly/monthly unique listeners','Daily audiences overlap'),
 'daily_saves':('actions','Save activity during the stated UTC day','Sum nonoverlapping days at same scope','Not necessarily unique savers'),
 'daily_playlist_adds':('actions','Playlist-add activity during stated UTC day','Sum nonoverlapping days at same scope','Not unique listeners or placements'),
 'followers_stock':('accounts','Following artist as of the date','Use endpoint; difference is net change','Do not sum stocks'),
 'follower_net_change':('net accounts','followers_stock[t]-followers_stock[t-1]','Sum adjacent nonoverlapping differences','First day missing; gross follows/unfollows unavailable'),
 'rolling28_listeners':('distinct accounts','Reported trailing-28-day monthly listeners ending on date','Never sum/difference into daily listeners','Overlapping windows create dependence'),
 'rolling28_active_listeners':('distinct accounts','Reported trailing-28-day intentionally active audience','Never sum across days','Not identical to source stream categories'),
 'rolling28_super_listeners':('distinct accounts','Reported trailing-28-day super-listener segment','Never sum across days','Nested segment; do not add to active audience'),
 'date':('ISO 8601 date','UTC activity day for daily tables; release date in release_events','Time key','Already aggregated days cannot be precisely timezone-shifted'),
 'value':('metric-specific','Observed selected metric at stated grain','Depends on metric: streams/saves/adds additive; listeners/ratios not additive','See metric/value_status/precision'),
 'metric':('label','Selected source measure','Dimension; never sum mixed metrics',''),
 'reported_value':('source text','Literal numeric display before numeric conversion','Never aggregate text','Preserves rounded ratios'),
 'listener_denominator':('distinct accounts','Daily recording listeners joined on recording/date','Not additive across dates or songs','Used only to mark undefined ratios'),
 'snapshot_class':('category','original_baseline, baseline_supplement, newer_snapshot','Never collapse vintages by date only','Later baseline supplement is a separate retrieval vintage'),
 'retrieved_at':('date or timestamp','Time evidence was collected, not activity date','Metadata','Date-only precision where exact original capture time absent'),
 'source_row':('integer','Original CSV physical line incl header, or JSON array element','Lineage key with source_file','See source_row_type'),
 'rolling_window_start':('ISO date','Inclusive rolling-28-day start for rolling28_* measures','Never sum overlapping windows','Date minus 27 days'),
 'rolling_window_end':('ISO date','Inclusive rolling-28-day end for rolling28_* measures','Never sum overlapping windows','Equals snapshot date'),
 'stock_as_of_date':('ISO date','Date of the end-date follower stock','Endpoint comparison only','Not interval activity'),
 'period_start':('ISO date','Inclusive source period start; in artist_daily applies only to daily_* fields','Do not overlap aggregate intervals','Unknown bounds remain missing'),
 'period_end':('ISO date','Inclusive source period end','Do not overlap aggregate intervals','Not retrieval date'),
 'precision':('category','Integer source count or displayed ratio precision','Metadata','Displayed ratios not exact measurements'),
 'recording_label':('text','Verified display title/version label','Use song_id for joins','Same title may represent distinct recordings'),
 'song_id':('Spotify ID','Stable recording identifier','Join one-to-many to fact data','Shared recording across releases is one recording'),
 'share_pct':('percent','Track streams / artist stream total in same complete period ×100','Shares sum only within identical denominator/window','Catalog coverage must be complete'),
 'streams_per_period_listener_exact':('streams/listener','period streams / period unique listeners','Recalculate from compatible totals; do not average daily ratios','Intensity ratio, not person-level repeat rate'),
 'save_actions_per_100_period_listeners':('actions per 100 listeners','100 × period saves / period unique listeners','Recalculate from compatible sums, not average ratios','Not unique-saver conversion'),
 'playlist_add_actions_per_100_period_listeners':('actions per 100 listeners','100 × period playlist adds / period unique listeners','Recalculate from compatible totals','Not conversion'),
}
defn.update({
 'streams':('count','Source-reported streams in stated period or completed launch window','Sum only disjoint periods and deduplicated recording IDs','Release membership overlaps; history is not lifetime'),
 'listeners':('distinct accounts','Unique listeners within the row’s reporting period and entity','Never sum across dates/tracks/overlapping source groups','Use artist period denominator for artist reach'),
 'saves':('actions','Source save activity in stated period/entity','Sum disjoint periods at same scope','Not unique savers'),
 'playlist_adds':('actions','Source playlist-add activity in stated period/entity','Sum disjoint periods at same scope','Not unique playlists or listeners'),
 'all_time_streams':('cumulative count','Reported all-time recording counter','Snapshot; do not sum across retrieval vintages','Conflicts with available-history totals retained'),
 'current_value':('metric-specific','Current source-period value for the selected metric','Respect metric additivity; followers are endpoint stocks','Status fields distinguish unavailable/dash'),
 'previous_value':('metric-specific','Previous source-period value for selected metric','Only compare matching scope and provided dates','Do not assume prior-year YTD from UI prior-period'),
 'active_listeners':('distinct accounts','Country monthly active listeners within trailing 28 days','Do not sum overlapping geographies or windows','Dashes preserved unavailable'),
 'share_pct_displayed':('percent','Rounded displayed share of named denominator','Not additive across different denominators','Keep reported precision'),
 'share_pct_calculated':('percent','100×row listeners/explicit matching denominator','Recompute from counts rather than average percentages','Rounded display and exact computed ratio distinct'),
 'streams_per_listener_displayed':('streams per listener','Reported ratio for the row’s segment/period','Do not sum or infer individual repeat listening','Rounded source display'),
 'current_share_of_total_streams':('fraction 0–1','Current category streams/current artist period total','Aggregate OR detail hierarchy only, never both','Stream categories differ from audience segments'),
 'previous_share_of_total_streams':('fraction 0–1','Previous category streams/previous artist period total','Same hierarchy constraint','Fractions, not percentage points'),
 'level':('category','Source hierarchy aggregate versus detailed','Select one complete level before summing','Avoid counting parent and child together'),
 'source_category':('label','Platform stream-source category','Dimension','Do not confuse with audience segment'),
 'percent_change':('percent','100×(current/previous−1), undefined for zero previous','Do not average percentages','Use exact comparable baseline'),
 'absolute_change':('metric units','Current minus previous','Only same metric/unit/scope','Follower difference means net'),
 'source_file':('path','Immediate input table or evidence file','Lineage','Evidence_source_file/source may identify earlier capture'),
 'evidence_source_file':('path','Preserved upstream original capture path','Lineage','Not overwritten by output normalization'),
 'observed_days':('days','Number of source dates actually observed','Count unique entity/metric dates','Do not infer missing days as zero'),
 'complete':('boolean','All dates required by the named interval observed','Logical qualification','False counts are not complete period totals'),
 'reporting_timezone':('IANA/fixed timezone','UTC aggregated source day basis','Do not relabel as local midnight','Date-only aggregates cannot be precisely shifted'),
 'baseline_endpoint':('ISO date','Original analysis cutoff 2026-10-20','Metadata only','Not source activity start or retrieval time'),
 'value_status':('category','Observed or undefined_zero_denominator_reported_zero','Do not coerce missing/undefined to zero','Reported value retained for audit'),
 'Current value':('metric-specific','Supplement source-period reported current value','Respect Metric and Hierarchy level','Distinct retrieval vintage'),
 'Previous value':('metric-specific','Supplement source-period reported previous value','Respect Metric and Hierarchy level','Distinct retrieval vintage'),
 'Value':('metric-specific','Snapshot measure named in Metric','Snapshot/unique/interval rules depend on Metric','Bounds may be unexposed'),
 'All active sources':('metric-specific','Supplement parent active-source measure','Do not add parent to its detail categories','Listeners overlap; streams additive only on one hierarchy'),
 'All programmed sources':('metric-specific','Supplement parent programmed-source measure','Do not add parent to detail','Listeners overlap'),
})
dictrows=[]
for f in C.glob('*.csv'):
 d=pd.read_csv(f,nrows=3)
 for col in d.columns:
  units,definition,agg,caveat=defn.get(col,('source-specific',f'{col}: preserved source field; definition context in {f.name} and original DATA_DICTIONARY.md','Do not aggregate unless its source dictionary establishes additivity','Source periods, scope and snapshots must match'))
  dictrows.append(dict(table=f.name,column=col,units=units,definition=definition,aggregation_rule=agg,caveat=caveat))
pd.DataFrame(dictrows).to_csv(O/'data_dictionary.csv',index=False)
pd.DataFrame(logs).to_csv(O/'cleaning_log.csv',index=False);pd.DataFrame(checks).to_csv(O/'validation_checks.csv',index=False);pd.DataFrame(issues).to_csv(O/'data_quality_issues.csv',index=False)
summary=dict(artist_name='[REDACTED]',artist_id=ARTIST,timezone='UTC',baseline_endpoint=BASELINE,retrieval_date='2026-10-22',artist_days=len(a),track_metric_rows=len(song),recordings=len(cat),complete_track_metric_histories=int(coverage.complete.sum()),total_track_metric_histories=len(coverage),catalog_matching_days=len(good),artist_total_observed_streams=int(a.daily_streams.sum()),artist_latest28_streams=int(latest.daily_streams.sum()),artist_prior28_streams=int(prior.daily_streams.sum()),latest28_median_daily_streams=float(latest.daily_streams.median()),prior28_median_daily_streams=float(prior.daily_streams.median()),largest_day_removed_current=trim_current,largest_day_removed_prior=trim_prior,largest_day_removed_change_pct=(trim_current/trim_prior-1)*100,followers_start=followers_start,followers_end=followers_end,followers_net_change=followers_end-followers_start,top_track=t.iloc[0].recording_label,top_track_streams=int(t.iloc[0].current_streams),top_track_share_pct=float(t.iloc[0].share_pct),top3_share_pct=float(t.head(3).share_pct.sum()),hhi=float(((t.current_streams/t.current_streams.sum())**2).sum()),growing_tracks=int(t.change.gt(0).sum()),falling_tracks=int(t.change.lt(0).sum()),unchanged_tracks=int(t.change.eq(0).sum()),comparisons=comp.to_dict('records'),track28=t.to_dict('records'),launch=launch.to_dict('records'),period28=p28.fillna('').to_dict('records'),peaks=peak.to_dict('records'),issues=issues,validation=checks)
def clean_json(x):
 if isinstance(x,dict):return {k:clean_json(v) for k,v in x.items()}
 if isinstance(x,list):return [clean_json(v) for v in x]
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
(O/'reviewed_findings.json').write_text(json.dumps(clean_json(summary),indent=2,default=str,allow_nan=False))
# Simple exportable scientific figures; interpretation belongs in report nearby.
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(10,4));ax.plot(pd.to_datetime(a.date),a.daily_streams,color='#bbc4ce',lw=.7,label='Daily streams');ax.plot(pd.to_datetime(a.date),a.daily_streams.rolling(28,min_periods=28).mean(),color='#6246af',lw=2,label='28-day mean (descriptive smoothing)');ax.set(title='Spotify daily streams: Jan 1, 2024–Oct 20, 2026 (UTC)',ylabel='Streams per day');ax.legend(frameon=False);fig.tight_layout();fig.savefig(O/'charts/artist_streams.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5));z=t.iloc[::-1];ax.barh(z.recording_label,z.current_streams,color='#6246af');ax.set(title='Track contribution: Sep 23–Oct 20, 2026 (UTC)',xlabel='Streams (all 14 recordings; total 4,246)');fig.tight_layout();fig.savefig(O/'charts/track_concentration.png',dpi=180);plt.close(fig)
print(json.dumps({k:v for k,v in summary.items() if not isinstance(v,list)},indent=2));print('Outputs:',O)

(O/'README.md').write_text("""# Spotify cleaned data and audit

Run `python code/spotify_pipeline.py` from the project folder (Python 3.11+, pandas, NumPy, matplotlib). Defaults are relative to this portable project. Optional flags: `--source`, `--supplement`, `--out`. No credentials or network calls. Inputs remain unchanged.

`cleaned/artist_daily.csv` is the native account-day table. `daily_*` columns use period_start/end. Rolling measures use rolling_window_start/end; follower stocks use stock_as_of_date. `track_daily_long.csv` is one recording-day-metric per original retrieval vintage and contains exact source/row lineage. `recordings.csv` supplies stable IDs and version labels. `artist_period_dashboard.csv` supplies unique listeners and period ratios; never substitute summed daily listeners. `track_28day_comparison.csv` reconciles all 14 recordings to artist totals. `recording_launch_windows.csv` keeps incomplete launches missing rather than zero.

Separate files retain countries, cities, segments, source categories, song locations/playlists, all-time counters, and release-period data. These have different grains and must not be stacked or summed into an artist daily table. Source category parents and children overlap. Source listener counts overlap. Release membership overlaps recording IDs. Playlist and geography Top tables may be incomplete.

`source_daily_supplement.csv`, `recovered_source_periods.csv`, `resume_snapshots.csv`, and `recovered_artist_metrics.csv` preserve later retrievals. Baseline-period supplements are a distinct retrieval vintage; a matching date window does not prove there were no historical revisions. Nothing overwrites the original October20 cutoff snapshot.

Validation and documentation: source_file_inventory.csv inventories every original/supplement archive file; validation_checks.csv records recomputed checks; cleaning_log.csv records substantive actions; excluded_records.csv preserves one invalid period capture; data_quality_issues.csv and analysis_readiness.csv explain limits; statistical_results.csv retains supported descriptive comparisons and blocked questions. analysis_plan.md predates the script’s numerical calculations. data_dictionary.csv defines every exported field; original source dictionaries remain in raw/spotify_baseline.

No Spotify-only p-values or confidence intervals were manufactured. Fixed-window observed population changes are descriptive; release windows are observational and confounded. Cross-platform inference is in the separate analysis pipeline.
""")
(O/'dashboard_handoff.md').write_text("""# Spotify dashboard handoff

Ready: artist daily additive activity, daily distinct listener counts, endpoint follower stocks, trailing28 audience stocks, period unique listener summaries, recent all14-track stream contribution, and complete launch windows. Show metric-specific units and period definitions. October2026 monthly row is partial and must not be compared with full months as an equal period.

Required caveats: 64/70 full-history recording-metric series complete; all14 stream histories only overlap in the final365 days. Full available history is not lifetime. Funny Guy and The Devil Wears Docs history sums exceed captured all-time counters. Demographic totals disagree with period listeners by1–2. Rounded segment stream shares/ratios remain rounded. Geographic and named playlist tables are Top tables.

Suggested next collection: export missing GOOMH stream dates (659) and Son stream dates (294) only if long-history catalog analysis matters. For future snapshots retain raw files, timestamp/timezone, explicit inclusive bounds, selected metric/filter, artist/recording ID, retrieval vintage and export provenance. Append snapshots; do not deduplicate across vintages by activity date alone. Capture dated promotion/release/show/paid campaign events and attributed links for prospective marketing tests; record gross follows/unfollows separately if available.
""")
# Profiles expose duplicate files/rows without treating overlapping sources as duplicate observations.
inv=pd.DataFrame(files)
dupfiles=inv[inv.duplicated('sha256',keep=False)].sort_values(['sha256','file']);dupfiles.to_csv(O/'duplicate_files.csv',index=False)
profile=[]
for f in sorted(C.glob('*.csv')):
 d=pd.read_csv(f)
 profile.append(dict(table=f.name,rows=len(d),columns=len(d.columns),exact_duplicate_rows=int(d.duplicated().sum()),missing_cells=int(d.isna().sum().sum()),negative_numeric_cells=int(d.select_dtypes('number').lt(0).sum().sum()),negative_note='Negatives may be valid differences; source count domain checked separately',grain='See table_inventory.csv; schemas in data_dictionary.csv'))
pd.DataFrame(profile).to_csv(O/'table_profiles.csv',index=False)
contracts={
'artist_daily.csv':('artist-date-vintage','artist_id,date,snapshot_class','mixed: interval daily counts; daily uniques; rolling28 uniques; follower stocks','Complete1024 days; rolling windows explicit; first net follower change unavailable'),
'recordings.csv':('recording','song_id','entity metadata','Same recording on multiple releases one ID; Lab Tapes versions distinct'),
'track_daily_long.csv':('recording-date-metric-vintage','song_id,date,metric,snapshot_class','interval counts; daily uniques; displayed ratios','64/70 full histories; undefined zero-denominator ratios flagged'),
'release_events.csv':('release','release_id','event metadata','Date not exact event timestamp; release tracks overlap'),
'artist_period_dashboard.csv':('artist-period-metric','period,metric','interval counts; period unique counts; ratios; follower stock','UI previous YTD is preceding293 days, not prior-year YTD'),
'song_period_canonical.csv':('recording-period','song_id,period','interval counts; unique counts; displayed ratio','Period bounds and selected metric capture govern; unique people not additive'),
'song_alltime_counters.csv':('recording cumulative snapshot','song_id,snapshot_class','cumulative count','All-time headers conflict with some history sums; retain separately'),
'release_metadata.csv':('release snapshot','release_id','metadata and cumulative/history counts','Shared recording membership prevents additive release totals'),
'release_periods.csv':('release-period','release_id,period','interval counts and unique counts','Release rows overlap recordings; never sum to artist total'),
'audience_segment_snapshot.csv':('audience segment snapshot','as_of_date,segment','2-year unique segment partition plus rounded28-day stream share','Denominators differ across measures; snapshot, not flow'),
'audience_active_subsegments.csv':('active audience subsegment-period','period_start,period_end,segment','rolling28 unique subgroup; rounded ratios','Nested in monthly active parent; do not double count'),
'audience_top_countries.csv':('country-period','period_start,period_end,country','period unique listeners and active subset','Top23 displayed countries; not listener identity matching'),
'audience_top_cities.csv':('city-period','period_start,period_end,city','period unique listeners and active subset','Top50 cities; not exhaustive'),
'audience_demographics_age.csv':('age band-period','period_start,period_end,age_range','period unique/rounded demographic measures','Source total1063 vs1062 artist listeners; discrepancy retained'),
'audience_demographics_gender.csv':('gender-period','period_start,period_end,gender','period demographic measures','Source total1064 vs1062; discrepancy retained'),
'audience_demographics_age_gender.csv':('age-gender-period','period_start,period_end,age_range,gender','period demographic cross-tab','Rounding/reconciliation discrepancies retained'),
'artist_sources_28day.csv':('artist-period-metric-source-hierarchy','level,metric,source_category,start_date,end_date','interval stream counts and overlapping unique source listeners','Choose parent OR detail hierarchy; dashes missing, not zero'),
'song_locations.csv':('recording-geography-period','song_id,location_type,rank,period_start,period_end','interval streams','Song locations use streams; artist geography uses listeners; only accessible pages'),
'song_playlists.csv':('recording-playlist-selected period','song_id,period_label,rank','top playlist interval streams/unique listeners','Exact date bounds may be unexposed; top threshold incomplete'),
'artist_playlists.csv':('artist-playlist-selected period','period_label,category,playlist_title,native_export_order','top playlist stream and unique listener counts','Exact bounds unexposed; listener rows overlap'),
'source_daily_supplement.csv':('recording-day-metric-retrieval','Spotify ID,Date,Metric,Collected UTC,Evidence','interval stream counts or source-specific unique/ratio','Hierarchy parents/details coexist; separate baseline supplement/newer snapshot'),
'recovered_source_periods.csv':('entity-period-metric-source-retrieval','Spotify ID,Period start,Period end,Metric,Source,Hierarchy level,Collected UTC','interval/unique/ratio by metric','Different retrieval vintage; do not merge into original baseline'),
'resume_snapshots.csv':('entity-dimension-metric-period-retrieval','Dataset,Spotify ID,Dimension,Metric,Selected period,Collected UTC','top playlist/geography/snapshot measures','Unknown bounds remain unavailable; retain evidence'),
'recovered_artist_metrics.csv':('artist-period-metric-retrieval','Spotify ID,Period start,Period end,Metric,Collected UTC','period unique listeners','Manual late-collected prior-year YTD unique count; distinct vintage'),
'artist_comparisons.csv':('comparison-metric','comparison,metric','derived additive interval comparison','No independent-observation inference; zero prior denominator undefined'),
'artist_monthly_additive.csv':('artist-month','month','additive streams/saves/adds with distribution statistics','Oct2026 partial; medians are not additive'),
'track_28day_comparison.csv':('recording matched28-day windows','song_id','derived additive stream totals/shares','All14 complete; latest and prior windows disjoint'),
'recording_launch_windows.csv':('recording-original-release-age window','song_id,days_since_release','additive streams if complete','Window includes release day; incomplete totals missing'),
'catalog_artist_daily_reconciliation.csv':('UTC date','date','comparison count','Only comparable=True includes all14 recordings'),
'history_counter_comparison.csv':('recording snapshot','song_id','available-history versus cumulative snapshot','History may be incomplete or start after release; not same scope'),
'artist_top_days.csv':('ranked artist date','date','daily count','Selection highlights spikes; not a representative sample'),
 'track_28day_activity_ratios.csv':('recording28-day period','song_id,period','action ratios using period unique listeners','Not unique-saver conversion or measured repeat-person behavior'),
 'track_coverage.csv':('recording-metric','song_id,metric','coverage metadata','Zero observed days means no captured series, not zero performance')
}
tables=[]
for f in sorted(C.glob('*.csv')):
 d=pd.read_csv(f);grain,key,typ,limits=contracts.get(f.name,('see schema','see schema','source-specific','No unapproved aggregation'))
 key_columns=key.split(','); assert all(x in d for x in key_columns),(f.name,key); duplicate_key_rows=int(d.duplicated(key_columns).sum())
 tables.append(dict(duplicate_key_rows=duplicate_key_rows,platform='Spotify',account='[REDACTED]',account_id=ARTIST,table=f.name,row_count=len(d),grain=grain,candidate_key=key,measure_type=typ,timezone='UTC',retrieval_date='2026-10-22 or explicit supplemental Collected UTC',coverage_gaps_and_limits=limits,source_link='https://drive.google.com/file/d/1T7ZsJq-iyR3IMoc4hQOqXnzOdTidtbJx/view'))
pd.DataFrame(tables).to_csv(O/'table_inventory.csv',index=False)
