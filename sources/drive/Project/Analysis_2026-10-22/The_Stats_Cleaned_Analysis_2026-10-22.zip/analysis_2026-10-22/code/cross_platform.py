#!/usr/bin/env python3
"""Reproduce the predeclared cross-platform exploratory analysis from clean tables.

Run after spotify_pipeline.py and social_pipeline.py. No network or credentials.
The calendar alignment is nominal, not a conversion of aggregated Pacific days.
"""
from pathlib import Path
import argparse
import json
import warnings
import numpy as np
import pandas as pd
from scipy.stats import rankdata
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
PREDICTORS = [(p, m) for p in ['Facebook', 'Instagram']
              for m in ['link_clicks', 'interactions', 'visits']]
START, END = pd.Timestamp('2026-01-01'), pd.Timestamp('2026-10-20')
SEED = 20261022


def rho(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < 3 or len(np.unique(x)) < 2 or len(np.unique(y)) < 2:
        return np.nan
    return float(np.corrcoef(rankdata(x), rankdata(y))[0, 1])


def bootstrap_ci(x, y, block=4, reps=2000, seed=SEED):
    """Paired circular moving-block percentile interval, approximate stationary pairs."""
    n = len(x)
    rng = np.random.default_rng(seed)
    starts = rng.integers(0, n, size=(reps, int(np.ceil(n / block))))
    idx = (starts[:, :, None] + np.arange(block)) % n
    idx = idx.reshape(reps, -1)[:, :n]
    a, b = rankdata(np.asarray(x)[idx], axis=1), rankdata(np.asarray(y)[idx], axis=1)
    a -= a.mean(axis=1, keepdims=True)
    b -= b.mean(axis=1, keepdims=True)
    denom = np.sqrt((a * a).sum(axis=1) * (b * b).sum(axis=1))
    good = denom > 0
    vals = (a[good] * b[good]).sum(axis=1) / denom[good]
    return tuple(np.percentile(vals, [2.5, 97.5])) if len(vals) else (np.nan, np.nan)


def circular_p(x, y):
    """All n rotations including observed rotation; resolution 1/n."""
    obs = abs(rho(x, y))
    if not np.isfinite(obs):
        return np.nan
    null = np.array([abs(rho(np.roll(x, k), y)) for k in range(len(x))])
    return float(np.mean(null >= obs - 1e-12))


def bh(p):
    p = np.asarray(p, float)
    finite = np.isfinite(p)
    out = np.full(len(p), np.nan)
    # All planned tests constitute family size even when a test cannot be estimated.
    idx = np.flatnonzero(finite)
    order = idx[np.argsort(p[finite])]
    q = p[order] * len(p) / np.arange(1, len(order) + 1)
    out[order] = np.minimum(1, np.minimum.accumulate(q[::-1])[::-1])
    return out


def holm(p):
    p = np.asarray(p, float)
    idx = np.flatnonzero(np.isfinite(p))
    order = idx[np.argsort(p[idx])]
    out = np.full(len(p), np.nan)
    out[order] = np.minimum(1, np.maximum.accumulate(p[order] * (len(p) - np.arange(len(order)))))
    return out


def week_start(date):
    return date - pd.to_timedelta(date.dt.dayofweek, unit='D')


def weekly(daily, value_col, source_name, date_shift=0):
    data = daily[['date', value_col]].copy()
    data['date'] = pd.to_datetime(data['date']) + pd.Timedelta(days=date_shift)
    data = data[data['date'].between(START, END)]
    if data['date'].duplicated().any():
        raise ValueError(f'Duplicate date in {source_name}; join would inflate observations')
    data['week_start'] = week_start(data['date'])
    rows = []
    for wk, g in data.groupby('week_start'):
        complete = (len(g) == 7 and g[value_col].notna().sum() == 7 and
                    g['date'].nunique() == 7 and wk >= START and
                    wk + pd.Timedelta(days=6) <= END)
        rows.append({'week_start': wk, 'value': g[value_col].sum(min_count=7) if complete else np.nan,
                     'observed_days': int(g[value_col].notna().sum()), 'complete_week': complete,
                     'source': source_name, 'date_shift_sensitivity_days': date_shift})
    return pd.DataFrame(rows)


def make_pairs(xw, yw, lag):
    x, y = xw.set_index('week_start')['value'], yw.set_index('week_start')['value']
    calendar = pd.date_range(min(x.index.min(), y.index.min()), max(x.index.max(), y.index.max()), freq='W-MON')
    x, y = x.reindex(calendar), y.reindex(calendar)
    out = pd.DataFrame({'social_week': calendar, 'social_value': x.values,
                        'spotify_week': calendar + pd.Timedelta(weeks=lag),
                        'spotify_streams': y.shift(-lag).values,
                        'social_log_change': np.log1p(x).diff().values,
                        'spotify_log_change': np.log1p(y).diff().shift(-lag).values})
    return out


def main(base):
    out = base / 'cross_platform'
    out.mkdir(parents=True, exist_ok=True)
    sp = pd.read_csv(base / 'spotify/cleaned/artist_daily.csv')
    social = pd.read_csv(base / 'social/account_daily.csv')
    sp['date'], social['date'] = pd.to_datetime(sp['date']), pd.to_datetime(social['date'])
    releases = pd.read_csv(base / 'raw/spotify_baseline/normalized/release_metadata.csv')
    releases['release_date'] = pd.to_datetime(releases['release_date'])
    release_dates = releases.loc[releases['release_date'].dt.year == 2026, 'release_date']
    release_wks = set(week_start(release_dates))
    excluded_event_wks = release_wks | {x + pd.Timedelta(weeks=1) for x in release_wks}
    spotify_weeks = weekly(sp, 'daily_streams', 'Spotify UTC daily streams')
    all_weekly, all_pairs, audits, results, readiness = [], [], [], [], []
    platform_col = 'platform_selected' if 'platform_selected' in social else 'platform'
    for p, m in PREDICTORS:
        d = social[(social[platform_col] == p) & (social['metric'] == m)].copy()
        d['value'] = pd.to_numeric(d['value'], errors='coerce')
        xw = weekly(d, 'value', f'{p} {m} Pacific daily')
        xw['platform'], xw['metric'] = p, m
        all_weekly.append(xw)
        for lag in [0, 1]:
            pairs = make_pairs(xw, spotify_weeks, lag)
            pairs['platform'], pairs['metric'], pairs['lag_weeks'] = p, m, lag
            pairs['analysis_id'] = f'{p.lower()}_{m}_lag{lag}'
            good = pairs.dropna(subset=['social_log_change', 'spotify_log_change']).copy()
            levels = pairs.dropna(subset=['social_value', 'spotify_streams'])
            all_pairs.append(pairs)
            x, y = good['social_log_change'].to_numpy(), good['spotify_log_change'].to_numpy()
            n = len(good)
            est = rho(x, y)
            status = 'Exploratory' if np.isfinite(est) else 'Blocked'
            ineligible = ('Only 3 Facebook clicks in 2 weeks; inadequate independent activity variation' if (p, m) == ('Facebook', 'link_clicks') else
                          'All Instagram clicks are zero; coefficient undefined' if (p, m) == ('Instagram', 'link_clicks') else
                          'Facebook interactions undergo a near-zero regime from June; stationary uncertainty not credible' if (p, m) == ('Facebook', 'interactions') else '')
            eligible = np.isfinite(est) and not ineligible
            ci = bootstrap_ci(x, y) if eligible else (np.nan, np.nan)
            # Exclude release/post-release weeks AND prior weeks entering each difference.
            event_mask = good.apply(lambda r: any(t in excluded_event_wks for t in [
                r.social_week, r.spotify_week,
                r.social_week - pd.Timedelta(weeks=1), r.spotify_week - pd.Timedelta(weeks=1)]), axis=1)
            no_event = good.loc[~event_mask]
            loo = [rho(np.delete(x, i), np.delete(y, i)) for i in range(n)]
            keep = np.ones(n, dtype=bool)
            if n:
                keep[np.argsort(np.abs(y))[-2:]] = False
            shifts = {}
            for shift in [-1, 1]:
                v = make_pairs(weekly(d, 'value', f'{p} {m}', shift), spotify_weeks, lag).dropna(
                    subset=['social_log_change', 'spotify_log_change'])
                shifts[shift] = rho(v['social_log_change'], v['spotify_log_change'])
            rec = {
                'analysis_id': f'{p.lower()}_{m}_lag{lag}',
                'question': f'{p} {m} change in week t versus Spotify streams change in week t+{lag}',
                'predictor_platform': p, 'predictor_metric': m, 'outcome': 'Spotify streams',
                'lag_weeks': lag, 'status': status,
                'inference_eligible': bool(eligible), 'inference_exclusion_reason': ineligible,
                'source_social_start': (good.social_week.min() - pd.Timedelta(weeks=1)).date().isoformat() if n else '',
                'source_social_end': (good.social_week.max() + pd.Timedelta(days=6)).date().isoformat() if n else '',
                'outcome_start': (good.spotify_week.min() - pd.Timedelta(weeks=1)).date().isoformat() if n else '',
                'outcome_end': (good.spotify_week.max() + pd.Timedelta(days=6)).date().isoformat() if n else '',
                'first_social_change_week': good.social_week.min().date().isoformat() if n else '',
                'first_spotify_change_week': good.spotify_week.min().date().isoformat() if n else '',
                'n_week_pairs_levels': len(levels), 'n_weekly_change_pairs': n,
                'n_distinct_predictor_changes': len(np.unique(x)),
                'n_nonzero_predictor_weeks': int((levels.social_value > 0).sum()),
                'method': 'Spearman of first differences of log1p complete weekly totals',
                'rho_change': est, 'ci95_low_block4': ci[0], 'ci95_high_block4': ci[1],
                'p_circular_shift': circular_p(x, y) if eligible else np.nan, 'p_resolution': 1 / n if eligible else np.nan,
                'rho_levels': rho(levels.social_value, levels.spotify_streams),
                'social_change_acf1': pd.Series(x).autocorr(1) if len(np.unique(x)) > 1 else np.nan,
                'spotify_change_acf1': pd.Series(y).autocorr(1) if len(np.unique(y)) > 1 else np.nan,
                'rho_without_release_windows': rho(no_event.social_log_change, no_event.spotify_log_change),
                'n_without_release_windows': len(no_event),
                'leave_one_out_min': min(loo) if loo else np.nan,
                'leave_one_out_max': max(loo) if loo else np.nan,
                'rho_without_two_largest_stream_changes': rho(x[keep], y[keep]),
                'rho_social_date_minus1': shifts[-1], 'rho_social_date_plus1': shifts[1],
                'ci95_low_block2': bootstrap_ci(x, y, block=2)[0] if eligible else np.nan,
                'ci95_high_block2': bootstrap_ci(x, y, block=2)[1] if eligible else np.nan,
                'ci95_low_block6': bootstrap_ci(x, y, block=6)[0] if eligible else np.nan,
                'ci95_high_block6': bootstrap_ci(x, y, block=6)[1] if eligible else np.nan,
                'uncertainty_caveat': 'Exploratory only; approximate stationarity/exchangeability of weekly changes; coarse shift p-values; unadjusted 4-week paired moving-block bootstrap percentile CI 2000 replicates; CI is not simultaneous or the dual of shift test; no causal interpretation',
                'limitations': 'Meta Pacific/Spotify UTC nominal weeks; unmeasured campaigns/paid/shows/playlists; first differences share adjacent weeks; release exclusions are sensitivity, not causal adjustment',
                'source_files': 'social/account_daily.csv;spotify/cleaned/artist_daily.csv;raw/spotify_baseline/normalized/release_metadata.csv'
            }
            results.append(rec)
            audits.append({'platform': p, 'metric': m, 'lag_weeks': lag,
                           'daily_rows': len(d), 'duplicate_date_count': int(d.date.duplicated().sum()),
                           'complete_social_weeks': int(xw.complete_week.sum()),
                           'complete_spotify_weeks': int(spotify_weeks.complete_week.sum()),
                           'joined_level_pairs': len(levels), 'joined_change_pairs': n,
                           'join_cardinality': 'one date per account-metric; one week per predictor; one-to-one shifted week pair',
                           'unmatched_or_partial_level_weeks': int(len(pairs) - len(levels)),
                           'missing_social_days_common_window': int(d[d.date.between(START, END)].value.isna().sum())})
            readiness.append({'question': rec['question'], 'status': status,
                              'inference_eligible': bool(eligible), 'inference_exclusion_reason': ineligible,
                              'unit': 'complete calendar-week change pair', 'n': n,
                              'period_start': rec['source_social_start'], 'period_end': rec['outcome_end'],
                              'dependence': rec['limitations'],
                              'next_data': 'Daily paid/organic; dated campaign/show/playlist calendar; tagged-link attribution; aligned cutoff'})
    results = pd.DataFrame(results)
    results['q_bh_12_tests'] = bh(results['p_circular_shift'])
    results['q_by_12_tests'] = np.minimum(1, results['q_bh_12_tests'] * sum(1 / j for j in range(1, 13)))
    results['p_holm_12_tests'] = holm(results['p_circular_shift'])
    results['inference_label'] = 'exploratory assumption-dependent screening; not causal or confirmatory'
    results.to_csv(out / 'statistical_results.csv', index=False)
    pd.concat(all_weekly, ignore_index=True).to_csv(out / 'social_weekly_complete.csv', index=False)
    spotify_weeks.to_csv(out / 'spotify_weekly_complete.csv', index=False)
    combined_pairs = pd.concat(all_pairs, ignore_index=True)
    combined_pairs.to_csv(out / 'joined_week_pairs.csv', index=False)
    pd.DataFrame(audits).to_csv(out / 'join_audit.csv', index=False)
    for question, reason, need in [
        ('TikTok activity and Spotify activity', 'No collected TikTok analytics', 'Verified TikTok identity and daily activity export'),
        ('Social-to-Spotify conversion', 'No person/link attribution or compatible funnel denominator', 'Destination-specific tagged link clicks and measured listening attribution if available'),
        ('Song-specific post effects', 'Post snapshots are cumulative; no comparable activity-by-day and complete song/post links', 'Post/song ID mapping, comparable post-age snapshots, complete song daily streams'),
        ('Paid versus organic incremental effect', 'No complete daily paid exposure/spend or experimental assignment', 'Daily paid/organic exposure and spend; randomized or staggered holdout design'),
        ('Geographic cross-platform correlation', 'Top geography snapshots and windows differ; not exhaustive matched populations', 'Full geography tables for identical periods with definitions and suppression rules')]:
        readiness.append({'question': question, 'status': 'Blocked', 'unit': 'unavailable compatible observation',
                          'n': 0, 'dependence': reason, 'next_data': need})
    pd.DataFrame(readiness).to_csv(out / 'analysis_readiness.csv', index=False)
    plot_results(results, out)
    plot_diagnostics(results, combined_pairs, out)
    plot_distribution(results, combined_pairs, out)
    summary = {
        'title': 'Social and streaming changes do not establish a conversion relationship',
        'status': 'Exploratory', 'planned_tests': 12,
        'inference_eligible_tests': int(results.inference_eligible.sum()),
        'usable_weekly_level_pairs_same_week': int(results.iloc[0].n_week_pairs_levels),
        'usable_weekly_change_pairs_same_week': int(results.iloc[0].n_weekly_change_pairs),
        'usable_weekly_change_pairs_next_week': int(results.iloc[1].n_weekly_change_pairs),
        'q_below_05_count': int((results.q_bh_12_tests < .05).sum()),
        'q_min': float(results.q_bh_12_tests.min()),
        'rho_change_range': [float(results.rho_change.min()), float(results.rho_change.max())],
        'primary_weeks_start': '2026-01-05', 'primary_weeks_end': '2026-10-18',
        'reported_release_dates_2026': [d.date().isoformat() for d in release_dates],
        'results': json.loads(results.to_json(orient='records')),
        'caveat': '12 planned exploratory tests. Nominal UTC/Pacific weeks, unmeasured promotion/release influences, only about 40 changes, and approximate stationarity limit inference. No significant finding does not prove no meaningful relationship.',
        'chart': 'cross_platform/association_intervals.png'
    }
    (out / 'reviewed_findings.json').write_text(json.dumps(summary, indent=2))
    make_report_payload(results, out)
    (out / 'README.md').write_text('''# Cross-platform exploratory analysis

The plan predates coefficient inspection. Run `python code/cross_platform.py` after the two source cleaning scripts. All outputs regenerate without network access. `joined_week_pairs.csv` holds one row per platform/predictor/lag/week; rows from different analyses are repeated analysis views, NOT independent extra observations. `social_weekly_complete.csv` and `spotify_weekly_complete.csv` retain incomplete-week records with null totals. Null is not zero.

Primary effect is Spearman correlation of first differences in log1p weekly totals. Positive values indicate weekly changes tend to move together. The 95% intervals are unadjusted paired moving-block bootstrap percentile intervals (four-week circular blocks, 2,000 replicates, fixed seed); inference requires approximately stationary/exchangeable changes. The intervals are not simultaneous or the dual of the circular-shift test, so an interval excluding zero must not be called a significant finding. Circular-shift p-values retain each predictor's temporal pattern, with about 1/40 resolution. BH adjustment includes all 12 planned tests; BY and Holm are included as conservative dependence sensitivities. Treat all as exploratory; observations are not randomized and confidence intervals do not resolve confounding or calendar misalignment.

Inspect the raw-level diagnostic, release-window removal, influential-week removal, one-day date-boundary sensitivities, and two-/six-week interval sensitivity before interpreting an association. Known releases come from source release_metadata.csv; unknown shows, campaigns, advertising and playlist events remain unadjusted. No weekly unique-person count, follower stock, combined-platform views, or lifetime-post engagement enters these tests. Nothing here estimates a conversion rate.
''')
    print(json.dumps({k: v for k, v in summary.items() if k != 'results'}, indent=2))


def plot_results(results, out):
    plt.rcParams.update({'font.size': 10, 'font.family': 'DejaVu Sans'})
    fig, ax = plt.subplots(figsize=(10, 7.4))
    y = np.arange(len(results))[::-1]
    colors = ['#3172C5' if x == 'Facebook' else '#A33F8D' for x in results.predictor_platform]
    for pos, (_, r), color in zip(y, results.iterrows(), colors):
        if r.inference_eligible:
            ax.plot([r.ci95_low_block4, r.ci95_high_block4], [pos, pos], color=color, lw=2)
        if np.isfinite(r.rho_change):
            ax.scatter(r.rho_change, pos, color=color, marker='o' if r.lag_weeks == 0 else 's', s=42)
            if not r.inference_eligible:
                ax.text(.98, pos, 'descriptive only', ha='right', va='center', fontsize=8, color='#777')
        else:
            ax.text(0, pos, 'undefined: no variation', ha='center', va='center', fontsize=8, color='#777')
    ax.set_yticks(y, [f'{r.predictor_platform} {r.predictor_metric.replace("_", " ")} → {"same" if r.lag_weeks == 0 else "next"} week'
                     for _, r in results.iterrows()])
    ax.axvline(0, color='#999', lw=1, ls='--')
    ax.set_xlim(-1, 1)
    ax.set_xlabel('Spearman correlation of weekly log changes (unadjusted approximate 95% intervals)')
    ax.set_title('Social activity and Spotify streams: 12 planned exploratory comparisons', loc='left', weight='bold', pad=18)
    ax.spines[['top', 'right', 'left']].set_visible(False)
    ax.grid(axis='x', alpha=.15)
    fig.text(.02, .025, 'Jan 5–Oct 18, 2026 complete weeks; UTC/Pacific boundaries differ. No comparison passes multiplicity correction.\nIntervals assume approximately stationary changes and are not simultaneous; unmeasured promotion/release factors remain.', fontsize=9, color='#444')
    fig.tight_layout(rect=(0, .08, 1, 1))
    fig.savefig(out / 'association_intervals.png', dpi=170, bbox_inches='tight')
    fig.savefig(out / 'association_intervals.svg', bbox_inches='tight')
    plt.close(fig)


def plot_diagnostics(results, pairs, out):
    eligible = results[results.inference_eligible]
    fig, axes = plt.subplots(3, 2, figsize=(10, 11))
    for ax, (_, r) in zip(axes.flat, eligible.iterrows()):
        g = pairs[pairs.analysis_id == r.analysis_id].dropna(subset=['social_log_change', 'spotify_log_change'])
        c = pd.to_datetime(g.social_week).map(pd.Timestamp.toordinal)
        ax.scatter(g.social_log_change, g.spotify_log_change, c=c, cmap='viridis', s=32, alpha=.8)
        influential = g.loc[g.spotify_log_change.abs().nlargest(2).index]
        for _, row in influential.iterrows():
            ax.annotate(pd.Timestamp(row.spotify_week).strftime('%b %d'), (row.social_log_change, row.spotify_log_change),
                        xytext=(3, 5), textcoords='offset points', fontsize=7)
        ax.axhline(0, color='#aaa', lw=.7); ax.axvline(0, color='#aaa', lw=.7)
        ax.set_title(f'{r.predictor_platform} {r.predictor_metric.replace("_", " ")}: lag {r.lag_weeks}\nn={r.n_weekly_change_pairs}; rho={r.rho_change:.2f}; BH q={r.q_bh_12_tests:.2f}', fontsize=10, loc='left')
        ax.set_xlabel('Social log1p weekly change'); ax.set_ylabel('Spotify log1p weekly stream change')
        ax.spines[['top', 'right']].set_visible(False)
    fig.suptitle('Diagnostic scatterplots: eligible exploratory change comparisons', weight='bold', y=.995)
    fig.text(.02, .004, 'Each dot is one week pair; color runs from early (purple) to late (yellow). Labels mark two largest stream changes.\nSame dates use Pacific social/UTC Spotify boundaries; no causal attribution. Full sensitivities are in statistical_results.csv.', fontsize=9)
    fig.tight_layout(rect=(0, .04, 1, .98))
    fig.savefig(out / 'scatter_diagnostics.png', dpi=160, bbox_inches='tight')
    plt.close(fig)


def make_report_payload(results, out):
    rows = []
    for _, r in results.iterrows():
        rows.append({
            'comparison': f'{r.predictor_platform} {r.predictor_metric.replace("_", " ")}',
            'lag': 'Same week' if r.lag_weeks == 0 else 'Next week',
            'n': int(r.n_weekly_change_pairs),
            'rho': round(float(r.rho_change), 3) if np.isfinite(r.rho_change) else None,
            'interval': f'{r.ci95_low_block4:.2f} to {r.ci95_high_block4:.2f}' if r.inference_eligible else 'Not estimated',
            'p': round(float(r.p_circular_shift), 3) if np.isfinite(r.p_circular_shift) else None,
            'q_bh': round(float(r.q_bh_12_tests), 3) if np.isfinite(r.q_bh_12_tests) else None,
            'q_by': round(float(r.q_by_12_tests), 3) if np.isfinite(r.q_by_12_tests) else None,
            'p_holm': round(float(r.p_holm_12_tests), 3) if np.isfinite(r.p_holm_12_tests) else None,
            'inference': 'Exploratory' if r.inference_eligible else r.inference_exclusion_reason,
            'analysis_id': r.analysis_id
        })
    source = {
        'label': 'Verified Spotify artist daily baseline and Meta native daily exports',
        'files': ['spotify/cleaned/artist_daily.csv', 'social/account_daily.csv', 'cross_platform/statistical_results.csv', 'cross_platform/analysis_plan.md'],
        'links': ['https://drive.google.com/file/d/1T7ZsJq-iyR3IMoc4hQOqXnzOdTidtbJx/view', 'https://docs.google.com/spreadsheets/d/1gfPLM_kj8mT1bNn0e3sv2udEU3644PR5z_20QMfl3Yc/edit'],
        'filters': ['Complete Monday–Sunday weeks Jan 5–Oct 18, 2026', 'Six predictors × same/next week; twelve planned comparisons', 'Exclude unique-person measures, follower stocks, lifetime post snapshots, and combined FB+IG views'],
        'metricDefinitions': {
            'rho': 'Spearman correlation between adjacent-week log1p activity differences, preserving lag direction: social t vs Spotify t+lag. Same-week n=40; next-week n=39.',
            'interval': 'Unadjusted approximate 95% paired circular moving-block percentile interval; 4-week blocks, 2000 resamples; assumes approximate stationarity. Not simultaneous or the dual of circular p.',
            'p': 'Two-sided all-rotation circular-shift p-value on weekly changes; approximate exchangeability under null and coarse 1/n resolution.',
            'q_bh': 'Benjamini–Hochberg adjusted p, family includes all 12 planned tests; six ineligible tests left null and retained in family denominator.',
            'q_by': 'Benjamini–Yekutieli dependence sensitivity, full family size12.',
            'p_holm': 'Holm familywise adjusted p, full planned family size12.'
        }
    }
    payload = {'queries': {'cross_tests': {'rows': rows, 'source': source, 'methods': [{'language': 'Python', 'code': 'python code/cross_platform.py  # full reproducible methods included in package'}]}},
               'blocks': [
                   {'id': 'cross-platform-findings', 'title': 'Positive associations remain exploratory', 'queryId': 'cross_tests', 'body': '''Across 41 complete calendar weeks, none of the planned social/streaming comparisons passed multiple-testing correction. The smallest BH-adjusted p-value was 0.385; the more conservative BY values were 1.00 and Holm values were at least 0.60. This is insufficient evidence of a reliable relationship, not evidence that promotion has no effect.

The weekly-change correlations were 0.33 for Facebook visits with same-week streams and 0.32 for Instagram visits. Next-week correlations were 0.03 and 0.24 respectively. Instagram interactions had a same-week correlation of 0.42 in raw weekly levels, but only 0.06 after comparing weekly changes, showing why common time patterns can mislead.

Only six comparisons supported exploratory uncertainty estimates. Facebook link clicks totaled three across two weeks; Instagram link clicks were all zero. Facebook interactions fell from 643 in January–May complete weeks to one in June–October, making stationary uncertainty across that series unreliable. These source values are preserved; the reason for that discontinuity is unknown.

The table uses changes between weeks, not person-level conversion. Pacific-time social weeks and UTC Spotify weeks have different boundaries. Release timing, shows, paid promotion, playlists, and shared interest may explain associations. Collect tagged links and a dated event calendar before interpreting marketing impact.'''},
                   {'id': 'cross-platform-tests', 'type': 'table', 'title': 'All twelve planned comparisons', 'queryId': 'cross_tests',
                    'columns': [{'key': k, 'label': label} for k, label in [('comparison', 'Social measure'), ('lag', 'Spotify timing'), ('n', 'Week changes'), ('rho', 'Correlation'), ('interval', 'Approx. 95% interval'), ('p', 'Raw p'), ('q_bh', 'BH adjusted p')]],
                    'note': 'All estimates are exploratory. Intervals are unadjusted block-bootstrap intervals, not simultaneous and not the dual of circular-shift p-values; an interval excluding zero is not a corrected significant finding. Null uncertainty means not estimable responsibly. Full source, BY/Holm corrections, diagnostics, and sensitivities are in the data package.'}
               ]}
    (out / 'report_payload.json').write_text(json.dumps(payload, indent=2))
    definitions = [
        ('week_start', 'Date', 'Monday nominal source-calendar week; Meta Pacific and Spotify UTC stay distinct'),
        ('value', 'Activity count', 'Sum seven observed daily additive counts; null when partial or missing; never a unique-person total'),
        ('social_log_change', 'log count change', 'log(1+social weekly total at t) minus log(1+total at t-1)'),
        ('spotify_log_change', 'log count change', 'log(1+Spotify weekly streams at t+lag) minus log(1+streams at t+lag-1)'),
        ('rho_change', 'Correlation [-1,1]', 'Spearman ranks of paired log changes; undefined for constant data; not causal or conversion'),
        ('lag_weeks', 'Weeks', '0=same week,1=social week t followed by Spotify week t+1'),
        ('n_weekly_change_pairs', 'Paired weeks', 'One distinct record per nominal week pair per analysis; temporal dependence remains; tests share data'),
        ('ci95_low_block4 / ci95_high_block4', 'Correlation bounds', 'Unadjusted approximate paired moving-block percentile interval,4-week blocks,2000 samples,fixed seed; not simultaneous'),
        ('p_circular_shift', 'Probability', 'Fraction of all rotations with absolute rho >= observed; approximate stationary/exchangeable null; coarse resolution'),
        ('q_bh_12_tests / q_by_12_tests / p_holm_12_tests', 'Adjusted probability', 'Full planned testing family12 including unperformed tests in denominator; null not significant,missing or unevaluable'),
        ('inference_eligible', 'Boolean', 'Uncertainty estimated only with nonconstant,not severely sparse,not visibly discontinuous source variation; still exploratory')
    ]
    pd.DataFrame(definitions, columns=['field', 'unit', 'definition_and_aggregation_rule']).to_csv(out / 'data_dictionary.csv', index=False)


def plot_distribution(results, pairs, out):
    eligible = results[results.inference_eligible]
    fig, axes = plt.subplots(2, 3, figsize=(11, 5.5))
    for ax, (_, r) in zip(axes.flat, eligible.iterrows()):
        g = pairs[pairs.analysis_id == r.analysis_id].dropna(subset=['social_log_change', 'spotify_log_change'])
        ax.hist(g.social_log_change, bins=10, color='#347CA5', alpha=.65, label='Social change')
        ax.hist(g.spotify_log_change, bins=10, histtype='step', color='#973C74', lw=2, label='Stream change')
        ax.set_title(f'{r.predictor_platform} {r.predictor_metric}\nlag {r.lag_weeks}', fontsize=10)
        ax.set_xlabel('log1p weekly change'); ax.set_ylabel('Week pairs')
    axes.flat[0].legend(fontsize=7)
    fig.suptitle('Change distributions: sparse clicks and discontinuous Facebook interactions excluded', fontsize=11)
    fig.tight_layout()
    fig.savefig(out / 'distribution_diagnostics.png', dpi=150, bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=BASE)
    main(parser.parse_args().base)
