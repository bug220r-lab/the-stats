"""Consolidate audited domain outputs; never change source evidence."""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]

def read(path): return pd.read_csv(ROOT/path)
def textval(v): return '' if pd.isna(v) else str(v)
def combine(sources,output,rename=None):
    frames=[]
    for domain,path in sources:
        d=read(path)
        if rename: d=d.rename(columns={k:v for k,v in rename.items() if k in d and v not in d})
        d.insert(0,'domain',domain);d['detail_file']=path;frames.append(d)
    pd.concat(frames,ignore_index=True,sort=False).to_csv(ROOT/output,index=False)

def main():
    rows=[]
    for i,r in read('spotify/statistical_results.csv').iterrows():
        rows.append(dict(analysis_id=f'spotify_{i+1:03}',domain='Spotify',question=r.question,status=r.status,
          variables=r.variables,date_ranges=r.periods,observation_unit=r.unit,n_usable=r.n,method=r.method,
          effect_measure='observed difference or descriptive statistic; see question',effect_size=r.effect_size,
          percent_change=r.percent_change,current_value=r.current,previous_value=r.previous,
          ci95_low=r.ci95_low,ci95_high=r.ci95_high,p_value=r.p_value,p_adjusted_bh=r.adjusted_p_value,
          uncertainty=r.uncertainty,limitations=r.limitations,source_records=textval(r.source_file)+' rows '+textval(r.source_rows),
          detail_file='spotify/statistical_results.csv'))
    for i,r in read('social/statistical_results.csv').iterrows():
        rows.append(dict(analysis_id=f'social_{i+1:03}',domain=r.platform,question=r.question,status=r.status,
          variables=r.metric_scope+'; '+r.question,date_ranges=f'{r.previous_start}/{r.previous_end} vs {r.current_start}/{r.current_end}',
          observation_unit=r.unit,n_usable=r.current_observed_days+r.previous_observed_days,
          n_current=r.current_observed_days,n_previous=r.previous_observed_days,method=r.method,
          effect_measure='observed count difference',effect_size=r.effect_absolute,percent_change=r.effect_percent,
          current_value=r.current_value,previous_value=r.previous_value,ci95_low=r.ci_low,ci95_high=r.ci_high,
          p_value=r.p_value,p_adjusted_bh=r.adjusted_p_value,
          uncertainty='Fixed-window descriptive totals; no sampling uncertainty estimated; missing totals remain null',
          limitations=r.limitations,source_records=r.source_files+'; '+r.analysis_row_filter,
          detail_file='social/statistical_results.csv'))
    cross=read('cross_platform/statistical_results.csv')
    for _,r in cross.iterrows():
        rows.append(dict(analysis_id=r.analysis_id,domain='Cross-platform',question=r.question,status=r.status,
          variables=f'{r.predictor_platform} {r.predictor_metric} → {r.outcome}; lag {r.lag_weeks} week(s)',
          date_ranges=f'Social {r.source_social_start}/{r.source_social_end}; Spotify {r.outcome_start}/{r.outcome_end}',
          observation_unit='paired weekly changes',n_usable=r.n_weekly_change_pairs,method=r.method,
          effect_measure='Spearman rho of log1p weekly changes',effect_size=r.rho_change,
          ci95_low=r.ci95_low_block4,ci95_high=r.ci95_high_block4,p_value=r.p_circular_shift,
          p_adjusted_bh=r.q_bh_12_tests,p_adjusted_by=r.q_by_12_tests,p_adjusted_holm=r.p_holm_12_tests,
          inference_eligible=r.inference_eligible,uncertainty=r.uncertainty_caveat,
          limitations=r.limitations+'; '+textval(r.inference_exclusion_reason),
          sensitivity=f'Leave-one-week-out rho [{r.leave_one_out_min}, {r.leave_one_out_max}]; release windows removed rho {r.rho_without_release_windows}; see detail file for boundary/block sensitivities',
          source_records=r.source_files+'; joined_week_pairs.csv filtered by analysis_id',detail_file='cross_platform/statistical_results.csv'))
    results=pd.DataFrame(rows);results.to_csv(ROOT/'statistical_results.csv',index=False)
    combine([('Spotify','spotify/analysis_readiness.csv'),('Social','social/analysis_readiness.csv'),('Cross-platform','cross_platform/analysis_readiness.csv')],
      'analysis_readiness.csv',{'usable_observations':'n','smallest_next_data':'next_data','smallest_additional_data':'next_data'})
    combine([('Spotify','spotify/data_dictionary.csv'),('Social','social/data_dictionary.csv'),('Cross-platform','cross_platform/data_dictionary.csv')],
      'data_dictionary.csv',{'column':'field','units':'unit'})
    combine([('Spotify','spotify/source_file_inventory.csv'),('Social','social/source_inventory.csv')],
      'source_inventory.csv',{'file':'source_file','source_link':'source_url','retrieval_date':'retrieved_at','snapshot_timestamp':'retrieved_at','rows':'source_data_rows'})
    combine([('Spotify','spotify/cleaning_log.csv'),('Social','social/cleaning_log.csv')],
      'cleaning_log.csv',{'action':'operation'})
    combine([('Spotify','spotify/excluded_records.csv'),('Social','social/excluded_records.csv')],
      'excluded_records.csv',{'exclusion_reason':'reason'})
    manifest=json.loads((ROOT/'raw_sha256.json').read_text())
    mismatches=[r['path'] for r in manifest if hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()!=r['sha256']]
    spotify_checks=read('spotify/validation_checks.csv')
    social_checks=read('social/validation_checks.csv')
    checks={
      'raw_source_files_unchanged':not mismatches,
      'spotify_domain_checks_pass':bool(spotify_checks.passed.all()),
      'social_domain_checks_pass':bool(social_checks['pass'].all()),
      'all_12_planned_cross_platform_questions_retained':len(cross)==12,
      'cross_platform_analysis_ids_unique':bool(cross.analysis_id.is_unique),
      'cross_platform_daily_duplicate_keys_zero':bool(read('cross_platform/join_audit.csv').duplicate_date_count.eq(0).all()),
      'no_significant_bh_adjusted_cross_platform_result':bool((cross.q_bh_12_tests.dropna()>=.05).all()),
      'ig_missing_follow_days_still_null':int(read('social/account_daily.csv')['value'].isna().sum())==128,
    }
    validation={'checks':checks,'raw_sha256_mismatches':mismatches,'baseline_preserved':not mismatches,
      'input_files':len(manifest),'result_rows':len(results),'planned_cross_platform_questions':len(cross),
      'inference_eligible_cross_platform_questions':int(cross.inference_eligible.sum()),
      'ci_note':'Marginal block-bootstrap intervals are not simultaneous and are not the inversion of circular-shift tests.',
      'report_note':'Analytical data and claims were independently checked. Browser rendering check is documented separately.'}
    (ROOT/'audit/final_validation.json').write_text(json.dumps(validation,indent=2))
    if not all(checks.values()):raise AssertionError(validation)
    print(json.dumps(validation,indent=2))

if __name__=='__main__':main()
