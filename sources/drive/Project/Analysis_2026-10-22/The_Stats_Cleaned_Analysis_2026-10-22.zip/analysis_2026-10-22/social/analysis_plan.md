# Social-data analysis plan

Recorded before calculating descriptive comparisons and before any cross-platform correlations.

- Audit every native Facebook/Instagram CSV against its retained manifest and file hash. Decode native UTF-16 daily exports and UTF-8 content exports without changing original bytes.
- Preserve each retrieval, source selection window, selected account, native author and row number. Keep Facebook+Instagram combined Views separate from Instagram-only measures.
- Use the latest retained retrieval per account/metric/date for a canonical descriptive view; compare overlaps, retaining all earlier snapshots and logging disagreements. Reindex missing calendar dates to missing, never zero. Exclude October 21 from complete-period comparisons because it was still the current Pacific reporting day at download.
- Compare July 23–October 20, 2026 with the preceding equal 90 days, April 24–July 22. Describe additive activity totals, daily medians, maxima and concentration. Daily reach/viewers remain daily-unique measures: report medians or explicitly labelled person-day sums, never period unique reach.
- Describe full calendar month activity and publication counts, treating October as partial and preserving all genuine spikes. Posting counts are publication events, not dates of engagement.
- For post outcomes, select one latest valid snapshot per platform/post ID. Keep lifetime metrics separate from account daily activity. Report distribution and format summaries for band-authored posts; keep verified collaborations and unverified other authors distinct. Compare same-scope aggregate engagement ratios with their denominators; do not claim same-age superiority from differently aged snapshots.
- Quarantine structurally short Stories records rather than guessing the missing column. Preserve source records and reasons. Any valid earlier snapshot can still be used; do not invent repairs.
- Preserve period UI displays and current follower/audience snapshots separately. Rounded values remain rounded, with numeric value blank. Reconcile only matched metrics/scopes/windows.
- No social-only significance tests are planned: content age, author selection, overlapping audiences, promotion and correlated dates prevent a simple independent-observation interpretation. Cross-platform inference is a separate pre-specified analysis.
- TikTok, first-seven-day post outcomes, complete paid/organic history, watch-time comparisons across formats and attributable streaming conversion are blocked where their required data is absent. Record the smallest missing dataset.
