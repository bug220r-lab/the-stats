# Social-data quality assessment

All 32 native CSV byte hashes match the retained export manifests. Raw inputs remain unchanged. Canonical keys are unique; the pipeline preserves all source versions and creates new outputs. There are no negative native daily values and no overlapping daily/post metric disagreements in the checked comparable fields.

| Issue | Evidence | Severity for analysis | Treatment |
|---|---|---|---|
| Incorrect platform attribution risk | Instagram-selected daily Views contains Facebook+Instagram combined activity; period components reconcile exactly for both retained windows | High | Retain actual scope; no daily Instagram-only reconstruction or conversion ratio |
| Malformed Story rows | 183 of 309 YTD Story rows have 19 fields against a 20-field header | High | Entire malformed records quarantined; no padding/shift guesses; 126 valid Stories explicitly a selected subset |
| Missing follows dates | 166 observed YTD Instagram Follows dates out of 294; 38 observed recent dates out of 90 | High for daily follower analysis | Reindex with null/status; retain UI totals separately; no zero filling |
| Lifetime versus interval mixing | Content exports use Date=Lifetime; daily account exports use interval activity | High | Separate grains, retain retrieval time and post age; no engagement assigned to publication date |
| Partial last date | October 21 was current Pacific date at download | Medium | Flag and exclude from complete-period comparisons; retain observations |
| Native date mismatch with Spotify | Meta Pacific daily bins versus Spotify UTC | High for daily cross-platform inference | Preserve native dates; separate cross-platform analysis states alignment limitations |
| Content author scope | 125 band-authored Instagram feed posts, three verified collaborations, ten other-author associations not independently verified | Medium | Retain native author IDs; summarize scopes separately |
| Duplicate windows | 1,028 daily keys appear in multiple sources; 57 valid post snapshot rows overlap | High if naive concatenation | Latest-retrieval canonical selection; snapshots and overlap audit preserved; zero checked numeric conflicts |
| Rounded and unique measures | Period UI displays such as 23.3K Views/2.6K Reach; daily Reach/Viewers count unique people within each day | High if converted/summed incorrectly | Numeric values blank for rounded displays; no sum of daily unique counts called period unique audience |
| Abrupt change in recorded Facebook interactions | Complete-week review found 643 interactions January–May and one June–October in the cross-platform analysis window; the native feed inventory also falls sharply | Medium, interpretation unresolved | Preserve explicit source zeros. Reduced posting is compatible with the pattern; reporting change or other causes cannot be ruled out. No fabricated correction |
| Paid activity, TikTok and attribution missing | Page-scoped Ad Center only; TikTok signed out; no person-level link-to-stream attribution | High for marketing-effect claims | Block those claims; specify collection gaps |

Exact additive manual/native comparisons agree when definitions/windows match. Rounded displays are checked for scope only, not forced to an exact number. Instagram Follows observed sums agree with period UI values despite omitted dates; this is not sufficient evidence to assign zero to each absent date. Native Facebook Page Views and the Facebook component of the Instagram-selected combined Views export have different observed scopes and are not interchangeable.

All retained performance spikes remain in the analysis. The chart uses a seven-day mean for readability only. No confidence intervals or independent-day significance tests are manufactured for these descriptive results. No topic/song identifiers are inferred from free-text captions; a verified mapping is still needed for song-specific marketing analysis.
