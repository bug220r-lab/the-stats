# Social analytics: cleaned data and handoff

Run from the project root:

```bash
python code/social_pipeline.py
```

The script reads `raw/meta` and writes `social`. Override paths with `--source` and `--output`. It requires Python, pandas, NumPy and matplotlib. It makes no network requests and never writes source files. The original plan is `analysis_plan.md`.

## Supported findings

For July 23–October 20, 2026, compared with the preceding equal 90 days, April 24–July 22, Instagram recorded 1,057 content interactions versus 2,077 (49.1% lower) and 776 profile visits versus 1,383 (43.9% lower). Facebook recorded 1,050 views versus 5,009 (79.0% lower), one content interaction versus 139, and 325 Page visits versus 352. These are complete, non-overlapping native Pacific-date intervals, with 90 observed days each. They describe these exports; they do not estimate a causal marketing effect or sampling uncertainty.

The retained feed inventory also changed sharply. January 1–May 31 contains 112 Facebook posts and 116 band-authored Instagram posts; June 1–October 20 contains one and nine, respectively. Because these windows are 151 and 142 days, their rates are 22.25 versus 0.21 Facebook posts and 23.05 versus 1.90 band-authored Instagram posts per 30 days. Three independently verified Instagram collaborations fall in the later window; ten additional other-author associations fall in the earlier one and remain separate. These are counts in the captured native publication-date exports, not a guarantee that deleted or omitted content never existed. Story activity continued later, with captured valid records through October 16; the Story history is structurally incomplete.

The Instagram-selected Views export is a combined Facebook-and-Instagram metric. Its latest 90-day total is 23,270, comprising 22,591 Instagram views and 679 Facebook views in the period UI. The 679 is a component of this combined metric, not the independently scoped Facebook Page Views series (1,050); do not force them to agree or subtract the Page series to construct daily Instagram views. The combined measure fell 57.1% from 54,252 in the prior 90 days.

## Exploratory content signals

Among band-authored Instagram feed posts, median lifetime views are 1,090 for 33 carousels, 787 for 65 Reels and 702 for 27 images. Corresponding median post ages are about 160, 226 and 194 days. This is an unequal-age, selected observational comparison. It supports testing formats prospectively; it does not establish that a carousel will outperform a Reel at the same age or budget.

Engagement actions mean likes + comments + shares + saves for Instagram feed posts, and reactions + comments + shares for Facebook. The aggregate ratio uses those actions divided by the sum of corresponding post reach over the same eligible records. That denominator is accumulated post reach, with possible repeat people, not unique audience or streaming conversion. `median_post_engagement_per_reach` is a different statistic and is labelled separately.

## Read the tables correctly

- `account_daily.csv`: 3,528 calendar rows, one selected-account/metric/scope/date. Values retain native reporting dates. There are 128 missing Instagram Follows dates; other daily series have complete selected calendar coverage. October 21 is retained and flagged partial, but excluded from complete-window analyses.
- `account_daily_snapshots.csv`: all 4,518 native daily snapshot records, including overlapping windows and the Facebook audience export's Follows section. There are 1,028 overlapping keys with no numeric disagreements. The canonical view chooses the latest retained retrieval; earlier observations remain intact.
- `posts_latest.csv`: one latest structurally valid lifetime snapshot per platform/post ID: 113 Facebook posts, 138 Instagram feed posts and 126 Stories. `post_snapshots.csv` retains 434 valid source rows, including 57 overlapping snapshots; `post_metrics_all_snapshots.csv` preserves all native numeric columns, including Facebook watch-time and retention breakdowns.
- `excluded_records.csv`: all 183 malformed Instagram Story records and their untouched serialized raw fields. These have 19 fields against a 20-field header. No column placement or missing metric is guessed. The remaining 126 Stories are a selected subset and cannot stand for all 309 exported Story records.
- `manual_period_and_current_snapshots.csv`: period summaries and follower stocks, kept outside daily activity. Rounded displays remain strings with null numeric values. Instagram Follows' observed-day sums happen to equal the reported period total, but that does not identify values on omitted dates.
- `audience_snapshots.csv`: follower distribution percentages from lifetime-labelled audience exports. These are displayed percentages, not exact reconstructed follower counts or daily audience composition. Country/city tables are top categories and may not sum to 100%.
- `account_period_summary.csv`, `account_period_comparisons.csv`, `account_monthly.csv`: descriptive comparisons. Daily reach/viewers are not summed into period unique people. All daily medians use observed days only; this matters especially for incomplete Follows series. October is not a complete month.
- `publication_counts.csv` and `publication_period_summary.csv`: publication events only. No lifetime performance is assigned to a publication date.

`source_inventory.csv`, `data_dictionary.csv`, `cleaning_log.csv`, the overlap/reconciliation tables, `validation_checks.csv`, `data_quality.json`, `analysis_readiness.csv`, and `statistical_results.csv` provide the audit trail. `findings.json` supplies reviewed report inputs. Each meaningful comparison in `statistical_results.csv` has dates, calendar/usable day counts, levels, effect, source files/URLs and a reproducible row filter. P-values and confidence intervals are intentionally blank for descriptive census comparisons.

## Dashboard handoff

The canonical daily table is ready for additive activity and properly labelled daily unique metrics. A dashboard must filter partial days by default, show actual metric platform scope, leave gaps visible, and show missing-date coverage when aggregating. Preserve dates in Pacific Time; the cross-platform analysis owns the documented comparison with Spotify's UTC days. Do not shift these daily bins to make them look aligned.

Content views are ready for browsing snapshots, with author scope and post age visible. Always display “lifetime as captured October 22 UTC” beside lifetime totals. Keep verified collaborations, band-authored posts and other-author associations selectable. Exclude quarantined Stories from outcome totals and disclose that the surviving Story population is incomplete. Do not call raw format rankings an experiment.

The social captures are October 22 supplements. Activity through October 20 may be compared on that activity cutoff; the retrieval date is still later. Lifetime/current snapshots cannot be backdated into the original October 20 baseline.

## Prioritized collection improvements

1. For future posts, capture outcomes at 24 hours and seven complete days, with post ID, publication timezone, format, creative/topic label, linked song ID, paid exposure and exact observation timestamp. This is the smallest improvement for fair content comparisons. Predefine reach and engagement-actions/reach as separate outcomes.
2. Export the missing daily Instagram Follows dates or document the platform's omission rule. Re-export the 183 malformed Story records with a verified schema. Until resolved, keep their states missing/quarantined.
3. Collect tagged smart-link destination/campaign activity and campaign promotion dates. Native Instagram Link clicks are zero in these exports; this does not establish that no one used any bio link or other route. Aggregate platform ratios are not streaming conversion rates.
4. Obtain Ads Manager daily spend, impressions, placement and promoted-post mappings for the actual ad account. The Page Ad Center's observed $0/0 ads for an unspecified last-60-day window is not proof that all ad accounts/history were unpaid.
5. Sign in to the correct TikTok Studio account and record its identity, timezone, daily metrics and post exports. No TikTok analytics were collected in the available package. Artist-account availability also remains unverified.

A practical next content test is to alternate comparable band-authored carousel and Reel treatments in a predeclared schedule, measuring each at seven days, using the same song/call-to-action within a block and recording paid promotion. Keep total reach and actions per reach separate. Accumulate enough independent blocks to inspect consistency; do not declare a winner from one unusually successful post or from the current unequal-age medians.
