THE STATS™️ — META AND TIKTOK COLLECTION
Collection date: 2026-10-22 UTC
Status: Partial collection; Meta files saved, TikTok and Ads Manager unfinished.

VERIFIED ACCOUNTS
Facebook: Redacted OH, @redactedbandoh, Page ID 100091779409539.
Instagram: [REDACTED], @redactedbandoh, account ID 17841454335424545.
Meta Business Suite asset ID 118246571240106 and business ID 1796073717406207 are retained as separate identifiers.
TikTok and TikTok for Artists band identities are not yet verified.

FILES SAVED
32 native CSVs: 15 Facebook and 17 Instagram. Original bytes and filenames are preserved in native/ folders. Manual captures are in manual/ folders.
Account trends: native Last 90 days July 23–October 20, 2026, and This year January 1–October 21, 2026.
Content: Facebook posts, Instagram posts/Reels and Instagram Stories for the same selected publication windows, with lifetime/snapshot metrics as labelled by each export.
Native YTD content files contain 113 Facebook posts, 138 Instagram posts and 309 Instagram Stories. Recent-window files overlap those YTD files; do not add row counts across windows.
Follower demographics: lifetime-labelled snapshots. The Facebook audience CSV also includes a daily Follows section.
Additional manual Facebook panels: July 24–October 21, 2026; 50-row partial historical Content Library checkpoint.
Paid promotion: Page Ad Center summary only. No Ads Manager daily/ad-level report was captured.

START WITH
file_index.csv or file_index.json: each dataset's filename, account, source, coverage, granularity, timestamp, status and limitations.
collection_log.json: access history and remaining gaps.
Facebook/native/native_export_manifest.json and Instagram/native/native_export_manifest.json: detailed source metadata, native headers and byte checks.

COVERAGE AND DATA LIMITS
- Native reporting date controls showed Pacific Time. YTD October 21 may be partial: collection occurred before midnight Pacific. Timezone was not shown on the Creator Dashboard manual panels.
- The native 90-day and manual 90-day windows differ by one day. Lifetime, selected-period and current snapshot values are distinct.
- Instagram-selected Results Views combines Facebook and Instagram views. Those daily CSV values are not separable by platform; exact visible period components are retained in the manual totals files.
- Instagram Follows CSVs omit dates: 38 recent-window rows and 166 YTD rows. Missing dates were not filled with zero.
- The original YTD Instagram Stories CSV has 183 data rows with 19 fields against a 20-field header. Bytes are unchanged; alignment of affected fields needs review before analysis.
- Instagram content exports include other-author collaboration rows. The three recent posts were verified as coauthored with @redactedbandoh. Additional YTD authors retain native identities and band-selected export provenance; individual author headers were not checked.
- The 50-row manual history is partial and overlaps native exports. No complete lifetime content-history claim is made.
- Facebook Story insights are switched off. No setting was changed.
- Instagram native post exports omit watch time, retention, completion, traffic sources and sound identifiers. Some visible watch-time values are retained in the manual Content Library checkpoint.
- Daily content-activity exports, additional pre-2026 history and remaining detail panels were not completed before browser disconnection.
- Ad Center displayed $0.00 on 0 ads in the last 60 days and 'You have not created any ads yet.' Exact dates and currency ISO were not shown. This does not establish absence of activity in every ad account or all history.
- TikTok Studio and TikTok for Artists were signed out. No TikTok analytics were collected; paid TikTok history remains unknown.

TO CONTINUE
Reconnect Chrome browser control and sign in directly to the band's TikTok account. Sign in to TikTok for Artists only if an existing band artist/team account is available. Continue the linked Meta Ads Manager check. Credentials must stay in the services' sign-in flows.

No performance conclusions, recommendations, dashboard or Spotify comparison were produced.
