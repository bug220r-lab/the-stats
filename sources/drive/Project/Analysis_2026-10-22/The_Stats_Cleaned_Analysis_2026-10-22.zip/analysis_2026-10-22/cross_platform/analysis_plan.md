# Cross-platform plan — recorded before coefficients

Scope: [REDACTED] Spotify artist 6X14XfGTmB560PF063wXDk and the verified @redactedbandoh Facebook/Instagram accounts. Original Spotify endpoint October 20, 2026; later Meta retrieval stays separately identified. This plan was recorded before computing any cross-platform coefficients.

## Planned questions and family

For each of Facebook and Instagram, test whether weekly link clicks, content interactions, or account/profile visits are associated with Spotify streams during the same week or the next week: six predictors × two lag directions = 12 planned exploratory tests in one Benjamini–Hochberg family. Lag 1 means social activity in week t is compared with Spotify activity in week t+1. No additional lags will be searched. TikTok, song-specific post attribution, paid-effect adjustment, and person-level conversion are blocked by absent compatible data or attribution.

## Observation structure and preparation

Use Jan 1–Oct 20, 2026 common calendar coverage. Aggregate only explicitly observed additive activity into complete Monday–Sunday weeks; the first/last partial weeks and any week with a missing constituent day are excluded. Spotify calendar dates are UTC; Meta calendar dates are Pacific Time. Their nominal calendar weeks overlap substantially but have shifted boundaries. Already aggregated days cannot be exactly converted. No reach, unique listeners, cumulative post metrics, follower stocks, or combined FB+IG Views metric enters the tests. A week contributes once per platform/metric; no track/post replication of artist outcomes.

## Effect and uncertainty

Primary effect: Spearman correlation between first differences of log(1 + weekly activity), paired at the prespecified lag. Differences reduce shared long-run trend; log1p reduces large-count scale effects and permits reported zeros. These are associations between weekly changes, not conversion rates or a causal estimate. Raw weekly-level Spearman correlation is a diagnostic, not an independent confirmatory test. Report all 12 planned results including weak/null estimates.

If enough variation and history remain, report exploratory 95% percentile confidence intervals from 2,000 paired circular moving-block bootstrap samples of four adjacent paired weeks (fixed seed); two- and six-week blocks assess sensitivity. Report two-sided circular-shift randomization p-values by comparing the observed absolute change correlation to all circular rotations of the predictor series, and BH-adjust all 12 tests together. These methods preserve serial patterns within blocks or rotations but require approximate stationarity/exchangeability of the change series under the null. With about 40 weekly changes, p-values have coarse resolution and intervals are approximate. Do not treat them as proof of absence, causal inference, or validated population uncertainty. If sparse variation, obvious nonstationarity, or influential events undermine assumptions, label inferential reliability limited and prioritize effect sensitivities rather than significance.

## Prespecified sensitivity checks

1. Compare raw-level and change correlations; examine lag-1 autocorrelation of each differenced series.
2. Exclude known 2026 release weeks and the following week from both sides of every pair (also exclude predecessor weeks involved in changes).
3. Leave each paired observation out; remove the two largest absolute Spotify weekly log changes. Preserve spikes in the data and label this as sensitivity only.
4. Shift Meta date labels by one day earlier/later before weekly aggregation to bound a plausible calendar-boundary effect; this is an alignment sensitivity, not a timezone correction.
5. Compare bootstrap block lengths 2 and 6 with the primary 4-week block.

No regression or forecast is planned: the history, two documented releases, absent complete campaign/show/paid/playlist event calendar, and unknown exposure attribution do not support a reliable causal model. No ordinary independent-observation p-values will be used.

## Eligibility decision after source variation audit, still before coefficients

The 41 complete weeks contain only three reported Facebook link clicks across two weeks, and zero Instagram link clicks. No interval or p-value will be produced for either clicks series; the Instagram coefficient is undefined, and Facebook is at most a descriptive two-event pattern. Facebook content interactions show a pronounced regime change: 643 in the January–May complete weeks and only one in June–October (19 of the last 20 weeks are zero). The observed zeros are retained; the cause is not established. Because rotation/bootstrapping across this regime does not have a credible stationary basis, both Facebook-interaction tests will be descriptive only. Six planned comparisons remain eligible for assumption-dependent exploratory uncertainty (Facebook visits; Instagram interactions and visits; two lags each). All 12 planned rows remain in the results and conservative testing-family size. Add BY and Holm adjustments as sensitivity to dependence between related predictors/lags; do not interpret unqualified BH as guaranteed error control under arbitrary dependence.

## Smallest next measurements

Retain complete platform daily exports through the same cutoff; collect daily paid/organic activity and a dated release/show/campaign/playlist calendar. Use destination-specific tagged music links and landing-page click timestamps, with post/song IDs, and preserve comparable first-seven-day post snapshots. A prospective randomized or balanced promotion schedule can test a predefined song-level stream outcome without interpreting aggregate correlations as conversions.
