# Spotify analysis plan

Recorded before this script computes results. Preserve the Oct 20 activity endpoint and the Oct 22 collection vintage; late-collected supplemental baseline observations remain a separate vintage.

1. Describe artist additive totals in latest 7/28/90 days, matched preceding windows, and matched Jan 1–Oct 20 year-to-date windows. Use period UI unique listeners only, never daily sums. Compare follower stocks and net changes.
2. Rank track contributions over latest 28 days and prior 28; calculate top-one/top-three share, HHI, numbers of growing/falling tracks, and contribution to artist net change, only with complete daily coverage.
3. Compare original-release first 7/28/90 days only when all days are observed. No significance test across different releases: release cohort, song identity, catalog size, promotion and calendar are confounded.
4. Inspect top daily spikes, median daily activity, and concentration; retain spikes. Sensitivity: compare 28, 90 and matched YTD windows and remove the largest single day from each paired 28-day window as an explicitly exploratory diagnostic.
5. Describe period unique-listener, source and geography measures with compatible windows. Do not sum hierarchical sources or unique people.

Counts are the observed platform population in fixed windows, so descriptive period changes receive no sampling confidence intervals/p-values. This work does not estimate a causal treatment effect. Source inconsistencies and incomplete song histories are explicit limitations. Cross-platform correlation testing is owned by the separate planned cross-platform script.
