# Spotify dashboard handoff

Ready: artist daily additive activity, daily distinct listener counts, endpoint follower stocks, trailing28 audience stocks, period unique listener summaries, recent all14-track stream contribution, and complete launch windows. Show metric-specific units and period definitions. October2026 monthly row is partial and must not be compared with full months as an equal period.

Required caveats: 64/70 full-history recording-metric series complete; all14 stream histories only overlap in the final365 days. Full available history is not lifetime. Funny Guy and The Devil Wears Docs history sums exceed captured all-time counters. Demographic totals disagree with period listeners by1–2. Rounded segment stream shares/ratios remain rounded. Geographic and named playlist tables are Top tables.

Suggested next collection: export missing GOOMH stream dates (659) and Son stream dates (294) only if long-history catalog analysis matters. For future snapshots retain raw files, timestamp/timezone, explicit inclusive bounds, selected metric/filter, artist/recording ID, retrieval vintage and export provenance. Append snapshots; do not deduplicate across vintages by activity date alone. Capture dated promotion/release/show/paid campaign events and attributed links for prospective marketing tests; record gross follows/unfollows separately if available.
