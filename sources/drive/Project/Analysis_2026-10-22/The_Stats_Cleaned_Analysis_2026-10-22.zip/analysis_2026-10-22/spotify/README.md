# Spotify cleaned data and audit

Run `python code/spotify_pipeline.py` from the project folder (Python 3.11+, pandas, NumPy, matplotlib). Defaults are relative to this portable project. Optional flags: `--source`, `--supplement`, `--out`. No credentials or network calls. Inputs remain unchanged.

`cleaned/artist_daily.csv` is the native account-day table. `daily_*` columns use period_start/end. Rolling measures use rolling_window_start/end; follower stocks use stock_as_of_date. `track_daily_long.csv` is one recording-day-metric per original retrieval vintage and contains exact source/row lineage. `recordings.csv` supplies stable IDs and version labels. `artist_period_dashboard.csv` supplies unique listeners and period ratios; never substitute summed daily listeners. `track_28day_comparison.csv` reconciles all 14 recordings to artist totals. `recording_launch_windows.csv` keeps incomplete launches missing rather than zero.

Separate files retain countries, cities, segments, source categories, song locations/playlists, all-time counters, and release-period data. These have different grains and must not be stacked or summed into an artist daily table. Source category parents and children overlap. Source listener counts overlap. Release membership overlaps recording IDs. Playlist and geography Top tables may be incomplete.

`source_daily_supplement.csv`, `recovered_source_periods.csv`, `resume_snapshots.csv`, and `recovered_artist_metrics.csv` preserve later retrievals. Baseline-period supplements are a distinct retrieval vintage; a matching date window does not prove there were no historical revisions. Nothing overwrites the original October20 cutoff snapshot.

Validation and documentation: source_file_inventory.csv inventories every original/supplement archive file; validation_checks.csv records recomputed checks; cleaning_log.csv records substantive actions; excluded_records.csv preserves one invalid period capture; data_quality_issues.csv and analysis_readiness.csv explain limits; statistical_results.csv retains supported descriptive comparisons and blocked questions. analysis_plan.md predates the script’s numerical calculations. data_dictionary.csv defines every exported field; original source dictionaries remain in raw/spotify_baseline.

No Spotify-only p-values or confidence intervals were manufactured. Fixed-window observed population changes are descriptive; release windows are observational and confounded. Cross-platform inference is in the separate analysis pipeline.
