import React from 'react';
import { DataComponent, DataTable, EvidenceChart, ReportSection, RichNarrative, useDataApp } from '../../data-app-public.jsx';

function EvidenceBlock({ block, queries }) {
  const { visible } = useDataApp();
  if (!visible(block.id)) return null;
  const query = queries[block.queryId];
  const rows = query?.rows || [];
  const sourceRowsByQuery = Object.fromEntries((block.queryIds || [block.queryId]).filter(Boolean).map(id => [id, queries[id]?.rows || []]));
  if (block.type === 'chart') return <div className="stats-evidence-group">
    {block.intro && <ReportSection id={`${block.id}-interpretation`} title={block.title} queryId={block.queryId} queryIds={block.queryIds} sourceRowsByQuery={sourceRowsByQuery} showHeading={false}><RichNarrative id={`${block.id}:intro`} value={block.intro} /></ReportSection>}
    <EvidenceChart id={block.id} queryId={block.queryId} title={block.title} rows={rows} sourceRows={rows} spec={block.spec} height={block.height || 340} description={block.description} />
    {block.note && <RichNarrative id={`${block.id}:note`} value={block.note} className="stats-figure-note" />}
  </div>;
  if (block.type === 'table') return <div className="stats-evidence-group">
    {block.intro && <RichNarrative id={`${block.id}:intro`} value={block.intro} />}
    <DataComponent id={block.id} queryId={block.queryId} kind="table" title={block.title} sourceRows={rows} displayRows={rows} description={block.description}>
      <DataTable rows={rows} columns={block.columns.map(column => ({...column, renderCell: value => typeof value === 'number' && Number.isFinite(value) ? new Intl.NumberFormat('en-US', {maximumFractionDigits: 3}).format(value) : String(value ?? '—')}))} searchable={false} caption={block.title} />
    </DataComponent>
    {block.note && <RichNarrative id={`${block.id}:note`} value={block.note} className="stats-figure-note" />}
  </div>;
  return block.queryId ? <ReportSection id={block.id} title={block.title} queryId={block.queryId} queryIds={block.queryIds} sourceRowsByQuery={sourceRowsByQuery} showHeading={false}>
    <RichNarrative id={`${block.id}:body`} value={block.body?.startsWith('#') ? block.body : `## ${block.title}\n\n${block.body}`} className={block.className || ''} />
  </ReportSection> : <section><RichNarrative id={`${block.id}:body`} value={block.body} /></section>;
}

export function ReportContent() {
  const { snapshot, appTitle, setAppTitle, canEdit, mode } = useDataApp();
  const report = snapshot.report || {};
  const blocks = report.blocks || [];
  return <article className="report-content stats-report" aria-label="Music and marketing findings report">
    <header className="report-hero">
      <RichNarrative id="report:eyebrow" value="THE STATS™ · DATA AUDIT & ANALYSIS" className="stats-eyebrow" />
      <h1 data-data-app-title contentEditable={canEdit && mode === 'edit'} suppressContentEditableWarning onBlur={canEdit && mode === 'edit' ? e=>setAppTitle(e.currentTarget.textContent.trim() || appTitle) : undefined}>{appTitle}</h1>
      <RichNarrative id="report:description" value={report.subtitle || 'A source-backed review of music, audience and marketing performance.'} className="report-deck" />
    </header>
    {blocks.map(block=><EvidenceBlock key={block.id} block={block} queries={snapshot.queries || {}} />)}
  </article>;
}
