# Editable findings report

`../report/The_Stats_Findings_Report.html` is the portable self-contained delivery. This directory retains the canonical report source and its stable app ID. The report is not a dashboard and no site was published.

Edit report composition in `src/content/report/ReportContent.jsx`, scoped presentation in `src/content/report/report.css`, and reviewed evidence in `src/data.json`. Read `AGENTS.md` before changes. Product-owned runtime files are preserved and must not be edited for routine content work.

Regenerate reviewed report data from the analysis project root:

```bash
python code/build_report_snapshot.py
```

That script reads the reviewed Spotify, social and cross-platform outputs, then writes this directory's snapshot. It does not rebuild the HTML automatically. Use the installed Data Analytics plugin's supported build and export commands, setting the paths to your installation:

```bash
node "$DATA_PLUGIN_ROOT/scripts/data-app.mjs" build --project-dir "$REPORT_PROJECT" --separate-data
node "$DATA_PLUGIN_ROOT/scripts/data-app.mjs" export-offline --project-dir "$REPORT_PROJECT" --output "$REPORT_PROJECT/.data-app-offline/exports/The_Stats_Findings_Report.html"
```

Set `REPORT_PROJECT` to this directory and `DATA_PLUGIN_ROOT` to the installed Data Analytics plugin. Original build used Data Analytics 1.0.11, API 1. Copy the newly exported HTML to the delivery report directory only after checking the updated evidence and presentation. No package installation is required for the supported prebuilt-runtime build.

See `../report/REPORT_DELIVERY_QA.md` for completed checks and the disclosed browser visual-QA limitation. The analysis pipeline and report assembler are separate so a data rerun cannot silently refresh prose without a reviewed report rebuild.
