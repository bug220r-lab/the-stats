# Final report quality assurance

Final build: 22 October 2026, after collection freeze.

## Artifact checks

- Editable document: `deliverables/The_Stats_Report.docx`.
- PDF: `deliverables/The_Stats_Report.pdf`; 20 pages, 42 bookmarks and 10 active external source links.
- Source: `analysis/build_report.py`.
- Final render: `analysis/report_final_qa/page-1.png` through `page-20.png`.
- All 20 final pages were individually visually inspected at full-page resolution. No clipped text, overlapping elements, broken tables, blank overflow pages, unreadable charts or unresolved placeholder content was found.
- All 20 planned sections occupy their intended page. Final catalog table includes all 14 recordings and the recovered 2024 album recording of ¡La Cocaína!.
- Pages 2 and 19 explicitly state the 64/70 complete daily-series coverage, Cut-only detailed song-source coverage, seven song Location errors and eleven song Playlist errors. Page 11 distinguishes Son!'s 730 observed stream days from continuous full history and GOOMH!'s 365 retained days.
- All eight release-engagement combinations, the aggregate/tier contradictions and cross-view baseline mismatch are retained. All-time contradictions are separated from legitimate pre-2024 scope differences.
- Original-release launch windows remain distinct from album-anchored presets.
- No unresolved drafting markers remain.

## Independent review

- The independent reviewer inspected stable draft pages 2-10 and 16-20 visually and found no layout defects.
- Independent source/arithmetic audit is in `analysis/validation.md`. It records exact check counts, source paths and deltas rather than a blanket pass.
- The audit found a stale Son! full-period snapshot; the catalog normalizer excluded the invalid capture, retained its raw evidence, and the reviewer confirmed the corrected canonical output before final render.
- Current and prior artist-period comparisons, daily stream reconciliation, release histories, audience, demographic, geographic, playlist and feature evidence were checked; source-level disagreements and collection limits remain explicit.

## Reproduction

Run `analysis/build_report.py` with python-docx available, then use the documents skill's `render_docx.py` with `--emit_pdf`. The final PDF is the rendered version of the delivered DOCX, not a separately authored layout. The chart PNGs and normalized data are inputs retained in the source package.

## File integrity

| File | Bytes | SHA-256 |
|---|---:|---|
| The_Stats_Report.docx | 1,167,126 | 35dd56e9c631e1c49606d0952a5651346b626c99ddb1e8bb721a13388ec2f927 |
| The_Stats_Report.pdf | 1,461,693 | 077e2d8abfd30841a7a2a2bf71fee0120e11fa9c39da3d88d3384e208fe08621 |
