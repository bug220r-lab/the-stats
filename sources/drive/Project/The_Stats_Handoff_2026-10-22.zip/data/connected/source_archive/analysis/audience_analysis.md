# Audience analysis — captured Spotify for Artists evidence

Latest 28-day reporting window: September 23–October 20, 2026, Worldwide. Audience stocks are as of October 20. Source data are visible DOM/chart labels, not native CSV exports. Standard demographic and location views only provide the latest 28 days; do not interpret these snapshots as historical audience composition.

## Audience depth

The two-year total audience is **12,351**, comprising **791 monthly active**, **4,672 previously active**, and **6,888 programmed** listeners. Spotify displays rounded shares of **6%, 38%, and 56%** respectively. This denominator is distinct from the latest 28-day monthly-listener total of **1,062**. Monthly active therefore represent **74.5%** of monthly listeners, while their displayed share of streams is **91%** (rounded). These are audience segments, not source-of-stream categories: an active listener can also use programmed sources.

Monthly active listeners comprise **47 super (6%)**, **230 moderate (29%)**, and **514 light (65%)** listeners. Displayed streams/listener are **40.1, 5.7, and 1.3** respectively (monthly active overall: **4.9**). These rates and percentages are rounded; multiplying them by counts does not recover exact stream counts. The definitions distinguish light as 1–2 intentional streams, moderate as 3–14, and super as 15+; do not substitute the displayed total streaming rate for the intentional-stream classification threshold.

Across the observed rolling stock history from **September 23 to October 20**, total audience increased **296 (+2.5%)**, monthly active increased **2 (+0.3%)**, previously active increased **114 (+2.5%)**, and programmed increased **180 (+2.7%)**. Super listeners rose **42→47 (+11.9%)**, moderate **231→230 (−0.4%)**, and light **516→514 (−0.4%)**. These are changes between the first and last observed stocks, not growth between two nonoverlapping 28-day cohorts. All three total-audience components and all active subsegments reconcile on all 28 chart dates.

The latest-28-day flow cards report **309 reactivated**, **153 new active**, and **350 new listeners**. Preserve these as separate measures; they do not supply an additive unique audience, conversion funnel, retention rate, or churn count. The nearly flat active stock alongside substantial activation flows identifies a useful retention question, but the captures do not identify which listeners left, returned, or progressed between tiers.

Sources: `audience_segments.txt`, `audience_segments_active.txt`, `audience_segments_active_chart.json`, `audience_segments_total_history_chart.json`, `audience_28day_listeners.txt`. Definitions: `analysis/definitions_notes.md`, section 5.

## Demographic composition and reconciliation

Displayed gender shares are **male 62% (655)**, **female 26% (278)**, **not specified 11% (121)**, and **non-binary 1% (10)**. Displayed age shares are **25–34: 39%**, **18–24: 30%**, **under 18: 11%**, **35–44: 11%**, **45–54: 7%**, **55–64: 2%**, and **65+: 0%**. The core 18–34 brackets account for 739 age-cell listeners and the two displayed rounded shares sum to 69%; this is not a separately displayed combined percentage. The snapshot describes the captured audience, not a recommended targeting exclusion.

**Unresolved source discrepancy:** gender counts sum to **1,064**; age-by-gender cells sum to **1,063**; the artist 28-day unique-listener total is **1,062**. The gender view shows 655 male listeners, while male age cells sum to 654. All captured counts and displayed percentages are retained. No rescaling or extra “unknown” listeners were invented. The 65+ group has five listeners despite its displayed rounded 0% share. Explicit zero cells are stored as observed zero; they are not missing values.

Sources: `audience_demographics.txt`, `audience_age_chart.json`, `audience_28day_listeners.txt`.

## Geography

The expanded Top countries table contains **23 rows** and the Top cities table contains **50 ranks**. Both remain Top/ranked coverage; all visible rows are captured, but full geographic coverage is not established. The country listener rows sum to **1,022** (96.2% of the 1,062 artist total as a reconciliation diagnostic), and the city listener rows sum to **436** (41.1%). Do not label the arithmetic residuals “other unique listeners” or infer a complete disjoint location partition from these tables.

The **United States has 777 listeners**, equal to **73.2%** of the artist's monthly-listener total, and **637 active listeners (82% displayed)**. The next largest displayed countries are the **United Kingdom (50)**, **Canada (44)**, **Germany (24)**, and **Netherlands (15)**. Cleveland (24), Columbus (23), and Akron (23) are the leading city rows; small counts make precise city-level response forecasts unsupported. Current geographic concentration supports testing local engagement in Ohio and adjacent markets, with explicit measurement, rather than assuming that listener counts equal reachable or ticket-buying fans.

**Peru has four listeners and dashes for both active percentage and active-listener count.** The normalized file keeps those two values blank with status `not_reported_dash`; they are not zero and the capture does not establish why they are absent. The sum of reported country active counts is 775, excluding the unavailable Peru value; this does not reconcile to 791 worldwide monthly active and is not forced to do so. Tiny-country active percentages are descriptive and should always be shown beside their counts (e.g. Poland 10/12; Denmark 5/6).

Sources: `geography_tables.json`, `audience_locations_all_available.txt`, `audience_28day_listeners.txt`.

## Actionable interpretation and limits

1. Track movement of the 514 light listeners toward moderate activity in comparable future snapshots. The current distribution supports a repeat-listening opportunity, but not a predicted conversion rate.
2. Maintain consistent contact and repeat-listening opportunities for the 47 super listeners without claiming listener identities are available. Monitor rolling stocks and release-cohort engagement separately.
3. Compare future regional activity against the current U.S./Ohio concentration, retaining both counts and rates. Small cells and Top-table truncation limit fine-grained allocation conclusions.
4. Investigate the demographic mismatch before using these counts for exact audience reconciliation. Retain displayed rounded shares for broad descriptive interpretation.

The platform's generic listener/stream benchmarks in the segment view are not a genre-, scale-, geography-, or release-age-matched peer benchmark. No causal effects, revenue forecasts, advertising ROI, or individual demographic attributes are inferred.

## Outputs

- `normalized/audience_segment_snapshot.csv` — latest two-year segment partition and observed active stream share.
- `normalized/audience_segment_daily.csv` — 28 daily rolling audience stocks, with all active subsegments.
- `normalized/audience_active_subsegments.csv` — current count, rounded displayed share and streams/listener.
- `normalized/audience_development.csv` — separate latest-28-day flow cards.
- `normalized/audience_demographics_gender.csv`, `audience_demographics_age.csv`, `audience_demographics_age_gender.csv` — counts and rounded shares, without forced reconciliation.
- `normalized/audience_top_countries.csv`, `audience_top_cities.csv` — all displayed ranked locations, missing-value status, raw city labels.
- `charts/audience_segments.png`, `audience_demographics.png`, `audience_top_locations.png` — reproducible static figures.

Reproduce with `analysis/analyze_audience.py`. Chart values derive from the normalized structures in that script. Every figure is scoped to the captured reporting date and population.
