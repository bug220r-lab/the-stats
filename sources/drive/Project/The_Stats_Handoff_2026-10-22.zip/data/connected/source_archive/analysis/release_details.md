# Release detail audit

Seven release detail pages were inspected read-only. Every release has direct overview metrics for the latest 7 days, latest 28 days, latest 12 months, and the custom January 1, 2024–October 20, 2026 window. The custom chart exposes **1,024 consecutive daily stream labels per release** (7,168 rows total). Native CSV export was not exposed on the inspected release detail pages; the retained evidence is rendered DOM and chart accessibility labels, not a claimed native export.

| Release | Release date | All-time header | Jan 2024–Oct 20, 2026 | Latest 12 months | Latest 28 days | Latest 7 days |
|---|---|---:|---:|---:|---:|---:|
| The Cut (Starts Tomorrow) | 2026-04-24 | 5,294 | 5,294 | 5,294 | 539 | 154 |
| [REDACTED] | 2024-05-31 | 81,263 | 81,391 | 45,748 | 3,142 | 857 |
| The Devil Wears Docs | 2026-02-13 | 11,861 | 11,872 | 11,872 | 510 | 160 |
| Lab Tapes | 2023-05-19 | 5,250 | 2,785 | 1,043 | 55 | 15 |
| Crawl | 2024-05-10 | 11,579 | 11,579 | 6,342 | 399 | 111 |
| Funny Guy | 2024-04-12 | 29,786 | 30,549 | 21,168 | 1,488 | 386 |
| GOOMH! | 2023-12-15 | 8,554 | 7,919 | 3,748 | 210 | 45 |

All figures above are **streams**. Period unique listeners, playlist adds, saves, rounded displayed streams/listener, and observed prior-period stream counts are in `normalized/release_periods.csv`. Missing prior-period values remain blank with explicit status. Do not calculate distinct-listener conversions from sums of daily listeners or release listeners.

## Reconciliation

The full daily series reproduces **28 of 28** captured period stream cards. Period chart arrays where captured also agree with their card. Crawl's shorter-window chart arrays were not separately retained, but its direct period cards are verified against slices of its full 1,024-day chart. For those three rows, exact bounds are derived from the full chart endpoint and selected 7/28/365-day length and labeled accordingly. All other bounds come directly from retained chart date labels.

Three contradictions remain: **Funny Guy's custom history totals 30,549 streams versus an all-time header of 29,786** (history exceeds header by **763**); the **[REDACTED] album totals 81,391 versus an all-time header of 81,263** (exceeds by **128**); and **The Devil Wears Docs totals 11,872 versus an all-time header of 11,861** (exceeds by **11**). Both values are retained for each release. The captures do not explain the discrepancies, so no source is silently corrected or treated as reconciled. GOOMH! and Lab Tapes were released in 2023, before the daily-history start; their smaller 2024-onward sums need not equal lifetime totals, but the unavailable earlier daily history cannot be reconstructed from the residual.

## Nonadditivity and scope

The album and singles share recordings. Release totals must not be added into artist totals or described as distinct catalog streams without deduplication by recording. Period release listeners also overlap and cannot be summed into artist unique listeners. Compare the releases individually; use the separate recording-level audit for a deduplicated catalog view. All-time cumulative counts do not establish an all-time daily history.

The release pages expose a checklist and Share your stats control. They were not used to create campaigns or publish content. No account data changed.

## Outputs

- `captured/agent_release_<release_id>_bundle.json`: seven bundles, each preserving four selected-period DOM snapshots, URLs, timestamps, and captured chart labels.
- `normalized/release_metadata.csv`: seven release identities, dates, all-time headers, daily-history scope and reconciliation status.
- `normalized/release_periods.csv`: 28 direct period overview rows.
- `normalized/release_daily_streams.csv`: 7,168 daily rows, retaining release ID and source filename.
- `normalized/release_detail_reconciliation.csv`: 28 period-card versus full-chart checks.
- `analysis/release_details.json`: machine-readable summary and issues.

Reproduce with `analysis/analyze_release_details.py`. Definition context: `analysis/definitions_notes.md`, especially release/song duplication and history limits.
