# Song location audit

All **14 song Location pages** were checked on October 22, 2026 for the latest 28 days, **September 23–October 20, 2026**. **Seven returned tables; seven returned Spotify's “Something went wrong” / “problem on our end” errors** for country comparison, Top countries, and Top cities. John Doe and the 2024 album recording of ¡La Cocaína! were reloaded once, with the same error. The remaining error pages were recorded without repeated recovery attempts. These are unavailable results, not zero activity.

## Metric and coverage

These song tables report **streams**, whereas the artist Location view reports **listeners**. Do not compare or combine those measures as equivalent audience counts. No active-listener counts or percent-active columns were displayed in the song location views.

The seven available pages contain **138 country rows** and **350 city rows** in total. Each available city table ends at **rank 50**. The available country tables retain their **Top countries** qualification; they show varying row counts and no additional Show More / below 1 percent controls. Six of seven available country sums match the corresponding latest 28-day song stream totals in `song_catalog_periods.csv`. Funny Guy’s country rows sum to **1,484**, four below its **1,488** song streams. The difference remains an unreconciled geographic residual, not an invented “Other” country. Matching sums for the other songs are useful checks, not independent proof of exhaustive geography or mutually exclusive listener populations.

| Recording | Country rows | Country stream sum | City rows | Leading city (streams) |
|---|---:|---:|---:|---|
| Funny Guy | 47 | 1,484 | 50 | Fort Worth (38) |
| The Cut (Starts Tomorrow) | 19 | 539 | 50 | Cleveland (23) |
| The Devil Wears Docs | 24 | 510 | 50 | Miami (26) |
| Crawl | 17 | 399 | 50 | Miami (30) |
| GOOMH! | 12 | 210 | 50 | Anchorage (14) |
| THIS MACHINE | 9 | 190 | 50 | Miami (26) |
| Waste Away | 10 | 190 | 50 | Miami (25) |

The United States is the top country in every available table. This supports a broad geographic concentration statement for the seven covered songs only. Small city counts are descriptive and do not establish reachable fans, ticket buyers, advertising conversions, or causal market potential.

## Unavailable song pages

- Method Acting (album, 2024) — `1CczfJ6sfBFVohNwW7T0nA`
- Son! (Hidden Track) — `2PWQKZvFk6wRGZmcgBzWRy`
- Goodnight Mrs. Henderson — `3Bmzrteo6IStTEPm13a1zZ`
- ¡La Cocaína! (album, 2024) — `54PvxNbXvtB1WXjVgJxNAk`
- ¡La Cocaína! (Lab Tapes, 2023) — `5SznyhiUBgOGjdMKZq8kye`
- Method Acting (Lab Tapes, 2023) — `6ZGIMyU6p94qLhzLB7kmWV`
- John Doe — `6qzVbJkXPRZNxX5rGCfCNj`

Each error page has its own capture bundle and coverage row. `country_stream_sum`, `city_stream_sum`, and top-location values are left blank for those pages. A zero in `country_rows_captured` or `city_rows_captured` means no rows were retrieved, not zero streams. No locations were inferred from another song, an artist-level table, a matching title, or a prior period.

## Country comparison charts

For each available song, the page also exposes 28 daily labels for three default selected countries. These yield **588 country/day rows** across the seven songs, kept separately in `song_location_country_comparison_daily.csv`. The first chart label names each country; subsequent labels sometimes omit names. The normalized country labels are carried forward by the same observed series position, with that derivation recorded in `country_label_status`. The chart selection is not a complete country panel. All original chart labels remain in the bundles and normalized rows.

## Files and provenance

- `normalized/song_locations.csv` — 488 ranked country/city observations, with song ID, recording label, metric, missing/zero status, and exact source.
- `normalized/song_location_coverage.csv` — 14 checked pages, including seven unavailable statuses and reconciliation diagnostics.
- `normalized/song_location_country_comparison_daily.csv` — limited selected-country daily chart observations.
- `captured/agent_song_location_<song_id>_bundle.json` —DOM snapshot, rendered table cells, chart labels, observed URL and collection timestamp for each page.
- `analysis/song_locations.json` —summary and validation results.

These are DOM-derived captures, not native CSV exports. All UI work was read-only; no saved country selections or account settings were changed. The temporary browser tab was closed. Reproduce normalization with `analysis/analyze_song_locations.py`.
