"""Normalize read-only Campaigns and Video & Visuals DOM captures."""
import csv
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CAP=ROOT/"captured";OUT=ROOT/"normalized"
manifest=json.loads((CAP/"agent_features_manifest.json").read_text())
meta={r["file"]:r for r in manifest}
rows=[]
def add(feature,entity,metric,value,status,unit,ui_status,source,note="",date_scope="Current UI at collection"):
    m=meta[source]
    rows.append({"feature":feature,"entity":entity,"metric":metric,"value":value,"value_status":status,"unit":unit,"ui_status":ui_status,"date_scope":date_scope,"observed_at":m["collected_at"],"source":source,"source_url":m["url"],"note":note})

c=(CAP/"agent_features_campaigns.txt").read_text()
sc=(CAP/"agent_features_subcampaigns.txt").read_text()
am=(CAP/"agent_features_artist_message.txt").read_text()
assert 'heading "No campaigns yet"' in c
assert 'heading "No sub-campaigns yet"' in sc
assert 'You don’t have any time-sensitive opportunities at the moment' in c
assert 'Submit before Nov 6th' in am and 'button "Submit now"' in am
add("Display campaigns","Artist account","campaigns_displayed",0,"observed_explicit_empty","campaigns","No campaigns yet","agent_features_campaigns.txt","Scope is the displayed account Campaigns list, not a claim about spending through every advertising platform.")
add("Display campaigns","Artist account","subcampaigns_displayed",0,"observed_explicit_empty","subcampaigns","No sub-campaigns yet","agent_features_subcampaigns.txt")
add("Display campaigns","Artist account","time_sensitive_opportunities_displayed",0,"observed_explicit_empty","opportunities","No time-sensitive opportunities at the moment","agent_features_campaigns.txt","UI still offers promotion of catalog with Showcase; no campaign was created.")
add("Display campaigns","Artist account","create_campaign_control",None,"qualitative_status","","Create campaign offered","agent_features_campaigns.txt","Marquee and Showcase are described in onboarding. An offered button alone does not confirm every campaign's eligibility, cost, or expected performance.")
add("Display campaigns","Artist account","performance_results",None,"not_available_empty_list","","No results displayed","agent_features_campaigns.txt","Do not substitute zeros for spend, reach, conversion, incremental streams, or ROI; those metrics are unavailable here.")
add("Artist Message","2026 Wrapped","submission_opportunity",None,"qualitative_status","","Submit now offered; Submit before Nov 6th","agent_features_artist_message.txt","No submission was opened or created. The landing page alone does not establish submission history or performance. Deadline year 2026 inferred from displayed 2026 Wrapped label.","2026 Wrapped")
add("Artist Message","2026 Wrapped","video_duration_limit",30,"observed","seconds","Up to 30 seconds; limit 1 per artist","agent_features_artist_message.txt","Displayed instructions say no music, lyrics, singing, or explicit content.","2026 Wrapped")

files=["agent_features_canvas_the_cut.txt","agent_features_canvas_devil_wears_docs.txt","agent_features_canvas_album.txt","agent_features_canvas_crawl.txt","agent_features_canvas_funny_guy.txt","agent_features_canvas_goomh.txt","agent_features_canvas_lab_tapes.txt"]
inventory=[];canvas_summary=[]
for fn in files:
    s=(CAP/fn).read_text()
    h=s.split('region "Selected release header":',1)[1].split('region "Canvas list"',1)[0]
    title=re.search(r'heading "(.+)" \[level=3\]',h).group(1)
    typ,year=re.search(r'paragraph: (.+) · (\d+)',h).groups()
    body=s.split('region "Canvas list"',1)[1].split('- generic: ©',1)[0]
    names=re.findall(r'heading "(.+)" \[level=3\]',body)
    assert 'button "Add Canvas"' in body
    for i,name in enumerate(names,1):
        inventory.append({"release":title,"release_type":typ,"release_year":int(year),"card_position":i,"track_label":name,"status":"Track card displayed in Canvas view; published asset unverified","source":fn,"source_url":meta[fn]["url"],"observed_at":meta[fn]["collected_at"],"note":"Release-level card appearance; track identifiers and asset identifiers not captured. Repeated labels across releases are not deduplicated."})
    add("Canvas",title,"cards_displayed",len(names),"observed_zero_cards" if not names else "observed","release-level card appearances","Add Canvas and named cards displayed" if names else "Only Add Canvas displayed",fn,"Card inventory only, not views or engagement. Add Canvas is a global action and does not mean existing cards are absent.")
    canvas_summary.append({"release":title,"cards":len(names),"labels":names,"source":fn})
assert len(inventory)==15
add("Canvas","All seven displayed releases","card_appearances_total",len(inventory),"observed_count_of_displayed_cards","release-level card appearances","15 card appearances across 6 of 7 releases","agent_features_canvas_album.txt","Derived from all seven Canvas captures. Repeated track labels across releases prevent treating this as 15 unique assets.")
add("Canvas","Captured inventory","performance_metrics",None,"not_displayed_in_captured_UI","","No performance results on captured Canvas inventory","agent_features_canvas_album.txt","Unavailable is not zero. A card detail click opened a Confirm your team prompt; it was canceled without selecting or confirming a team.")
add("Canvas","Funny Guy card detail","detail_access",None,"workflow_stopped_before_team_confirmation","","Confirm your team prompt; canceled","agent_features_canvas_detail_team_prompt.txt","No update, replacement, upload, or deletion occurred. Inventory evidence was already available outside this detail flow.")

for name,data in [("content_feature_status.csv",rows),("canvas_card_inventory.csv",inventory)]:
    with (OUT/name).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
summary={"collected_date":"2026-10-22","campaigns_displayed":0,"subcampaigns_displayed":0,"campaign_results":"not_available_empty_list","artist_message":{"label":"2026 Wrapped","status":"Submit now offered","deadline_displayed":"Submit before Nov 6th","deadline_year_inferred":2026,"max_duration_seconds":30,"submission_history":"not_established"},"canvas":{"release_selectors_observed":7,"release_rows":canvas_summary,"card_appearances":15,"distinct_track_labels":len({r["track_label"] for r in inventory}),"unique_asset_count":"not_established","performance_metrics":"not_displayed","detail_prompt":"team_confirmation_canceled"},"mutations":"No campaigns, uploads, settings changes or submissions performed","source_manifest":"captured/agent_features_manifest.json"}
(ROOT/"analysis/content_features.json").write_text(json.dumps(summary,indent=2)+"\n")
table="\n".join(f'| {x["release"]} | {x["cards"]} |' for x in canvas_summary)
md=f'''# Campaign and content feature status

Read-only account inspection on **October 22, 2026**, using visible Spotify for Artists UI. Exact observed URLs and collection timestamps are in `captured/agent_features_manifest.json`. Private Campaigns/Video & Visuals capabilities were unavailable through the Spotify catalog connector, so the authorized browser session supplied the evidence.

## Campaigns

The **Display → Campaigns** list explicitly says **“No campaigns yet.”** The **Sub-campaigns** tab independently says **“No sub-campaigns yet.”** These are observed empty states for the displayed account lists. They do not establish that the artist has never advertised through any other channel.

The UI offers **Create campaign** and describes **Marquee** and **Showcase**. It says there are **no time-sensitive opportunities at the moment**, while still offering catalog promotion with Showcase. A creation control does not establish final eligibility, price, or expected returns for a chosen campaign; no creation flow was started.

There are no campaign performance rows to analyze. Spend, reach, click-through, conversion, incremental streams, and ROI are **unavailable**, not observed zero metrics. Sources: `agent_features_campaigns.txt`, `agent_features_subcampaigns.txt`.

## Artist Message

Video & Visuals exposes an **Artist Message for 2026 Wrapped**, with **Submit now** and **“Submit before Nov 6th.”** The displayed instructions allow a video up to **30 seconds**, **one per artist**, with no music, lyrics, singing, or explicit content. The deadline year **2026** follows the displayed Wrapped year; the UI itself abbreviates the deadline without a year.

This is an available submission opportunity. The landing page does not independently establish submission history, a successfully submitted asset, or performance. No upload or submission flow was opened. Source: `agent_features_artist_message.txt`.

## Canvas inventory

All **seven release selectors** visible in the Canvas view were inspected after their content loaded:

| Selected release | Named track cards in Canvas view |
|---|---:|
{table}

This yields **15 release-level card appearances**, with **12 distinct track labels**. Funny Guy, Crawl, and GOOMH! appear on both album and single views. These are repeated displayed labels, not proven distinct asset or recording IDs; do not sum them as 15 unique Canvases. **Lab Tapes shows only Add Canvas, with no named track card.**

The album cards visibly display thumbnail/video artwork. The **Add Canvas** tile is also present beside existing cards, so its presence does **not** imply missing Canvas for every track. Published Canvas asset availability is unverified. No card-level metrics, view totals, engagement rates, or asset IDs were displayed in the inventory. An attempt to inspect an existing Funny Guy card opened **Confirm your team**; that prompt was canceled before selecting or confirming a team. The inventory remains valid, while detailed asset state and performance remain unverified.

Sources: `agent_features_canvas_the_cut.txt`, `agent_features_canvas_devil_wears_docs.txt`, `agent_features_canvas_album.txt`, `agent_features_canvas_crawl.txt`, `agent_features_canvas_funny_guy.txt`, `agent_features_canvas_goomh.txt`, `agent_features_canvas_lab_tapes.txt`; detail boundary: `agent_features_canvas_detail_team_prompt.txt`.

## Scope and follow-through

The captured Video & Visuals navigation exposes **Your Artist Message** and **Canvas**. No additional Clips or music-video analytics are established by these captures. Do not convert absent UI controls into a claim that the underlying feature is globally unavailable or contains zero activity.

The Wrapped Artist Message is a current, concrete content opportunity to review before the displayed deadline. The Canvas UI already lists track cards across the main album and five single releases; assess Lab Tapes separately if its promotion remains relevant. These observations establish availability and inventory, not a causal claim that adding a feature increases streams.

No campaign was started, no content was uploaded, no team selection was confirmed, and no account settings were changed. The temporary audit tab was closed.

## Outputs

- `normalized/content_feature_status.csv` — structured availability, explicit empty states, missing metrics, timestamps and provenance.
- `normalized/canvas_card_inventory.csv` — 15 release-level named card appearances with repeated labels retained.
- `analysis/content_features.json` — machine-readable summary.
- `analysis/analyze_content_features.py` — reproducible normalization from the captured DOM files.
'''
(ROOT/"analysis/content_features.md").write_text(md)
print(json.dumps(summary,indent=2))
