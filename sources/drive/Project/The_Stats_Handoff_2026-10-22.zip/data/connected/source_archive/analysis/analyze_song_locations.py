"""Normalize captured song location tables; missing UI results remain unavailable."""
import csv
import json
import re
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CAP=ROOT/"captured";OUT=ROOT/"normalized"
def read_csv(name):
    with (OUT/name).open() as f:return list(csv.DictReader(f))
def write_csv(name,rows):
    with (OUT/name).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
catalog={r["song_id"]:r for r in read_csv("song_catalog.csv")}
monthly={r["song_id"]:r for r in read_csv("song_catalog_periods.csv") if r["period"]=="28day"}
locations=[];coverage=[];comparison=[]
files=sorted(CAP.glob("agent_song_location_*_bundle.json"))
assert len(files)==14
for p in files:
    b=json.loads(p.read_text());sid=b["song_id"];cat=catalog[sid];period=monthly[sid]
    error="Something went wrong." in b["dom"]
    base={"song_id":sid,"recording_label":cat["recording_label"],"title":cat["title"],"first_released":cat["first_released"],"period_start":"2026-09-23","period_end":"2026-10-20","metric":"streams","source":p.name,"source_url":b["url"],"collected_at":b["collected_at"]}
    country_rows=[];city_rows=[]
    if not error:
        assert "Sep 23, 2026 - Oct 20, 2026" in b["dom"]
        assert len(b["tables"])==3
        for ti,t in enumerate(b["tables"]):
            assert t["headers"][1].lower()=="streams"
            for cells in t["rows"][1:]:
                rank,raw,value=cells
                count=None if value.strip() in ["—","-"] else int(value.replace(",",""))
                if ti==0:
                    country=raw;city="";region="";kind="country"
                else:
                    city,geography=raw.split("\n",1)
                    parts=geography.rsplit(", ",1)
                    country=parts[0];region=parts[1] if len(parts)==2 else "";kind="city"
                r={**base,"location_type":kind,"rank":int(rank),"country":country,"city":city,"region":region,"streams":count,"value_status":"not_reported_dash" if count is None else "observed_zero" if count==0 else "observed","raw_location_label":raw,"active_count":None,"active_count_status":"not_shown_for_song_location","coverage":"Top countries shown; completeness not established" if kind=="country" else "Top50cities shown; completeness not established"}
                locations.append(r)
                (country_rows if ti==0 else city_rows).append(r)
        assert [r["rank"] for r in country_rows]==list(range(1,len(country_rows)+1))
        assert [r["rank"] for r in city_rows]==list(range(1,51))
        labels=b["chart_aria_labels"]
        assert len(labels)==28
        names=[]
        for li,label in enumerate(labels):
            parts=label.split(", ");date=datetime.strptime(parts[0],"%B %d %Y").date().isoformat()
            coords=[re.fullmatch(r"(.*?)\s*(\d+) streams?",x).groups() for x in parts[1:]]
            if li==0:
                names=[x[0].strip() for x in coords]
                assert all(names)
            assert len(coords)==len(names)
            for pos,(named,n) in enumerate(coords):
                assert not named.strip() or named.strip()==names[pos]
                comparison.append({**base,"date":date,"country":names[pos],"series_position":pos+1,"streams":int(n),"country_label_status":"named_in_label" if named.strip() else "inherited_from_first_label_same_series_position","scope":"Only default selected country comparison series; not all countries","raw_chart_label":label})
    row={**base,"status":"unavailable_site_error" if error else "captured_top_tables","country_rows_captured":len(country_rows),"city_rows_captured":len(city_rows),"country_stream_sum":None if error else sum(r["streams"] or 0 for r in country_rows),"city_stream_sum":None if error else sum(r["streams"] or 0 for r in city_rows),"song_28day_streams":int(period["streams"]),"song_total_source":period["source"],"country_sum_minus_song_total":None if error else sum(r["streams"] or 0 for r in country_rows)-int(period["streams"]),"country_total_reconciles":None if error else sum(r["streams"] or 0 for r in country_rows)==int(period["streams"]),"comparison_chart_days_captured":len(b["chart_aria_labels"]),"top_country":country_rows[0]["country"] if country_rows else None,"top_country_streams":country_rows[0]["streams"] if country_rows else None,"top_city":city_rows[0]["city"] if city_rows else None,"top_city_streams":city_rows[0]["streams"] if city_rows else None,"note":"Spotify shows a problem-on-our-end error for comparison/countries/cities; unavailable is not zero" if error else "All visible ranked rows captured; no additional ShowMore or below1percent control exposed; Top qualification retained"}
    coverage.append(row)

write_csv("song_locations.csv",locations)
write_csv("song_location_coverage.csv",coverage)
write_csv("song_location_country_comparison_daily.csv",comparison)
summary={"period_start":"2026-09-23","period_end":"2026-10-20","metric":"streams","song_pages_checked":len(files),"song_pages_with_tables":sum(r["status"]=="captured_top_tables" for r in coverage),"song_pages_with_errors":sum(r["status"]=="unavailable_site_error" for r in coverage),"country_rows":sum(r["location_type"]=="country" for r in locations),"city_rows":sum(r["location_type"]=="city" for r in locations),"country_comparison_daily_rows":len(comparison),"coverage":coverage,"validation":{"all_available_country_ranks_consecutive":True,"all_available_city_ranks_1_to_50":True,"all_captured_comparison_series_28_days":True,"all_available_country_sums_match_catalog_song_streams":all(r["country_total_reconciles"] for r in coverage if r["status"]=="captured_top_tables")},"cautions":["Song location metric is streams, distinct from the artist location listeners metric.","Top tables retained; matching country sum does not independently prove exhaustive geography.","City rows are capped at displayed50; do not infer remaining city values.","Seven page errors are preserved as unavailable, not zero streams.","No active-listener counts or percent-active values are shown on these song pages.","Repeated song titles remain distinct by song ID and first_release date."]}
(ROOT/"analysis/song_locations.json").write_text(json.dumps(summary,indent=2)+"\n")
available=[r for r in coverage if r["status"]=="captured_top_tables"]
missing=[r for r in coverage if r["status"]=="unavailable_site_error"]
table="\n".join(f'| {r["recording_label"]} | {r["country_rows_captured"]} | {r["country_stream_sum"]:,} | {r["city_rows_captured"]} | {r["top_city"]} ({r["top_city_streams"]}) |' for r in sorted(available,key=lambda r:-r["song_28day_streams"]))
gaps="\n".join(f'- {r["recording_label"]} — `{r["song_id"]}`' for r in missing)
md=f'''# Song location audit

All **14 song Location pages** were checked on October 22, 2026 for the latest 28 days, **September 23–October 20, 2026**. **Seven returned tables; seven returned Spotify's “Something went wrong” / “problem on our end” errors** for country comparison, Top countries, and Top cities. John Doe and the 2024 album recording of ¡La Cocaína! were reloaded once, with the same error. The remaining error pages were recorded without repeated recovery attempts. These are unavailable results, not zero activity.

## Metric and coverage

These song tables report **streams**, whereas the artist Location view reports **listeners**. Do not compare or combine those measures as equivalent audience counts. No active-listener counts or percent-active columns were displayed in the song location views.

The seven available pages contain **{summary["country_rows"]} country rows** and **{summary["city_rows"]} city rows** in total. Each available city table ends at **rank 50**. The available country tables retain their **Top countries** qualification; they show varying row counts and no additional Show More / below 1 percent controls. Six of seven available country sums match the corresponding latest 28-day song stream totals in `song_catalog_periods.csv`. Funny Guy’s country rows sum to **1,484**, four below its **1,488** song streams. The difference remains an unreconciled geographic residual, not an invented “Other” country. Matching sums for the other songs are useful checks, not independent proof of exhaustive geography or mutually exclusive listener populations.

| Recording | Country rows | Country stream sum | City rows | Leading city (streams) |
|---|---:|---:|---:|---|
{table}

The United States is the top country in every available table. This supports a broad geographic concentration statement for the seven covered songs only. Small city counts are descriptive and do not establish reachable fans, ticket buyers, advertising conversions, or causal market potential.

## Unavailable song pages

{gaps}

Each error page has its own capture bundle and coverage row. `country_stream_sum`, `city_stream_sum`, and top-location values are left blank for those pages. A zero in `country_rows_captured` or `city_rows_captured` means no rows were retrieved, not zero streams. No locations were inferred from another song, an artist-level table, a matching title, or a prior period.

## Country comparison charts

For each available song, the page also exposes 28 daily labels for three default selected countries. These yield **{len(comparison)} country/day rows** across the seven songs, kept separately in `song_location_country_comparison_daily.csv`. The first chart label names each country; subsequent labels sometimes omit names. The normalized country labels are carried forward by the same observed series position, with that derivation recorded in `country_label_status`. The chart selection is not a complete country panel. All original chart labels remain in the bundles and normalized rows.

## Files and provenance

- `normalized/song_locations.csv` — {len(locations)} ranked country/city observations, with song ID, recording label, metric, missing/zero status, and exact source.
- `normalized/song_location_coverage.csv` — 14 checked pages, including seven unavailable statuses and reconciliation diagnostics.
- `normalized/song_location_country_comparison_daily.csv` — limited selected-country daily chart observations.
- `captured/agent_song_location_<song_id>_bundle.json` —DOM snapshot, rendered table cells, chart labels, observed URL and collection timestamp for each page.
- `analysis/song_locations.json` —summary and validation results.

These are DOM-derived captures, not native CSV exports. All UI work was read-only; no saved country selections or account settings were changed. The temporary browser tab was closed. Reproduce normalization with `analysis/analyze_song_locations.py`.
'''
(ROOT/"analysis/song_locations.md").write_text(md)
print(json.dumps({k:v for k,v in summary.items() if k!="coverage"},indent=2))
