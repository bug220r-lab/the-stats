"""Join native playlist exports to visible category metadata without filling hidden coverage."""
import csv,json,re
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
CAP=ROOT/'captured';OUT=ROOT/'normalized'

def save(name, rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

rows=[];summary=[];checks=[]
for key,label in [('7day','7 days'),('28day','28 days'),('12months','12 months')]:
    native_name=f'agent_playlists_{key}_native.csv'
    native=list(csv.DictReader((CAP/native_name).open(encoding='utf-8-sig')))
    tables=json.loads((CAP/f'agent_playlists_{key}_tables.json').read_text())
    dom=(CAP/f'agent_playlists_{key}.txt').read_text()
    assert 'No stats for this time period' in dom
    lookup={}
    for typ,table in zip(['Algorithmic','Listener'],tables):
        for r in table[1:]:
            rank,title,*tail=r['cells'];name=title.splitlines()[0]
            links=r['links']
            lookup[name]=(typ,int(rank),title,next((a['href'] for a in links if '/playlist/' in a['href']),''),next((a['href'] for a in links if '/song/' in a['href']),''),int(tail[0].replace(',','')),int(tail[1].replace(',','')))
    assert len(native)==len(lookup)
    for source_rank,r in enumerate(native,1):
        typ,rank,title,playlist_url,song_url,dlisteners,dstreams=lookup[r['title']]
        listeners,streams=int(r['listeners']),int(r['streams'])
        assert (listeners,streams)==(dlisteners,dstreams)
        songinfo=' '.join(x.strip() for x in title.splitlines()[1:] if x.strip() and x.strip() not in ['•','Personalized'])
        m=re.fullmatch(r'(\d+) songs',songinfo)
        rows.append({'period_label':label,'period_start':None,'period_end':None,'date_bounds_status':'not_exposed_in_playlist_page_or_native_CSV','category':typ,'category_rank_displayed':rank,'native_export_order':source_rank,'playlist_title':r['title'],'author_displayed':r['author'],'author_status':'not_reported_dash' if r['author']=='-' else 'reported','listeners':listeners,'streams':streams,'streams_per_listener_calculated':streams/listeners,'date_added':None if r['date_added']=='n/a' else r['date_added'],'date_added_status':'not_applicable' if r['date_added']=='n/a' else 'reported','song_count_displayed':int(m[1]) if m else (None if songinfo=='Song title not available' else 1),'song_info_displayed':songinfo,'playlist_url':playlist_url,'song_url':song_url,'native_source':native_name,'DOM_source':f'agent_playlists_{key}.txt','coverage':'All accessible rendered/exported rows; thresholded reporting, not exhaustive playlist universe'})
    checks.append({'period_label':label,'native_rows':len(native),'DOM_rows':len(lookup),'listener_and_stream_cells_match':True,'scope_status':'date_bounds_unreported'})
    for typ in ['Algorithmic','Listener','Editorial and personalized editorial']:
        selected=[r for r in rows if r['period_label']==label and r['category']==typ]
        summary.append({'period_label':label,'category':typ,'row_count':len(selected),'streams_from_captured_rows':sum(r['streams'] for r in selected) if selected else None,'listener_row_sum_not_unique_reach':sum(r['listeners'] for r in selected) if selected else None,'status':'captured_rows' if selected else 'no_stats_for_period_displayed','footer_displayed':'Showing 21 of 1.8k' if key=='12months' and typ=='Listener' else ('Showing 10 of 10' if key=='12months' and typ=='Algorithmic' else ('Showing 6 of 6' if key=='28day' and typ=='Algorithmic' else '')),'coverage':'Reported playlist rows only; people may appear in more than one row','source':native_name+f';agent_playlists_{key}.txt'})

save('artist_playlists.csv',rows)
save('artist_playlist_summary.csv',summary)
save('artist_playlist_reconciliation.csv',checks)
info={'collected_date_utc':'2026-10-22','periods':summary,'checks':checks,'coverage_notes':['7/28-day and 12-month controls verified; longest offered period 12 months.','12-month listener table expanded to 21 rows then Show Less; footer still said Showing 21 of 1.8k. Native export included same 21 listener rows plus 10 algorithmic groups.','All row counts and listener/stream values match native CSV versus visible DOM tables.','Playlist page and native files do not expose exact reporting date bounds; none imputed.','Editorial shows No stats for this time period; missing reported metrics not treated as zero.','Playlist listeners overlap across rows; row sums are not artist unique listeners.','Date added records the playlist addition date, which can precede the reporting period.','Native author dash and unavailable song titles preserved as missing metadata.','Named playlist tables are not a substitute for source-of-stream totals.']}
(ROOT/'analysis/content_playlists.json').write_text(json.dumps(info,indent=2)+'\n')

md='''# Artist playlists and content feature audit

Captured read-only in Spotify for Artists on October 22, 2026. Playlist analysis combines native CSV downloads with rendered DOM metadata. Exact start/end dates are not exposed by these playlist views or exports, so only the selected period labels are stored; the artist timeline's October 20 endpoint has not been silently imposed.

## Playlist coverage

| Selected period | Algorithmic groups | Listener playlist rows | Editorial view |
|---|---:|---:|---|
| 7 days | 5 | 1 | No stats for this time period |
| 28 days | 6 | 3 | No stats for this time period |
| 12 months | 10 | 21 | No stats for this time period |

The Filters drawer offers 24 hours, 7 days, 28 days and 12 months. Twelve months is the longest offered option. All available expansion controls were used in the requested views. The twelve-month listener table initially showed five rows; Show More expanded it to 21 and changed to Show Less, while its footer read **“Showing 21 of 1.8k.”** No additional pagination control was exposed. The native twelve-month CSV contains the same 21 listener playlists and ten algorithmic groups. The 1.8k footer does not establish 1,800 individually retrievable or qualified rows, and the reason for the display difference is not stated.

These are reported/thresholded playlist rows, not the artist's full playlist universe. Official source notes describe top-100 reporting and a three-listener threshold (`analysis/definitions_notes.md`, section 8). Preserve both that documentation and this account's observed footer without inventing an explanation. Every captured row has at least three listeners. “No stats” in the editorial panel is retained as a status, not converted to a numeric zero or a lifetime absence claim.

## Observations

In the **12-month** view, Release Radar has **2,250 listeners / 3,078 streams**, Radio **1,683 / 2,518**, and Mixes **822 / 2,327**. These are algorithmic groups personalized by listener, not necessarily individual shared playlist IDs. The leading listener-playlist row by streams is Pure Punk (**140 listeners / 199 streams**), followed by This is the jam 🎧 (**3 / 189**) and Metal/Rock Variety (**5 / 91**). Ratios based on such small listener counts describe repetition, not evidence of manipulation or reliable future reach.

In the **28-day** view, Mixes leads the algorithmic groups with **118 listeners / 181 streams**; the six captured algorithmic groups total **263 streams**. The three listener-playlist rows are Slipknot Radio (**14 / 16**), Loud Rock&Metal (**3 / 8**), and Highway Song (**7 / 8**), totaling **32 streams**. All three display The Cut (Starts Tomorrow). “Slipknot Radio” is categorized by this UI as a **Listener** playlist, distinct from Spotify's **Radio** algorithmic group.

In the **7-day** view, Mixes has **46 listeners / 58 streams**. Five algorithmic groups total **81 streams**; the sole reported listener-playlist row, Slipknot Radio, has **3 listeners / 3 streams**. These nested periods must not be treated as separate nonoverlapping comparisons.

Do not sum playlist listeners into unique artist reach. The same person can use several playlists. Do not use absence from a recent-period table as proof a playlist removed the song: eligibility/thresholds and reporting windows can affect visibility. Date added can precede the selected period and does not identify when the captured streams occurred.

## Reconciliation limitations

Native exports and DOM tables agree on **all 46 rows' listener and stream values** across the three selected periods. Their table order is descending streams in the observed view; keep that observed ranking rather than relabel it a listener ranking.

The captured 28-day named algorithmic rows total **263 streams**, while the separately captured artist source category “Personalized playlists, autoplay and mixes” reports **256**. Named listener-playlist rows total **32**, while “Other listeners’ playlists” reports **99**. The source categories and thresholded playlist tables are different reporting surfaces, and playlist exact bounds are not exposed. These differences remain unresolved; no residual is assigned to a playlist, autoplay, or missing audience, and no table is forced to match. Evidence: `normalized/artist_sources_28day.csv` plus the playlist sources below.

## Evidence and outputs

- `captured/agent_playlists_7day.txt`, `agent_playlists_28day.txt`, `agent_playlists_12months.txt`: rendered UI snapshots with selected filters and category/coverage text.
- Matching `_tables.json`: rendered table cells and visible links.
- Matching `_native.csv`: downloaded native playlist files, preserving author dashes and nonapplicable dates.
- `captured/agent_content_manifest.json`: source URLs and collection metadata.
- `normalized/artist_playlists.csv`: 46 joined native/DOM rows with category, visible rank, period label, metadata status and provenance.
- `normalized/artist_playlist_summary.csv`: coverage and descriptive row totals; listener sums explicitly non-unique.
- `normalized/artist_playlist_reconciliation.csv`: native-versus-DOM checks for each period.
- `analysis/content_playlists.json`: machine-readable coverage and checks.

Campaign and Video & Visuals status findings are captured separately in `analysis/content_features.md` and `normalized/content_feature_status.csv`. The current Campaigns/Sub-campaigns lists are empty; performance metrics are unavailable. Artist Message for 2026 Wrapped offers submission before November 6. Canvas shows 15 track-card appearances across seven selected releases (12 distinct labels); published assets are unverified. No campaign, upload, publication, or account setting was changed.
'''
(ROOT/'analysis/content_playlists.md').write_text(md)
print(json.dumps({'rows':len(rows),'summaries':summary},indent=2))
