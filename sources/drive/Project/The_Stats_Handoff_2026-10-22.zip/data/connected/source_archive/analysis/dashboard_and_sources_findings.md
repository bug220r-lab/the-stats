# Dashboard and stream-source reconciliation

## Period totals

All 44 dashboard current/prior additive and follower values match the native timeline exactly.

The YTD dashboard compares January 1–October 20, 2026 with the immediately preceding 293 days: March 14–December 31, 2025. Its +111.8% streams comparison is not year-over-year YTD growth. Matching January 1–October 20, 2025 gives +154.9%, calculated independently from the timeline.

## Snapshot comparison anchors

The native monthly-active and super-listener cards compare the first selected date with the last selected date. The timeline first-day values reproduce both displayed percentages: monthly active September 23 = 789; October 20 = 791 (+0.3%). Super September 23 = 42; October 20 = 47 (+11.9%).
Using the day immediately before the selected window (September 22) gives monthly active 791 to 791 (flat) and super 44 to 47 (+6.8%). Both describe different endpoint comparisons; retain the dates explicitly. Followers instead match September 22 = 1,616 to October 20 = 1,644 (+28; +1.7%).

## Sources

The previous 145-stream residual is fully reconciled: the UI explicitly labels 145 as Other, defined as devices where the source cannot be identified. Active 3,746 + programmed 355 + Other 145 = total 4,246. Prior 3,421 + 443 + 147 = 4,011.

| Source | Current streams | Prior streams | Share of current | Change |
|---|---:|---:|---:|---:|
| Artist profile and catalog | 446 | 330 | 10.5% | +35.2% |
| Listener's own playlists and library | 3171 | 2966 | 74.7% | +6.9% |
| Listener’s queue | 129 | 125 | 3.0% | +3.2% |
| Editorial and personalized editorial playlists | None | None | — | — |
| Personalized playlists, autoplay and mixes | 256 | 349 | 6.0% | -26.6% |
| Other listeners’ playlists | 99 | 94 | 2.3% | +5.3% |
| Other | 145 | 147 | 3.4% | -1.4% |

The editorial category displays dashes. These are preserved as `dashboard_dash` with no numeric value even though the other observed stream categories reconcile to the artist total.

Active sources account for 88.2% of streams, versus 85.3% in the preceding28. Own playlists/libraries contribute 74.7%, versus 73.9%. These are stream-source shares, not listener retention rates.

Personalized playlists/autoplay/mixes fell by93 streams; artist profile/catalog rose by116 and own playlists/libraries rose by205. This supports an interpretation of stronger intentional listening with weaker programmed discovery, without proving any campaign or content caused the change.

## Capture naming issues

`artist_sources_detailed_28day_listeners.txt` actually contains the Streams table and duplicates the streams snapshot. It was excluded from normalization. `artist_sources_detailed_28day_saves.txt` actually contains the Listeners table; the actual selected metric and table header establish this, so it was normalized as listeners and flagged with metric_filename_mismatch=true. No source-level saves were collected in these snapshots.

Source listener counts overlap and are not additive. Derived source-specific streams/listener ratios use matching categories and28-day periods; they describe listening frequency within each source, not unique-person conversion or causal quality.
