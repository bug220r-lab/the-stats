#!/usr/bin/env bash
# Recreate the final workbook with the Codex primary runtime and 8 GB V8 heap.
set -euo pipefail
STATS_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
: "${CODEX_PRIMARY_RUNTIME_NODE:?Codex primary Node runtime is required}"
: "${CODEX_PRIMARY_RUNTIME_NODE_MODULES:?Codex primary Node modules are required}"
export STATS_ROOT="${STATS_ROOT:-$(dirname "$STATS_SCRIPT_DIR")}"
STATS_BUILD_TMP="$(mktemp -d /tmp/the-stats-workbook.XXXXXX)"
trap 'rm -rf "$STATS_BUILD_TMP"' EXIT
ln -s "$CODEX_PRIMARY_RUNTIME_NODE_MODULES" "$STATS_BUILD_TMP/node_modules"
cp "$STATS_SCRIPT_DIR/build_workbook.mjs" "$STATS_BUILD_TMP/build_workbook.mjs"
STATS_PREVIEW_ALL="${STATS_PREVIEW_ALL:-1}" "$CODEX_PRIMARY_RUNTIME_NODE" --max-old-space-size=8192 "$STATS_BUILD_TMP/build_workbook.mjs"
