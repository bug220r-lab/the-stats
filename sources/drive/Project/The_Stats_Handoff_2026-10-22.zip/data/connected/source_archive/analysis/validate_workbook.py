"""Read-only XLSX validation using ZIP/XML; no spreadsheet authoring library."""
import csv, json, math, re, sys, zipfile
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
QA = ROOT / 'qa/workbook'
NS = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main', 'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
M='{'+NS['m']+'}'
checks=json.loads((QA/'checks.json').read_text())
registry=json.loads((QA/'registry.json').read_text())
inputs={p.name:list(csv.DictReader(p.open(newline=''))) for p in sorted((ROOT/'normalized').glob('*.csv'))}
errors=[]
for name,sheet,range_,count,note in checks['datasets']:
    if count!=len(inputs[name]): errors.append(f'{name}: source/index row count mismatch')
if set(inputs)!=set(x[0] for x in checks['datasets']): errors.append('Normalized/index file inventory differs')
for test in checks['recalculationTests']:
    if test['actual']!=test['expected']: errors.append('Recalculation failed: '+test['test'])
with zipfile.ZipFile(ROOT/'deliverables/The_Stats_Workbook.xlsx') as z:
    strings=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        strings=[''.join(si.itertext()) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall(M+'si')]
    wb=ET.fromstring(z.read('xl/workbook.xml'))
    rels={r.get('Id'):r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    sheets={s.get('name'):'xl/'+rels[s.get('{'+NS['r']+'}id')].lstrip('/') for s in wb.find(M+'sheets')}
    sheets={k:v.replace('xl/xl/','xl/') for k,v in sheets.items()}
    def cell_value(c):
        if c is None:return None
        v=c.find(M+'v');raw=v.text if v is not None else None;t=c.get('t')
        if t=='s':return strings[int(raw)] if raw is not None else None
        if t=='inlineStr':return ''.join(c.find(M+'is').itertext())
        if t=='b':return raw=='1'
        if t=='d':return (datetime.fromisoformat(raw.replace('Z','+00:00')).replace(tzinfo=None)-datetime(1899,12,30)).total_seconds()/86400
        if t in ('str','e'):return raw
        return float(raw) if raw is not None else None
    def expected(s,h):
        if not s:return None
        if h=='month' and re.fullmatch(r'\d{4}-\d{2}',s):s+='-01'
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}',s):return (datetime.strptime(s,'%Y-%m-%d')-datetime(1899,12,30)).days
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}T.*Z',s):return (datetime.fromisoformat(s.replace('Z','+00:00')).replace(tzinfo=None)-datetime(1899,12,30)).total_seconds()/86400
        if s.lower() in ('true','false'):return s.lower()=='true'
        if re.fullmatch(r'[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?',s,re.I) and not re.search(r'(^|_)(id|code|uri)($|_)',h):return float(s)
        return s
    def col(i):
        out='';i+=1
        while i:i,r=divmod(i-1,26);out=chr(65+r)+out
        return out
    samples={};checked_cells=0;formula_count=0;formula_errors=[];frozen=[];overview={}
    for sheet,xmlpath in sheets.items():
        needed={}
        for name,d in registry.items():
            if d['sheet']!=sheet:continue
            rows=inputs[name]
            for idx in sorted(set([0,len(rows)//2,len(rows)-1])):
                if idx<0:continue
                rownum=d['start']+idx
                needed[rownum]=(name,idx,d['headers'])
        for event,el in ET.iterparse(z.open(xmlpath),events=('end',)):
            if el.tag==M+'row':
                rn=int(el.get('r'));cells={c.get('r'):c for c in el.findall(M+'c')}
                for addr,c in cells.items():
                    if c.find(M+'f') is not None:formula_count+=1
                    if c.get('t')=='e':formula_errors.append([sheet,addr,cell_value(c)])
                if rn in needed:
                    name,idx,headers=needed[rn];source=inputs[name][idx]
                    for ci,h in enumerate(headers):
                        address=f'{col(ci)}{rn}';actual=cell_value(cells.get(address));exp=expected(source[h],h);checked_cells+=1
                        good=math.isclose(actual,exp,rel_tol=1e-12,abs_tol=1e-9) if isinstance(actual,(float,int)) and isinstance(exp,(float,int)) else actual==exp
                        if not good:errors.append(f'{name} source row {idx+1} {h}: {actual!r} != {exp!r}')
                if sheet=='Overview' and rn in (6,7,8,9,10,11,16,17,33):
                    overview.update({addr:cell_value(c) for addr,c in cells.items()})
                el.clear()
            elif el.tag==M+'pane':frozen.append({'sheet':sheet,**el.attrib})
    table_files=[n for n in z.namelist() if n.startswith('xl/tables/') and n.endswith('.xml')]
    filtered=sum(ET.fromstring(z.read(n)).find(M+'autoFilter') is not None for n in table_files)
    chart_files=[n for n in z.namelist() if '/charts/chart' in n and n.endswith('.xml')]
    if len(table_files)!=len(registry):errors.append('Native table count differs from included CSV count')
    if filtered!=len(table_files):errors.append('A native source table lacks filters')
    if len(sheets)!=22:errors.append('Expected 22 worksheets')
    if formula_errors:errors.append('Cached Excel formula errors found')
    expected_overview={'B6':4246,'B7':1062,'B9':217,'B10':362,'B11':1644}
    for address,exp in expected_overview.items():
        if overview.get(address)!=exp:errors.append(f'Overview {address}: {overview.get(address)} != {exp}')
    result={'datasets_indexed':len(inputs),'datasets_reproduced':len(registry),'reproduced_rows':sum(len(inputs[n]) for n in registry),'archive_only_rows':len(inputs['song_chart_points.csv']),'worksheets':len(sheets),'native_tables':len(table_files),'filtered_tables':filtered,'frozen_worksheets':len(frozen),'native_charts':len(chart_files),'formula_cells':formula_count,'formula_errors':formula_errors,'sampled_source_cells_checked':checked_cells,'sample_method':'First, middle and last row of every reproduced CSV; all cells in each sampled row. Dates, booleans, numeric values, IDs, missing cells and text compared with source.','overview_cells':overview,'recalculation_tests':checks['recalculationTests'],'errors':errors}
(QA/'export_validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('overview_cells',)},indent=2))
sys.exit(bool(errors))
