from pathlib import Path
import hashlib
import json
import shutil
import calendar
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

ROOT = Path('/workspace/scratch/84b5e0c87afd')
RAW = ROOT / 'raw'
OUT = ROOT / 'analysis'
NORM = ROOT / 'normalized'
CHART = ROOT / 'charts'
for directory in (RAW, OUT, NORM, CHART):
    directory.mkdir(parents=True, exist_ok=True)
source = Path('/workspace/scratch/[REDACTED]-audience-timeline.csv')
copy = RAW / 'artist_timeline_2024-01-01_2026-10-20.csv'
shutil.copyfile(source, copy)
df = pd.read_csv(copy, encoding='utf-8-sig')
date = pd.to_datetime(df['date'])
df['date'] = date
end = pd.Timestamp('2026-10-20')
assert date.min() == pd.Timestamp('2024-01-01')
assert date.max() == end
assert not date.duplicated().any()
assert date.is_monotonic_increasing
assert len(pd.date_range(date.min(), end)) == len(df)
value_cols = [c for c in df.columns if c != 'date']
quality = {
    'rows': len(df),
    'earliest_date': date.min().date().isoformat(),
    'latest_date': date.max().date().isoformat(),
    'duplicate_dates': int(date.duplicated().sum()),
    'missing_dates': 0,
    'null_counts': {c:int(df[c].isna().sum()) for c in df},
    'negative_counts': {c:int((df[c]<0).sum()) for c in value_cols},
    'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'copy_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),
    'original_dtypes': {c: str(df[c].dtype) for c in df},
}
assert quality['source_sha256'] == quality['copy_sha256']
assert all(n == 0 for n in quality['null_counts'].values())
for c in value_cols:
    assert pd.api.types.is_integer_dtype(df[c])
df.to_csv(NORM / 'artist_daily.csv', index=False, date_format='%Y-%m-%d')

windows = {
    'latest_7': ('2026-10-14','2026-10-20'),
    'previous_7': ('2026-10-07','2026-10-13'),
    'latest_28': ('2026-09-23','2026-10-20'),
    'previous_28': ('2026-08-26','2026-09-22'),
    'latest_90': ('2026-07-23','2026-10-20'),
    'previous_90': ('2026-04-24','2026-07-22'),
    'latest_12_months': ('2025-10-21','2026-10-20'),
    'previous_12_months': ('2024-10-21','2025-10-20'),
    'year_to_date': ('2026-01-01','2026-10-20'),
    'previous_year_same_dates': ('2025-01-01','2025-10-20'),
    'available_history': ('2024-01-01','2026-10-20'),
}
additive = ['streams','saves','playlist adds']
snapshots = ['followers','monthly listeners','monthly active listeners','super listeners']
rows = []
for key,(start,stop) in windows.items():
    selected = df.loc[df['date'].between(start,stop)]
    before = df.loc[df.date == pd.Timestamp(start)-pd.Timedelta(days=1)]
    first = selected.iloc[0]
    last = selected.iloc[-1]
    row = {'window':key, 'start_date':start,'end_date':stop,'days':len(selected)}
    for col in additive:
        row[col.replace(' ','_')] = int(selected[col].sum())
    for col in snapshots:
        field=col.replace(' ','_')
        row[field+'_end'] = int(last[col])
        row[field+'_before_start'] = int(before[col].iloc[0]) if len(before) else None
        row[field+'_change'] = row[field+'_end']-row[field+'_before_start'] if len(before) else None
    row['period_unique_listeners'] = int(last['monthly listeners']) if len(selected)==28 else None
    row['period_unique_listeners_method'] = 'End-date monthly listeners (rolling 28 days)' if len(selected)==28 else 'Requires dashboard period total; daily listeners not additive'
    row['streams_per_day'] = row['streams']/len(selected)
    row['source'] = copy.name
    rows.append(row)
pd.DataFrame(rows).to_csv(NORM/'artist_periods_from_timeline.csv',index=False)
by_window={r['window']:r for r in rows}
comparisons=[]
for current,previous in [('latest_7','previous_7'),('latest_28','previous_28'),('latest_90','previous_90'),('latest_12_months','previous_12_months'),('year_to_date','previous_year_same_dates')]:
    for metric in ['streams','saves','playlist_adds'] + (['period_unique_listeners'] if current=='latest_28' else []):
        a,b=by_window[current][metric],by_window[previous][metric]
        comparisons.append({'current_window':current,'previous_window':previous,'metric':metric,'current':a,'previous':b,'absolute_change':a-b,'percent_change':(a/b-1)*100 if b else None})
pd.DataFrame(comparisons).to_csv(NORM/'artist_period_comparisons.csv',index=False)

monthly=[]
for month,g in df.groupby(df['date'].dt.to_period('M')):
    start=g.date.iloc[0]
    stop=g.date.iloc[-1]
    row={'month':str(month),'start_date':start.date().isoformat(),'end_date':stop.date().isoformat(),'days_observed':len(g),'complete_calendar_month':len(g)==calendar.monthrange(start.year,start.month)[1]}
    for col in additive: row[col.replace(' ','_')]=int(g[col].sum())
    for col in snapshots: row[col.replace(' ','_')+'_end']=int(g[col].iloc[-1])
    row['streams_per_day']=row['streams']/len(g)
    monthly.append(row)
monthlydf=pd.DataFrame(monthly)
monthlydf.to_csv(NORM/'artist_monthly.csv',index=False)

latest=by_window['latest_28'];previous=by_window['previous_28']
ratios={
 'streams_per_listener_28': latest['streams']/latest['period_unique_listeners'],
 'streams_per_listener_previous28':previous['streams']/previous['period_unique_listeners'],
 'saves_per_listener_28':latest['saves']/latest['period_unique_listeners'],
 'saves_per_listener_previous28':previous['saves']/previous['period_unique_listeners'],
 'playlist_adds_per_listener_28':latest['playlist_adds']/latest['period_unique_listeners'],
 'playlist_adds_per_listener_previous28':previous['playlist_adds']/previous['period_unique_listeners'],
 'monthly_active_share_28': latest['monthly_active_listeners_end']/latest['monthly_listeners_end'],
 'super_share_of_monthly_active_28':latest['super_listeners_end']/latest['monthly_active_listeners_end'],
}
highs={c:{'value':int(df[c].max()),'dates':df.loc[df[c].eq(df[c].max()),'date'].dt.strftime('%Y-%m-%d').tolist()} for c in value_cols}
result={'quality':quality,'periods':rows,'comparisons':comparisons,'ratios':ratios,'monthly':monthly,'daily_maxima':highs,'cautions':[
 'Daily listeners are distinct within each day, not additive across days. They have not been summed to construct period unique listeners.',
 'Monthly listener, monthly active listener and super listener columns are rolling-28-day snapshots; followers are cumulative snapshots. Never sum these columns.',
 '28-day period unique listeners are taken from the end-date monthly listeners column; compare with dashboard totals before final publication.',
 'End-minus-before-start follower changes are net stock changes, not gross newly acquired followers.',
 'October 2026 includes only October 1-20; use streams per day or matched dates rather than compare the raw monthly total with complete months.',
 'Available-history totals begin January 1, 2024; they are not all-time totals.',
 'Saves/listener and playlist-adds/listener are activity ratios, not unique-person conversion rates.',
 'Changes in aggregate audience snapshots do not establish person-level retention or churn.',
]}
(OUT/'artist_analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')

lines=['# Artist timeline analysis','',f'Source: `{copy.name}`. {len(df):,} daily rows from 2024-01-01 through 2026-10-20. The raw file is a byte-identical copy of the native export.','',
 '## Data validation','',f"No missing dates, duplicate dates, null metric values or negative metrics. SHA-256: `{quality['source_sha256']}`.",'',
 '## Comparison periods','', '| Window | Dates (inclusive) | Streams | Saves | Playlist adds | Unique listeners |', '|---|---|---:|---:|---:|---:|']
for row in rows:
    ul=f"{row['period_unique_listeners']:,}" if row['period_unique_listeners'] is not None else 'Dashboard required'
    lines.append(f"| {row['window']} | {row['start_date']} to {row['end_date']} | {row['streams']:,} | {row['saves']:,} | {row['playlist_adds']:,} | {ul} |")
lines+=['','## Changes','','| Comparison | Metric | Current | Previous | Absolute change | Relative change |','|---|---|---:|---:|---:|---:|']
for r in comparisons:
    lines.append(f"| {r['current_window']} vs {r['previous_window']} | {r['metric']} | {r['current']:,} | {r['previous']:,} | {r['absolute_change']:+,} | {r['percent_change']:+.1f}% |")
lines+=['','## Latest 28-day ratios','']+[f"- {k}: {v:.6f}" for k,v in ratios.items()]
lines+=['','## Snapshot changes','', '| Window | Followers at end | Net follower change | Monthly active at end | Super at end |','|---|---:|---:|---:|---:|']
for row in rows:
    lines.append(f"| {row['window']} | {row['followers_end']:,} | {row['followers_change']} | {row['monthly_active_listeners_end']:,} | {row['super_listeners_end']:,} |")
lines+=['','## Daily maxima','']+[f"- {k}: {v['value']:,} on {', '.join(v['dates'])}" for k,v in highs.items()]
lines+=['','## Limitations','']+['- '+t for t in result['cautions']]
(OUT/'artist_analysis.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':16,'axes.labelsize':11,'axes.edgecolor':'#CBD0D5','axes.labelcolor':'#23272B','text.color':'#23272B','xtick.color':'#4D555D','ytick.color':'#4D555D','figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white'})
def style(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.set_axisbelow(True)
    ax.grid(axis='y',color='#E7E9EC',linewidth=.6)
    ax.set_ylim(bottom=0)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v,p:f'{v:,.0f}'))

m=monthlydf.copy(); m['date']=pd.to_datetime(m['month'])
fig,ax=plt.subplots(figsize=(11.5,4.8))
ax.bar(m['date'],m['streams'],width=23,color=['#245987' if x else '#AABDD0' for x in m['complete_calendar_month']],edgecolor='none')
ax.set_title('Monthly streams, January 2024–October 2026',loc='left',pad=18)
ax.set_ylabel('Streams')
ticks=pd.to_datetime(['2024-01-01','2024-07-01','2025-01-01','2025-07-01','2026-01-01','2026-07-01','2026-10-01'])
ax.set_xticks(ticks);ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
style(ax)
fig.text(.07,.015,'October 2026 includes October 1–20 only. Source: Spotify for Artists audience timeline export.',fontsize=9,color='#606971')
fig.tight_layout(rect=[0,.045,1,1]);fig.savefig(CHART/'artist_monthly_streams.png',dpi=200);plt.close(fig)

last90=df[df.date.between('2026-07-23','2026-10-20')].copy()
fig,ax=plt.subplots(figsize=(11.5,4.8))
ax.plot(last90.date,last90.streams,color='#B6C9DA',lw=1,label='Daily streams')
rolling=df.set_index('date').streams.rolling(7,min_periods=7).mean().reindex(last90.date)
ax.plot(last90.date,rolling.values,color='#245987',lw=2.3,label='7-day trailing average')
ax.set_title('Daily streams, July 23–October 20, 2026',loc='left',pad=18);ax.set_ylabel('Streams per day')
ax.set_xticks(pd.to_datetime(['2026-07-23','2026-08-15','2026-09-01','2026-09-15','2026-10-01','2026-10-20']))
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %d'))
style(ax);ax.legend(frameon=False,ncol=2,loc='upper right')
fig.text(.07,.015,'Source: Spotify for Artists audience timeline export. The trailing average includes the prior six calendar days.',fontsize=9,color='#606971')
fig.tight_layout(rect=[0,.045,1,1]);fig.savefig(CHART/'artist_latest90_streams.png',dpi=200);plt.close(fig)
print(json.dumps({'quality':quality,'periods':rows,'comparisons':comparisons,'ratios':ratios,'monthly2026':monthly[-10:]},indent=2))
