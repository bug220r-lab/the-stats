"""Reproduce catalog normalization from preserved Spotify UI and native exports.

No audience sums are used as period-unique listener counts. Song IDs define
recordings; the same ID on multiple releases is mapped but never counted twice.
"""
from pathlib import Path
import re, json, hashlib, calendar
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path('/workspace/scratch/84b5e0c87afd')
CAP,RAW,NORM,OUT,CHART=[ROOT/x for x in ('captured','raw','normalized','analysis','charts')]
for d in (NORM,OUT,CHART): d.mkdir(exist_ok=True)
END=pd.Timestamp('2026-10-20')

# Browser collection writes consolidated bundles to survive individual-file
# synchronization delays. Expand them deterministically without changing any
# native downloaded CSV bytes; preserve each original bundle as evidence.
capture_index=[]
for bundle in sorted(CAP.glob('bundle_*.json')):
    records=json.loads(bundle.read_text())
    if not isinstance(records,list):continue
    for rec in records:
        if not isinstance(rec,dict) or 'name' not in rec:continue
        name=rec['name']
        if '/' in name or '..' in name:raise ValueError('Unexpected capture name')
        if 'snapshot' not in rec:
            capture_index.append({'capture':name,'bundle_source':bundle.name,'url':rec.get('url'),'collected_at':rec.get('collected_at'),'error':rec.get('error')})
            continue
        (CAP/(name+'.txt')).write_text(rec['snapshot'])
        if rec.get('chart'):
            (CAP/(name+'_chart.json')).write_text(json.dumps(rec['chart'],indent=2))
        capture_index.append({'capture':name,'bundle_source':bundle.name,'url':rec.get('url'),'collected_at':rec.get('collected_at')})
if capture_index:pd.DataFrame(capture_index).to_csv(NORM/'song_capture_index.csv',index=False)

def number(s):
    if s is None or s in ('','—','No data available','No change'): return None
    try:
        v=float(s.replace(',','').replace('%',''))
        return int(v) if v.is_integer() else v
    except (ValueError,AttributeError): return None

def rowblocks(s):
    return re.findall(r'^      - row (.*?)(?=^      - row |^    - rowgroup:|^  - table:|^-[^ ]|\Z)',s,re.M|re.S)

def cells(block):
    return [x if x else '' for x in re.findall(r'^        - cell(?: "([^"\n]*)")?(?::[^\n]*)?$',block,re.M)]

def save(name,rows):
    df=pd.DataFrame(rows)
    if len(df): df.to_csv(NORM/name,index=False)
    return df

def canon_metric(s):return s.lower().replace(' / ','_per_').replace(' ','_')

catalog=[]
for period,start in [('28day','2026-09-23'),('7day','2026-10-14')]:
    path=CAP/f'catalog_songs_{period}.txt'
    if not path.exists(): continue
    text=path.read_text()
    assert f'radio "{28 if period=="28day" else 7} days" [checked]' in text
    for block in rowblocks(text):
        mid=re.search(r'/song/([A-Za-z0-9]+)/stats',block)
        if not mid: continue
        vals=cells(block)
        assert len(vals)==9,(path,vals)
        catalog.append(dict(song_id=mid[1],title=vals[1],period=period,start_date=start,end_date='2026-10-20',rank=number(vals[0]),streams=number(vals[3]),listeners=number(vals[4]),canvas_views=number(vals[5]),saves=number(vals[6]),first_released=pd.Timestamp(vals[7]).date().isoformat(),source=path.name))
catalog_df=save('song_catalog_periods.csv',catalog)
base=catalog_df[catalog_df.period=='28day'].copy().drop(columns=['period','start_date','end_date','rank','streams','listeners','canvas_views','saves','source'])
assert base.song_id.is_unique
base['recording_label']=base['title']
for i,r in base.iterrows():
    if (base.title==r.title).sum()>1: base.loc[i,'recording_label']=r.title+(' (Lab Tapes, 2023)' if r.first_released.startswith('2023') else ' (album, 2024)')
labels=base.set_index('song_id').recording_label.to_dict()
release_rows=[];mapping=[]
path=CAP/'catalog_releases_28day.txt'
release=None
for block in rowblocks(path.read_text()):
    relid=re.search(r'/release/([A-Za-z0-9]+)',block)
    songid=re.search(r'/song/([A-Za-z0-9]+)/stats',block)
    vals=cells(block)
    if relid:
        heads=re.findall(r'- heading "([^"\n]+)" \[level=[34]\]',block)
        release={'release_id':relid[1],'release_title':heads[0],'release_type':heads[1],'streams_28day':number(vals[2]),'release_year':number(vals[6]),'source':path.name}
        release_rows.append(release)
    elif songid:
        assert release
        mapping.append(dict(release_id=release['release_id'],release_title=release['release_title'],song_id=songid[1],title=vals[1],track_number=number(vals[0]),streams_28day=number(vals[3]),source=path.name))
releases=save('release_catalog.csv',release_rows)
mapping_df=save('release_song_mapping.csv',mapping)
base['release_memberships']=base.song_id.map(mapping_df.groupby('song_id').release_title.agg(' | '.join))
base.to_csv(NORM/'song_catalog.csv',index=False)

# Daily native exports. Prefer an explicitly named metric export over an older
# generic native copy of the same bytes; preserve both raw files unchanged.
daily_parts=[];quality=[];seen={}
files=sorted(RAW.glob('song_*.csv'),key=lambda p: ('_native' in p.stem,p.name))
for p in files:
    match=re.match(r'song_([A-Za-z0-9]+)_',p.name)
    if not match: continue
    songid=match[1]
    frame=pd.read_csv(p,encoding='utf-8-sig')
    if 'date' not in frame: continue
    frame['date']=pd.to_datetime(frame.date)
    metrics=[c for c in frame if c!='date']
    q={'source':p.name,'song_id':songid,'rows':len(frame),'start_date':str(frame.date.min().date()),'end_date':str(frame.date.max().date()),'metrics':' | '.join(metrics),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'duplicate_dates':int(frame.date.duplicated().sum()),'missing_dates':len(pd.date_range(frame.date.min(),frame.date.max()))-frame.date.nunique(),'null_values':int(frame[metrics].isna().sum().sum()),'negative_values':int((frame[metrics].select_dtypes('number')<0).sum().sum())}
    quality.append(q)
    assert q['duplicate_dates']==q['missing_dates']==0,q
    for m in metrics:
        key=(songid,canon_metric(m))
        if key in seen:
            assert seen[key].equals(frame[['date',m]].reset_index(drop=True)), f'Conflicting duplicate metric export {key}'
            continue
        seen[key]=frame[['date',m]].reset_index(drop=True)
        g=frame[['date',m]].rename(columns={m:'value'}).copy()
        g['song_id']=songid;g['recording_label']=labels.get(songid,songid)
        g['metric']=canon_metric(m);g['source']=p.name;g['origin']='native_export'
        daily_parts.append(g)
# Rendered daily chart values supplement missing native metric exports. These
# remain explicitly distinguished from byte-for-byte downloaded files.
ui_daily_quality=[]
for p in sorted(CAP.glob('song_*_full*_chart.json')):
    sm=re.match(r'song_([A-Za-z0-9]{22})_',p.name)
    if not sm:continue
    points=[]
    for label in json.loads(p.read_text()):
        cm=re.match(r'([A-Z][a-z]{2} \d{1,2}, \d{4}), ([\d,.]+) (.+)',label)
        if cm:points.append({'date':pd.Timestamp(cm[1]),'metric':canon_metric(cm[3]),'value':number(cm[2])})
    if not points:continue
    df=pd.DataFrame(points);sid=sm[1]
    for metric,g in df.groupby('metric'):
        g=g.sort_values('date').reset_index(drop=True)
        if g.date.min()!=pd.Timestamp('2024-01-01') or g.date.max()!=END or len(g)!=1024:continue
        key=(sid,metric)
        if key in seen:
            native=seen[key]
            if not np.array_equal(native.iloc[:,1].to_numpy(),g.value.to_numpy()):
                ui_daily_quality.append(dict(song_id=sid,metric=metric,source=p.name,rows=len(g),status='DIFFERS from earlier metric evidence'))
            else:ui_daily_quality.append(dict(song_id=sid,metric=metric,source=p.name,rows=len(g),status='matches earlier metric evidence'))
            continue
        seen[key]=g[['date','value']].rename(columns={'value':metric})
        g['song_id']=sid;g['recording_label']=labels[sid];g['source']=p.name;g['origin']='rendered_chart_labels'
        daily_parts.append(g)
        ui_daily_quality.append(dict(song_id=sid,metric=metric,source=p.name,rows=len(g),status='supplements native export coverage'))
# If a full-history UI query is unavailable, retain the available daily points
# from shorter windows. Overlapping dates are checked, never double-counted.
for p in sorted(CAP.glob('song_*_chart.json')):
    sm=re.match(r'song_([A-Za-z0-9]{22})_',p.name)
    if not sm:continue
    points=[]
    for label in json.loads(p.read_text()):
        cm=re.match(r'([A-Z][a-z]{2} \d{1,2}, \d{4}), ([\d,.]+) (.+)',label)
        if cm:points.append({'date':pd.Timestamp(cm[1]),'metric':canon_metric(cm[3]),'value':number(cm[2])})
    if not points:continue
    df=pd.DataFrame(points);sid=sm[1]
    for metric,g in df.groupby('metric'):
        g=g.sort_values('date').drop_duplicates('date').reset_index(drop=True);key=(sid,metric)
        future_count=int((g.date>END).sum())
        if future_count:
            ui_daily_quality.append(dict(song_id=sid,metric=metric,source=p.name,rows=future_count,status='future chart dates excluded from observed daily history'))
            g=g[g.date<=END].copy()
        if not len(g):continue
        if key in seen:
            existing=seen[key].copy();existing.columns=['date','value']
            overlap=existing.merge(g[['date','value']],on='date',suffixes=('_existing','_new'))
            differences=int((~np.isclose(overlap.value_existing,overlap.value_new,rtol=0,atol=0.000001)).sum())
            if differences:ui_daily_quality.append(dict(song_id=sid,metric=metric,source=p.name,rows=len(g),status=f'{differences} overlapping dates differ; retained earlier native/full-history evidence'))
            g=g[~g.date.isin(existing.date)].copy()
            if not len(g):continue
            seen[key]=pd.concat([existing,g[['date','value']]],ignore_index=True).sort_values('date').rename(columns={'value':metric})
        else:seen[key]=g[['date','value']].rename(columns={'value':metric})
        g['song_id']=sid;g['recording_label']=labels[sid];g['source']=p.name;g['origin']='rendered_chart_labels'
        daily_parts.append(g)
        ui_daily_quality.append(dict(song_id=sid,metric=metric,source=p.name,rows=len(g),status='supplements missing daily dates from partial UI window'))
daily=pd.concat(daily_parts,ignore_index=True) if daily_parts else pd.DataFrame()
if len(daily): daily[['song_id','recording_label','date','metric','value','source','origin']].to_csv(NORM/'song_daily_long.csv',index=False,date_format='%Y-%m-%d')
if len(daily):
    wide=daily.pivot(index=['song_id','recording_label','date'],columns='metric',values='value').reset_index()
    wide.to_csv(NORM/'song_daily_wide.csv',index=False,date_format='%Y-%m-%d')
save('song_export_quality.csv',quality)
save('song_chart_quality.csv',ui_daily_quality)
daily_coverage=[]
for _,song in base.iterrows():
    for metric in ('streams','listeners','streams_per_listener','playlist_adds','saves'):
        selected=daily[(daily.song_id==song.song_id)&(daily.metric==metric)] if len(daily) else pd.DataFrame()
        nstandard=int(selected.date.between('2024-01-01','2026-10-20').sum()) if len(selected) else 0
        daily_coverage.append(dict(song_id=song.song_id,recording_label=song.recording_label,metric=metric,collected_days=len(selected),start_date=str(selected.date.min().date()) if len(selected) else None,end_date=str(selected.date.max().date()) if len(selected) else None,covered_days_in_standard_history=nstandard,standard_history_complete=nstandard==1024,origins=' | '.join(sorted(selected.origin.unique())) if len(selected) else None,sources=' | '.join(sorted(selected.source.unique())) if len(selected) else None))
save('song_daily_coverage.csv',daily_coverage)

windows={'7day':('2026-10-14','2026-10-20'),'previous_7day':('2026-10-07','2026-10-13'),'28day':('2026-09-23','2026-10-20'),'previous_28day':('2026-08-26','2026-09-22'),'90day':('2026-07-23','2026-10-20'),'previous_90day':('2026-04-24','2026-07-22'),'12months':('2025-10-21','2026-10-20'),'previous_12months':('2024-10-21','2025-10-20'),'ytd':('2026-01-01','2026-10-20'),'prior_year_ytd':('2025-01-01','2025-10-20'),'full':('2024-01-01','2026-10-20')}
period_rows=[];monthly=[];launch=[]
if len(daily):
    for (sid,metric),df in daily.groupby(['song_id','metric']):
        for name,(start,end) in windows.items():
            selected=df[df.date.between(start,end)]
            if len(selected)!=len(pd.date_range(start,end)):continue
            if metric in ('streams','saves','playlist_adds','canvas_views'):
                period_rows.append(dict(song_id=sid,recording_label=labels.get(sid,sid),period=name,start_date=start,end_date=end,metric=metric,value=float(selected.value.sum()),method='sum of daily additive counts',source=' | '.join(selected.source.unique())))
        if metric=='streams':
            for month,g in df.groupby(df.date.dt.to_period('M')):
                monthly.append(dict(song_id=sid,recording_label=labels[sid],month=str(month),streams=int(g.value.sum()),days=len(g),complete_calendar_month=len(g)==calendar.monthrange(g.date.iloc[0].year,g.date.iloc[0].month)[1],source=' | '.join(g.source.unique())))
            release_date=pd.Timestamp(base.set_index('song_id').loc[sid,'first_released'])
            g=df[df.date.between(release_date,release_date+pd.Timedelta(days=27))].copy()
            if len(g)==28:
                g=g.sort_values('date');g['cumulative_streams']=g.value.cumsum()
                for _,r in g.iterrows(): launch.append(dict(song_id=sid,recording_label=labels[sid],release_date=str(release_date.date()),date=str(r.date.date()),day=int((r.date-release_date).days)+1,streams=r.value,cumulative_streams=r.cumulative_streams,source=r.source))
save('song_periods_from_daily.csv',period_rows);save('song_monthly_streams.csv',monthly);save('song_first28_daily_streams.csv',launch)
launch_summary=[]
for _,song in base.iterrows():
    g=daily[(daily.song_id==song.song_id)&(daily.metric=='streams')] if len(daily) else pd.DataFrame()
    rd=pd.Timestamp(song.first_released)
    row={'song_id':song.song_id,'recording_label':song.recording_label,'original_release_date':song.first_released,'history_start_date':str(g.date.min().date()) if len(g) else None,'history_end_date':str(g.date.max().date()) if len(g) else None}
    for days in (7,28,90,365):
        chosen=g[g.date.between(rd,rd+pd.Timedelta(days=days-1))] if len(g) else pd.DataFrame()
        row[f'first_{days}_days_complete']=len(chosen)==days
        row[f'first_{days}_days_streams']=int(chosen.value.sum()) if len(chosen)==days else None
    if len(g):
        peak=g.loc[g.value.idxmax()]
        row.update(available_history_peak_date=str(peak.date.date()),available_history_peak_daily_streams=int(peak.value))
    row['launch_scope_note']='Original-release date; pre-2024 launch unavailable if outside retained daily history.'
    launch_summary.append(row)
save('song_launch_summary.csv',launch_summary)

# Exact UI period-unique counts and full overview counters.
overview=[];alltime=[];issues=[];chart_points=[];dashboard_comparisons=[];canvas_evidence=[];query_errors=[]
for p in sorted(CAP.glob('song_*.txt')):
    m=re.match(r'song_([A-Za-z0-9]{22})_(.+)\.txt',p.name)
    if not m:continue
    sid,period=m.groups();s=p.read_text()
    errors=[line.strip() for line in s.splitlines() if 'not part of your catalog' in line or 'problem on our end' in line]
    if errors:query_errors.append(dict(song_id=sid,recording_label=labels.get(sid,sid),capture_scope=period,error_text=' | '.join(errors),source=p.name,interpretation='Observed query error; does not establish removal from the catalog.'))
    for action in ('Add Canvas','Manage Canvas'):
        if re.search(r'- button "'+action+r'"',s):canvas_evidence.append(dict(song_id=sid,recording_label=labels.get(sid,sid),observed_action=action,source=p.name,scope='UI control label only; asset contents and effectiveness not inspected'))
    metrics={}
    for label,field in [('Streams','streams'),('Listeners','listeners'),('Streams / Listener','streams_per_listener'),('Playlist adds','playlist_adds'),('Saves','saves')]:
        value=re.search(r'- button "'+re.escape(label)+r' ([\d,.]+)"',s)
        if value:metrics[field]=number(value[1])
    if not metrics:continue
    selected=re.search(r'- main:\n  - paragraph: ([^\n]+) · Worldwide',s)
    context=selected[1] if selected else None
    if not context:
        issues.append({'type':'missing_selected_scope','source':p.name});continue
    cp=p.with_name(p.stem+'_chart.json')
    points=[]
    if cp.exists():
        for label in json.loads(cp.read_text()):
            cm=re.match(r'([A-Z][a-z]{2} \d{1,2}, \d{4}), ([\d,.]+) (.+)',label)
            if cm:
                point=dict(song_id=sid,recording_label=labels.get(sid,sid),capture_period=period,date=pd.Timestamp(cm[1]).date().isoformat(),metric=cm[3].lower().replace(' / ','_per_').replace(' ','_'),value=number(cm[2]),source=cp.name)
                points.append(point);chart_points.append(point)
    point_dates=[r['date'] for r in points]
    base_period=re.sub(r'^full_.+$','full',period)
    valid_scope=True;invalid_reason=None
    aliases=[]
    if base_period in windows:
        start,end=windows[base_period]
        fmt=lambda v:f'{pd.Timestamp(v).strftime("%b")} {pd.Timestamp(v).day}, {pd.Timestamp(v).year}'
        aliases=[f'{fmt(start)} - {fmt(end)}']
        if base_period in ('7day','28day','12months'):aliases.append({'7day':'7 days','28day':'28 days','12months':'12 months'}[base_period])
        if context not in aliases:
            valid_scope=False;invalid_reason=f'Filename period {base_period} does not match displayed scope {context}'
        elif point_dates and (min(point_dates)!=start or max(point_dates)!=end):
            valid_scope=False;invalid_reason=f'Chart dates {min(point_dates)}–{max(point_dates)} differ from expected {start}–{end}'
    if not valid_scope:issues.append(dict(type='invalid_capture_scope',song_id=sid,period=period,displayed_period=context,reason=invalid_reason,source=p.name))
    head=re.search(r'- columnheader "([^"\n]+) · ([^"\n]+)"',s)
    selected_metric=None;selected_value=None;hero_selected=None
    if head:
        for block in rowblocks(s):
            vals=cells(block)
            if len(vals)==4 and vals[0]=='Worldwide':
                previous,current=number(vals[1]),number(vals[2])
                if current is not None:
                    selected_metric=canon_metric(head[1]);selected_value=current;hero_selected=metrics.get(selected_metric)
                    if valid_scope and (not aliases or head[2] in aliases):
                        if hero_selected is not None and hero_selected!=current:
                            issues.append(dict(type='hero_table_mismatch_table_retained',song_id=sid,period=period,metric=selected_metric,hero_value=hero_selected,table_value=current,source=p.name))
                        metrics[selected_metric]=current
                    dashboard_comparisons.append(dict(song_id=sid,recording_label=labels.get(sid,sid),period=period,metric=selected_metric,displayed_period=head[2],current=current,previous=previous,absolute_change=current-previous if previous is not None else None,percent_change=(current/previous-1)*100 if previous else None,comparison_basis='Spotify UI preceding equal-length period; YTD is not prior-year YTD',capture_valid=valid_scope,source=p.name))
    row=dict(song_id=sid,recording_label=labels.get(sid,sid),period=period,displayed_period=context,chart_start_date=min(point_dates) if point_dates else None,chart_end_date=max(point_dates) if point_dates else None,**metrics,capture_valid=valid_scope,invalid_reason=invalid_reason,selected_metric=selected_metric,selected_table_value=selected_value,hero_selected_value=hero_selected,source=p.name)
    if period in ('first28days','first12months','first28') and points:
        original_date=base.set_index('song_id').loc[sid,'first_released']
        if min(point_dates)!=original_date:
            issues.append(dict(type='ui_launch_preset_anchor_differs_from_original_release',song_id=sid,period=period,original_release_date=original_date,chart_start_date=min(point_dates),chart_end_date=max(point_dates),source=p.name))
    overview.append(row)
    at=re.search(r'- generic "All-time streams ([\d,]+)"',s)
    if at:alltime.append(dict(song_id=sid,recording_label=labels.get(sid,sid),all_time_streams=number(at[1]),source=p.name))
overview_df=save('song_period_dashboard.csv',overview)
save('song_dashboard_metric_comparisons.csv',dashboard_comparisons)
save('song_chart_points.csv',chart_points)
chart_total_checks=[]
for r in overview:
    if not r['capture_valid']:continue
    points=[x for x in chart_points if x['song_id']==r['song_id'] and x['capture_period']==r['period']]
    for metric in ('streams','saves','playlist_adds'):
        metric_points=[x for x in points if x['metric']==metric]
        if not metric_points or r.get(metric) is None:continue
        total=sum(x['value'] for x in metric_points)
        chart_total_checks.append(dict(song_id=r['song_id'],capture_period=r['period'],metric=metric,chart_points=len(metric_points),chart_total=total,hero_total=r[metric],difference=total-r[metric],source=r['source']))
save('song_chart_total_reconciliation.csv',chart_total_checks)
if canvas_evidence:
    canvas=pd.DataFrame(canvas_evidence).drop_duplicates(['song_id','observed_action'])
    canvas.to_csv(NORM/'song_canvas_status.csv',index=False)
    action_map=canvas.groupby('song_id').observed_action.agg(' | '.join)
    base['canvas_ui_action']=base.song_id.map(action_map)
    base.to_csv(NORM/'song_catalog.csv',index=False)
if len(overview_df):
    canonical=overview_df[overview_df.capture_valid & (overview_df.period.isin(['7day','28day','90day','12months','ytd','full','first28days','first28','first12months'])|overview_df.period.str.startswith('full_'))].copy()
    canonical['period']=canonical.period.str.replace(r'^full_.+$','full',regex=True)
    canonical['period']=canonical.period.replace({'first28days':'first28'})
    canonical=canonical.drop_duplicates(['song_id','period'])
    # The selected-metric table has precedence over hero cards. Merge separately
    # selected full-history metric tables into the canonical full-period row.
    for i,r in canonical.iterrows():
        evidence=[x for x in dashboard_comparisons if x['capture_valid'] and x['song_id']==r.song_id and re.sub(r'^full_.+$','full',x['period'])==r.period]
        for e in evidence:
            if e['metric'] in ('streams','listeners','streams_per_listener','playlist_adds','saves'):canonical.loc[i,e['metric']]=e['current']
        canonical.loc[i,'metric_table_sources']=' | '.join(e['metric']+':'+e['source'] for e in evidence)
    fallback=catalog_df.copy()
    fallback['recording_label']=fallback.song_id.map(labels)
    fallback['displayed_period']=fallback.period.map({'7day':'7 days (catalog)','28day':'28 days (catalog)'})
    fallback['chart_start_date']=fallback.start_date;fallback['chart_end_date']=fallback.end_date
    fallback['streams_per_listener']=fallback.streams/fallback.listeners
    fallback['capture_valid']=True
    fallback=fallback[[c for c in fallback if c in canonical.columns]]
    canonical=pd.concat([canonical,fallback],ignore_index=True).drop_duplicates(['song_id','period'])
    canonical=canonical.sort_values(['song_id','period'])
    canonical.to_csv(NORM/'song_period_canonical.csv',index=False)
alltime_df=pd.DataFrame(alltime).drop_duplicates(['song_id','all_time_streams']) if alltime else pd.DataFrame()
if len(alltime_df):alltime_df.to_csv(NORM/'song_alltime_counters.csv',index=False)

source_rows=[]
for p in sorted(CAP.glob('song_*sources*.txt')):
    sm=re.match(r'song_([A-Za-z0-9]{22})_(.+)\.txt',p.name)
    if not sm:continue
    sid,scope=sm.groups();s=p.read_text()
    header=re.search(r'- columnheader "([^"\n]+) · ([^"\n]+)"',s)
    if not header:continue
    for block in rowblocks(s):
        vals=cells(block)
        if len(vals)!=4 or vals[0] in ('Worldwide',''):continue
        previous,current=number(vals[1]),number(vals[2])
        name=vals[0].split(' Data from a range')[0]
        source_rows.append(dict(song_id=sid,recording_label=labels[sid],capture_scope=scope,metric=canon_metric(header[1]),displayed_period=header[2],stream_source=name,previous=previous,current=current,absolute_change=current-previous if current is not None and previous is not None else None,percent_change=(current/previous-1)*100 if previous and current is not None else None,displayed_change_text=vals[3],source=p.name))
save('song_source_comparisons.csv',source_rows)
save('song_query_errors.csv',query_errors)
source_ids={r['song_id'] for r in source_rows}
save('song_source_coverage.csv',[dict(song_id=r.song_id,recording_label=r.recording_label,status='collected' if r.song_id in source_ids else 'uncollected',collected_scope='28 days' if r.song_id in source_ids else None,limitation='Longer source histories uncollected' if r.song_id in source_ids else 'No retained song-source breakdown; this does not establish individual unavailability') for _,r in base.iterrows()])

reconciliations=[]
pdaily=pd.DataFrame(period_rows)
for r in catalog:
    same=pdaily[(pdaily.song_id==r['song_id'])&(pdaily.period==r['period'])] if len(pdaily) else pd.DataFrame()
    for metric in ('streams','saves'):
        d=same[same.metric==metric] if len(same) else pd.DataFrame()
        if len(d) and r[metric] is not None:reconciliations.append(dict(song_id=r['song_id'],period=r['period'],metric=metric,ui_value=r[metric],daily_value=d.iloc[0].value,difference=d.iloc[0].value-r[metric],ui_source=r['source']))
if len(overview_df):
    for _,r in overview_df.iterrows():
        if not r.capture_valid:continue
        same=pdaily[(pdaily.song_id==r.song_id)&(pdaily.period==r.period)] if len(pdaily) else pd.DataFrame()
        for metric in ('streams','saves','playlist_adds'):
            d=same[same.metric==metric] if len(same) else pd.DataFrame()
            if len(d) and pd.notna(r.get(metric)):reconciliations.append(dict(song_id=r.song_id,period=r.period,metric=metric,ui_value=r[metric],daily_value=d.iloc[0].value,difference=d.iloc[0].value-r[metric],ui_source=r.source))
save('song_period_reconciliation.csv',reconciliations)
comparisons=[]
for current,prev in [('7day','previous_7day'),('28day','previous_28day'),('90day','previous_90day'),('12months','previous_12months'),('ytd','prior_year_ytd')]:
    if not len(pdaily):continue
    x=pdaily[pdaily.period==current].merge(pdaily[pdaily.period==prev],on=['song_id','metric'],suffixes=('_current','_previous'))
    for _,r in x.iterrows():comparisons.append(dict(song_id=r.song_id,recording_label=labels[r.song_id],current_period=current,previous_period=prev,metric=r.metric,current=r.value_current,previous=r.value_previous,absolute_change=r.value_current-r.value_previous,percent_change=(r.value_current/r.value_previous-1)*100 if r.value_previous else None,method='derived daily additive counts',source=' | '.join([r.source_current,r.source_previous])))
comparison_keys={(r['song_id'],r['current_period'],r['metric']) for r in comparisons}
for r in dashboard_comparisons:
    if not r['capture_valid'] or r['period'] not in ('7day','28day','90day','12months') or r['previous'] is None:continue
    key=(r['song_id'],r['period'],r['metric'])
    if key in comparison_keys:continue
    comparisons.append(dict(song_id=r['song_id'],recording_label=r['recording_label'],current_period=r['period'],previous_period='previous_'+r['period'],metric=r['metric'],current=r['current'],previous=r['previous'],absolute_change=r['absolute_change'],percent_change=r['percent_change'],method='direct UI period comparison',source=r['source']))
    comparison_keys.add(key)
save('song_period_comparisons.csv',comparisons)
contributions=[]
top_ids=['3QVtuSBGLC9fTmLfF6qP7Z','3HqynH6ObSuDPZM0RMnFxN','7ARwqXOE4Hoi53M8TIra5P']
artist_windows={'28day':(4246,4011),'90day':(13775,19832),'12months':(63957,24087)}
for period,(artist_current,artist_previous) in artist_windows.items():
    chosen=[r for r in comparisons if r['song_id'] in top_ids and r['metric']=='streams' and r['current_period']==period]
    if len(chosen)!=3:continue
    top_current=sum(r['current'] for r in chosen);top_previous=sum(r['previous'] for r in chosen)
    for group,current,previous in [('Top three current recordings',top_current,top_previous),('Artist streams outside those three',artist_current-top_current,artist_previous-top_previous)]:
        contributions.append(dict(period=period,group=group,current_streams=current,previous_streams=previous,absolute_change=current-previous,percent_change=(current/previous-1)*100 if previous else None,share_of_artist_net_change=(current-previous)/(artist_current-artist_previous) if artist_current!=artist_previous else None,method='Top three summed by unique recording ID; outside-three group is artist-total residual',source='artist_daily.csv and song daily native/rendered-chart evidence'))
save('catalog_stream_contributions.csv',contributions)
period_catalog_checks=[]
known_artist_periods={'7day':(1186,1106),'28day':(4246,4011),'90day':(13775,19832),'12months':(63957,24087)}
for period,(current,previous) in known_artist_periods.items():
    part=[r for r in comparisons if r['current_period']==period and r['metric']=='streams']
    if len({r['song_id'] for r in part})!=14:continue
    for side,artist_value in [('current',current),('previous',previous)]:
        total=sum(r[side] for r in part)
        period_catalog_checks.append(dict(period=period,side=side,metric='streams',recordings=14,catalog_total=total,artist_total=artist_value,difference=total-artist_value,method='daily-derived or exact selected-metric UI comparisons'))
save('catalog_artist_period_reconciliation.csv',period_catalog_checks)

# 28-day song ratios are count-per-listener measures, not conversion rates:
# saves may include repeated actions and listeners can overlap across songs.
ratios=catalog_df[catalog_df.period=='28day'].copy()
ratios['recording_label']=ratios.song_id.map(labels)
ratios['saves_raw_catalog']=ratios.saves
ratios['saves_basis']='catalog UI table'
if len(overview_df):
    detailed28=overview_df[(overview_df.period=='28day')&overview_df.capture_valid].drop_duplicates('song_id').set_index('song_id')
    for i,r in ratios.iterrows():
        if pd.isna(r.saves) and r.song_id in detailed28.index and pd.notna(detailed28.loc[r.song_id].get('saves')):
            ratios.loc[i,'saves']=detailed28.loc[r.song_id,'saves']
            ratios.loc[i,'saves_basis']='exact 28-day song detail overview; catalog displayed dash'
ratios['streams_per_listener']=ratios.streams/ratios.listeners
ratios['saves_per_listener']=ratios.saves/ratios.listeners
ratios['saves_per_100_streams']=100*ratios.saves/ratios.streams
ratios['stream_share_artist']=ratios.streams/4246
ratios['canvas_views_per_100_streams']=100*ratios.canvas_views/ratios.streams
ratios.to_csv(NORM/'song_28day_rankings_ratios.csv',index=False)

summary={'recordings':len(base),'releases':len(releases),'release_song_memberships':len(mapping_df),'catalog_28day_streams':int(ratios.streams.sum()),'artist_28day_streams':4246,'release_row_streams_sum_non_additive':int(releases.streams_28day.sum()),'release_overlap_streams_28day':int(releases.streams_28day.sum()-4246),'catalog_7day_streams':int(catalog_df[catalog_df.period=='7day'].streams.sum()),'artist_7day_streams':1186,'song_export_files':len(quality),'recordings_with_native_export':len(set(q['song_id'] for q in quality)),'recordings_with_any_daily_evidence':int(daily.song_id.nunique()) if len(daily) else 0,'daily_rows_long':len(daily),'overview_rows':len(overview),'issues':issues,'alltime_discrepancies':[]}
summary['full_standard_history_metric_series']=sum(r['standard_history_complete'] for r in daily_coverage)
summary['daily_metric_series_with_any_data']=sum(r['collected_days']>0 for r in daily_coverage)
summary['expected_song_metric_series']=70
summary['collection_status']='final; collection frozen October 22, 2026'
summary['recordings_with_all_five_full_daily_series']=sum(all(r['standard_history_complete'] for r in daily_coverage if r['song_id']==sid) for sid in base.song_id)
summary['recordings_with_collected_source_breakdown']=len(source_ids)
summary['recordings_with_uncollected_source_breakdown']=len(base)-len(source_ids)
summary['source_breakdown_scope']='The Cut only, 28 days; other 13 recordings and longer song-source histories uncollected.'
catalog_artist_checks=[]
artist_path=NORM/'artist_daily.csv'
if artist_path.exists() and len(daily):
    artist=pd.read_csv(artist_path,parse_dates=['date'])
    for metric in ('streams','saves','playlist_adds'):
        part=daily[daily.metric==metric]
        if part.song_id.nunique()!=14:continue
        sums=part.groupby('date').agg(catalog_total=('value','sum'),recordings_observed=('song_id','nunique')).reset_index()
        # An absent song-day is missing, not zero. Compare only dates on which
        # every distinct catalog recording has an observed value.
        sums=sums[sums.recordings_observed==14]
        artist_column=metric.replace('_',' ')
        if artist_column not in artist:continue
        merged=sums.merge(artist[['date',artist_column]],on='date')
        for _,r in merged.iterrows():catalog_artist_checks.append({'date':str(r.date.date()),'metric':metric,'catalog_total':r.catalog_total,'artist_total':r[artist_column],'difference':r.catalog_total-r[artist_column]})
save('catalog_artist_daily_reconciliation.csv',catalog_artist_checks)
summary['catalog_artist_metric_reconciliation']={m:{'dates_checked':len([r for r in catalog_artist_checks if r['metric']==m]),'dates_different':len([r for r in catalog_artist_checks if r['metric']==m and r['difference']!=0]),'total_difference':sum(r['difference'] for r in catalog_artist_checks if r['metric']==m)} for m in sorted(set(r['metric'] for r in catalog_artist_checks))}
if len(alltime_df) and len(pdaily):
    full=pdaily[(pdaily.period=='full')&(pdaily.metric=='streams')]
    for _,r in alltime_df.merge(full,on='song_id').iterrows():
        if r.all_time_streams != r.value:
            prehistory=base.set_index('song_id').loc[r.song_id,'first_released']<'2024-01-01'
            explanation='May include pre-2024 history for a 2023 release; the two counters have different available-history scopes.' if prehistory and r.all_time_streams>r.value else 'Unresolved counter/scope discrepancy; do not substitute one for the other.'
            summary['alltime_discrepancies'].append({'song_id':r.song_id,'recording_label':labels[r.song_id],'all_time_header':int(r.all_time_streams),'available_history_streams':int(r.value),'header_minus_history':int(r.all_time_streams-r.value),'interpretation':explanation})
assert summary['catalog_28day_streams']==4246
assert summary['catalog_7day_streams']==1186
(OUT/'catalog_analysis.json').write_text(json.dumps(summary,indent=2))

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.titleweight':'bold','axes.labelcolor':'#24313F','text.color':'#24313F','xtick.color':'#4B5968','ytick.color':'#24313F','axes.edgecolor':'#CAD0D7'})
fig,ax=plt.subplots(figsize=(10,7))
x=ratios.sort_values('streams')
bars=ax.barh(x.recording_label,x.streams,color='#235F8B')
ax.bar_label(bars,labels=[f'{v:,} ({v/4246:.1%})' for v in x.streams],padding=6,fontsize=10)
ax.set_xlim(0,max(x.streams)*1.25);ax.set_xlabel('Streams');ax.set_title('Streams by recording',loc='left',pad=35,fontsize=17)
fig.text(.04,.922,'Sep 23–Oct 20, 2026 · Worldwide · 14 distinct recording IDs',fontsize=11,color='#526170')
ax.xaxis.grid(True,alpha=.18);ax.set_axisbelow(True)
fig.text(.04,.015,'Source: Spotify for Artists song catalog. Repeated single/album appearances counted once.',fontsize=9,color='#526170')
fig.tight_layout(rect=(0,.035,1,.93));fig.savefig(CHART/'catalog_streams_28day.png',dpi=180);plt.close(fig)
if len(monthly):
    mon=pd.DataFrame(monthly)
    selected_ids=ratios.sort_values('streams',ascending=False).song_id.head(4).tolist()
    if set(selected_ids).issubset(set(mon.song_id)):
        fig,ax=plt.subplots(figsize=(10,5))
        for sid,color in zip(selected_ids,['#235F8B','#BD7421','#827D2E','#A94A75']):
            df=mon[(mon.song_id==sid)&(mon.complete_calendar_month)].copy()
            ax.plot(pd.to_datetime(df.month),df.streams,label=labels[sid],color=color,lw=2)
        ax.set_title('Monthly streams for the four current leaders',loc='left',fontsize=16,pad=45)
        ax.set_ylabel('Streams');ax.set_ylim(bottom=0);ax.yaxis.grid(True,alpha=.18);ax.set_axisbelow(True)
        ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),ncol=2,frameon=False,fontsize=10)
        import matplotlib.dates as mdates
        ax.set_xlim(pd.Timestamp('2024-01-01'),pd.Timestamp('2026-09-01'))
        ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1,5,9]));ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
        fig.text(.04,.015,'Source: preserved Spotify native exports/rendered daily charts. Complete months only; October 2026 excluded.',fontsize=9,color='#526170')
        fig.tight_layout(rect=(0,.045,1,1));fig.savefig(CHART/'catalog_monthly_leaders.png',dpi=180);plt.close(fig)
if len(launch):
    launchdf=pd.DataFrame(launch)
    selected=launchdf[launchdf.release_date.str.startswith('2026')]
    if selected.song_id.nunique()==2:
        fig,ax=plt.subplots(figsize=(9,4.7))
        for (sid,g),color in zip(selected.groupby('song_id'),['#BD7421','#827D2E']):
            ax.plot(g.day,g.cumulative_streams,lw=2.3,color=color,label=labels[sid])
        ax.set_title('First 28 days of the 2026 singles',loc='left',fontsize=16,pad=40)
        ax.set_xlabel('Days since original release');ax.set_ylabel('Cumulative streams');ax.set_xlim(1,28);ax.set_ylim(bottom=0)
        ax.set_xticks([1,7,14,21,28]);ax.yaxis.grid(True,alpha=.18);ax.set_axisbelow(True);ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),frameon=False,fontsize=10)
        fig.text(.04,.015,'Source: daily Spotify streams. Launches occurred on different dates; promotion and audience size were not controlled.',fontsize=9,color='#526170')
        fig.tight_layout(rect=(0,.045,1,1));fig.savefig(CHART/'catalog_2026_launches.png',dpi=180);plt.close(fig)

lines=['# Catalog findings','',f'Observed catalog: {len(base)} distinct recordings across {len(releases)} releases; {len(mapping_df)} release memberships.','',f'The deduplicated 28-day recording total is {summary["catalog_28day_streams"]:,}, matching artist streams exactly; the 7-day total is {summary["catalog_7day_streams"]:,}, also matching exactly.','',f'Funny Guy supplies {1488/4246:.1%} of 28-day streams; the top three recordings supply {(1488+539+510)/4246:.1%}.','', 'Distinct 2023 Lab Tapes recordings of Method Acting and ¡La Cocaína! have different song IDs from the 2024 album recordings and remain separate. Funny Guy, Crawl and GOOMH! repeat the same song IDs across single and album releases. Never sum release rows to produce an artist total.','', '## Song assessment (latest 28 days)','', '| Recording | Streams | Listeners | Streams/listener | Saves | Saves/listener | Assessment |','|---|---:|---:|---:|---:|---:|---|']
recommendations={
'Funny Guy':'Primary reach and catalog entry point. Test a refreshed performance hook; route interested listeners into a short catalog sequence.',
'The Cut (Starts Tomorrow)':'Current single to reactivate. Test a second creative angle and a clear save/follow invitation; compare against its own prior window.',
'The Devil Wears Docs':'Reach is similar to The Cut but recorded saves are much lower. Test song framing and strongest excerpt before scaling promotion.',
'Crawl':'Secondary catalog entry point. Pair with Funny Guy in live/performance content; check whether next-window listeners and saves rise together.',
'GOOMH!':'Established catalog support. Use a familiar live hook; retain in set and profile pathways while testing discovery.',
'THIS MACHINE':'Modest scale with repeat use. Give a focused performance test and assess incremental reach before broad promotion.',
'Waste Away':'Highest repeat listening among the larger catalog tail; test deeper-fan content while expanding reach cautiously.',
'John Doe':'Useful catalog follow-through candidate. Test narrative/lyric content and compare return listening with its own baseline.',
'¡La Cocaína! (album, 2024)':'Album recording has materially more current activity than its early version. Keep recording IDs clear in links and tests.',
'Goodnight Mrs. Henderson':'Small audience with recorded saves; test a focused excerpt. Current sample cannot establish a reliable conversion advantage.',
'Method Acting (album, 2024)':'Small but relatively high repeat/save intensity; test as a deep-catalog candidate. Avoid declaring a winner from 40 listeners.',
'Son! (Hidden Track)':'Smallest album-track audience. Use discovery/context storytelling for existing fans; 26 listeners make ratios unstable.',
'¡La Cocaína! (Lab Tapes, 2023)':'Low-volume archival version. Treat as fan context, preserve distinct identity, and direct general promotion to the intended recording.',
'Method Acting (Lab Tapes, 2023)':'Low-volume archival version. Song detail explicitly reports zero saves in the latest 28 days; the catalog table displayed a dash. Keep this version distinct in links and fan-history content.'}
assessment=[]
for _,r in ratios.sort_values('streams',ascending=False).iterrows():
    rec=recommendations.get(r.recording_label,'Review alongside the next comparable reporting window.')
    sv='—' if pd.isna(r.saves) else f'{r.saves:,.0f}'
    sr='—' if pd.isna(r.saves_per_listener) else f'{r.saves_per_listener:.1%}'
    lines.append(f'| {r.recording_label} | {r.streams:,.0f} | {r.listeners:,.0f} | {r.streams_per_listener:.2f} | {sv} | {sr} | {rec} |')
    assessment.append(dict(song_id=r.song_id,recording_label=r.recording_label,assessment=rec))
save('song_assessments.csv',assessment)
lines+=['','Ratios are descriptive count-per-listener measures, not person-level conversion probabilities. Raw catalog dashes remain missing in the source table; a missing save count is filled for analysis only when an exact same-period song detail explicitly supplies it. Method Acting (Lab Tapes) detail reports zero saves, while its catalog row is a dash. Canvas dashes remain missing. Small song audiences make ranking by ratios unstable.','', '## Final daily-history scope','',f'Collection froze October 22, 2026, with a common reporting endpoint of October 20. The archive retains {len(quality)} native export files for {summary["recordings_with_native_export"]} recordings. Native exports and rendered chart labels together provide {summary["full_standard_history_metric_series"]} of 70 complete daily metric series for January 1, 2024–October 20, 2026, including all five metrics for {summary["recordings_with_all_five_full_daily_series"]} recordings. Son! has four complete metric series but only 730 observed stream days. GOOMH! has 365 observed stream days and no retained daily series for its other four metrics. Daily unique listeners remain at their daily grain and are never summed into period-unique listeners.','', 'Only The Cut has a retained song-source breakdown, covering the latest 28 days. Breakdowns for the other 13 songs and longer source histories are uncollected; individual unavailability was not established for every song. Preserved detail-query errors do not prove removal from the catalog. The invalid Son! capture labeled full history but displaying the latest 28 days is retained as evidence and excluded from canonical full-period values.','', '## All-time counter checks','']
for item in summary['alltime_discrepancies']:lines.append(f'- {item["recording_label"]}: all-time header {item["all_time_header"]:,}; Jan 2024–Oct 2026 daily history {item["available_history_streams"]:,}. {item["interpretation"]}')
lines+=['','## Preset date scope','']
for item in issues:
    if item['type']=='ui_launch_preset_anchor_differs_from_original_release':lines.append(f'- {labels[item["song_id"]]} / {item["period"]}: dashboard chart spans {item["chart_start_date"]}–{item["chart_end_date"]}, although original release date is {item["original_release_date"]}. Keep this preset separate from original-release launch calculations.')
(OUT/'catalog_analysis.md').write_text('\n'.join(lines))

# Compact report-ready history statements from the final collection.
history_text={}
comparison_df=pd.DataFrame(comparisons)
launch_by_id={r['song_id']:r for r in launch_summary}
for _,song in base.iterrows():
    matches=comparison_df[(comparison_df.song_id==song.song_id)&(comparison_df.metric=='streams')] if len(comparison_df) else pd.DataFrame()
    if not len(matches):
        history_text[song.song_id]='The retained evidence for this recording contains the 7-day and 28-day catalog tables; longer historical detail is unavailable. This is an access/query coverage gap, not evidence that the recording was removed.'
        continue
    by={r.current_period:r for _,r in matches.iterrows()}
    bits=[]
    for period,label in [('28day','28-day'),('90day','90-day')]:
        if period not in by:continue
        r=by[period]
        direction='rose' if r.absolute_change>0 else 'fell' if r.absolute_change<0 else 'were unchanged'
        change=f'{abs(r.percent_change):.1f}%' if pd.notna(r.percent_change) else 'from a zero baseline'
        bits.append(f'{label} streams {direction} {change} ({r.current:,.0f} vs {r.previous:,.0f})')
    first=launch_by_id[song.song_id]
    conclusion='; '.join(bits)+'.' if bits else ''
    if first['first_28_days_complete']:
        rd=pd.Timestamp(song.first_released);end=rd+pd.Timedelta(days=27)
        conclusion+=f' The original-release first 28 days ({rd.strftime("%b %d, %Y")}–{end.strftime("%b %d, %Y")}) generated {first["first_28_days_streams"]:,} streams.'
    else:conclusion+=' The original launch predates the retained daily history, so its first-28-day total is unavailable.'
    if song.song_id=='3HqynH6ObSuDPZM0RMnFxN':conclusion+=' Its previous 90-day comparator is the launch window.'
    history_text[song.song_id]=conclusion
(OUT/'report_song_history.json').write_text(json.dumps(history_text,indent=2))
total28=int(ratios.streams.sum())
p1=f'The album\'s ten recording IDs contribute 3,142 streams ({3142/total28:.1%}) in the latest 28 days; the two 2026 singles contribute 1,049 ({1049/total28:.1%}) and two Lab Tapes recordings 55 ({55/total28:.1%}). These groups do not overlap. Separate Funny Guy, Crawl and GOOMH! singles reuse album IDs, so adding their release rows again would double-count recordings.'
covered=summary['full_standard_history_metric_series'];anyseries=summary['daily_metric_series_with_any_data']
fullsongs=sum(all(r['standard_history_complete'] for r in daily_coverage if r['song_id']==sid) for sid in base.song_id)
p2=f'Daily evidence covers {anyseries} of 70 recording-metric series; {covered} span Jan 1, 2024–Oct 20, 2026, providing all five metrics for {fullsongs} recordings. Native CSV exports are retained for {summary["recordings_with_native_export"]} recordings. Other series are partial or unavailable; the workbook documents coverage. Launch totals require complete windows. Site query errors do not establish that a catalog recording was removed.'
(OUT/'report_collection_summary.txt').write_text(p1+'\n\n'+p2)
print(json.dumps(summary,indent=2))
