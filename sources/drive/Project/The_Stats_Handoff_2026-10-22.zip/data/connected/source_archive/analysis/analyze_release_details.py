"""Normalize release detail DOM bundles; keep overlapping releases and conflicting totals separate."""
import csv,json,re
from datetime import datetime,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];CAP=ROOT/'captured';OUT=ROOT/'normalized'
def save(name,rows):
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def date(s):return datetime.strptime(s,'%b %d, %Y').date().isoformat()
def number(s):return float(s.replace(',','')) if '.' in s else int(s.replace(',',''))
def chart_rows(labels):
 result=[]
 for label in labels:
  m=re.fullmatch(r'(.+?, \d{4}), ([\d,]+) Streams',label)
  if not m:raise ValueError(label)
  result.append({'date':date(m[1]),'streams':number(m[2])})
 return result
meta=[];periods=[];daily=[];checks=[]
for p in sorted(CAP.glob('agent_release_*_bundle.json')):
 b=json.loads(p.read_text());rid=b['release_id'];captures=b['captures']
 titles={re.search(r'heading "(.+)" \[level=1\]',c['dom'])[1] for c in captures};assert len(titles)==1
 title=titles.pop();heads={number(re.search(r'generic "All-time streams ([\d,]+)"',c['dom'])[1]) for c in captures};assert len(heads)==1
 alltime=heads.pop();reldate=date(re.search(r'generic "Release date (.+?)"',captures[0]['dom'])[1])
 kind=re.search(r'- main:\n  - img .+?\n  - paragraph: (.+)',captures[0]['dom'])[1]
 fullcap=next(c for c in captures if len(c['chart'])==1024);full=chart_rows(fullcap['chart'])
 assert full[0]['date']=='2024-01-01' and full[-1]['date']=='2026-10-20' and len({r['date'] for r in full})==1024
 expected=[(datetime(2024,1,1)+timedelta(days=i)).date().isoformat() for i in range(1024)]
 assert [r['date'] for r in full]==expected
 fullsum=sum(r['streams'] for r in full)
 meta.append({'release_id':rid,'release_title':title,'release_type':kind,'release_date':reldate,'all_time_streams_displayed':alltime,'observed_history_start':full[0]['date'],'observed_history_end':full[-1]['date'],'history_streams_sum':fullsum,'history_minus_all_time':fullsum-alltime,'all_time_comparison_status':'unresolved_history_exceeds_alltime' if fullsum>alltime else ('equal' if fullsum==alltime else 'historical_window_shorter_than_release_lifetime'),'native_csv_status':b.get('native_csv_status','No native CSV export control identified'),'source':p.name})
 for r in full:daily.append({'release_id':rid,'release_title':title,**r,'provenance':'DOM rendered chart aria label','source':p.name})
 for c in captures:
  dom=c['dom'];label=c['period_requested'];key='full_history' if ('full' in label or 'custom' in label) else ('12_months' if '12' in label else ('28_days' if '28' in label else '7_days'))
  vals={k:number(re.search(r'button "'+re.escape(k)+r' ([\d,.]+)"',dom)[1]) for k in ['Streams','Listeners','Streams / Listener','Playlist adds','Saves']}
  chart=chart_rows(c['chart'])
  if chart:start,end=chart[0]['date'],chart[-1]['date'];bounds='observed rendered chart date labels'
  else:
   n={'7_days':7,'28_days':28,'12_months':365}[key];end=full[-1]['date'];start=(datetime.fromisoformat(end)-timedelta(days=n-1)).date().isoformat();bounds='derived from same-release full chart endpoint and selected period length; validated by stream sum'
  subset=sum(r['streams'] for r in full if start<=r['date']<=end)
  comparison=re.search(r'row "Worldwide ([\d,]+|—) ([\d,]+) (.*?)"',dom)
  previous=number(comparison[1]) if comparison and comparison[1]!='—' else None
  periods.append({'release_id':rid,'release_title':title,'period':key,'start_date':start,'end_date':end,'bounds_method':bounds,'streams':vals['Streams'],'listeners':vals['Listeners'],'streams_per_listener_displayed':vals['Streams / Listener'],'playlist_adds':vals['Playlist adds'],'saves':vals['Saves'],'previous_period_streams_displayed':previous,'previous_period_status':'not_reported_dash' if previous is None else 'observed','captured_chart_points':len(chart),'source':p.name,'source_url':c['url'],'collected_at':c['collected_at']})
  checks.append({'release_id':rid,'release_title':title,'period':key,'period_card_streams':vals['Streams'],'full_chart_subset_sum':subset,'difference':subset-vals['Streams'],'captured_window_chart_sum':sum(r['streams'] for r in chart) if chart else None,'status':'match' if subset==vals['Streams'] and (not chart or sum(r['streams'] for r in chart)==vals['Streams']) else 'unresolved_difference','source':p.name})
assert len(meta)==7 and len(periods)==28 and len(daily)==7168
save('release_metadata.csv',meta);save('release_periods.csv',periods);save('release_daily_streams.csv',daily);save('release_detail_reconciliation.csv',checks)
summary={'release_count':len(meta),'period_rows':len(periods),'daily_rows':len(daily),'daily_coverage':'1024 consecutive observed chart dates per release, 2024-01-01 through 2026-10-20','native_csv':'Not exposed on inspected release detail pages; output is DOM-derived','period_reconciliation':{'matches':sum(r['status']=='match' for r in checks),'total':len(checks)},'all_time_discrepancies':[r for r in meta if r['history_minus_all_time']>0],'releases':meta,'nonadditivity':'Shared recordings recur across album/single releases; do not sum release totals into artist totals. Release unique listeners also cannot be summed.'}
(ROOT/'analysis/release_details.json').write_text(json.dumps(summary,indent=2)+'\n')
lookup={(r['release_id'],r['period']):r for r in periods}
table='\n'.join('| '+ ' | '.join([r['release_title'],r['release_date'],f"{r['all_time_streams_displayed']:,}",f"{r['history_streams_sum']:,}",f"{lookup[(r['release_id'],'12_months')]['streams']:,}",f"{lookup[(r['release_id'],'28_days')]['streams']:,}",f"{lookup[(r['release_id'],'7_days')]['streams']:,}"])+ ' |' for r in meta)
md=f'''# Release detail audit

Seven release detail pages were inspected read-only. Every release has direct overview metrics for the latest 7 days, latest 28 days, latest 12 months, and the custom January 1, 2024–October 20, 2026 window. The custom chart exposes **1,024 consecutive daily stream labels per release** (7,168 rows total). Native CSV export was not exposed on the inspected release detail pages; the retained evidence is rendered DOM and chart accessibility labels, not a claimed native export.

| Release | Release date | All-time header | Jan 2024–Oct 20, 2026 | Latest 12 months | Latest 28 days | Latest 7 days |
|---|---|---:|---:|---:|---:|---:|
{table}

All figures above are **streams**. Period unique listeners, playlist adds, saves, rounded displayed streams/listener, and observed prior-period stream counts are in `normalized/release_periods.csv`. Missing prior-period values remain blank with explicit status. Do not calculate distinct-listener conversions from sums of daily listeners or release listeners.

## Reconciliation

The full daily series reproduces **{summary['period_reconciliation']['matches']} of {len(checks)}** captured period stream cards. Period chart arrays where captured also agree with their card. Crawl's shorter-window chart arrays were not separately retained, but its direct period cards are verified against slices of its full 1,024-day chart. For those three rows, exact bounds are derived from the full chart endpoint and selected 7/28/365-day length and labeled accordingly. All other bounds come directly from retained chart date labels.

Three contradictions remain: **Funny Guy's custom history totals 30,549 streams versus an all-time header of 29,786** (history exceeds header by **763**); the **[REDACTED] album totals 81,391 versus an all-time header of 81,263** (exceeds by **128**); and **The Devil Wears Docs totals 11,872 versus an all-time header of 11,861** (exceeds by **11**). Both values are retained for each release. The captures do not explain the discrepancies, so no source is silently corrected or treated as reconciled. GOOMH! and Lab Tapes were released in 2023, before the daily-history start; their smaller 2024-onward sums need not equal lifetime totals, but the unavailable earlier daily history cannot be reconstructed from the residual.

## Nonadditivity and scope

The album and singles share recordings. Release totals must not be added into artist totals or described as distinct catalog streams without deduplication by recording. Period release listeners also overlap and cannot be summed into artist unique listeners. Compare the releases individually; use the separate recording-level audit for a deduplicated catalog view. All-time cumulative counts do not establish an all-time daily history.

The release pages expose a checklist and Share your stats control. They were not used to create campaigns or publish content. No account data changed.

## Outputs

- `captured/agent_release_<release_id>_bundle.json`: seven bundles, each preserving four selected-period DOM snapshots, URLs, timestamps, and captured chart labels.
- `normalized/release_metadata.csv`: seven release identities, dates, all-time headers, daily-history scope and reconciliation status.
- `normalized/release_periods.csv`: 28 direct period overview rows.
- `normalized/release_daily_streams.csv`: 7,168 daily rows, retaining release ID and source filename.
- `normalized/release_detail_reconciliation.csv`: 28 period-card versus full-chart checks.
- `analysis/release_details.json`: machine-readable summary and issues.

Reproduce with `analysis/analyze_release_details.py`. Definition context: `analysis/definitions_notes.md`, especially release/song duplication and history limits.
'''
(ROOT/'analysis/release_details.md').write_text(md)
print(json.dumps({'releases':meta,'reconciliation':summary['period_reconciliation']},indent=2))
