# Song playlist breakdowns

Checked all 14 catalog song IDs. Three songs loaded playlist tables for Last 28 days and Last 12 months: 52 rows across six tables. The remaining 11 song pages showed Spotify’s generic stats error, preserved as unavailable.

| Song | Period | Displayed playlists | Reported playlists | Streams in displayed rows |
|---|---|---:|---:|---:|
| The Cut (Starts Tomorrow) | Last 28 days | 4 | 83 | 38 |
| The Cut (Starts Tomorrow) | Last 12 months | 10 | 214 | 958 |
| Funny Guy | Last 28 days | 5 | 242 | 188 |
| Funny Guy | Last 12 months | 20 | 1,097 | 2,441 |
| The Devil Wears Docs | Last 28 days | 2 | 89 | 11 |
| The Devil Wears Docs | Last 12 months | 11 | 326 | 4,589 |

## Interpretation and coverage

- All successful captures are explicitly Top tables, not complete playlist inventories.
- Playlist counts refer to each song and period; summing across songs double-counts playlists.
- Streams are shown; listeners are not exposed in song playlist tables.
- Missing makers and dates remain blank with missing_dash status.
- 11 song playlist pages returned the site generic stats error; values remain missing, not zero.
- Crawl, GOOMH! and THIS MACHINE remained unavailable after one reload; other error pages were read after initial loading settled.
- Latest 24 hours and Last 7 days were exposed options but not captured in this supplementary song-playlist pass.
- Exact date boundaries were absent. The date bounds in the normalized tables are blank.
- The local playlist-table filter is authoritative. The disabled page-level 28-day control remained visible even when the table showed Last 12 months.

## Evidence

Each normalized row points to `captured/agent_song_playlists_<song_id>_bundle.json`, containing the rendered DOM and table cell extraction. `normalized/song_playlist_coverage.csv` retains both requested periods for every song, including 22 unavailable song-period combinations.

## Displayed annual highlights

- Funny Guy: Mixes 1,043 streams; Radio 446; Your DJ 241. Pure Punk contributed 151 in the displayed table.
- The Cut (Starts Tomorrow): Radio 508; Mixes 148; Release Radar 117; Slipknot Radio 78.
- The Devil Wears Docs: Release Radar 2,961; Radio 1,052; Your DJ 150. These are song-level playlist rows, not additive artist-source totals.
