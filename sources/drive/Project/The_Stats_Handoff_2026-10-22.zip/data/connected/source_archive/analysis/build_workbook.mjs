// Reproduce with analysis/build_workbook.sh (primary runtime; --max-old-space-size=8192).
import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const root = process.env.STATS_ROOT || '/workspace/scratch/84b5e0c87afd';
const output = path.join(root, 'deliverables');
const qa = path.join(root, 'qa/workbook');
await fs.mkdir(output, {recursive:true});
await fs.mkdir(qa, {recursive:true});
const wb = Workbook.create();
const navy='#142D38', green='#207E64', pale='#EAF3EF', ink='#253C46', grey='#657780';
const names = ['Overview','Period comparison','Song comparison','Data index','Artist daily','Artist monthly','Artist periods','Artist metrics','Artist sources','Audience segments','Demographics','Geography','Catalog','Song daily','Song periods','Release data','Release history','Release engagement','Playlists','Content','Checks','ReadMe'];
const sheets = Object.fromEntries(names.map(n=>[n,wb.worksheets.add(n)]));
const cursors = Object.fromEntries(names.map(n=>[n,5]));
const registry = {};
const datasets=[];
const widths = Object.fromEntries(names.map(n=>[n,[]]));
const title = s=>s.replace(/\.csv$/,'').replace(/_/g,' ').replace(/\b\w/g,x=>x.toUpperCase());
const col = i=>{let s=''; for(let n=i+1;n>0;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const quote = n=>`'${n.replace(/'/g,"''")}'`;
const route = f=>{
  if(f==='artist_daily.csv')return 'Artist daily';
  if(f==='artist_monthly.csv')return 'Artist monthly';
  if(f==='artist_period_dashboard.csv')return 'Artist metrics';
  if(/reconciliation|validation|quality|coverage|audit|crosscheck|errors/.test(f))return 'Checks';
  if(/^artist_source/.test(f))return 'Artist sources';
  if(/^artist_period/.test(f))return 'Artist periods';
  if(/^audience_demographics/.test(f))return 'Demographics';
  if(/^audience_top/.test(f))return 'Geography';
  if(/^song_(location|countr|cit)/.test(f))return 'Geography';
  if(/^audience_/.test(f))return 'Audience segments';
  if(/release_engagement/.test(f))return 'Release engagement';
  if(/^release_daily/.test(f))return 'Release history';
  if(/^release_(metadata|periods)/.test(f))return 'Release data';
  if(/playlist/.test(f))return 'Playlists';
  if(/content|canvas|campaign/.test(f))return 'Content';
  if(/periods_from_daily/.test(f))return 'Song periods';
  if(/song.*daily|daily.*song/.test(f))return 'Song daily';
  if(/catalog|mapping|release_tracks|release_summary/.test(f))return 'Catalog';
  if(/^song|^track|^release/.test(f))return 'Song periods';
  return 'Checks';
};
const descriptions = {
  'artist_daily.csv':'Native artist timeline. Daily listeners are unique within a day. Rolling audiences and follower stocks must not be summed.',
  'artist_monthly.csv':'Calendar-month activity. October 2026 includes October 1–20 only. Compare daily averages for incomplete months.',
  'artist_periods_integrated.csv':'Selected-period activity with direct dashboard unique listeners. Followers and rolling audience measures are endpoint stocks.',
  'artist_periods_from_timeline.csv':'Timeline aggregation before dashboard unique-listener integration. Blank period listeners remain unavailable.',
  'artist_period_dashboard.csv':'Direct dashboard period totals. YTD uses the preceding 293 days in the platform comparison, not prior-year matching dates.',
  'artist_period_comparisons.csv':'Calculated activity changes. The YTD comparison here uses matching prior-year dates.',
  'artist_period_reconciliation.csv':'Independent comparison of direct dashboard figures with the native timeline.',
  'artist_sources_28day.csv':'Source listener counts can overlap. Source groups and detailed categories are separate levels and must not be summed together.',
  'artist_source_ratios_28day.csv':'Streams divided by listeners within the same source and window. These ratios are not conversion rates.',
  'audience_segment_snapshot.csv':'Two-year audience segments as of October 20, 2026. Displayed percentages are rounded.',
  'audience_segment_daily.csv':'Rolling audience stocks from September 23 to October 20, 2026. Do not sum dates.',
  'audience_active_subsegments.csv':'Active-listener tiers. Displayed streams per listener and shares are rounded.',
  'audience_development.csv':'Separate flow measures. New, reactivated and new active listeners do not form an additive funnel.',
  'audience_demographics_gender.csv':'Gender counts total 1,064, compared with 1,062 artist monthly listeners. Preserve the source discrepancy.',
  'audience_demographics_age.csv':'Age-cell counts total 1,063. Shares are the rounded values displayed by Spotify.',
  'audience_demographics_age_gender.csv':'Observed age-by-gender cells. Explicit zero is retained; counts have not been rescaled.',
  'audience_top_countries.csv':'All 23 displayed top-country rows. Peru active values are unavailable. Ranked coverage is not exhaustive.',
  'audience_top_cities.csv':'All 50 displayed top-city ranks. Small counts do not establish ticket sales or reachable fans.',
  'artist_playlists.csv':'Native export and displayed playlist rows. Exact period date bounds were not exposed and remain blank. Playlist listener counts overlap.',
  'artist_playlist_summary.csv':'Visible playlist-category coverage by selected period. These are reported playlist totals, not a complete source-of-stream partition.',
  'artist_playlist_reconciliation.csv':'Native playlist export compared with all displayed rows for each selected period.',
  'release_engagement_cohort_crosscheck.csv':'Release engagement baseline differs from the artist timeline on the prerelease cohort date. Both observed figures are retained.',
  'release_engagement_snapshot.csv':'Fixed April 23 prerelease cohort for the April 24 release. Segment engagement sums do not reconcile with aggregate engagement.',
  'release_engagement_daily.csv':'Cumulative release-day engagement within the fixed prerelease cohort. Do not sum release days.',
  'release_engagement_source_comparison.csv':'Active-source and all-source release engagement for matching cohort segments. Missing source views remain unavailable.',
  'content_feature_status.csv':'Observed campaign and content-feature availability. An empty list is not proof that a tool was never used. Performance remains unavailable where not exposed.',
  'canvas_card_inventory.csv':'Observed Canvas selector/card appearances. A card does not establish whether a published Canvas asset exists.',
  'release_metadata.csv':'Displayed lifetime stream counters and release metadata. Several lifetime headers are below selected-history sums; both are retained.',
  'release_periods.csv':'Direct release overview periods. Release listener counts overlap and releases share recordings. Do not sum release totals into artist totals.',
  'release_daily_streams.csv':'Daily release streams from the rendered full-history chart. Shared single/album recordings make release totals nonadditive.',
  'release_detail_reconciliation.csv':'Selected release stream totals compared with corresponding daily chart sums.',
  'song_28day_rankings_ratios.csv':'Distinct recordings. Detail-view saves of zero are retained when explicitly observed; the original catalog dash and basis remain separate.',
  'catalog_stream_contributions.csv':'Contribution to the artist stream change. Negative contributors and contributions above 100% can occur when gains and declines offset.',
  'song_playlists.csv':'Reported song-playlist rows. Failed song pages remain unavailable in the coverage table; no missing rows are treated as zero. Exact period bounds were not exposed.',
  'song_playlist_coverage.csv':'One record per attempted song and selected period, including page errors. Available rows do not imply complete playlist coverage.',
  'song_locations.csv':'All captured top song-location rows. The metric is streams. Country totals can differ from the song total; page-error gaps are retained separately.',
  'song_location_coverage.csv':'Per-song geographic capture status, including site errors and differences between top-country sums and the song total.',
  'song_location_country_comparison_daily.csv':'Daily streams for the selected comparison countries in the latest 28-day song view. This is not an exhaustive country-by-date matrix.'
};
function setup(s,n){
  s.showGridLines=false;
  s.getRange('A1:P40').format.font={name:'Arial',size:10,color:ink};
  s.getRange('A1:P40').format.verticalAlignment='center';
  s.getRange('A2').values=[[n]];
  s.getRange('A2').format.font={name:'Arial',size:16,bold:true,color:navy};
  s.getRange('A3:P3').format.borders={bottom:{style:'thin',color:green}};
  s.getRange('A1:P40').format.columnWidth=16;
  s.getRange('A:A').format.columnWidth=27;
}
for(const [n,s] of Object.entries(sheets))setup(s,n);
sheets.Overview.tabColor=navy;
sheets['Period comparison'].tabColor=green;
sheets['Song comparison'].tabColor=green;
sheets['Data index'].tabColor='#B5CFC5';
sheets.ReadMe.tabColor='#81949E';
function header(s,r,n){
  const x=s.getRangeByIndexes(r-1,0,1,n);
  x.format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,horizontalAlignment:'center',verticalAlignment:'center',rowHeight:42};
  x.format.borders={insideVertical:{style:'thin',color:'#FFFFFF'}};
}
function fmt(h,values){
  if(h==='month'&&values.some(x=>x instanceof Date))return 'mmm yyyy';
  if(values.some(x=>x instanceof Date))return 'mmm d, yyyy';
  if(/_pct_|_pct$|percent_change|percentage/.test(h))return '0.0"%"';
  if(/share_of_total_streams|stream_share_artist|share_of_artist_net_change/.test(h))return '0.0%';
  if(/per_100_/.test(h))return '0.0';
  if(/per_listener|per_source_listener|per_day/.test(h))return '0.000';
  if(values.some(x=>typeof x==='number'&&!Number.isInteger(x)))return '#,##0.000';
  return '#,##0';
}
function value(x,h){
  if(x===null||x===undefined||x==='')return null;
  const s=String(x);
  if(h==='month'&&/^\d{4}-\d{2}$/.test(s))return new Date(s+'-01T00:00:00Z');
  if(/^\d{4}-\d{2}-\d{2}$/.test(s))return new Date(s+'T00:00:00Z');
  if(/^true$/i.test(s))return true;
  if(/^false$/i.test(s))return false;
  if(/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(s)&&!/(^|_)(id|code|uri)($|_)/.test(h))return Number(s);
  return s;
}
// Parse RFC 4180 CSV without constructing temporary workbooks for source ingestion.
// All spreadsheet authoring, calculation, rendering and export use Artifact Tool.
function parseCSV(text){
  const rows=[];let row=[],field='',quoted=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i];
    if(quoted){if(ch==='"'){if(text[i+1]==='"'){field+='"';i++;}else quoted=false;}else field+=ch;}
    else if(ch==='"'&&field==='')quoted=true;
    else if(ch===','){row.push(field);field='';}
    else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(field);rows.push(row);row=[];field='';}
    else field+=ch;
  }
  if(quoted)throw new Error('Unterminated quoted CSV field');
  if(field!==''||row.length){row.push(field);rows.push(row);}
  return rows;
}
const files=(await fs.readdir(path.join(root,'normalized'))).filter(f=>f.endsWith('.csv')).sort();
for(const f of files){
  const csv=await fs.readFile(path.join(root,'normalized',f),'utf8');
  const grid=parseCSV(csv);
  const headers=grid[0].map(x=>String(x??'').replace(/^\uFEFF/,''));
  const body=grid.slice(1).filter(r=>r.some(v=>v!==null&&v!==''));
  if(f==='song_chart_points.csv'){
    datasets.push([f,'Companion archive','Evidence only',body.length,'Repeated UI chart evidence. Canonical daily and period datasets are included in this workbook.']);
    continue;
  }
  const n=route(f),s=sheets[n];
  const section=cursors[n],r=section+3,end=r+body.length;
  s.getRange(`A${section}`).values=[[f==='artist_daily.csv'?'Daily observations':f==='artist_monthly.csv'?'Calendar-month totals':title(f)]];
  s.getRange(`A${section}`).format.font={name:'Arial',size:11,bold:true,color:green};
  s.getRange(`A${section+1}`).values=[[`Source: ${f}. ${descriptions[f]||'Normalized captured Spotify for Artists data. Retain the source, period and missing-value fields when filtering.'}`]];
  s.getRange(`A${section+1}`).format.font={name:'Arial',size:10,italic:true,color:grey};
  s.getRangeByIndexes(r-1,0,1,headers.length).values=[headers.map(title)];
  for(let offset=0;offset<body.length;offset+=5000){
    const batch=body.slice(offset,offset+5000).map(row=>headers.map((h,i)=>value(row[i],h)));
    s.getRangeByIndexes(r+offset,0,batch.length,headers.length).values=batch;
  }
  const area=s.getRangeByIndexes(r-1,0,body.length+1,headers.length);
  area.format.font={name:'Arial',size:10,color:ink};
  area.format.rowHeight=21;
  area.format.verticalAlignment='center';
  header(s,r,headers.length);
  if(body.length){
    const table=s.tables.add(`A${r}:${col(headers.length-1)}${end}`,true,'Data_'+f.replace(/\.csv$/,'').replace(/[^A-Za-z0-9_]/g,''));
    table.showFilterButton=true;
    table.style='TableStyleMedium2';
    for(let i=0;i<headers.length;i++){
      const vals=body.map(row=>value(row[i],headers[i]));
      const range=s.getRangeByIndexes(r,i,body.length,1);
      range.setNumberFormat(fmt(headers[i],vals));
      range.format.horizontalAlignment=vals.some(v=>typeof v==='number'||v instanceof Date)?'right':'left';
      if(n==='Checks'&&/^(difference|panel_minus_timeline|subsegment_sum_minus_total)$/.test(headers[i])){
        range.conditionalFormats.add('cellIs',{operator:'notEqual',formula:0,format:{fill:'#FCE8E5',font:{color:'#A42A22',bold:true}}});
      }
      const contentMax=body.reduce((m,row)=>Math.max(m,String(row[i]??'').length),headers[i].length/1.5);
      const width=/source|notes|status|coverage|method|extraction|type|raw|name|title|song|release|category|metric|comparison|window|segment/.test(headers[i])?Math.min(62,Math.max(22,contentMax+2)):Math.min(24,Math.max(14,contentMax+2));
      widths[n][i]=Math.max(widths[n][i]||0,width,i===0?22:14);
      if(contentMax>width){
        range.format.wrapText=true;
        // Long narrative fields retain all text; small source tables get fitted rows.
        if(body.length<500){
          for(let ri=0;ri<body.length;ri++){
            const need=Math.max(21,Math.ceil(String(body[ri][i]??'').length/(width*.9))*13+7);
            if(need>21)s.getRangeByIndexes(r+ri,0,1,headers.length).format.rowHeight=need;
          }
        }
      }
    }
  }
  s.freezePanes.freezeRows(8);
  s.freezePanes.freezeColumns(1);
  registry[f]={sheet:n,start:r+1,end,headers,body,headerRow:r};
  if(f==='artist_period_dashboard.csv')for(let bi=0;bi<body.length;bi++){
    const metric=String(body[bi][headers.indexOf('metric')]);
    for(const h of ['current_value','previous_value','absolute_change']){
      const ci=headers.indexOf(h);
      if(ci>=0)s.getRangeByIndexes(r+bi,ci,1,1).setNumberFormat(metric==='streams_per_listener'?'0.000':'#,##0');
    }
  }
  datasets.push([f,n,`A${r}:${col(headers.length-1)}${end}`,body.length,descriptions[f]||'See row-level period, source and status fields.']);
  cursors[n]=end+4;
  console.log(`Imported ${f}: ${body.length} rows`);
}
for(const [n,ws] of Object.entries(widths))for(let i=0;i<ws.length;i++)if(ws[i])sheets[n].getRange(`${col(i)}1:${col(i)}${cursors[n]}`).format.columnWidth=ws[i];
function ref(file,index,field){const d=registry[file];if(!d)return null;return `${quote(d.sheet)}!${col(d.headers.indexOf(field))}${d.start+index}`;}
function find(file,criteria){const d=registry[file];if(!d)return -1;return d.body.findIndex(r=>Object.entries(criteria).every(([k,v])=>String(r[d.headers.indexOf(k)])===v));}
function source(file,criteria,field){const i=find(file,criteria);return i<0?null:ref(file,i,field);}
function safeLink(r){return r?`=IF(ISNUMBER(${r}),${r},"n.a.")`:'="n.a."';}

// One calculation area owns period changes and activity ratios.
const p=sheets['Period comparison'];
p.getRange('A3').values=[['Counts and activity ratios. Dashboard YTD compares with the preceding 293 days.']];
const pHeaders=['Period','Metric','Start','End','Current','Previous','Change','Change %','Prior start','Prior end','Comparison'];
p.getRange('A5:K5').values=[pHeaders];header(p,5,11);
const metricData=registry['artist_period_dashboard.csv'];
const periodRows={};
if(metricData){
  for(let i=0;i<metricData.body.length;i++){
    const row=metricData.body[i],r=6+i,get=h=>row[metricData.headers.indexOf(h)];
    const period=String(get('period')),metric=String(get('metric'));periodRows[period+'|'+metric]=r;
    p.getRange(`A${r}:D${r}`).values=[[period,metric.replace(/_/g,' '),value(get('start_date'),'date'),value(get('end_date'),'date')]];
    p.getRange(`E${r}:H${r}`).formulas=[[safeLink(ref('artist_period_dashboard.csv',i,'current_value')),safeLink(ref('artist_period_dashboard.csv',i,'previous_value')),`=IF(AND(ISNUMBER(E${r}),ISNUMBER(F${r})),E${r}-F${r},"n.a.")`,`=IF(AND(ISNUMBER(E${r}),ISNUMBER(F${r})),IF(F${r}=0,"n.a.",G${r}/F${r}),"n.a.")`]];
    p.getRange(`I${r}:K${r}`).values=[[value(get('previous_period_start'),'date'),value(get('previous_period_end'),'date'),String(get('comparison_type')??'')]];
    p.getRange(`E${r}:G${r}`).setNumberFormat(metric==='streams_per_listener'?'0.000':'#,##0');
    p.getRange(`E${r}:H${r}`).format.horizontalAlignment='right';
  }
}
p.getRange('A6:B45').format.columnWidth=23;p.getRange('C6:D45').setNumberFormat('mmm d, yyyy');p.getRange('I6:J45').setNumberFormat('mmm d, yyyy');
p.getRange('H6:H45').setNumberFormat('0.0%');p.getRange('K:K').format.columnWidth=55;
p.freezePanes.freezeRows(5);p.freezePanes.freezeColumns(2);

// Compare distinct recordings with matched period denominators.
const sc=sheets['Song comparison'];
sc.getRange('A3').values=[['September 23–October 20, 2026. Each Spotify recording ID appears once.']];
const scHeads=['Recording','28d streams','Prior 28d streams','Stream change','28d listeners','Streams / listener','Saves','Saves / listener','Playlist adds','Stream share','7d streams','7d / 28d daily rate'];
sc.getRange('A5:L5').values=[scHeads];header(sc,5,scHeads.length);
const catalog=registry['song_catalog.csv'];
const artistStreamRef=source('artist_period_dashboard.csv',{period:'28day',metric:'streams'},'current_value');
if(catalog){
 for(let i=0;i<catalog.body.length;i++){
   const rr=6+i,songId=String(catalog.body[i][catalog.headers.indexOf('song_id')]);
   const label=String(catalog.body[i][catalog.headers.indexOf('recording_label')]);
   sc.getRange(`A${rr}`).values=[[label]];
   const cp=(period,field)=>source('song_catalog_periods.csv',{song_id:songId,period},field);
   const dp=(period,field)=>source('song_period_canonical.csv',{song_id:songId,period},field);
   const previous=source('song_periods_from_daily.csv',{song_id:songId,period:'previous_28day',metric:'streams'},'value');
   sc.getRange(`B${rr}:L${rr}`).formulas=[[
     safeLink(dp('28day','streams')||cp('28day','streams')),
     safeLink(previous),
     `=IF(AND(ISNUMBER(B${rr}),ISNUMBER(C${rr})),IF(C${rr}=0,"n.a.",B${rr}/C${rr}-1),"n.a.")`,
     safeLink(dp('28day','listeners')||cp('28day','listeners')),
     `=IF(AND(ISNUMBER(B${rr}),ISNUMBER(E${rr})),IF(E${rr}=0,"n.a.",B${rr}/E${rr}),"n.a.")`,
     safeLink(dp('28day','saves')||cp('28day','saves')),
     `=IF(AND(ISNUMBER(G${rr}),ISNUMBER(E${rr})),IF(E${rr}=0,"n.a.",G${rr}/E${rr}),"n.a.")`,
     safeLink(dp('28day','playlist_adds')),
     artistStreamRef?`=IF(${artistStreamRef}=0,"n.a.",B${rr}/${artistStreamRef})`:'="n.a."',
     safeLink(dp('7day','streams')||cp('7day','streams')),
     `=IF(AND(ISNUMBER(K${rr}),ISNUMBER(B${rr})),IF(B${rr}=0,"n.a.",(K${rr}/7)/(B${rr}/28)),"n.a.")`
   ]];
 }
 const last=5+catalog.body.length,total=last+2;
 sc.getRange(`A${total}`).values=[['Distinct recording streams']];sc.getRange(`B${total}`).formulas=[[`=SUM(B6:B${last})`]];
 sc.getRange(`A${total}:B${total}`).format.font={bold:true,color:navy};
 sc.getRange(`A${total+3}`).values=[['Saves/listener is an activity ratio. Listeners overlap between recordings and are not summed.']];
 sc.getRange(`A${total+4}`).values=[['The daily-rate index compares the most recent 7 days with the overlapping 28-day average. 1.00x means equal daily pace.']];
 sc.getRange(`A${total+5}`).values=[['Blank source values remain n.a. A prior 28-day sum is shown only when a complete matching timeline is available.']];
 sc.getRange(`A${total+3}:A${total+5}`).format.font={italic:true,color:grey};
 sc.getRange(`B6:L${last}`).setNumberFormat('#,##0');
 sc.getRange(`D6:D${last}`).setNumberFormat('0.0%');sc.getRange(`J6:J${last}`).setNumberFormat('0.0%');
 sc.getRange(`F6:F${last}`).setNumberFormat('0.000');sc.getRange(`H6:H${last}`).setNumberFormat('0.000');sc.getRange(`L6:L${last}`).setNumberFormat('0.00"x"');
 sc.getRange(`B6:L${last}`).format.horizontalAlignment='right';
 sc.getRange(`A6:L${last}`).format.rowHeight=24;
 sc.getRange('A:A').format.columnWidth=40;sc.getRange('B:L').format.columnWidth=16;
 sc.freezePanes.freezeRows(5);sc.freezePanes.freezeColumns(1);
}

const ov=sheets.Overview;
ov.getRange('A2').values=[['The Stats™: [REDACTED]']];
ov.getRange('A3').values=[['Latest 28 days: September 23–October 20, 2026. Worldwide.']];
ov.getRange('A5:D5').values=[['Metric','Current','Previous','Change %']];header(ov,5,4);
const shown=[['Streams','streams'],['Unique listeners','listeners'],['Streams per listener','streams_per_listener'],['Saves','saves'],['Playlist adds','playlist_adds'],['Followers at period end','followers']];
for(let i=0;i<shown.length;i++){
 const r=6+i,pr=periodRows['28day|'+shown[i][1]];
 ov.getRange(`A${r}`).values=[[shown[i][0]]];
 if(pr)ov.getRange(`B${r}:D${r}`).formulas=[[`='Period comparison'!E${pr}`,`='Period comparison'!F${pr}`,`='Period comparison'!H${pr}`]];
}
ov.getRange('B6:C11').setNumberFormat('#,##0');ov.getRange('B8:C8').setNumberFormat('0.000');ov.getRange('D6:D11').setNumberFormat('0.0%');
ov.getRange('A:A').format.columnWidth=29;ov.getRange('B:D').format.columnWidth=14;
ov.getRange('A13').values=[['Listening depth']];ov.getRange('A13').format.font={bold:true,color:green};
ov.getRange('A15:C15').values=[['Measure','Value','Meaning']];header(ov,15,3);
const sr=periodRows['28day|streams'],lr=periodRows['28day|listeners'],sav=periodRows['28day|saves'],pa=periodRows['28day|playlist_adds'];
const ratioDefs=[['Saves per listener',sav,'Activity / unique listener'],['Playlist adds per listener',pa,'Activity / unique listener']];
for(let i=0;i<ratioDefs.length;i++){let r=16+i;ov.getRange(`A${r}`).values=[[ratioDefs[i][0]]];if(lr&&ratioDefs[i][1])ov.getRange(`B${r}`).formulas=[[`=IF('Period comparison'!E${lr}=0,"n.a.",'Period comparison'!E${ratioDefs[i][1]}/'Period comparison'!E${lr})`]];ov.getRange(`C${r}`).values=[[ratioDefs[i][2]]];}
ov.getRange('B16:B17').setNumberFormat('0.000');
ov.getRange('A19').values=[['These activity ratios are not unique-person conversion rates.']];ov.getRange('A19').format.font={italic:true,color:grey};
ov.getRange('A22').values=[['Audience as of October 20']];ov.getRange('A22').format.font={bold:true,color:green};
ov.getRange('A24:B24').values=[['Audience segment','Listeners']];header(ov,24,2);
const seg=registry['audience_active_subsegments.csv'];
if(seg){for(let i=0;i<seg.body.length;i++){const r=25+i;ov.getRange(`A${r}`).values=[[String(seg.body[i][seg.headers.indexOf('segment')])]];ov.getRange(`B${r}`).formulas=[[safeLink(ref('audience_active_subsegments.csv',i,'listeners'))]];}}
ov.getRange('B25:B27').setNumberFormat('#,##0');
ov.getRange('A30').values=[['Interpretation']];ov.getRange('A30').format.font={bold:true,color:green};
ov.getRange('A32').values=[['Recent streams recovered while monthly reach declined.']];
ov.getRange('A33').values=[['Compare the 90-day slowdown with the strong 12-month expansion.']];
ov.getRange('A34').values=[['Use song, source and release-cohort evidence to prioritize repeat listening.']];
ov.getRange('F28:J28').values=[['Period','Streams','Stream change','Listeners','Listener change']];
const hp=ov.getRange('F28:J28');hp.format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,horizontalAlignment:'center',rowHeight:35};
const summaryPeriods=[['7 days','7day'],['28 days','28day'],['90 days','90day'],['12 months','12months']];
for(let i=0;i<summaryPeriods.length;i++){
 const r=29+i,[label,key]=summaryPeriods[i],st=periodRows[key+'|streams'],lt=periodRows[key+'|listeners'];
 ov.getRange(`F${r}`).values=[[label]];
 if(st&&lt)ov.getRange(`G${r}:J${r}`).formulas=[[`='Period comparison'!E${st}`,`='Period comparison'!H${st}`,`='Period comparison'!E${lt}`,`='Period comparison'!H${lt}`]];
}
const ys=source('artist_periods_integrated.csv',{window:'year_to_date'},'streams'),yp=source('artist_periods_integrated.csv',{window:'previous_year_same_dates'},'streams'),yl=source('artist_periods_integrated.csv',{window:'year_to_date'},'period_unique_listeners'),ypl=source('artist_periods_integrated.csv',{window:'previous_year_same_dates'},'period_unique_listeners');
ov.getRange('F33').values=[['YTD (YoY)']];
if(ys&&yp)ov.getRange('G33:H33').formulas=[[`=${ys}`,`=IF(${yp}=0,"n.a.",${ys}/${yp}-1)`]];
ov.getRange('I33:J33').formulas=[[safeLink(yl),yl&&ypl?`=IF(AND(ISNUMBER(${yl}),ISNUMBER(${ypl})),IF(${ypl}=0,"n.a.",${yl}/${ypl}-1),"n.a.")`:'="n.a."']];
ov.getRange('G29:J33').setNumberFormat('#,##0');ov.getRange('H29:H33').setNumberFormat('0.0%');ov.getRange('J29:J33').setNumberFormat('0.0%');
ov.getRange('G29:J33').format.horizontalAlignment='right';
ov.getRange('F35').values=[['YTD stream change uses January 1–October 20 in both years.']];ov.getRange('F35').format.font={italic:true,color:grey};

// Native chart: monthly streams per observed day includes partial October fairly.
const m=registry['artist_monthly.csv'];
if(m){
  const begin=Math.max(0,m.body.length-13),sh=sheets['Artist monthly'];let hr=m.end+7;
  sh.getRange(`A${hr}:B${hr}`).values=[['Month','Streams per observed day']];header(sh,hr,2);
  for(let i=begin;i<m.body.length;i++){
    const r=hr+1+i-begin,month=String(m.body[i][m.headers.indexOf('month')]);
    sh.getRange(`A${r}`).values=[[month]];
    sh.getRange(`B${r}`).formulas=[[`=${ref('artist_monthly.csv',i,'streams')}/${ref('artist_monthly.csv',i,'days_observed')}`]];
  }
  sh.getRange(`B${hr+1}:B${hr+m.body.length-begin}`).setNumberFormat('0.0');
  const chart=ov.charts.add('line',[sh.getRange(`A${hr}:A${hr+m.body.length-begin}`),sh.getRange(`B${hr}:B${hr+m.body.length-begin}`)]);
  chart.title='Monthly streams per observed day';chart.titleTextStyle.fontSize=13;chart.titleTextStyle.typeface='Arial';chart.hasLegend=false;
  chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:10}};
  chart.yAxis={numberFormatCode:'0',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:10}};
  chart.series.items[0].line={fill:green,style:'solid',width:2};
  chart.setPosition('F5','N23');
  ov.getRange('F25').values=[['October includes 20 days. Full history starts January 1, 2024.']];ov.getRange('F25').format.font={italic:true,color:grey};
}

// Keep all normalized data discoverable, including source overlap and audit-only datasets.
const idx=sheets['Data index'];
idx.getRange('A3').values=[['All normalized CSVs are indexed. Repeated chart evidence is archive-only; canonical datasets are reproduced in full.']];
idx.getRange('A5:E5').values=[['Dataset','Worksheet','Range','Rows','Scope / caution']];header(idx,5,5);
if(datasets.length)idx.getRangeByIndexes(5,0,datasets.length,5).values=datasets;
idx.getRange('A:A').format.columnWidth=48;idx.getRange('B:B').format.columnWidth=23;idx.getRange('C:D').format.columnWidth=15;idx.getRange('E:E').format.columnWidth=110;
idx.getRange(`A6:E${6+datasets.length}`).format.rowHeight=24;idx.freezePanes.freezeRows(5);

// Definitions and material limitations, retained once with the source workflow.
const readme=sheets.ReadMe;
readme.getRange('A3').values=[['Scope, definitions and refresh instructions']];
const notes=[
['Scope','Private Spotify for Artists audit. Reporting endpoint October 20, 2026. Worldwide unless a source row says otherwise.'],
['Available history','The artist daily export begins January 1, 2024. Available-history totals are not lifetime totals.'],
['Song history coverage','Twelve recordings have all five full-history metric series. Son! has four full series and 730 stream days. GOOMH! has 365 stream days only. Missing history is not filled with zero.'],
['Unique listeners','Do not add daily, song or source listeners to construct artist period unique listeners. Use the direct dashboard period total.'],
['Streams','An additive activity count. Song overview identifies audio-track-only scope; retain this distinction from other surfaces.'],
['Audience stocks','Followers, monthly listeners, monthly active listeners and super listeners are endpoint stocks. Do not add across dates.'],
['Activity ratios','Saves/listener and playlist-adds/listener divide activity counts by period unique listeners. They are not unique-person conversion rates.'],
['YTD comparison','The dashboard YTD comparison is the immediately preceding 293 days. Matching prior-year dates are separately calculated from timeline activity.'],
['Source levels','Aggregate active/programmed groups and their detailed subcategories overlap hierarchically. Never sum both levels. Source listeners overlap across categories.'],
['Missing values','Blank source values remain unavailable. Dashes are not silently converted to zero. Explicit numeric zeros remain zero.'],
['Rounded percentages','Headers containing Pct or Percent retain source units (0–100). Other fractional source-share columns use percent formatting.'],
['Audience discrepancy','Gender counts total 1,064; age-by-gender cells total 1,063; monthly unique listeners total 1,062. No forced reconciliation.'],
['Geographic scope','Country and city tables contain all displayed top rows, not a verified exhaustive geographical partition.'],
['Song identity','Join songs by Spotify ID. Shared single/album appearances count once; same title with a different recording ID remains distinct.'],
['Song counters','Keep displayed lifetime counters separate from selected-history sums. Source discrepancies are preserved in the catalog reconciliation tables.'],
['Release engagement','The fixed prerelease cohort differs from the current active audience. Engaged subsegments and the aggregate do not reconcile; the cohort baseline also differs from the artist timeline.'],
['Playlist periods','The playlist interface exposes selected 7-day, 28-day and 12-month windows without exact date boundaries. Blank boundaries are intentional.'],
['Workbook calculations','Overview and comparison sheets contain formulas linked to imported source cells. Normalized tables preserve recorded audit results and provenance; rerun the analysis scripts to refresh them.'],
['Refresh','Recollect the same scope and UTC dates. Replace normalized CSVs, regenerate with build_workbook.mjs, then inspect the figures and source discrepancies.'],
['Benchmark','No invented Spotify-wide average or matched peer percentile is used. Internal period and catalog comparisons provide the baseline.']
];
readme.getRange('A5:B5').values=[['Topic','Definition / instruction']];header(readme,5,2);readme.getRangeByIndexes(5,0,notes.length,2).values=notes;
readme.getRange('A:A').format.columnWidth=27;readme.getRange('B:B').format.columnWidth=112;readme.getRange(`B6:B${5+notes.length}`).format.wrapText=true;readme.getRange(`A6:B${5+notes.length}`).format.rowHeight=42;
readme.freezePanes.freezeRows(5);

// Avoid empty worksheets in a partial build; final run includes all completed datasets.
for(const n of names){if(cursors[n]===5&&!['Overview','Period comparison','Song comparison','Data index','ReadMe'].includes(n)){sheets[n].getRange('A5').values=[['No normalized dataset available in this build.']];}}
wb.recalculate();
const recalculationTests=[];
const ar=registry['artist_period_dashboard.csv'];
if(ar){
  const si=find('artist_period_dashboard.csv',{period:'28day',metric:'streams'});
  const li=find('artist_period_dashboard.csv',{period:'28day',metric:'listeners'});
  if(si>=0&&li>=0){
    const ci=ar.headers.indexOf('current_value');
    const streamCell=sheets[ar.sheet].getRangeByIndexes(ar.start+si-1,ci,1,1);
    const listenerCell=sheets[ar.sheet].getRangeByIndexes(ar.start+li-1,ci,1,1);
    const streamOriginal=streamCell.values[0][0],listenerOriginal=listenerCell.values[0][0];
    streamCell.values=[[streamOriginal+100]];
    recalculationTests.push({test:'Source streams update linked Overview',expected:streamOriginal+100,actual:ov.getRange('B6').values[0][0]});
    streamCell.values=[[streamOriginal]];
    listenerCell.values=[[0]];
    recalculationTests.push({test:'Zero listener denominator remains unavailable',expected:'n.a.',actual:ov.getRange('B16').values[0][0]});
    listenerCell.values=[[listenerOriginal]];
  }
}
wb.recalculate();
const checks={
  overview:(await wb.inspect({kind:'table',range:'Overview!A5:D17',include:'values,formulas',tableMaxRows:15,tableMaxCols:4,maxChars:10000})).ndjson,
  formulas:(await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'Formula error scan',maxChars:8000})).ndjson,
  datasetCount:datasets.length,
  recalculationTests,
  datasets
};
await fs.writeFile(path.join(qa,'checks.json'),JSON.stringify(checks,null,2));
await fs.writeFile(path.join(qa,'registry.json'),JSON.stringify(Object.fromEntries(Object.entries(registry).map(([k,d])=>[k,{sheet:d.sheet,start:d.start,end:d.end,headers:d.headers}])),null,2));
const previewNames=process.env.STATS_SKIP_PREVIEWS==='1'?[]:process.env.STATS_PREVIEW_ALL==='1'?names:['Overview','Period comparison','Song comparison','Data index','Artist daily','Audience segments','Demographics','Geography','ReadMe'];
console.log(`Source tables complete: ${datasets.length} indexed datasets. Rendering ${previewNames.length} sheets.`);
for(const n of previewNames){
 const range=n==='Overview'?'A1:N35':n==='ReadMe'?'A1:B27':n==='Data index'?'A1:E20':n==='Song comparison'?'A1:L25':'A1:H16';
 const image=await wb.render({sheetName:n,range,scale:1.25,format:'png'});
 await fs.writeFile(path.join(qa,n.replace(/ /g,'_')+'.png'),new Uint8Array(await image.arrayBuffer()));
 console.log(`Rendered ${n}`);
}
console.log('Exporting final XLSX');
const xlsx=await SpreadsheetFile.exportXlsx(wb);await xlsx.save(path.join(output,'The_Stats_Workbook.xlsx'));
await fs.copyFile(new URL(import.meta.url),path.join(root,'analysis/build_workbook.mjs'));
console.log(JSON.stringify({output:path.join(output,'The_Stats_Workbook.xlsx'),datasets:datasets.length,sheets:names.length,qa}));
