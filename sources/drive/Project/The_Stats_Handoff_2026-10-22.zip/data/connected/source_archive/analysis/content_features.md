# Campaign and content feature status

Read-only account inspection on **October 22, 2026**, using visible Spotify for Artists UI. Exact observed URLs and collection timestamps are in `captured/agent_features_manifest.json`. Private Campaigns/Video & Visuals capabilities were unavailable through the Spotify catalog connector, so the authorized browser session supplied the evidence.

## Campaigns

The **Display → Campaigns** list explicitly says **“No campaigns yet.”** The **Sub-campaigns** tab independently says **“No sub-campaigns yet.”** These are observed empty states for the displayed account lists. They do not establish that the artist has never advertised through any other channel.

The UI offers **Create campaign** and describes **Marquee** and **Showcase**. It says there are **no time-sensitive opportunities at the moment**, while still offering catalog promotion with Showcase. A creation control does not establish final eligibility, price, or expected returns for a chosen campaign; no creation flow was started.

There are no campaign performance rows to analyze. Spend, reach, click-through, conversion, incremental streams, and ROI are **unavailable**, not observed zero metrics. Sources: `agent_features_campaigns.txt`, `agent_features_subcampaigns.txt`.

## Artist Message

Video & Visuals exposes an **Artist Message for 2026 Wrapped**, with **Submit now** and **“Submit before Nov 6th.”** The displayed instructions allow a video up to **30 seconds**, **one per artist**, with no music, lyrics, singing, or explicit content. The deadline year **2026** follows the displayed Wrapped year; the UI itself abbreviates the deadline without a year.

This is an available submission opportunity. The landing page does not independently establish submission history, a successfully submitted asset, or performance. No upload or submission flow was opened. Source: `agent_features_artist_message.txt`.

## Canvas inventory

All **seven release selectors** visible in the Canvas view were inspected after their content loaded:

| Selected release | Named track cards in Canvas view |
|---|---:|
| The Cut (Starts Tomorrow) | 1 |
| The Devil Wears Docs | 1 |
| [REDACTED] | 10 |
| Crawl | 1 |
| Funny Guy | 1 |
| GOOMH! | 1 |
| Lab Tapes | 0 |

This yields **15 release-level card appearances**, with **12 distinct track labels**. Funny Guy, Crawl, and GOOMH! appear on both album and single views. These are repeated displayed labels, not proven distinct asset or recording IDs; do not sum them as 15 unique Canvases. **Lab Tapes shows only Add Canvas, with no named track card.**

The album cards visibly display thumbnail/video artwork. The **Add Canvas** tile is also present beside existing cards, so its presence does **not** imply missing Canvas for every track. Published Canvas asset availability is unverified. No card-level metrics, view totals, engagement rates, or asset IDs were displayed in the inventory. An attempt to inspect an existing Funny Guy card opened **Confirm your team**; that prompt was canceled before selecting or confirming a team. The inventory remains valid, while detailed asset state and performance remain unverified.

Sources: `agent_features_canvas_the_cut.txt`, `agent_features_canvas_devil_wears_docs.txt`, `agent_features_canvas_album.txt`, `agent_features_canvas_crawl.txt`, `agent_features_canvas_funny_guy.txt`, `agent_features_canvas_goomh.txt`, `agent_features_canvas_lab_tapes.txt`; detail boundary: `agent_features_canvas_detail_team_prompt.txt`.

## Scope and follow-through

The captured Video & Visuals navigation exposes **Your Artist Message** and **Canvas**. No additional Clips or music-video analytics are established by these captures. Do not convert absent UI controls into a claim that the underlying feature is globally unavailable or contains zero activity.

The Wrapped Artist Message is a current, concrete content opportunity to review before the displayed deadline. The Canvas UI already lists track cards across the main album and five single releases; assess Lab Tapes separately if its promotion remains relevant. These observations establish availability and inventory, not a causal claim that adding a feature increases streams.

No campaign was started, no content was uploaded, no team selection was confirmed, and no account settings were changed. The temporary audit tab was closed.

## Outputs

- `normalized/content_feature_status.csv` — structured availability, explicit empty states, missing metrics, timestamps and provenance.
- `normalized/canvas_card_inventory.csv` — 15 release-level named card appearances with repeated labels retained.
- `analysis/content_features.json` — machine-readable summary.
- `analysis/analyze_content_features.py` — reproducible normalization from the captured DOM files.
