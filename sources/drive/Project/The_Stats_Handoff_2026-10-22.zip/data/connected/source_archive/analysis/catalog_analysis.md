# Catalog findings

Observed catalog: 14 distinct recordings across 7 releases; 17 release memberships.

The deduplicated 28-day recording total is 4,246, matching artist streams exactly; the 7-day total is 1,186, also matching exactly.

Funny Guy supplies 35.0% of 28-day streams; the top three recordings supply 59.8%.

Distinct 2023 Lab Tapes recordings of Method Acting and ¡La Cocaína! have different song IDs from the 2024 album recordings and remain separate. Funny Guy, Crawl and GOOMH! repeat the same song IDs across single and album releases. Never sum release rows to produce an artist total.

## Song assessment (latest 28 days)

| Recording | Streams | Listeners | Streams/listener | Saves | Saves/listener | Assessment |
|---|---:|---:|---:|---:|---:|---|
| Funny Guy | 1,488 | 624 | 2.38 | 70 | 11.2% | Primary reach and catalog entry point. Test a refreshed performance hook; route interested listeners into a short catalog sequence. |
| The Cut (Starts Tomorrow) | 539 | 204 | 2.64 | 32 | 15.7% | Current single to reactivate. Test a second creative angle and a clear save/follow invitation; compare against its own prior window. |
| The Devil Wears Docs | 510 | 205 | 2.49 | 6 | 2.9% | Reach is similar to The Cut but recorded saves are much lower. Test song framing and strongest excerpt before scaling promotion. |
| Crawl | 399 | 152 | 2.62 | 12 | 7.9% | Secondary catalog entry point. Pair with Funny Guy in live/performance content; check whether next-window listeners and saves rise together. |
| GOOMH! | 210 | 95 | 2.21 | 13 | 13.7% | Established catalog support. Use a familiar live hook; retain in set and profile pathways while testing discovery. |
| THIS MACHINE | 190 | 63 | 3.02 | 12 | 19.0% | Modest scale with repeat use. Give a focused performance test and assess incremental reach before broad promotion. |
| Waste Away | 190 | 54 | 3.52 | 10 | 18.5% | Highest repeat listening among the larger catalog tail; test deeper-fan content while expanding reach cautiously. |
| John Doe | 175 | 72 | 2.43 | 12 | 16.7% | Useful catalog follow-through candidate. Test narrative/lyric content and compare return listening with its own baseline. |
| ¡La Cocaína! (album, 2024) | 154 | 59 | 2.61 | 13 | 22.0% | Album recording has materially more current activity than its early version. Keep recording IDs clear in links and tests. |
| Goodnight Mrs. Henderson | 139 | 53 | 2.62 | 12 | 22.6% | Small audience with recorded saves; test a focused excerpt. Current sample cannot establish a reliable conversion advantage. |
| Method Acting (album, 2024) | 125 | 40 | 3.12 | 13 | 32.5% | Small but relatively high repeat/save intensity; test as a deep-catalog candidate. Avoid declaring a winner from 40 listeners. |
| Son! (Hidden Track) | 72 | 26 | 2.77 | 10 | 38.5% | Smallest album-track audience. Use discovery/context storytelling for existing fans; 26 listeners make ratios unstable. |
| ¡La Cocaína! (Lab Tapes, 2023) | 29 | 20 | 1.45 | 2 | 10.0% | Low-volume archival version. Treat as fan context, preserve distinct identity, and direct general promotion to the intended recording. |
| Method Acting (Lab Tapes, 2023) | 26 | 12 | 2.17 | 0 | 0.0% | Low-volume archival version. Song detail explicitly reports zero saves in the latest 28 days; the catalog table displayed a dash. Keep this version distinct in links and fan-history content. |

Ratios are descriptive count-per-listener measures, not person-level conversion probabilities. Raw catalog dashes remain missing in the source table; a missing save count is filled for analysis only when an exact same-period song detail explicitly supplies it. Method Acting (Lab Tapes) detail reports zero saves, while its catalog row is a dash. Canvas dashes remain missing. Small song audiences make ranking by ratios unstable.

## Final daily-history scope

Collection froze October 22, 2026, with a common reporting endpoint of October 20. The archive retains 4 native export files for 4 recordings. Native exports and rendered chart labels together provide 64 of 70 complete daily metric series for January 1, 2024–October 20, 2026, including all five metrics for 12 recordings. Son! has four complete metric series but only 730 observed stream days. GOOMH! has 365 observed stream days and no retained daily series for its other four metrics. Daily unique listeners remain at their daily grain and are never summed into period-unique listeners.

Only The Cut has a retained song-source breakdown, covering the latest 28 days. Breakdowns for the other 13 songs and longer source histories are uncollected; individual unavailability was not established for every song. Preserved detail-query errors do not prove removal from the catalog. The invalid Son! capture labeled full history but displaying the latest 28 days is retained as evidence and excluded from canonical full-period values.

## All-time counter checks

- Funny Guy: all-time header 29,786; Jan 2024–Oct 2026 daily history 30,549. Unresolved counter/scope discrepancy; do not substitute one for the other.
- ¡La Cocaína! (Lab Tapes, 2023): all-time header 2,559; Jan 2024–Oct 2026 daily history 1,362. May include pre-2024 history for a 2023 release; the two counters have different available-history scopes.
- Method Acting (Lab Tapes, 2023): all-time header 2,691; Jan 2024–Oct 2026 daily history 1,423. May include pre-2024 history for a 2023 release; the two counters have different available-history scopes.
- The Devil Wears Docs: all-time header 11,861; Jan 2024–Oct 2026 daily history 11,872. Unresolved counter/scope discrepancy; do not substitute one for the other.

## Preset date scope

- Funny Guy / first12months: dashboard chart spans 2024-05-31–2025-05-30, although original release date is 2024-04-12. Keep this preset separate from original-release launch calculations.
- Funny Guy / first28: dashboard chart spans 2024-05-31–2024-06-27, although original release date is 2024-04-12. Keep this preset separate from original-release launch calculations.
- Crawl / first12months: dashboard chart spans 2024-05-31–2025-05-30, although original release date is 2024-05-10. Keep this preset separate from original-release launch calculations.
- Crawl / first28: dashboard chart spans 2024-05-31–2024-06-27, although original release date is 2024-05-10. Keep this preset separate from original-release launch calculations.