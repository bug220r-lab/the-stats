# Spotify for Artists — official definition and methodology notes

Research date: 2026-10-22. Temporary research artifact for the parent analyst. Sources below are Spotify primary sources retrieved by web search, not authenticated account observations. References are retrieval IDs for the parent to reopen before citing in the final response. Paraphrases are intentionally concise.

## 1. Stream counting and duplication

Source: https://support.spotify.com/us/artists/article/how-your-streams-are-counted/
Refs: turn0search5, turn1view2.

- Audio/song and music-video streams require at least 30 seconds played.
- All-time song/release stream totals include music-video streams. Do not add a video total to an already combined total.
- A release's streams sum its tracks; a recording on multiple releases contributes to each release. Do not aggregate release totals without deduplicating shared recordings.
- Offline plays are counted after the listener reconnects; Spotify says reconnection is required at least every 30 days.
- Artist totals cover songs credited to the artist as main artist or remixer.
- The page says Spotify retains the all-time count for 90 days after a recording/release becomes unavailable; later redelivery does not preserve the former count. This should be treated as a caveat if catalog removals occurred, not an assumption that any did.

## 2. UTC and update timing

Timezone source: https://support.spotify.com/us/artists/article/time-zone-for-stats-in-spotify-for-artists/
Ref: turn0search0. Additional locale reading ref: turn1search0.

- Reporting days are UTC, midnight through 23:59 UTC, and the reporting timezone is not configurable. Preserve date-only exports as UTC days; do not relabel them as local Ohio days.

Update source: https://support.spotify.com/us/artists/article/when-stats-update/
Refs: turn2view4, turn3search9.

- The dedicated update page currently states daily refresh at approximately 5 PM ET / 9 PM UTC; newly released music has a live count during its first 7 days, updated every 2 seconds.

Conflicting official source: https://support.spotify.com/us/artists/article/live-stream-count/
Ref: turn3search6.

- The live-stream-count page agrees on the first-7-day live window and says the live count includes audio and music-video streams, but still states the older approximate daily time of 3 PM EST / 8 PM UTC.
- Analyst handling: cite the dedicated update page and mention the documentation discrepancy only if useful. Determine the audit endpoint from the dashboard's latest processed date, not a presumed update clock. Avoid converting the ET/UTC pair mechanically across daylight-saving changes.

## 3. History and coverage limits

Source: https://support.spotify.com/us/artists/article/how-far-back-your-stats-go/
Ref: turn4view1. Equivalent locale refs: turn2view3, turn1view5.

- Artist audience history covers the previous 2 calendar years plus the current year to date: listeners, streams, streams/listener, saves, playlist adds, followers.
- Song/release daily unique listeners and daily streams have the same history window.
- Demographics and locations are available only for the latest 28 days.
- Audience stats include music-video streams from May 2025 onward; this is a possible measurement break if this artist had video viewing.
- All-time streams extend back to availability, subject to the removal/redelivery retention caveat. All-time cumulative totals do not imply an all-time daily history.
- Inference for this audit: a 2026 collection can start on January 1, 2024. Check exact observed coverage separately for every export.

## 4. Listeners and followers

Source: https://support.spotify.com/us/artists/article/understanding-your-listener-and-follower-stats/
Refs: turn2view1, turn1view3.

- Listeners are distinct people who streamed audio or music videos in the selected period. Followers are accounts following the artist profile.
- The dashboard exposes follower totals, not individual follower identities.
- Analyst implication: never sum daily or per-song unique listeners into period artist listeners. Obtain the period's unique count directly. Followers are a stock at a point in time; change between snapshots is net growth, not necessarily gross acquisitions.
- Spotify's general claim about greater future streaming among followers is an association across its population, not a forecast or causal estimate for this band.

## 5. Audience segments

Source: https://support.spotify.com/us/artists/article/audience-segments-on-spotify/
Refs: turn2view0, turn1view0.

- Total audience represents distinct listeners over the past 2 years, partitioned into monthly active, previously active, and programmed listeners.
- Monthly active: intentional listening from active sources during the past 28 days.
- Previously active: formerly monthly active, with no intentional listen in at least 28 days; programmed listening may continue.
- Programmed segment: programmed-source listening with no active-source listen in at least 2 years.
- Active subsegments use intentional streams in 28 days: light 1–2, moderate 3–14, super 15+.
- Monthly listeners include everyone who listened within 28 days; monthly active listeners are a subset.
- Segment stream share uses streams in 28 days; segment audience share uses the 2-year audience denominator.
- Reactivated listeners return from previously active to monthly active. New active listeners enter monthly active after not belonging within 2 years. New listeners had no streams within 2 years.
- Analyst implication: audience segments and stream-source categories are different measures. Active listeners can also generate programmed streams. Do not equate segment stream contribution with streams from active sources.

## 6. Source categories

Source: https://support.spotify.com/us/artists/article/source-of-streams/
Refs: turn2view2, turn1view4.

- Source breakdowns apply to audio/music videos and can appear on artist audience, song, and release pages; compatible date, country, and metric filters apply.
- Active categories: artist profile/catalog (including album pages and This Is playlists); listener's own playlists/library (including Liked Songs/saved albums); listener's queue.
- Programmed categories: editorial/personalized editorial playlists (including charts); personalized playlists/autoplay/mixes (including Discover Weekly, Release Radar, Radio, Daily Mix, daylist, AI DJ); playlists created by other listeners.
- A person may use multiple sources, so source-listener subtotals may exceed the unique artist listener total.
- Analyst implication: preserve any extra/unknown categories actually observed in the account instead of forcing all totals into the documented categories. A source residual should remain unreconciled until explained.

## 7. Release engagement

Source: https://support.spotify.com/us/artists/article/understanding-release-engagement/
Ref: turn4view2. Equivalent locale ref: turn1view1.

- Denominator is the artist's monthly active audience on the day before release.
- It tracks the share of that fixed cohort that streams the new release during its first 28 days, with daily updates.
- The view covers releases from the latest 3 months.
- Filters can select active-audience subsegments, include programmed sources, or restrict to a country.
- Analyst implication: capture all filters. Do not replace the original baseline cohort with the current monthly active count, or confuse engaged cohort members with all release listeners. Compare completed windows at equal post-release ages. Do not infer churn from cohort members absent from the engagement numerator.

## 8. Saves, Canvas, exports, and playlist coverage

Saves: https://support.spotify.com/us/artists/article/how-we-count-saves/
Ref: turn4view3.

- Save activity is counted when a listener uses the save control to add the music to their library. Saving a music video also saves its audio track.
- Analyst implication: the documentation does not establish a distinct-person conversion rate from saves divided by listeners. Label that calculation a ratio, with dates/entity/denominator specified.

Canvas: https://support.spotify.com/us/artists/article/how-we-count-canvas-views/
Ref: turn0search16.

- A Canvas view occurs when the listener opens Now Playing and sees it, capped at one view per stream and without a minimum listening duration. Canvas views can exceed counted streams because streams require 30 seconds.

Exports: https://support.spotify.com/us/artists/article/exporting-data/
Ref: turn4view4.

- Spotify offers native CSV downloads for some song counts, audience timelines, and Music-section song/playlist tables. This is not a promise that every visible metric has a CSV.

Playlist limits: https://support.spotify.com/us/artists/article/seeing-playlists-your-music-is-on/
Ref: turn5view0.

- The playlist view shows the top 100 playlists ranked by the number of listeners to this artist's music.
- A playlist needs at least 3 such listeners to appear.
- Playlist data is available for the latest 12 months.
- Analyst implication: even collecting all displayed rows is not exhaustive coverage of every playlist. Keep the top/ranked qualification and threshold in both manifest and report.

## 9. External benchmark limits

Spotify Loud & Clear methodology/context: https://loudandclear.byspotify.com/faqs/there-are-millions-of-artist-profiles-on-spotify-yet-only-a-small-fraction-are-generating-money-shouldnt-a-higher-percentage-of-all-artists-on-spotify-be-making-money-arent-there-8-milli/
Ref: turn2view5.

- The page describes roughly 13 million uploaders, many with very small catalogs, alongside a much smaller estimated professional/aspiring-professional population. Its indicators include catalog size, monthly listening, and concert activity, and Spotify acknowledges uncertainty in inferring professional intent.
- The page displays an old publication date but contains 2025 observations; cite the observed data vintage and retrieval date, not the old date as if the contents were from 2023.
- Analyst inference: an all-artist average is an ill-matched benchmark for a developing independent band; these broad cohorts do not supply genre/scale-matched engagement norms.

Spotify comparison tool: https://loudandclear.byspotify.com/process/
Ref: turn2view6.

- The page offers an approximate global comparison for monthly listeners or all-time track streams, based on 2025 data, with rounded numbers.
- No actual comparison was run in this research task. Do not quote the page's unfilled placeholder as a rank, and do not invent a percentile.
- This broad global comparison, if later used, is dated and not matched for genre, release age, geographic footprint, or professional intent. Prioritize the band's own nonoverlapping periods and equal-age releases.

## Research handling

Only primary Spotify sources were used. No authenticated artist data was obtained by this researcher. Parent must reopen the relevant references before using web citations in its final response. These notes intentionally do not establish an average artist benchmark, causal effects, or revenue forecasts.
