"""Normalize DOM-visible song playlist tables without imputing missing pages."""
from pathlib import Path
import csv
import json
import re
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'normalized'
catalog = {r['song_id']: r for r in csv.DictReader((OUT / 'song_catalog.csv').open())}
rows, coverage = [], []
for source in sorted((ROOT / 'captured').glob('agent_song_playlists_*_bundle.json')):
    bundle = json.loads(source.read_text())
    sid = bundle['song_id']
    meta = catalog[sid]
    valid = {}
    for capture in bundle['captures']:
        if capture.get('tables'):
            requested = capture['period_requested']
            header = capture['tables'][0][0]['cells']
            assert header == ['', f'Last {requested}', 'Made by', 'Streams', 'Date Added'], (sid, header)
            assert f'/song/{sid}/playlists' in capture['url']
            valid[requested] = capture
    for period in ['28 days', '12 months']:
        capture = valid.get(period)
        base = dict(song_id=sid, song_title=meta['title'], first_released=meta['first_released'],
                    period_label=f'Last {period}', period_start='', period_end='',
                    bounds_status='not_exposed', metric='streams',
                    evidence_file=str(source.relative_to(ROOT)))
        if not capture:
            last = bundle['captures'][-1]
            assert "Something went wrong" in last['dom'], sid
            coverage.append({**base, 'status':'unavailable_page_error', 'displayed_rows':'',
                             'reported_playlist_count':'', 'displayed_streams':'',
                             'coverage_note':'Spotify generic stats error; blank metrics are not zero.',
                             'source_url':last['url'], 'collected_at':last['collected_at']})
            continue
        match = re.search(r'Top ([\d,]+) of ([\d,]+) playlists for this song', capture['dom'])
        assert match, sid
        shown, population = (int(v.replace(',','')) for v in match.groups())
        table = capture['tables'][0][1:]
        assert len(table) == shown
        playlist_uris = re.findall(r'- row "(spotify:playlist:[^"]+)":', capture['dom'])
        assert len(playlist_uris) == shown, (sid, period, len(playlist_uris), shown)
        for entry, uri in zip(table, playlist_uris):
            rank, title, maker, streams, date_added = entry['cells']
            assert int(rank) >= 1
            is_missing = lambda value: value.strip() in ('—','–','-','')
            rows.append({**base, 'rank':int(rank), 'playlist_title':title.strip(),
                         'playlist_uri':uri, 'made_by': '' if is_missing(maker) else maker.strip(),
                         'made_by_raw':maker, 'made_by_status':'missing_dash' if is_missing(maker) else 'observed',
                         'streams':int(streams.replace(',','')), 'streams_status':'observed',
                         'date_added': '' if is_missing(date_added) else datetime.strptime(date_added,'%b %d, %Y').date().isoformat(),
                         'date_added_raw':date_added,
                         'date_added_status':'missing_dash' if is_missing(date_added) else 'observed',
                         'source_url':capture['url'], 'collected_at':capture['collected_at']})
        coverage.append({**base, 'status':'observed_top_table', 'displayed_rows':shown,
                         'reported_playlist_count':population,
                         'displayed_streams':sum(int(e['cells'][3].replace(',','')) for e in table),
                         'coverage_note':'Top table only; no Show More or pagination exposed. Population exceeds displayed rows.',
                         'source_url':capture['url'], 'collected_at':capture['collected_at']})

def write_csv(name, data):
    with (OUT / name).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0]))
        writer.writeheader()
        writer.writerows(data)

assert len(coverage) == 28
assert len(rows) == 52
write_csv('song_playlists.csv', rows)
write_csv('song_playlist_coverage.csv', coverage)
observed = [r for r in coverage if r['status'] == 'observed_top_table']
result = {
    'songs_checked':len(catalog), 'songs_with_tables':len(set(r['song_id'] for r in rows)),
    'songs_with_page_errors':len(catalog)-len(set(r['song_id'] for r in rows)),
    'playlist_rows':len(rows), 'observed_period_tables':len(observed),
    'periods':['Last 28 days','Last 12 months'],
    'date_bounds':'not exposed; no date bounds inferred from artist timeline',
    'coverage':observed,
    'cautions':[
        'All successful captures are explicitly Top tables, not complete playlist inventories.',
        'Playlist counts refer to each song and period; summing across songs double-counts playlists.',
        'Streams are shown; listeners are not exposed in song playlist tables.',
        'Missing makers and dates remain blank with missing_dash status.',
        '11 song playlist pages returned the site generic stats error; values remain missing, not zero.',
        'Crawl, GOOMH! and THIS MACHINE remained unavailable after one reload; other error pages were read after initial loading settled.',
        'Latest 24 hours and Last 7 days were exposed options but not captured in this supplementary song-playlist pass.',
    ]
}
(ROOT / 'analysis/song_playlists.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
lines = ['# Song playlist breakdowns', '',
         'Checked all 14 catalog song IDs. Three songs loaded playlist tables for Last 28 days and Last 12 months: 52 rows across six tables. The remaining 11 song pages showed Spotify’s generic stats error, preserved as unavailable.', '',
         '| Song | Period | Displayed playlists | Reported playlists | Streams in displayed rows |',
         '|---|---|---:|---:|---:|']
for r in observed:
    lines.append(f"| {r['song_title']} | {r['period_label']} | {r['displayed_rows']} | {r['reported_playlist_count']:,} | {r['displayed_streams']:,} |")
lines.extend(['', '## Interpretation and coverage', ''] + ['- '+v for v in result['cautions']] + [
    '- Exact date boundaries were absent. The date bounds in the normalized tables are blank.',
    '- The local playlist-table filter is authoritative. The disabled page-level 28-day control remained visible even when the table showed Last 12 months.',
    '', '## Evidence', '',
    'Each normalized row points to `captured/agent_song_playlists_<song_id>_bundle.json`, containing the rendered DOM and table cell extraction. `normalized/song_playlist_coverage.csv` retains both requested periods for every song, including 22 unavailable song-period combinations.',
    '', '## Displayed annual highlights', '',
    '- Funny Guy: Mixes 1,043 streams; Radio 446; Your DJ 241. Pure Punk contributed 151 in the displayed table.',
    '- The Cut (Starts Tomorrow): Radio 508; Mixes 148; Release Radar 117; Slipknot Radio 78.',
    '- The Devil Wears Docs: Release Radar 2,961; Radio 1,052; Your DJ 150. These are song-level playlist rows, not additive artist-source totals.',
])
(ROOT / 'analysis/song_playlists.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:result[k] for k in ['songs_checked','songs_with_tables','songs_with_page_errors','playlist_rows','observed_period_tables']}))
