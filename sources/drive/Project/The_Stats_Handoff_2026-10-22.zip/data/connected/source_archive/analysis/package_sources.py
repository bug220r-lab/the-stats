"""Package frozen audit evidence without changing downloaded native CSV bytes."""
from pathlib import Path
import csv
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
META = ROOT / 'package_metadata'
META.mkdir(exist_ok=True)

coverage = [
    ('Artist daily history','captured','2024-01-01','2026-10-20','1,024 continuous daily rows; unchanged native CSV','raw/artist_timeline_2024-01-01_2026-10-20.csv'),
    ('Artist period summaries','captured','2024-01-01','2026-10-20','7/28/90 days, 12 months, YTD, available history; prior-year YTD unique listeners not captured','normalized/artist_periods_integrated.csv'),
    ('Artist all-time history','not_exposed','','','Available daily history begins Jan 1, 2024; do not call its total lifetime','analysis/definitions_notes.md'),
    ('Artist sources','partial','2026-09-23','2026-10-20','Detailed latest28 and preceding28; longer source histories not collected','normalized/artist_sources_28day.csv'),
    ('Audience segments','captured','2026-09-23','2026-10-20','Latest snapshot and28-day curves; active/super history also in native timeline','normalized/audience_segment_daily.csv'),
    ('Demographics','captured_with_conflict','2026-09-23','2026-10-20','Displayed age/gender counts and percentages; sums differ slightly from artist listeners','normalized/audience_demographics_age_gender.csv'),
    ('Artist geography','reported_top_rows','2026-09-23','2026-10-20','23 countries and50 cities, metric listeners; not exhaustive worldwide rows','normalized/audience_top_countries.csv'),
    ('Recording catalog','captured','','','14 distinct song IDs,7 releases,17 release memberships; assessment for all14','normalized/song_catalog.csv'),
    ('Recording daily history','partial','2024-01-01','2026-10-20','64 of70 metric series complete:12 recordings all5; Son4 full metrics but730 stream days; GOOMH365 stream days only','normalized/song_daily_coverage.csv'),
    ('Recording native CSVs','partial','2024-01-01','2026-10-20','4 unchanged native song stream exports; other collected daily metrics use rendered chart labels','normalized/song_export_quality.csv'),
    ('Recording period summaries','captured_with_scope_limits','','2026-10-20','7/28/90/12months/YTD where captured or validly derived; first28/first12 presets have actual date scope recorded','normalized/song_period_canonical.csv'),
    ('Recording source breakdowns','partial','2026-09-23','2026-10-20','Only The Cut latest28 with prior28 captured; other13 not collected. Final detail pages returned errors','normalized/song_source_comparisons.csv'),
    ('Recording geography','partial_page_errors','2026-09-23','2026-10-20','All14 checked;7 available,7 generic page errors;138 country and350 city rows, metric streams','normalized/song_location_coverage.csv'),
    ('Recording playlists','partial_page_errors','','','All14 checked;3 songs have28-day and12-month Top tables,11 page errors;52 rows; exact bounds not exposed','normalized/song_playlist_coverage.csv'),
    ('Release daily history','captured','2024-01-01','2026-10-20','7 releases x1,024 days=7,168 streams; rendered chart labels; native download not exposed','normalized/release_daily_streams.csv'),
    ('Release period summaries','captured','','2026-10-20','7/28 days,12 months,available-history summaries for all7;28 cards reconcile; do not sum releases','normalized/release_periods.csv'),
    ('Release engagement','captured_with_conflict','2026-04-24','2026-05-21','Only The Cut exposed;8 combinations x28 daily points=224; tier sums and timeline cohort baselines disagree','normalized/release_engagement_snapshot.csv'),
    ('Artist playlists','reported_top_rows','','','Native7/28-day and12-month exports:46 rows;12-month UI shows21 listener rows of1.8k with no additional pagination','normalized/artist_playlist_summary.csv'),
    ('Campaigns','observed_empty','','','Campaign and sub-campaign lists empty; spend/ROI/performance unavailable, not zero','normalized/content_feature_status.csv'),
    ('Canvas','inventory_only','','','All14 song controls checked;12 Manage Canvas,2 Add Canvas. Asset publication/performance unverified','normalized/song_canvas_status.csv'),
    ('Artist Message','availability_only','','','2026 Wrapped submission control and Nov6 deadline observed; no submission/history/performance verified','normalized/content_feature_status.csv'),
    ('Clips and music-video analytics','not_established','','','No separate analytics established by inspected Video & Visuals navigation','analysis/content_features.md'),
    ('External artist benchmarks','not_available','','','Recommendations use self-history and within-catalog comparisons; no invented average artist baseline','analysis/definitions_notes.md'),
]
with (META/'coverage_manifest.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['area','status','start_date','end_date','scope_and_limit','primary_reference']); w.writerows(coverage)

readme = '''# The Stats — source data and audit trail

Prepared for Lewis. Artist name as displayed: [REDACTED]. Spotify artist ID: 6X14XfGTmB560PF063wXDk.
Collected October 22, 2026. Common timeline endpoint: October 20, 2026. Dates are inclusive and use Spotify's UTC reporting basis. Playlist exact bounds were not exposed and have not been invented.

## Start here

The companion PDF explains findings and the 30/60/90-day plan; the DOCX is editable. The XLSX organizes the canonical datasets, formulas, charts and checks. This ZIP retains the underlying evidence and analysis scripts. It is a documented accessible-account audit, not a claim that every requested page or lifetime daily record was obtainable.

Read `coverage_manifest.csv` for exactly what was captured, partially captured, reported as empty, not exposed, or not collected. Read `DATA_DICTIONARY.md` and `analysis/catalog_data_dictionary.md` before aggregating rows. `file_manifest.csv` lists packaged files, byte counts, SHA-256 checksums and CSV row counts. Checksums establish the bytes included in this archive, not an independent guarantee by Spotify.

## Folder guide

- `raw/`: unchanged native artist timeline and four native song-stream CSV downloads.
- `captured/`: rendered page snapshots, chart accessibility labels, source URLs/timestamps and original native playlist CSVs (`agent_playlists_*_native.csv`). These are evidence, not all native exports. Capture bundles can repeat the same data across periods and may include failed/loading captures that canonical tables exclude.
- `normalized/`: cleaned, typed, deduplicated analysis datasets and reconciliation tables. Native files are never overwritten to create these.
- `analysis/`: reproducible normalization and authoring scripts, findings, source definitions and data dictionary. Report-render temporary images are omitted.
- `charts/`: generated analytical figures used in the report.

## Coverage that matters

The native artist timeline covers all 1,024 dates from January 1, 2024 through October 20, 2026. There are14 distinct recordings across7 releases. Twelve recordings have complete available-history daily streams, listeners, streams/listener, playlist adds and saves. Son! has complete daily history for the latter4 metrics, but730 observed stream days; GOOMH! has365 observed stream days and no captured daily series for the other4 metrics. Thus64 of70 requested recording-metric series are complete for this history window. Full recording history begins in2024 even when the original release was in2023. Seven release stream charts each cover1,024 days but are a different reporting grain and are not used to silently fill missing song histories.

Every song location and playlist page was checked. Seven song location pages were available (488 geographic rows); seven returned generic Spotify errors. Three song playlist pages supplied28-day and12-month Top tables (52 rows); eleven returned errors. Artist playlists have46 native rows over three selected periods. These Top tables are incomplete representations of all playlist use. Only The Cut has a collected song-source breakdown (latest28 days and prior28); the other13 source breakdowns are not collected. Artist source history is also limited to the latest28-day comparison.

Campaign and sub-campaign lists are explicitly empty in the inspected views. That is not evidence of zero advertising in every channel. Canvas controls and inventory were captured, but published assets and their performance remain unverified. No campaigns, uploads, settings, playlists or content were changed.

## Rules for using the data

1. Join recordings by Spotify song ID. Funny Guy, Crawl and GOOMH! share song IDs across single and album releases; the two2023 Lab Tapes versions have distinct IDs from their2024 album counterparts. Never add release totals into an artist total.
2. Streams, saves and playlist adds can be summed over complete, nonoverlapping daily windows at the same grain. Daily listeners, rolling monthly listeners, monthly active listeners, super listeners and followers cannot. Period unique listeners come from period-level UI values.
3. Followers are an end-date stock. A stock difference is net change, not gross newly acquired followers or person-level retention.
4. Standard windows end October20:7days Oct14–20;28days Sep23–Oct20;90days Jul23–Oct20;12months Oct21,2025–Oct20,2026. Prior windows are contiguous as labeled. UI YTD comparison uses the preceding293days, not prior-year YTD; separately derived YTD additive comparisons use Jan1–Oct20 in each year. Prior-year YTD unique listeners were not captured.
5. Launch presets for Funny Guy and Crawl were anchored to May31,2024 album release, not their original single dates. Original-release calculations use separately verified dates and only complete observed windows.
6. Blanks and source dashes mean missing/not reported unless an explicit zero was captured. Method Acting (Lab Tapes) is one documented exception: latest28-day detail explicitly reports0 saves while its catalog row shows a dash.
7. Percent-change fields use the scale described in the dictionary. A rate with zero or unavailable denominator is undefined. Saves/listener and adds/listener are activity ratios, not unique-person conversion probabilities. Small samples are unstable.
8. Do not sum source or playlist listeners into unique reach. Artist geography uses listeners, while song geography uses streams. Named playlist rows and aggregate source categories have differing scope and cannot be forced to reconcile.
9. Raw chart captures may have overlapping windows, stale unselected hero cards, or loading/error states. Use canonical normalized tables; selected-metric tables and validated chart labels take precedence over stale cards. In particular, the mislabeled Son full overview is excluded as an invalid full-period capture, while its evidence remains preserved.

## Unresolved source conflicts

- Funny Guy: available-history streams30,549 versus all-time header29,786. The Devil Wears Docs:11,872 versus11,861. Album:81,391 versus81,263. No explanation is proven; both values remain.
- Gender cells total1,064 and age cells1,063 versus1,062 artist listeners; a male cross-tab subtotal also differs by1. No cell is adjusted.
- The Cut engagement tiers do not sum to the overall engaged count; displayed baseline cohorts also differ from timeline snapshots. All eight curves are retained, and aggregate and tier analyses remain separate.
- Latest28-day named algorithmic playlist rows total263 streams versus256 in the corresponding broad personalized-source category; exact playlist bounds are not exposed. No artificial residual is assigned.
- Funny Guy song-country rows sum1,484 streams versus1,488 total; the unexplained gap4 is retained.

Many captured additive comparisons reconcile exactly, including44 artist checks,288 song period checks,131 song chart-total checks,28 release period checks and365 daily catalog-to-artist stream comparisons. These checks validate those comparisons only; they do not resolve the conflicts above or establish causal attribution.

## Reproduction

Python analysis scripts read preserved evidence and emit normalized CSVs and findings; report generation additionally uses python-docx and the document-render runtime. The workbook builder uses the installed artifact-tool JavaScript runtime. For this full dataset, run Node with `--max-old-space-size=8192`; the default heap limit was insufficient for export. Paths may need adjustment outside the supplied workspace. Scripts do not fetch hidden Spotify APIs. Re-running from this archive reconstructs captured data, not a fresh account audit. See the scripts for their explicit local inputs and outputs; the original native files remain the authoritative byte-preserved exports.
'''
for old,new in {
 'and12-month':'and 12-month','latest28':'latest 28','Latest28':'Latest 28','prior28':'prior 28','20:7 days':'20: 7 days',';28 days':'; 28 days',';90 days':'; 90 days',';12 months':'; 12 months','are14':'are 14','across7':'across 7','latter4':'latter 4','but730':'but 730','has365':'has 365','other4':'other 4','Thus64 of70':'Thus 64 of 70',
 'in2024':'in 2024','in2023':'in 2023','cover1,024':'cover 1,024','supplied28-day':'supplied 28-day','have46':'have 46','other13':'other 13',
 'two2023':'two 2023','their2024':'their 2024','October20':'October 20','7days Oct14–20':'7 days Oct 14–20','28days Sep23–Oct20':'28 days Sep 23–Oct 20',
 '90days Jul23–Oct20':'90 days Jul 23–Oct 20','12months Oct21,2025–Oct20,2026':'12 months Oct 21, 2025–Oct 20, 2026',
 'preceding293days':'preceding 293 days','Jan1–Oct20':'Jan 1–Oct 20','May31,2024':'May 31, 2024','reports0':'reports 0',
 'streams30,549':'streams 30,549','header29,786':'header 29,786','Docs:11,872':'Docs: 11,872','versus11,861':'versus 11,861','Album:81,391':'Album: 81,391','versus81,263':'versus 81,263',
 'total1,064':'total 1,064','cells1,063':'cells 1,063','versus1,062':'versus 1,062','by1.':'by 1.','total263':'total 263','versus256':'versus 256',
 'sum1,484':'sum 1,484','versus1,488':'versus 1,488','gap4':'gap 4','including44':'including 44','checks,288':'checks, 288','checks,131':'checks, 131','checks,28':'checks, 28','and365':'and 365'
}.items(): readme=readme.replace(old,new)
(META/'README.md').write_text(readme,encoding='utf-8')

groups={
 'artist':'Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain.',
 'audience':'Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled.',
 'song':'Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain.',
 'release':'Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals.',
 'catalog':'Deduplicated recording comparisons or reconciliation. Residual outside top3 does not establish historical tail membership.',
 'canvas':'Displayed content inventory; repeated release appearances are not unique published assets.',
 'content':'Feature availability and explicit status; missing performance is not zero.',
}
lines=['# Dataset inventory and field guide','','This inventory lists every normalized CSV, row count and exact field names. Domain-specific interpretation appears in the analysis notes and catalog dictionary.','','| Dataset | Rows | Purpose |','|---|---:|---|']
schemas=[]
for p in sorted((ROOT/'normalized').glob('*.csv')):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.reader(f); cols=next(r,[]); n=sum(1 for _ in r)
    lines.append(f'| `{p.name}` | {n:,} | {groups.get(p.stem.split("_")[0],"Structured analysis output; see matching analysis notes.")} |')
    schemas += [f'## {p.name}', '', f'{n:,} data rows. Fields: ' + ', '.join(f'`{c}`' for c in cols) + '.', '']
lines += ['','## Common fields and units','','- `date`, `start_date`, `end_date`: inclusive calendar dates; playlist blanks reflect unexposed exact bounds.','- `song_id`, `release_id`: exact Spotify identity, not title matching.','- `source`, `evidence_file`, `sources`, `source_url`, `collected_at`: provenance, with bundle metadata resolving URLs/timestamps where available.','- `origin`: native download versus rendered-chart extraction.','- `status`, `coverage_note`, `complete`, `standard_history_complete`: explicit validity/coverage; blank values must not be treated as zero.','- `difference`: reported comparison residual; a nonzero value remains unresolved unless a note explicitly explains differing scope.','- `percent_change`: normally0–100 percentage units. Fields ending `_share`/`share_of_...` and `_per_listener` may be fractional ratios; see dataset-specific dictionary and XLSX formatting.','- Rolling snapshots and period unique listeners are not additive. Daily streams/saves/adds are additive only within complete, nonoverlapping windows.','- Repeated evidence tables (especially song_chart_points and song_period_dashboard) are for audit, not totals.','']+schemas
(META/'DATA_DICTIONARY.md').write_text('\n'.join(lines),encoding='utf-8')

files=[]
for folder in ('raw','captured','normalized','analysis','charts'):
    for p in sorted((ROOT/folder).iterdir()):
        if p.is_file() and p.suffix.lower() in {'.csv','.json','.txt','.md','.py','.mjs','.sh','.png'}:
            files.append((p,p.relative_to(ROOT).as_posix()))
for p in sorted(META.iterdir()):
    if p.name not in {'file_manifest.csv','archive_summary.json'}: files.append((p,p.name))
with (META/'file_manifest.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['path','bytes','sha256','csv_data_rows','classification'])
    for p,name in files:
        raw=p.read_bytes(); n=''
        if p.suffix=='.csv':
            with p.open(encoding='utf-8-sig',newline='') as cf: n=max(0,sum(1 for _ in csv.reader(cf))-1)
        native=name.startswith('raw/') or (name.startswith('captured/agent_playlists_') and name.endswith('_native.csv'))
        typ='native_download' if native else ('rendered_UI_evidence' if name.startswith('captured/') else 'derived_analysis_or_documentation')
        w.writerow([name,len(raw),hashlib.sha256(raw).hexdigest(),n,typ])
files.append((META/'file_manifest.csv','file_manifest.csv'))
out=ROOT/'deliverables/The_Stats_Source_Data.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in files: z.write(p,name)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
summary={'archive':str(out),'files':len(files),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'native_files':8}
(META/'archive_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
