# Song and release data dictionary

`analysis/analyze_catalog.py` reproduces these normalized outputs from the preserved catalog snapshots, capture bundles and native CSV exports. It does not modify native downloaded CSV files.

| Dataset | Grain and use |
|---|---|
| `song_catalog.csv` | One row per distinct Spotify song ID. Same-title 2023 Lab Tapes recordings remain separate from 2024 album recordings. |
| `release_catalog.csv` | One row per displayed release, latest 28-day streams. Release streams are not additive across releases containing the same recording IDs. |
| `release_song_mapping.csv` | One row per release–recording membership; 17 memberships map to 14 distinct IDs. |
| `song_catalog_periods.csv` | Exact catalog rows for 7 and 28 days, including raw dash values as missing. |
| `song_period_dashboard.csv` | Overview evidence, including repeated metric-specific full-history captures. Evidence table, not a table to sum. |
| `song_period_canonical.csv` | One overview row per recording and canonical period. Exact detail takes precedence over catalog fallback. Period-unique listeners come from UI totals. Actual chart dates identify launch-preset scope. |
| `song_daily_long.csv` | One observed recording–date–metric value. `origin` distinguishes native exports from rendered chart labels. Native/full-history evidence is preferred over overlapping shorter captures. |
| `song_daily_wide.csv` | The same observed daily values pivoted into metric columns. Missing metric values remain blank. |
| `song_daily_coverage.csv` | All 70 expected recording–metric series, with observed day count, exact endpoints and completeness for Jan 1, 2024–Oct 20, 2026. A span can contain gaps; an endpoint alone does not prove completeness. |
| `song_periods_from_daily.csv` | Complete-window sums only for additive metrics. Daily listeners and daily streams-per-listener are never summed into period totals. |
| `song_dashboard_metric_comparisons.csv` | Direct UI preceding-period comparisons, retaining the UI basis. The UI YTD predecessor is not a prior-year YTD comparison. |
| `song_period_comparisons.csv` | Daily-derived additive comparisons where complete; direct UI comparisons supplement missing 7/28/90/12-month histories. YTD daily comparisons use the same dates in the preceding year. |
| `song_launch_summary.csv` | Original-release first 7/28/90/365-day stream sums only when all days exist, with explicit complete flags. These may differ in scope from album-anchored UI launch presets. |
| `song_first28_daily_streams.csv` | Complete original-release launch windows with cumulative streams. |
| `song_alltime_counters.csv` | Displayed all-time header counts, kept separate from selected-history totals. |
| `song_source_comparisons.csv` | Exact source-category comparison rows. Percent changes are recomputed with sign; source-listener categories can overlap and must not be summed. |
| `song_source_coverage.csv` | All 14 recordings; The Cut has a retained 28-day source breakdown. Other song-source breakdowns are uncollected, not individually confirmed unavailable. |
| `song_query_errors.csv` | Retained detail-query errors. Errors do not establish that a recording was removed from the catalog. |
| `catalog_artist_daily_reconciliation.csv` | Stream checks only on dates where all 14 recordings have observed values. Missing song-days are never treated as zero. |
| `catalog_artist_period_reconciliation.csv` | Current and previous 7/28/90-day and 12-month stream totals across all 14 recordings compared with artist totals. |
| `catalog_stream_contributions.csv` | Top-three recording stream contributions and artist-total residual outside them. This residual does not establish historical membership of all other current catalog IDs. |
| `song_chart_points.csv` | Repeated chart evidence across captures. It deliberately contains overlapping dates/windows and should not be used as an additive table. |

The common comparison endpoint is October 20, 2026. Seven days means Oct 14–20; 28 days Sep 23–Oct 20; 90 days Jul 23–Oct 20; 12 months Oct 21, 2025–Oct 20, 2026. Previous periods are contiguous equal-length windows except the explicitly named prior-year YTD comparison.

`percent_change`, `saves_per_100_streams` and `canvas_views_per_100_streams` use a 0–100 scale. `saves_per_listener`, `stream_share_artist` and `share_of_artist_net_change` use fractions. `streams_per_listener` is a count ratio. Saves-per-listener is a descriptive count ratio, not a person-level conversion probability.

Raw catalog dashes remain missing. If an exact same-period detail supplies a number, analysis may use that explicit detail with a provenance field. For Method Acting (Lab Tapes), the latest 28-day detail reports zero saves while the catalog table displays a dash. Canvas dashes remain missing.

All-time headers larger than available history for 2023 releases can include pre-2024 listening. A smaller all-time header than a retained daily-history total is an unresolved counter/scope discrepancy. Neither is silently substituted for the other. Site errors are query-coverage limitations, not proof of removal from the catalog.

Final coverage is 64 complete series out of 70 expected recording–metric series, with all five metrics complete for 12 recordings. Son! has four full series and 730 observed stream days; GOOMH! has 365 stream days and no other retained daily metric series. Four native CSV exports are retained. Invalid capture scopes remain flagged in the overview evidence table and are excluded from canonical values. Exact selected-metric table values take precedence over stale overview cards, with provenance retained.
