"""Normalize DOM-captured Spotify audience data; preserve all reported discrepancies."""
import csv
import json
import re
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import StrMethodFormatter

ROOT = Path(__file__).resolve().parents[1]
CAP = ROOT / "captured"
OUT = ROOT / "normalized"
CHARTS = ROOT / "charts"
OUT.mkdir(exist_ok=True)
CHARTS.mkdir(exist_ok=True)
START, END = "2026-09-23", "2026-10-20"
SCOPE = dict(period_start=START, period_end=END, geography="Worldwide")

def write_csv(name, rows):
    with (OUT / name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def read_json(name):
    return json.loads((CAP / name).read_text())

def history(name):
    rows = []
    for line in read_json(name):
        date, rest = line.split(". ", 1)
        d = datetime.strptime(date.removeprefix("Date: "), "%a, %b %d, %Y").date().isoformat()
        row = {"date": d}
        for label, value in re.findall(r"([^.:]+) size: ([\d,]+)", rest):
            row[label.strip().lower().replace(" ", "_")] = int(value.replace(",", ""))
        rows.append(row)
    return rows

active = history("audience_segments_active_chart.json")
total = history("audience_segments_total_history_chart.json")
assert len(active) == len(total) == 28
assert [r["date"] for r in active] == [r["date"] for r in total]
daily = []
for a, t in zip(active, total):
    assert a["monthly_active_listeners"] == t["monthly_active_listeners"]
    assert sum(a[k] for k in ["super_listeners", "moderate_listeners", "light_listeners"]) == a["monthly_active_listeners"]
    assert sum(t[k] for k in ["monthly_active_listeners", "previously_active", "programmed"]) == t["total_audience"]
    daily.append({**t, **a, "measurement_type":"rolling_audience_stock", "source":"audience_segments_total_history_chart.json;audience_segments_active_chart.json"})
write_csv("audience_segment_daily.csv", daily)

text = (CAP / "audience_segments.txt").read_text()
overview = (CAP / "audience_28day_listeners.txt").read_text()
prev_listeners, monthly_listeners = [int(x.replace(",", "")) for x in re.search(r'row "Worldwide ([\d,]+) ([\d,]+) decreased', overview).groups()]
total_audience = int(re.search(r"You have ([\d,]+) listeners", text).group(1).replace(",", ""))
assert total_audience == total[-1]["total_audience"]
segment_rows = []
for label, col, share in [("Monthly active", "monthly_active_listeners", 6), ("Previously active", "previously_active", 38), ("Programmed", "programmed", 56)]:
    assert f'{share}% {label.lower()}' in text
    n = total[-1][col]
    segment_rows.append({"as_of_date":END,"segment":label,"listeners":n,"total_audience":total_audience,"share_of_total_audience_pct_displayed":share,"share_of_total_audience_pct_calculated":100*n/total_audience,"share_of_28day_streams_pct_displayed":91 if col=="monthly_active_listeners" else None,"stream_share_status":"rounded_displayed" if col=="monthly_active_listeners" else "not_captured","audience_window":"past 2 years partition; monthly active qualified within past 28 days","source":"audience_segments_total_history_chart.json;audience_segments.txt;audience_28day_listeners.txt"})
assert "91% of your streams came from your monthly active listeners" in overview
write_csv("audience_segment_snapshot.csv", segment_rows)

active_text = (CAP / "audience_segments_active.txt").read_text()
sub = []
for label, pct, count, spl in re.findall(r'paragraph: (Super|Moderate|Light) listeners • (\d+)%\n    - generic: "(\d+)"\n    - generic: Streams / listener\n    - generic: "([\d.]+)"', active_text):
    sub.append({**SCOPE,"segment":label,"listeners":int(count),"monthly_active_denominator":791,"share_pct_displayed":int(pct),"share_pct_calculated":100*int(count)/791,"streams_per_listener_displayed":float(spl),"rounding":"displayed percent and streams per listener rounded","source":"audience_segments_active.txt"})
assert len(sub)==3 and sum(r["listeners"] for r in sub)==791
write_csv("audience_active_subsegments.csv", sub)

development=[]
for label in ["Reactivated listeners", "New active listeners", "New listeners"]:
    n=int(re.search(rf'generic: {label}\n(?:  - button "Help icon":\n)?  - generic: "(\d+)"',text).group(1))
    development.append({**SCOPE,"metric":label,"listeners":n,"status":"observed","note":"Flow measures; not additive unique audiences or a cohort retention calculation","source":"audience_segments.txt"})
write_csv("audience_development.csv", development)

gender=[]
for label,pct,n in re.findall(r'listitem "(Female|Male|Non-binary|Not specified) (\d+)% (\d+)"', (CAP/"audience_demographics.txt").read_text()):
    gender.append({**SCOPE,"gender":label,"listeners":int(n),"share_pct_displayed":int(pct),"percent_status":"rounded_displayed","source":"audience_demographics.txt"})
assert len(gender)==4
ages=[]
age_gender=[]
for line in read_json("audience_age_chart.json"):
    m=re.fullmatch(r'Age range (.+) (\d+)% of listeners, female (\d+) listeners, male (\d+), non-binary (\d+), not specified (\d+)',line)
    label,pct,*nums=m.groups(); nums=list(map(int,nums))
    ages.append({**SCOPE,"age_range":label,"listeners_from_gender_sum":sum(nums),"share_pct_displayed":int(pct),"percent_status":"rounded_displayed","source":"audience_age_chart.json"})
    for g,n in zip(["Female","Male","Non-binary","Not specified"],nums):
        age_gender.append({**SCOPE,"age_range":label,"gender":g,"listeners":n,"status":"observed_zero" if n==0 else "observed","source":"audience_age_chart.json"})
write_csv("audience_demographics_gender.csv",gender)
write_csv("audience_demographics_age.csv",ages)
write_csv("audience_demographics_age_gender.csv",age_gender)

geo=read_json("geography_tables.json")
countries=[]
for rank,country,n,pct,an in geo[0][1:]:
    countries.append({**SCOPE,"rank":int(rank),"country":country,"listeners":int(n),"active_pct_displayed":None if pct=="—" else float(pct.rstrip("%")),"active_listeners":None if an=="—" else int(an),"active_status":"not_reported_dash" if an=="—" else "observed","share_of_artist_monthly_listeners_pct_calculated":100*int(n)/monthly_listeners,"monthly_listener_denominator":monthly_listeners,"coverage":"Top countries; all 23 displayed rows after enabling less-than-1-percent countries","source":"geography_tables.json;audience_locations_all_available.txt"})
cities=[]
for table in geo[1:]:
    for rank,raw,n in table[1:]:
        m=re.fullmatch(r"(.+?)(United States|United Kingdom|Canada|Australia), (.+)",raw)
        city,country,region=m.groups()
        cities.append({**SCOPE,"rank":int(rank),"city":city,"country":country,"region":region,"listeners":int(n),"raw_location_label":raw,"coverage":"Top 50 cities displayed; not exhaustive geographic coverage","source":"geography_tables.json;audience_locations_all_available.txt"})
assert len(countries)==23 and len(cities)==50
assert [r["rank"] for r in cities]==list(range(1,51))
write_csv("audience_top_countries.csv",countries)
write_csv("audience_top_cities.csv",cities)

country_sum=sum(r["listeners"] for r in countries)
city_sum=sum(r["listeners"] for r in cities)
gender_sum=sum(r["listeners"] for r in gender)
age_sum=sum(r["listeners_from_gender_sum"] for r in ages)
summary={
    "period":SCOPE,"artist_monthly_listeners":monthly_listeners,"total_audience":total_audience,
    "active_share_of_monthly_listeners_pct_calculated":791/monthly_listeners*100,
    "active_share_of_streams_pct_displayed_rounded":91,
    "segment_changes_sep23_to_oct20":{k:{"start":total[0][k],"end":total[-1][k],"delta":total[-1][k]-total[0][k],"pct_change":100*(total[-1][k]/total[0][k]-1)} for k in list(total[0])[1:]},
    "active_subsegment_changes_sep23_to_oct20":{k:{"start":active[0][k],"end":active[-1][k],"delta":active[-1][k]-active[0][k],"pct_change":100*(active[-1][k]/active[0][k]-1)} for k in list(active[0])[1:]},
    "demographic_quality":{"gender_total":gender_sum,"age_gender_total":age_sum,"artist_monthly_listener_total":monthly_listeners,"gender_minus_artist":gender_sum-monthly_listeners,"age_minus_artist":age_sum-monthly_listeners,"male_gender_view":next(r["listeners"] for r in gender if r["gender"]=="Male"),"male_age_view_sum":sum(r["listeners"] for r in age_gender if r["gender"]=="Male"),"status":"Unresolved source inconsistency; retained as captured, not forced to reconcile"},
    "geography":{"country_rows":len(countries),"country_listener_row_sum":country_sum,"country_row_sum_divided_by_monthly_total_pct":country_sum/monthly_listeners*100,"city_rows":len(cities),"city_listener_row_sum":city_sum,"city_row_sum_divided_by_monthly_total_pct":city_sum/monthly_listeners*100,"us_listener_share_pct":777/monthly_listeners*100,"known_country_active_sum":sum(r["active_listeners"] or 0 for r in countries),"missing_country_active_values":[r["country"] for r in countries if r["active_listeners"] is None],"coverage":"Top ranked tables; sums are diagnostics and do not establish complete or mutually exclusive location coverage"},
    "source_files":["audience_segments.txt","audience_segments_active.txt","audience_segments_active_chart.json","audience_segments_total_history_chart.json","audience_demographics.txt","audience_age_chart.json","audience_locations_all_available.txt","geography_tables.json","audience_28day_listeners.txt"],
    "quality_checks":{"active_subsegments_sum_to_active_on_all_28_dates":True,"three_segments_sum_to_total_on_all_28_dates":True,"geographic_ranks_complete_within_displayed_top_lists":True},
}
(ROOT/"analysis/audience_analysis.json").write_text(json.dumps(summary,indent=2)+"\n")

plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.titlesize":15,"axes.labelsize":10,"text.color":"#263344","axes.labelcolor":"#263344","xtick.color":"#526273","ytick.color":"#263344","axes.spines.top":False,"axes.spines.right":False,"axes.spines.left":False,"axes.edgecolor":"#BBC4CC","axes.grid":False,"savefig.facecolor":"white","figure.facecolor":"white"})
BLUE="#356C9B"; GOLD="#BE8B39"; LIGHT="#A8C5DC"; GRAY="#D0D5DB"
def bar_style(ax):
    ax.set_axisbelow(True);ax.grid(axis="x",color="#E8ECF0",linewidth=.7);ax.tick_params(axis="y",length=0);ax.xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))

fig,axs=plt.subplots(1,2,figsize=(13,5.3),gridspec_kw={"width_ratios":[1.12,1]})
fig.suptitle("Audience segments at October 20, 2026",x=.05,ha="left",fontsize=19,fontweight="bold")
for ax,rows,title,limit,share_field in [(axs[0],segment_rows,"Total audience · 12,351 listeners in two years",9000,"share_of_total_audience_pct_displayed"),(axs[1],sub,"Monthly active · 791 listeners in 28 days",680,"share_pct_displayed")]:
    names=[r["segment"] for r in rows];values=[r["listeners"] for r in rows]
    ax.barh(names,values,color=BLUE,height=.55);ax.invert_yaxis();bar_style(ax);ax.set_xlim(0,limit);ax.set_title(title,loc="left",fontsize=12,pad=16);ax.set_xlabel("Listeners")
    for i,r in enumerate(rows):ax.text(r["listeners"]+limit*.025,i,f'{r["listeners"]:,} · {r[share_field]}%',va="center",fontsize=11)
fig.text(.05,.09,"Percentages are Spotify's rounded shares within each panel's audience denominator.",fontsize=10,color="#526273")
fig.text(.05,.045,"Source: captured audience_segments*.txt and audience_segments_total_history_chart.json",fontsize=9,color="#526273")
fig.subplots_adjust(left=.17,right=.97,top=.79,bottom=.23,wspace=.58)
fig.savefig(CHARTS/"audience_segments.png",dpi=180);plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(13,5.8),gridspec_kw={"width_ratios":[1.25,1]})
fig.suptitle("Listener demographics · latest 28 days",x=.05,ha="left",fontsize=19,fontweight="bold")
for ax,rows,key,val,title,lim in [(axs[0],ages,"age_range","listeners_from_gender_sum","Age · count from age-by-gender labels",530),(axs[1],gender,"gender","listeners","Gender · displayed count",840)]:
    ax.barh([r[key] for r in rows],[r[val] for r in rows],color=BLUE,height=.65);ax.invert_yaxis();bar_style(ax);ax.set_xlim(0,lim);ax.set_title(title,loc="left",fontsize=12,pad=14);ax.set_xlabel("Listeners")
    for i,r in enumerate(rows):ax.text(r[val]+lim*.025,i,f'{r[val]:,} · {r["share_pct_displayed"]}%',va="center",fontsize=11)
fig.text(.05,.105,"Source counts disagree: age cells total 1,063; gender totals 1,064; artist monthly listeners = 1,062.",fontsize=10,color="#526273")
fig.text(.05,.065,"Percentages are displayed rounded values; 65+ is shown as 0% despite five listeners. Values retained as captured.",fontsize=10,color="#526273")
fig.text(.05,.025,"Source: audience_demographics.txt; audience_age_chart.json · Worldwide · Sep 23–Oct 20, 2026",fontsize=9,color="#526273")
fig.subplots_adjust(left=.11,right=.97,top=.79,bottom=.23,wspace=.55)
fig.savefig(CHARTS/"audience_demographics.png",dpi=180);plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(13,6.8),gridspec_kw={"width_ratios":[1.1,1]})
fig.suptitle("Top listener locations · latest 28 days",x=.05,ha="left",fontsize=19,fontweight="bold")
for ax,rows,labels,title,lim in [(axs[0],countries[:8],[r["country"] for r in countries[:8]],"Top 8 of 23 displayed countries",960),(axs[1],cities[:10],[r["city"] for r in cities[:10]],"Top 10 of 50 displayed cities",30)]:
    ax.barh(labels,[r["listeners"] for r in rows],color=BLUE,height=.60);ax.invert_yaxis();bar_style(ax);ax.set_xlim(0,lim);ax.set_title(title,loc="left",fontsize=12,pad=14);ax.set_xlabel("Listeners")
    for i,r in enumerate(rows):ax.text(r["listeners"]+lim*.025,i,f'{r["listeners"]:,}',va="center",fontsize=11)
fig.text(.05,.12,"United States: 777 listeners (73.2% of the artist's 1,062 monthly listeners); 637 monthly active (82% displayed).",fontsize=10,color="#526273")
fig.text(.05,.08,"Ranked Top tables are not exhaustive. City rows below the displayed 50 and other country coverage are unavailable.",fontsize=10,color="#526273")
fig.text(.05,.04,"Source: geography_tables.json; audience_locations_all_available.txt · Worldwide · Sep 23–Oct 20, 2026",fontsize=9,color="#526273")
fig.subplots_adjust(left=.16,right=.97,top=.82,bottom=.23,wspace=.62)
fig.savefig(CHARTS/"audience_top_locations.png",dpi=180);plt.close(fig)

md=f'''# Audience analysis — captured Spotify for Artists evidence

Latest 28-day reporting window: September 23–October 20, 2026, Worldwide. Audience stocks are as of October 20. Source data are visible DOM/chart labels, not native CSV exports. Standard demographic and location views only provide the latest 28 days; do not interpret these snapshots as historical audience composition.

## Audience depth

The two-year total audience is **12,351**, comprising **791 monthly active**, **4,672 previously active**, and **6,888 programmed** listeners. Spotify displays rounded shares of **6%, 38%, and 56%** respectively. This denominator is distinct from the latest 28-day monthly-listener total of **1,062**. Monthly active therefore represent **{791/monthly_listeners*100:.1f}%** of monthly listeners, while their displayed share of streams is **91%** (rounded). These are audience segments, not source-of-stream categories: an active listener can also use programmed sources.

Monthly active listeners comprise **47 super (6%)**, **230 moderate (29%)**, and **514 light (65%)** listeners. Displayed streams/listener are **40.1, 5.7, and 1.3** respectively (monthly active overall: **4.9**). These rates and percentages are rounded; multiplying them by counts does not recover exact stream counts. The definitions distinguish light as 1–2 intentional streams, moderate as 3–14, and super as 15+; do not substitute the displayed total streaming rate for the intentional-stream classification threshold.

Across the observed rolling stock history from **September 23 to October 20**, total audience increased **296 (+2.5%)**, monthly active increased **2 (+0.3%)**, previously active increased **114 (+2.5%)**, and programmed increased **180 (+2.7%)**. Super listeners rose **42→47 (+11.9%)**, moderate **231→230 (−0.4%)**, and light **516→514 (−0.4%)**. These are changes between the first and last observed stocks, not growth between two nonoverlapping 28-day cohorts. All three total-audience components and all active subsegments reconcile on all 28 chart dates.

The latest-28-day flow cards report **309 reactivated**, **153 new active**, and **350 new listeners**. Preserve these as separate measures; they do not supply an additive unique audience, conversion funnel, retention rate, or churn count. The nearly flat active stock alongside substantial activation flows identifies a useful retention question, but the captures do not identify which listeners left, returned, or progressed between tiers.

Sources: `audience_segments.txt`, `audience_segments_active.txt`, `audience_segments_active_chart.json`, `audience_segments_total_history_chart.json`, `audience_28day_listeners.txt`. Definitions: `analysis/definitions_notes.md`, section 5.

## Demographic composition and reconciliation

Displayed gender shares are **male 62% (655)**, **female 26% (278)**, **not specified 11% (121)**, and **non-binary 1% (10)**. Displayed age shares are **25–34: 39%**, **18–24: 30%**, **under 18: 11%**, **35–44: 11%**, **45–54: 7%**, **55–64: 2%**, and **65+: 0%**. The core 18–34 brackets account for 739 age-cell listeners and the two displayed rounded shares sum to 69%; this is not a separately displayed combined percentage. The snapshot describes the captured audience, not a recommended targeting exclusion.

**Unresolved source discrepancy:** gender counts sum to **1,064**; age-by-gender cells sum to **1,063**; the artist 28-day unique-listener total is **1,062**. The gender view shows 655 male listeners, while male age cells sum to 654. All captured counts and displayed percentages are retained. No rescaling or extra “unknown” listeners were invented. The 65+ group has five listeners despite its displayed rounded 0% share. Explicit zero cells are stored as observed zero; they are not missing values.

Sources: `audience_demographics.txt`, `audience_age_chart.json`, `audience_28day_listeners.txt`.

## Geography

The expanded Top countries table contains **23 rows** and the Top cities table contains **50 ranks**. Both remain Top/ranked coverage; all visible rows are captured, but full geographic coverage is not established. The country listener rows sum to **1,022** (96.2% of the 1,062 artist total as a reconciliation diagnostic), and the city listener rows sum to **436** (41.1%). Do not label the arithmetic residuals “other unique listeners” or infer a complete disjoint location partition from these tables.

The **United States has 777 listeners**, equal to **73.2%** of the artist's monthly-listener total, and **637 active listeners (82% displayed)**. The next largest displayed countries are the **United Kingdom (50)**, **Canada (44)**, **Germany (24)**, and **Netherlands (15)**. Cleveland (24), Columbus (23), and Akron (23) are the leading city rows; small counts make precise city-level response forecasts unsupported. Current geographic concentration supports testing local engagement in Ohio and adjacent markets, with explicit measurement, rather than assuming that listener counts equal reachable or ticket-buying fans.

**Peru has four listeners and dashes for both active percentage and active-listener count.** The normalized file keeps those two values blank with status `not_reported_dash`; they are not zero and the capture does not establish why they are absent. The sum of reported country active counts is 775, excluding the unavailable Peru value; this does not reconcile to 791 worldwide monthly active and is not forced to do so. Tiny-country active percentages are descriptive and should always be shown beside their counts (e.g. Poland 10/12; Denmark 5/6).

Sources: `geography_tables.json`, `audience_locations_all_available.txt`, `audience_28day_listeners.txt`.

## Actionable interpretation and limits

1. Track movement of the 514 light listeners toward moderate activity in comparable future snapshots. The current distribution supports a repeat-listening opportunity, but not a predicted conversion rate.
2. Maintain consistent contact and repeat-listening opportunities for the 47 super listeners without claiming listener identities are available. Monitor rolling stocks and release-cohort engagement separately.
3. Compare future regional activity against the current U.S./Ohio concentration, retaining both counts and rates. Small cells and Top-table truncation limit fine-grained allocation conclusions.
4. Investigate the demographic mismatch before using these counts for exact audience reconciliation. Retain displayed rounded shares for broad descriptive interpretation.

The platform's generic listener/stream benchmarks in the segment view are not a genre-, scale-, geography-, or release-age-matched peer benchmark. No causal effects, revenue forecasts, advertising ROI, or individual demographic attributes are inferred.

## Outputs

- `normalized/audience_segment_snapshot.csv` — latest two-year segment partition and observed active stream share.
- `normalized/audience_segment_daily.csv` — 28 daily rolling audience stocks, with all active subsegments.
- `normalized/audience_active_subsegments.csv` — current count, rounded displayed share and streams/listener.
- `normalized/audience_development.csv` — separate latest-28-day flow cards.
- `normalized/audience_demographics_gender.csv`, `audience_demographics_age.csv`, `audience_demographics_age_gender.csv` — counts and rounded shares, without forced reconciliation.
- `normalized/audience_top_countries.csv`, `audience_top_cities.csv` — all displayed ranked locations, missing-value status, raw city labels.
- `charts/audience_segments.png`, `audience_demographics.png`, `audience_top_locations.png` — reproducible static figures.

Reproduce with `analysis/analyze_audience.py`. Chart values derive from the normalized structures in that script. Every figure is scoped to the captured reporting date and population.
'''
(ROOT/"analysis/audience_analysis.md").write_text(md)
print(json.dumps(summary,indent=2))
