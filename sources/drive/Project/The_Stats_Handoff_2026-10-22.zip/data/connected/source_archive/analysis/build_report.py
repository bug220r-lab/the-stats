from pathlib import Path
import csv, json, math, re
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables'
OUT.mkdir(exist_ok=True)
def rows(name):
    p=ROOT/'normalized'/name
    return list(csv.DictReader(p.open(encoding='utf-8-sig',newline=''))) if p.exists() else []
def num(v):
    try:return float(v)
    except:return None
def fmt(v,d=0):
    n=num(v)
    return 'Not reported' if n is None else f'{n:,.{d}f}'
def pct(v,d=1):
    n=num(v)
    return 'Not reported' if n is None else f'{100*n:.{d}f}%'
def change(a,b):
    a,b=num(a),num(b)
    return 'Not comparable' if a is None or b in (None,0) else f'{(a/b-1)*100:+.1f}%'

D=Document()
s=D.sections[0]
s.page_width=Inches(8.5);s.page_height=Inches(11)
s.top_margin=Inches(.66);s.bottom_margin=Inches(.66);s.left_margin=Inches(.7);s.right_margin=Inches(.7)
s.header_distance=Inches(.25);s.footer_distance=Inches(.28)
for name in ['Normal','Body Text','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
 st=D.styles[name];st.font.name='Calibri';st.font.color.rgb=RGBColor(0,0,0)
 st.element.get_or_add_rPr().rFonts.set(qn('w:ascii'),'Calibri');st.element.rPr.rFonts.set(qn('w:hAnsi'),'Calibri')
 st.paragraph_format.space_after=Pt(7)
D.styles['Normal'].font.size=Pt(11)
D.styles['Normal'].paragraph_format.line_spacing=1.08
D.styles['Title'].font.size=Pt(29);D.styles['Title'].font.bold=True
D.styles['Title'].paragraph_format.space_after=Pt(12)
D.styles['Heading 1'].font.size=Pt(20);D.styles['Heading 1'].font.bold=True
D.styles['Heading 1'].paragraph_format.space_before=Pt(0);D.styles['Heading 1'].paragraph_format.space_after=Pt(12)
D.styles['Heading 2'].font.size=Pt(13);D.styles['Heading 2'].font.bold=True
D.styles['Heading 2'].paragraph_format.space_before=Pt(11);D.styles['Heading 2'].paragraph_format.space_after=Pt(5)
D.styles['Caption'].font.size=Pt(9);D.styles['Caption'].font.bold=False;D.styles['Caption'].font.color.rgb=RGBColor.from_string('555555')
for st in D.styles:
 for border in list(st.element.xpath('.//w:pBdr')):border.getparent().remove(border)
D.styles['Caption'].paragraph_format.space_after=Pt(10)
D.core_properties.title='Spotify Artist Performance Audit'
D.core_properties.subject='The Stats Spotify audit through October 20 2026'
D.core_properties.author=''
D.core_properties.keywords='Spotify, artist, catalog, audience, performance'
footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=footer.add_run('The Stats  |  ');r.font.size=Pt(9)
f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');footer._p.append(f)

outline=[]
def page(title):
 if outline:D.add_page_break()
 D.add_heading(title,0 if not outline else 1)
 outline.append(title)
def p(text,boldlead=None,style=None):
 text=text.replace('–','-').replace('—','-')
 x=D.add_paragraph(style=style)
 if boldlead and text.startswith(boldlead):x.add_run(boldlead).bold=True;x.add_run(text[len(boldlead):])
 else:x.add_run(text)
 return x
def h(text):D.add_heading(text,2)
def bullet(text):
 x=p(text,style='List Bullet');x.paragraph_format.space_after=Pt(5);return x
def note(text):return p(text,style='Caption')
def chart(file,caption,width=6.85):
 path=ROOT/'charts'/file
 if path.exists():
  x=D.add_paragraph();x.paragraph_format.space_after=Pt(3)
  x.add_run().add_picture(str(path),width=Inches(width))
  pic=x._p.xpath('.//wp:docPr')
  if pic:pic[0].set('descr',caption)
  note(caption)
def hyperlink(para,url):
 rel=para.part.relate_to(url,RT.HYPERLINK,is_external=True)
 link=OxmlElement('w:hyperlink');link.set(qn('r:id'),rel)
 run=OxmlElement('w:r');prop=OxmlElement('w:rPr')
 size=OxmlElement('w:sz');size.set(qn('w:val'),'17');prop.append(size)
 color=OxmlElement('w:color');color.set(qn('w:val'),'555555');prop.append(color)
 run.append(prop);text=OxmlElement('w:t');text.text=url;run.append(text);link.append(run);para._p.append(link)
def table(headers,data,widths=None,small=10):
 t=D.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 if widths:
  for c,w in zip(t.columns,widths):c.width=Inches(w)
 for i,a in enumerate(headers):t.rows[0].cells[i].text=a
 hdr=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(hdr)
 for row in data:
  for c,v in zip(t.add_row().cells,row):c.text=str(v)
 for ri,row in enumerate(t.rows):
  trPr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trPr.append(cant)
  for ci,c in enumerate(row.cells):
   if widths:c.width=Inches(widths[ci])
   c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   tcPr=c._tc.get_or_add_tcPr();shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'233B4B' if ri==0 else ('F2F5F7' if ri%2==0 else 'FFFFFF'));tcPr.append(shd)
   mar=OxmlElement('w:tcMar')
   for tag,val in [('top','80'),('bottom','80'),('left','90'),('right','90')]:
    el=OxmlElement('w:'+tag);el.set(qn('w:w'),val);el.set(qn('w:type'),'dxa');mar.append(el)
   tcPr.append(mar)
   bd=OxmlElement('w:tcBorders')
   for tag in ['top','left','bottom','right']:
    el=OxmlElement('w:'+tag);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');bd.append(el)
   tcPr.append(bd)
   for para in c.paragraphs:
    para.paragraph_format.space_after=Pt(0);para.paragraph_format.line_spacing=1.02
    if ci>0:para.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for r in para.runs:
     r.font.size=Pt(small);r.font.bold=ri==0;r.font.color.rgb=RGBColor.from_string('FFFFFF' if ri==0 else '000000')
 D.add_paragraph().paragraph_format.space_after=Pt(1)
 return t

P={r['window']:r for r in rows('artist_periods_integrated.csv')}
S=rows('song_28day_rankings_ratios.csv')
A={r['song_id']:r['assessment'] for r in rows('song_assessments.csv')}
R=rows('release_catalog.csv')
RM={r['release_id']:r for r in rows('release_metadata.csv')}
RP={(r['release_id'],r['period']):r for r in rows('release_periods.csv')}
CAT=json.loads((ROOT/'analysis'/'catalog_analysis.json').read_text())
H=json.loads((ROOT/'analysis'/'report_song_history.json').read_text()) if (ROOT/'analysis'/'report_song_history.json').exists() else {}

page('Spotify Artist Performance Audit')
p('The Stats™  |  Prepared for Lewis  |  22 October 2026',style='Subtitle')
p('Artist: [REDACTED]  |  Worldwide  |  Latest processed date: 20 October 2026',style='Caption')
p('Listening to the catalog has grown substantially over the past year, but recent discovery has softened. The next priority is to rebuild listener reach while protecting the repeat listening that already supports most streams. Recent 28-day stream growth came from outside the leading three recordings. Funny Guy remains the clearest catalog entry point; The Cut is the strongest current single to retest.')
table(['Latest 28 days','Result','Previous 28 days','Change'],[
 ['Unique listeners','1,062','1,121','-5.3%'],['Streams','4,246','4,011','+5.9%'],['Streams per listener','4.00','3.58','+11.7%'],['Saves','217','129','+68.2%'],['Playlist adds','362','366','-1.1%'],['Followers at window end','1,644','1,616','+28 net']],[2.3,1.1,1.65,1.1])
note('Current: 23 September-20 October 2026. Previous: 26 August-22 September 2026. Counts are worldwide; reporting days use UTC.')
h('Decisions for the next cycle')
bullet('Use Funny Guy to bring listeners into the catalog, and test a second creative angle for The Cut. Keep links tied to the correct recording.')
bullet('Run a small, documented creative test for The Devil Wears Docs before increasing effort: it reaches about as many listeners as The Cut, but has fewer recorded saves.')
bullet('Build a repeat-listening habit around the 514 light active listeners. Review active, moderate and super listener stocks together at the next comparable snapshot.')
p('Confidence is highest in reconciled artist totals and deduplicated song counts. The report keeps several Spotify display inconsistencies visible, including demographic totals and release-engagement segment counts. These do not invalidate the overall direction, but they limit precise cohort claims.')

page('Scope and how to read the findings')
p('This audit connects artist activity, catalog performance, audience composition and release engagement to practical decisions. The latest shared endpoint is 20 October 2026. Long-history calculations begin on 1 January 2024; older all-time counters, where exposed, are reported separately.')
table(['Evidence family','Primary scope','Interpretation'],[
 ['Artist timeline','1 Jan 2024-20 Oct 2026','1,024 daily observations'],['Artist comparisons','7, 28, 90 days; 12 months; YTD','Direct period uniques plus additive activity'],['Catalog','14 recordings across 7 releases','Deduplicate by song ID'],['Demographics and geography','Latest 28 days','Current composition, not historic trend'],['Audience segments','Latest snapshot and observed history','Rolling audience stocks'],['Release engagement','The Cut first 28 days','Fixed pre-release active cohort'],['Playlists and features','Captured account views','Coverage and thresholds apply']],[1.7,2.45,2.95])
p('Daily song evidence contains 64 complete series out of 70 expected recording-metric combinations, plus two partial series and four unavailable series. Detailed source breakdowns were collected for The Cut only. Song Location pages loaded for seven recordings and errored for seven; song Playlist pages loaded for three and errored for eleven.')
h('Three distinctions that change the answer')
p('A listener is unique within a selected period. Adding daily listeners or song-level listeners counts some people repeatedly. This report uses direct period totals for audience reach and adds only additive activity measures such as streams.')
p('Audience segments describe people; stream sources describe listening occasions. The 91% of streams attributed to monthly active listeners is different from the 88.2% generated through active sources. A monthly active listener can also use programmed sources.')
p('Available history is different from all time. A 2023 recording can have streams before the daily series begins. Conversely, a contradictory header counter cannot be repaired by assuming a cause that the account does not show.')
h('Navigation')
p('The next sections cover period comparisons, history, stream sources, audience depth, demographics, geography, catalog priorities, every recording, release engagement, playlists and features, and the 30/60/90-day plan. The final pages explain benchmarks, quality limits and source references. The workbook contains the detailed normalized datasets and calculation trail.')

page('Performance across comparable periods')
data=[]
for key,prev,label in [('latest_7','previous_7','7 days'),('latest_28','previous_28','28 days'),('latest_90','previous_90','90 days'),('latest_12_months','previous_12_months','12 months'),('year_to_date','previous_year_same_dates','YTD matched dates')]:
 a,b=P[key],P[prev]
 data.append([label,fmt(a['streams']),change(a['streams'],b['streams']),fmt(a['period_unique_listeners']),change(a['period_unique_listeners'],b['period_unique_listeners']),fmt(a['saves'])])
table(['Window','Streams','Stream change','Unique listeners','Listener change','Saves'],data,[1.6,1.0,1.1,1.15,1.15,1.0])
note('Changes use the preceding equal-length period except YTD, which compares 1 January-20 October in 2026 and 2025. Prior-year YTD unique listeners are unavailable for this comparison and are not reconstructed by adding daily counts.')
h('Short term improvement is narrower than the stream total suggests')
p('The latest week generated 1,186 streams, up 7.2% from the preceding week. Over 28 days, a 5.9% stream increase coincided with a 5.3% decline in unique listeners. More listening per reached person explains the divergence; it does not establish that the same people returned.')
p('Saves rose by 88 to 217 in the latest 28 days. The saves-per-listener activity ratio rose from 11.5% to 20.4%. This is useful as a directional engagement signal, but it is not a measured unique-person conversion rate.')
h('The quarter remains below its preceding release period')
p('The latest 90 days produced 13,775 streams, down 30.5%; listeners fell 26.2% to 2,436 and saves fell 49.3%. The prior window began on The Cut release day, so release timing is part of the context. The comparison measures a decline in activity, not proof that promotion or the music caused it.')
h('The longer view remains materially larger')
p('The latest 12 months generated 63,957 streams and 9,924 unique listeners, up 165.5% and 213.5%. Streams per listener fell from 7.61 to 6.44 as reach expanded faster than listening volume. Year-to-date streams are 58,175, up 154.9% against the same dates in 2025.')
p('The dashboard custom YTD previous-period option instead compares against the prior 293 days. Its 111.8% stream change answers a different question and is not used as the year-over-year YTD headline.')

page('History shows a larger but uneven audience')
chart('artist_monthly_streams.png','Figure 1. Monthly streams from the native artist timeline. October 2026 is partial through 20 October; compare daily rates or matched dates, not its raw total with a complete month.')
p('March 2026 was the largest complete month in this history at 10,538 streams. September recorded 4,305, 59.1% below that peak. October 1-20 averaged 156.4 streams per day, compared with 143.5 in September, a 9.0% improvement in daily rate.')
table(['Observed milestone','Value','Date'],[['Highest daily streams','896','8 Aug 2025'],['Highest daily listeners','608','6 Mar 2026'],['Highest rolling monthly listeners','4,030','19 Mar 2026'],['Highest monthly active listeners','1,276','3 Sep 2025'],['Highest super listeners','110','3 Sep 2025']],[3.65,1.35,2.0])
p('The difference between the reach peak in March 2026 and the active-audience peak in September 2025 supports tracking both breadth and depth. A large monthly-listener count can fade if it does not lead to continuing intentional listening.')
p('Across the available history, the artist has 101,342 streams, 7,947 saves and 10,280 playlist adds. These are January 2024 onward totals, not lifetime totals. The direct unique-listener total for that window is 15,250.')

page('Intentional listening supports the current base')
chart('artist_stream_sources_28day.png','Figure 2. Source of 4,246 streams in the latest 28 days. The explicit Other category is unidentified-source activity, not a reconciliation estimate.')
table(['Source','Streams','Share','Change vs prior 28 days'],[
 ['Own playlists and library','3,171','74.7%','+6.9%'],['Artist profile and catalog','446','10.5%','+35.2%'],['Personalized playlists autoplay and mixes','256','6.0%','-26.6%'],['Other unidentified source','145','3.4%','-1.4%'],['Listener queue','129','3.0%','+3.2%'],['Other listeners playlists','99','2.3%','+5.3%'],['Editorial and personalized editorial','Not reported','Not reported','Not reported']],[3.2,.85,.85,1.85],9.5)
p('Active sources supplied 3,746 streams, or 88.2%, up from 85.3%. Programmed sources fell from 443 to 355 streams. The increase came mainly from own playlists and libraries (+205) and profile/catalog (+116), while personalized playlists, autoplay and mixes fell by 93.')
p('The practical response is to keep intentional listeners engaged while testing ways to restore discovery. These source movements do not identify an external campaign or establish causal attribution. Source-listener counts overlap and cannot be added.')

p('The Cut shows the same tension: active-source streams rose from 457 to 483, while programmed streams fell from 59 to 42 and Other from 29 to 14. Personalized playlists, autoplay and mixes fell from 37 to 11. Detailed song-source evidence was collected for The Cut only; the other 13 recordings were not collected at this level.')

page('Audience depth and repeat listening')
chart('audience_segments.png','Figure 3. Audience stocks as of 20 October 2026. The two-year audience denominator differs from the latest 28-day monthly-listener denominator.')
p('Monthly active listeners number 791, or 74.5% of the 1,062 monthly listeners. They generated a displayed, rounded 91% of latest-28-day streams. The broader two-year audience is 12,351: 791 monthly active, 4,672 previously active and 6,888 programmed listeners.')
p('Within the active audience, 47 super listeners form 6%, 230 moderate listeners 29%, and 514 light listeners 65%. The large light group is the clearest repeat-listening opportunity. The displayed streams-per-listener figures are 40.1, 5.7 and 1.3, but those rounded totals are not the intentional-stream thresholds used to assign tiers.')
h('Growth flows are not retention rates')
p('The latest period shows 309 reactivated listeners, 153 new active listeners and 350 new listeners. These cards have different definitions and do not form an additive funnel. The active stock moved only from 789 on 23 September to 791 on 20 October, despite the activation flows.')
p('For nonoverlapping period endpoints, active listeners were 791 on both 22 September and 20 October. Super listeners rose from 44 to 47 over those dates. This is different from the UI first-date-to-last-date comparison of 42 to 47, or +11.9%. Keep the anchor dates beside every change.')

page('Demographic composition')
chart('audience_demographics.png','Figure 4. Latest 28-day demographic snapshot. Displayed percentages are rounded and count totals differ slightly across Spotify views.')
p('The largest displayed age group is 25-34 at 39%, followed by 18-24 at 30%. Their displayed rounded shares sum to 69%; the underlying age-cell counts total 739. Gender shares are 62% male, 26% female, 1% non-binary and 11% not specified.')
p('These patterns can guide inclusive creative references and content experiments. They do not establish who will respond to a particular message, and they are not a reason to exclude smaller audience groups from the artist’s communication.')
h('Preserve the small source mismatch')
table(['View','Count total','Difference from artist monthly listeners'],[['Artist unique listeners','1,062','Reference'],['Gender view','1,064','+2'],['Age by gender cells','1,063','+1']],[2.7,1.3,3.0])
p('The male total is 655 in the gender view but 654 when summed across age cells. No correction or invented category has been applied. The 65+ group contains five listeners despite its rounded 0% display. Broad composition is informative; exact reconciliation remains unresolved.')

page('Geography suggests local tests')
chart('audience_top_locations.png','Figure 5. Largest displayed countries and cities, latest 28 days. These are ranked Top tables, not a complete geographic census.')
p('The United States has 777 listeners, equal to 73.2% of the artist monthly-listener total. Of those, 637 are shown as active, a displayed 82%. The United Kingdom follows with 50 listeners, Canada with 44, Germany with 24 and the Netherlands with 15.')
p('Cleveland leads the city table with 24 listeners; Columbus and Akron each have 23. This supports a measured Ohio-focused content or live-engagement test. The counts are too small to forecast ticket sales or assume reachable fans. A listener count is not a mailing-list, purchaser or attendance count.')
h('Keep small cells in context')
p('The captured tables contain 23 country rows and 50 city ranks. Their listener counts sum to 1,022 and 436, respectively. Those sums are coverage diagnostics, not permission to invent an “other listeners” population. Peru shows four listeners but no active percentage or active count; both remain unavailable.')
p('Song Location views report streams, not listeners. Seven of 14 pages loaded; the United States leads each available table. Leading cities differ: Funny Guy has 38 streams in Fort Worth, The Cut 23 in Cleveland, and The Devil Wears Docs 26 in Miami. The other seven pages returned errors. Each available city list stops at rank 50; Funny Guy’s country sum is four streams below its total. These limits remain explicit.')
p('For the next cycle, log each local activity and examine matching city/country snapshots, song reach and active listening together. A change after an event is an association until a suitable comparison or controlled test supports attribution.')

page('Catalog concentration and release identity')
chart('catalog_streams_28day.png','Figure 6. Latest 28-day streams for 14 distinct recordings. Identically titled recordings from 2023 and 2024 remain separate.')
p('Funny Guy supplies 35.0% of current streams. Together with The Cut and The Devil Wears Docs, the top three recordings supply 59.8%. This gives the artist a clear entry point, while also exposing dependence on a few tracks.')
p('Recent growth came from deeper catalog use: the top three fell by 20 streams versus the prior 28 days, while artist streams outside those three rose by 255 (+17.5%), producing the net artist gain of 235. Over 12 months, the picture differs: Funny Guy and the two 2026 singles account for 31,502 of the 39,870 net stream increase, or 79.0%. The new singles had no prior-year streams, so their percentage growth is undefined.')
p('The 14 unique recording totals sum exactly to the artist total of 4,246 streams over 28 days and 1,186 over seven days. The catalog has 17 release memberships because Funny Guy, Crawl and GOOMH! share the same recording IDs across their single and album releases. Adding all release totals would double-count them.')
p('The 2023 Lab Tapes versions of Method Acting and ¡La Cocaína! use different IDs from the 2024 album versions. They remain separate recordings in every calculation. Promotion should link to the intended version and preserve older versions as fan context where useful.')

page('Every recording at a glance')
table(['Recording','Streams','Listeners','Streams per listener','Saves','Saves per listener'],[[r['recording_label'],fmt(r['streams']),fmt(r['listeners']),fmt(r['streams_per_listener'],2),fmt(r['saves']),pct(r['saves_per_listener'])] for r in S],[2.45,.75,.78,1.03,.67,1.12],9.4)
note('23 September-20 October 2026, worldwide. Ratios are activity counts per period listener, not unique-person conversion rates. Not reported preserves a displayed dash.')
p('The Cut and The Devil Wears Docs reach similar numbers of listeners (204 and 205), but The Cut records 32 saves against six. That is a useful within-catalog test signal, not a definitive quality verdict: exposure context and audience overlap are not controlled.')
p('High ratios in the catalog tail are based on small denominators. Son! has a 38.5% saves/listener ratio from only 26 listeners; Method Acting’s album version has 32.5% from 40. Use these as candidates for controlled discovery tests rather than automatic ranking winners.')

page('Recording history and release age')
per={(r['song_id'],r['period']):r['value'] for r in rows('song_periods_from_daily.csv') if r['metric']=='streams'}
counters={r['song_id']:r['all_time_streams'] for r in rows('song_alltime_counters.csv')}
first={}
for r in rows('song_first28_daily_streams.csv'):first.setdefault(r['song_id'],[]).append(r)
hr=[]
for r in S:
 sid=r['song_id'];f=first.get(sid,[])
 first28=sum(float(a['streams']) for a in f) if len(f)==28 and {int(a['day']) for a in f}==set(range(1,29)) else None
 hr.append([r['recording_label'],fmt(per.get((sid,'90day'))),change(per.get((sid,'90day')),per.get((sid,'previous_90day'))),fmt(per.get((sid,'12months'))),fmt(first28),fmt(counters.get(sid))])
table(['Recording','90-day streams','90-day change','12-month streams','Original first 28 days','All-time header'],hr,[2.25,.85,.85,.95,1.0,1.1],9.2)
note('Latest 90 days: 23 July-20 October 2026 versus 24 April-22 July. Latest 12 months: 21 October 2025-20 October 2026. First 28 days uses the original recording release date and requires all 28 daily observations. Old release windows before available history remain unavailable. All-time header is a separate displayed counter. GOOMH! has 365 retained stream days; Son! has 730 observed stream days across disjoint windows, not a continuous full-history series.')
p('Release age matters. A new single’s preceding 90-day window can contain its launch surge, while an older track is being compared between catalog-use periods. A percentage decline is not a matched peer benchmark or a measured decay expectation. Selected-history totals and all-time headers are never merged when they disagree.')
h('A fair launch comparison')
p('Compare the first seven or 28 days from each recording’s original release date, then review follow-through after that launch. When Spotify’s preset starts at an album date rather than the original single date, use the actual chart dates recorded in the workbook. A zero before a song existed is different from unavailable early history.')

page('Priorities for the leading recordings')
for r in S[:7]:
 p(r['recording_label']+': '+A.get(r['song_id'],''),boldlead=r['recording_label']+': ')
 if H.get(r['song_id']):p(H[r['song_id']],style='Caption')
 else:p(f"Latest 28 days: {fmt(r['streams'])} streams, {fmt(r['listeners'])} listeners, {fmt(r['saves'])} saves; {fmt(r['streams_per_listener'],2)} streams per listener.",style='Caption')
h('Choose tests that answer one question')
p('For the leading tracks, vary one creative element at a time: opening excerpt, performance setting or story. Keep the destination recording and measurement window consistent. Record publishing dates and compare reach with intentional listening, saves and follow-through; a stream increase alone does not establish stronger fandom.')

page('Priorities for the remaining recordings')
for r in S[7:]:
 p(r['recording_label']+': '+A.get(r['song_id'],''),boldlead=r['recording_label']+': ')
 if H.get(r['song_id']):p(H[r['song_id']],style='Caption')
 else:p(f"Latest 28 days: {fmt(r['streams'])} streams, {fmt(r['listeners'])} listeners, {fmt(r['saves'])} saves; {fmt(r['streams_per_listener'],2)} streams per listener.",style='Caption')
h('Keep the catalog accessible')
p('A short route from an entry song into related catalog material is easier to evaluate than promoting every recording equally. Rotate one deeper track into the test schedule, preserve recording IDs, and judge it on growth in both audience and engagement against its own baseline. Low-volume archival versions can remain available without receiving the same promotional effort as the main recording.')

page('Release comparison and history')
table(['Release','Release date','28-day streams','12-month streams','2024 onward','All-time header'],[[r['release_title'],RM.get(r['release_id'],{}).get('release_date',r['release_year']),fmt(r['streams_28day']),fmt(RP.get((r['release_id'],'12_months'),{}).get('streams')),fmt(RM.get(r['release_id'],{}).get('history_streams_sum')),fmt(RM.get(r['release_id'],{}).get('all_time_streams_displayed'))] for r in R],[2.65,1.0,.75,.85,.9,.85],9.2)
note('All activity columns are streams. Latest 28 days: 23 September-20 October 2026; latest 12 months: 21 October 2025-20 October 2026; available history: 1 January 2024-20 October 2026. Release totals overlap and must not be summed into an artist total.')
p('The album grew from 2,912 to 3,142 streams against the preceding 28 days (+7.9%). Current counts describe catalog use at different release ages. The 2023 releases have activity before daily history begins, so their smaller available-history totals need not equal all-time counters.')
h('Compare releases at the same age')
p('Use first-seven-day and first-28-day activity from each recording’s actual release date, and compare those with later equivalent windows. Distinguish the original recording release date from a Spotify preset that may anchor to a later album release. Funny Guy and Crawl first-window presets anchor to the album date, 31 May 2024, while their original single release dates are 12 April and 10 May 2024. The age-aligned table uses the original dates.')
h('Keep all time separate from available history')
conflicts=[r for r in CAT.get('alltime_discrepancies',[]) if r.get('header_minus_history',0)<0]
if conflicts:
 pieces=[f"{r['recording_label']}: header {fmt(r['all_time_header'])}, available-history total {fmt(r['available_history_streams'])}" for r in conflicts]
 
 if any(r.get('release_type')=='Album' and num(r.get('history_minus_all_time'))>0 for r in RM.values()):
  pieces += [f"{r['release_title']} album: header {fmt(r['all_time_streams_displayed'])}, available-history total {fmt(r['history_streams_sum'])}" for r in RM.values() if r.get('release_type')=='Album' and num(r.get('history_minus_all_time'))>0]
 p('The following counters disagree: '+('; '.join(pieces))+'. These differences are unresolved. The displayed headers and selected-history sums retain their separate labels; neither is silently substituted for the other.')
else:
 p('Available daily history and all-time header counters retain separate scope labels. A later history start does not establish a lifetime total.')

# Collection-dependent evidence is read as explicit prose, not fabricated.
extra=ROOT/'analysis'/'report_collection_summary.txt'
if extra.exists():
 for line in extra.read_text().split('\n\n'):
  if line.strip():p(line.strip())
else:
 p('The workbook retains the collected daily histories, period totals and reconciliation checks at recording level. All-time counters and any incomplete first-window history are explicitly labeled so that unavailable data do not become zero values.')

page('The Cut reached part of the existing active audience')
chart('release_engagement.png','Figure 7. The Cut first-28-day engagement, 24 April-21 May 2026. This measures members of the fixed 23 April active cohort, not all listeners to the release.')
p('The release panel displays a pre-release monthly active cohort of 1,076 listeners. By day 28, 252 had listened from active sources (23.4% displayed); including all sources raises this to 269 (25.0%). The difference is 17 cohort members and 1.58 percentage points, not a causal estimate of programmed promotion.')
p('Active-source aggregate reach rose from 40 on day one to 120 on day seven, 172 on day 14 and 252 on day 28. The curve describes cumulative unique reached cohort members; daily values must not be added.')
h('The segment views do not reconcile')
p('The baseline tier counts sum correctly: 85 super + 366 moderate + 625 light = 1,076. Their active-source engaged counts do not: 51 + 110 + 145 = 306, exceeding the aggregate 252 by 54. The report therefore keeps aggregate and tier results separate. The source captures do not establish the cause. All-source tier counts also sum to 325 (53 + 120 + 152), exceeding the aggregate 269 by 56. All eight source/tier combinations were captured.')
p('The artist timeline reports 957 monthly active and 77 super listeners on 23 April, while the release panel uses 1,076 and 85. Those baseline views also disagree; the release-panel rates retain their displayed denominators. The current release picker exposes only The Cut and labels its window as the last six months, while Spotify’s support article says three months. This audit preserves the account’s observed coverage. The pre-release baseline is distinct from the current 791 monthly active listeners.')

page('Playlists content and campaigns')
table(['Selected period','Algorithmic groups','Listener playlists','Editorial view'],[['7 days','5','1','No stats'],['28 days','6','3','No stats'],['12 months','10','21','No stats']],[1.3,1.55,1.55,2.6],9.8)
p('In the 12-month view, Release Radar leads with 3,078 streams from 2,250 listeners, followed by Radio at 2,518 and Mixes at 2,327 streams. Pure Punk leads the reported listener playlists by streams at 199 from 140 listeners. These are opportunities to understand current discovery, not guaranteed sources of future reach.')
p('Mixes leads the 28-day algorithmic view with 181 streams from 118 listeners. All three reported listener playlists in that view feature The Cut: Slipknot Radio, Loud Rock&Metal and Highway Song, together contributing 32 streams. Slipknot Radio is categorized as a listener playlist, distinct from the algorithmic Radio group.')
p('Song-level playlist views loaded for the leading three recordings. In their 12-month tables, Funny Guy draws 1,043 streams from Mixes, The Cut 508 from Radio, and The Devil Wears Docs 2,961 from Release Radar. The other 11 song playlist pages returned errors; their missing results are not zeros or proof of playlist removal.')
h('Coverage limits matter')
p('Exact playlist period dates were not exposed. The 12-month view expanded to 21 listener rows but displayed “Showing 21 of 1.8k”; its native CSV contained the same 21 rows, with no further pagination visible. Spotify documents a top-100 view and a minimum of three listeners. These tables are not an exhaustive playlist universe, and editorial “No stats” is not a numeric zero. [5]')
p('The 28-day named algorithmic rows total 263 streams versus 256 in the separately captured personalized-source category; listener rows total 32 versus 99 in other listeners’ playlists. Different surfaces and unknown playlist bounds remain unresolved. Do not force a reconciliation or add playlist listeners into unique reach.')
h('Content opportunities and observed availability')
p('Campaigns and Sub-campaigns both show empty current lists. Spend, conversion and ROI are unavailable. Marquee and Showcase creation controls do not establish final eligibility or expected returns. The 2026 Wrapped Artist Message offers one video of up to 30 seconds before 6 November; review that opportunity promptly.')
p('Song pages show Manage Canvas for 12 recordings and Add Canvas for the two Lab Tapes versions. The release inventory separately shows 15 card appearances and 12 distinct labels; repeated single/album appearances are not unique assets. Controls and cards do not verify published asset contents or effectiveness. Song analytics separately reports 388 Canvas views for Funny Guy, 157 for The Cut and 118 for The Devil Wears Docs in the latest 28 days. These views are not stream conversions. [6]')
note('Sources: captured artist playlist exports and rendered tables; Campaigns, Sub-campaigns, Artist Message and Canvas account views, collected 22 October 2026. No campaign or content changes were made.')

page('Action plan for the next ninety days')
h('Days 1 to 30')
p('Review the 2026 Wrapped Artist Message opportunity before its displayed 6 November deadline. Confirm one owner for the measurement log and one owner for creative production. Use the current 28-day snapshot as the baseline. Resolve the all-time and release-engagement discrepancies with Spotify support if those exact totals are needed for external claims.')
p('Test a refreshed Funny Guy performance excerpt and a second framing of The Cut. Give The Devil Wears Docs one focused excerpt or story test before expanding promotional effort. Use exact recording links and record the date, asset, destination and intended audience for each post.')
p('Create a short route from the entry tracks into two catalog selections, including one small-audience track such as the album Method Acting or Waste Away. Make save and follow invitations part of useful song context.')
h('Days 31 to 60')
p('Review the next nonoverlapping 28-day window. Look for increases in unique listeners alongside active listening, saves and net followers. Retain only creative approaches that improve a meaningful combination of these measures; repeat promising tests before treating a small result as reliable.')
p('Run one Ohio-focused engagement test if it fits the artist’s existing activity. Compare observed location and song snapshots while keeping the very small city denominators visible. Do not turn the current city ranks into ticket forecasts.')
h('Days 61 to 90')
p('Concentrate effort on the strongest repeated creative result and one catalog follow-through track. Prepare any next release with a documented pre-release active baseline and a fixed first-7/14/28-day review. Measure aggregate engagement and tier views separately until Spotify’s tier discrepancy is understood.')
p('Review whether reach is recovering without losing intentional listening. Update the catalog priority list, retain the export archive, and choose the next cycle from measured outcomes rather than a single highest ratio.')
table(['Review point','Decision','Evidence needed'],[['Day 30','Which test deserves another cycle','Reach and activity against the baseline'],['Day 60','Which approach can be repeated','Two consistent observations and context log'],['Day 90','Which songs lead the next cycle','Audience reach depth and release readiness']],[1.0,2.35,3.65])

page('Measurement and useful benchmarks')
p('The most useful benchmark is the artist’s own comparable history: nonoverlapping windows, equal release age and the same metric definition. No genre-, scale-, geography- and release-age-matched peer sample was established, so the report does not invent an average Spotify artist or a percentile.')
table(['Measure','Current baseline','What would support progress'],[['28-day unique listeners','1,062','Reach recovers across repeated windows'],['Monthly active listeners','791','Stock grows while reach also grows'],['Moderate and super listeners','230 and 47','Depth grows beyond just light listeners'],['Streams per listener','4.00','Useful with reach not alone'],['28-day saves','217','Growth persists beyond one week'],['Net followers per 28 days','+28','Growth alongside active audience'],['Programmed-source streams','355','Discovery improves without losing depth'],['The Cut cohort reach','252 / 1,076 active sources','Future releases compared at equal age']],[2.1,1.7,3.2],9.8)
h('Use targets as decisions rather than forecasts')
p('For the first review, aim to exceed the 1,062-listener and 791-active-listener baselines while maintaining at least 217 saves and positive net follower growth. These are proposed operating goals, not statistical thresholds or predicted outcomes. If reach grows but active listening weakens, inspect source mix and song-level follow-through before scaling activity.')
p('Keep a simple weekly log of content, release, live and campaign activity. A seven-day movement is an early signal; a second nonoverlapping 28-day observation gives a stronger basis for a decision. Avoid comparing a partial month with a full one or calling correlation a causal lift.')
h('Calculations to preserve')
p('Relative change is current divided by comparison minus one. Streams per listener uses the direct unique listener count for that entity and period. Saves per listener and playlist adds per listener are activity ratios. Follower growth is the difference between end-of-window and pre-window stocks. Missing values stay missing; explicit zeros stay zero.')

page('Quality limits and source record')
table(['Issue','Handling and consequence'],[['History begins in 2024','Available history is not lifetime; 64/70 song-metric daily series are complete'],['Duplicate release memberships','Song IDs deduplicate artist catalog sums'],['Listeners overlap','No summed daily song or source unique counts'],['Demographic totals differ','Retain 1,064 gender and 1,063 age-cell totals against 1,062 artist listeners'],['Release cohort views disagree','Keep panel baselines and tier counts separate from artist timeline and aggregate'],['All-time counter conflict','Retain header and history totals with separate scopes'],['Song breakdown coverage','Sources: The Cut only; Location: 7 loaded/7 errors; Playlists: 3 loaded/11 errors'],['Top geography and playlist tables','Rows are not exhaustive; exact playlist period bounds are unreported'],['YTD previous period differs','Use matched calendar dates for year-over-year headline'],['Partial October','Compare per-day rates or matched dates'],['Attribution unavailable','Do not infer campaign ROI revenue or retention from aggregate changes']],[2.2,4.8],9.8)
h('Evidence and reproducibility')
p('The accompanying source package retains native exports unchanged, observed dashboard text and chart labels, normalized CSVs and reproducible calculation scripts. The workbook keeps source fields and missing-value statuses so that each result can be traced to its grain, period and origin. Collection dates and file-level coverage are retained in the package manifest.')
p('The artist native timeline contains 1,024 consecutive daily rows with no duplicate dates, missing dates, null metric values or negative values. Its additive period totals reconcile with the captured dashboard. The 14 distinct recording totals reconcile with artist streams for the seven-day and 28-day catalog views. Their daily stream sum also matches the artist total on every one of the latest 365 dates.')
p('Spotify includes music-video streams in audience statistics from May 2025, while captured song pages state audio-track scope. That definition change is a possible comparability limit if video activity exists; it is not assumed to explain any specific discrepancy. [3]')

page('Reference definitions and source links')
p('Account evidence comes from the authenticated Spotify for Artists views and exports recorded in the accompanying source package. Public Spotify documentation supplies definitions and documented coverage, not the private artist values. Documentation was checked on 22 October 2026.')
refs=[
('1','Audience segments on Spotify','https://support.spotify.com/us/artists/article/audience-segments-on-spotify/','Defines the two-year total audience, monthly active listeners, intentional-listening tiers and activation flows.'),
('2','Source of streams','https://support.spotify.com/us/artists/article/source-of-streams/','Defines active and programmed sources and explains overlapping source audiences.'),
('3','How far back your stats go','https://support.spotify.com/us/artists/article/how-far-back-your-stats-go/','Documents history limits and the May 2025 inclusion of video streams in audience statistics.'),
('4','Understanding release engagement','https://support.spotify.com/us/artists/article/understanding-release-engagement/','Defines the fixed pre-release monthly active cohort and first-28-day engagement.'),
('5','Seeing playlists your music is on','https://support.spotify.com/us/artists/article/seeing-playlists-your-music-is-on/','Documents ranked playlist coverage and the listener threshold.'),
('6','How we count Canvas views','https://support.spotify.com/us/artists/article/how-we-count-canvas-views/','Explains why Canvas views and qualifying streams use different definitions.'),
('7','How your streams are counted','https://support.spotify.com/us/artists/article/how-your-streams-are-counted/','Defines qualifying streams and overlapping recording membership across releases.'),
('8','Understanding your listener and follower stats','https://support.spotify.com/us/artists/article/understanding-your-listener-and-follower-stats/','Defines period-unique listeners and follower counts.'),
('9','Time zone for stats in Spotify for Artists','https://support.spotify.com/us/artists/article/time-zone-for-stats-in-spotify-for-artists/','Defines UTC reporting days.'),
('10','How we count saves','https://support.spotify.com/us/artists/article/how-we-count-saves/','Describes save activity; does not establish a unique-person conversion rate.')]
for n,title,url,desc in refs:
 p(f'[{n}] {title}. {desc}')
 x=p('',style='Caption');hyperlink(x,url)
p('The report uses the account’s observed latest processed date rather than an assumed refresh time. Where the visible account and support documentation differ, the difference remains explicit instead of being silently reconciled.')
D.save(OUT/'The_Stats_Report.docx')
(ROOT/'analysis'/'report_outline.txt').write_text('\n'.join(f'{i+1}. {x}' for i,x in enumerate(outline)))
print(f'Created {OUT / "The_Stats_Report.docx"} with {len(outline)} planned sections')
