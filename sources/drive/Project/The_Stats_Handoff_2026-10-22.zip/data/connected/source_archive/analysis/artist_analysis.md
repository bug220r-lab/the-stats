# Artist timeline analysis

Source: `artist_timeline_2024-01-01_2026-10-20.csv`. 1,024 daily rows from 2024-01-01 through 2026-10-20. The raw file is a byte-identical copy of the native export.

## Data validation

No missing dates, duplicate dates, null metric values or negative metrics. SHA-256: `6b4f56d8d9fc7d4ae93e06157b6a4cb1ea0d978094bb72d49ffdceb02377eebe`.

## Comparison periods

| Window | Dates (inclusive) | Streams | Saves | Playlist adds | Unique listeners |
|---|---|---:|---:|---:|---:|
| latest_7 | 2026-10-14 to 2026-10-20 | 1,186 | 88 | 108 | 438 |
| previous_7 | 2026-10-07 to 2026-10-13 | 1,106 | 30 | 90 | 422 |
| latest_28 | 2026-09-23 to 2026-10-20 | 4,246 | 217 | 362 | 1,062 |
| previous_28 | 2026-08-26 to 2026-09-22 | 4,011 | 129 | 366 | 1,121 |
| latest_90 | 2026-07-23 to 2026-10-20 | 13,775 | 562 | 1,267 | 2,436 |
| previous_90 | 2026-04-24 to 2026-07-22 | 19,832 | 1,108 | 1,752 | 3,301 |
| latest_12_months | 2025-10-21 to 2026-10-20 | 63,957 | 4,290 | 6,643 | 9,924 |
| previous_12_months | 2024-10-21 to 2025-10-20 | 24,087 | 2,751 | 2,838 | 3,166 |
| year_to_date | 2026-01-01 to 2026-10-20 | 58,175 | 3,742 | 5,854 | 9,419 |
| previous_year_same_dates | 2025-01-01 to 2025-10-20 | 22,825 | 2,694 | 2,760 | Dashboard required |
| available_history | 2024-01-01 to 2026-10-20 | 101,342 | 7,947 | 10,280 | 15,250 |

## Changes

| Comparison | Metric | Current | Previous | Absolute change | Relative change |
|---|---|---:|---:|---:|---:|
| latest_7 vs previous_7 | streams | 1,186 | 1,106 | +80 | +7.2% |
| latest_7 vs previous_7 | saves | 88 | 30 | +58 | +193.3% |
| latest_7 vs previous_7 | playlist_adds | 108 | 90 | +18 | +20.0% |
| latest_28 vs previous_28 | streams | 4,246 | 4,011 | +235 | +5.9% |
| latest_28 vs previous_28 | saves | 217 | 129 | +88 | +68.2% |
| latest_28 vs previous_28 | playlist_adds | 362 | 366 | -4 | -1.1% |
| latest_28 vs previous_28 | period_unique_listeners | 1,062 | 1,121 | -59 | -5.3% |
| latest_90 vs previous_90 | streams | 13,775 | 19,832 | -6,057 | -30.5% |
| latest_90 vs previous_90 | saves | 562 | 1,108 | -546 | -49.3% |
| latest_90 vs previous_90 | playlist_adds | 1,267 | 1,752 | -485 | -27.7% |
| latest_12_months vs previous_12_months | streams | 63,957 | 24,087 | +39,870 | +165.5% |
| latest_12_months vs previous_12_months | saves | 4,290 | 2,751 | +1,539 | +55.9% |
| latest_12_months vs previous_12_months | playlist_adds | 6,643 | 2,838 | +3,805 | +134.1% |
| year_to_date vs previous_year_same_dates | streams | 58,175 | 22,825 | +35,350 | +154.9% |
| year_to_date vs previous_year_same_dates | saves | 3,742 | 2,694 | +1,048 | +38.9% |
| year_to_date vs previous_year_same_dates | playlist_adds | 5,854 | 2,760 | +3,094 | +112.1% |

## Latest 28-day ratios

- streams_per_listener_28: 3.998117
- streams_per_listener_previous28: 3.578055
- saves_per_listener_28: 0.204331
- saves_per_listener_previous28: 0.115076
- playlist_adds_per_listener_28: 0.340866
- playlist_adds_per_listener_previous28: 0.326494
- monthly_active_share_28: 0.744821
- super_share_of_monthly_active_28: 0.059418

## Snapshot changes

| Window | Followers at end | Net follower change | Monthly active at end | Super at end |
|---|---:|---:|---:|---:|
| latest_7 | 1,644 | 14 | 791 | 47 |
| previous_7 | 1,630 | 10 | 784 | 44 |
| latest_28 | 1,644 | 28 | 791 | 47 |
| previous_28 | 1,616 | 20 | 791 | 44 |
| latest_90 | 1,644 | 72 | 791 | 47 |
| previous_90 | 1,572 | 180 | 885 | 56 |
| latest_12_months | 1,644 | 608 | 791 | 47 |
| previous_12_months | 1,036 | 829 | 747 | 52 |
| year_to_date | 1,644 | 593 | 791 | 47 |
| previous_year_same_dates | 1,036 | 818 | 747 | 52 |
| available_history | 1,644 | None | 791 | 47 |

## Daily maxima

- listeners: 608 on 2026-03-06
- monthly listeners: 4,030 on 2026-03-19
- monthly active listeners: 1,276 on 2025-09-03
- super listeners: 110 on 2025-09-03
- streams: 896 on 2025-08-08
- playlist adds: 238 on 2025-07-27
- saves: 298 on 2025-08-08
- followers: 1,644 on 2026-10-20

## Limitations

- Daily listeners are distinct within each day, not additive across days. They have not been summed to construct period unique listeners.
- Monthly listener, monthly active listener and super listener columns are rolling-28-day snapshots; followers are cumulative snapshots. Never sum these columns.
- 28-day period unique listeners agree between the end-date monthly listeners column and the independently captured dashboard total.
- End-minus-before-start follower changes are net stock changes, not gross newly acquired followers.
- October 2026 includes only October 1-20; use streams per day or matched dates rather than compare the raw monthly total with complete months.
- Available-history totals begin January 1, 2024; they are not all-time totals.
- Saves/listener and playlist-adds/listener are activity ratios, not unique-person conversion rates.
- Changes in aggregate audience snapshots do not establish person-level retention or churn.

## Dashboard integration

Direct period unique-listener totals were integrated from `captured/period_metrics.json`. See `dashboard_and_sources_findings.md` for all44 timeline reconciliations, the YTD comparison distinction, snapshot-date reconciliation, and stream-source analysis.
