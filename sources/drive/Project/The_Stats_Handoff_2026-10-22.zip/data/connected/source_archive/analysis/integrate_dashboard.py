from pathlib import Path
import json,re
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path('/workspace/scratch/84b5e0c87afd')
CAP=ROOT/'captured'; NORM=ROOT/'normalized'; OUT=ROOT/'analysis'; CHART=ROOT/'charts'
df=pd.read_csv(NORM/'artist_daily.csv',parse_dates=['date'])
END=pd.Timestamp('2026-10-20')
period_starts={'7day':'2026-10-14','28day':'2026-09-23','90day':'2026-07-23','12months':'2025-10-21','ytd':'2026-01-01','full':'2024-01-01'}
period_names={'7day':'latest_7','28day':'latest_28','90day':'latest_90','12months':'latest_12_months','ytd':'year_to_date','full':'available_history'}
previous_names={'7day':'previous_7','28day':'previous_28','90day':'previous_90','12months':'previous_12_months'}
metric_csv={'streams':'streams','saves':'saves','playlist_adds':'playlist adds','followers':'followers'}
def number(t):
    if t.strip()=='—': return None
    f=float(t.replace(',',''))
    return int(f) if f.is_integer() else f
rows=[]; checks=[]
original=json.loads((CAP/'period_metrics.json').read_text())
for r in original:
    lines=r['table'].split('\n'); cols=lines[1].split('\t'); prev=number(cols[1]); current=number(cols[2])
    start=pd.Timestamp(period_starts[r['period']]); days=(END-start).days+1
    prior_end=start-pd.Timedelta(days=1); prior_start=prior_end-pd.Timedelta(days=days-1)
    if r['period']=='full':prior_start=None;prior_end=None
    row={'period':r['period'],'metric':r['metric'],'scope':'Worldwide','start_date':str(start.date()),'end_date':str(END.date()),'days':days,
      'current_value':current,'previous_value':prev,'current_status':'available' if current is not None else 'dashboard_dash','previous_status':'available' if prev is not None else 'dashboard_dash',
      'previous_period_start':str(prior_start.date()) if prior_start is not None else None,'previous_period_end':str(prior_end.date()) if prior_end is not None else None,
      'comparison_type':'prior contiguous equal-duration period' if r['period']!='full' else 'unavailable',
      'absolute_change':current-prev if prev is not None else None,'percent_change':(current/prev-1)*100 if prev else None,
      'dashboard_change_text':' '.join(lines[2:]).strip(),'source_file':'captured/period_metrics.json','extraction':'Visible dashboard table capture',
      'unit':'streams/listener' if r['metric']=='streams_per_listener' else 'count'}
    if r['metric']=='followers':
        row['comparison_type']='end-of-current-window stock versus stock immediately before current window' if prev is not None else 'ending stock; prior unavailable'
        row['previous_snapshot_date']=str((start-pd.Timedelta(days=1)).date()) if prev is not None else None
        row['current_snapshot_date']=str(END.date())
    if r['period']=='ytd' and r['metric']!='followers':row['comparison_type']='prior contiguous 293 days; not prior-year YTD'
    rows.append(row)
    if r['metric'] in metric_csv:
        col=metric_csv[r['metric']]
        segment=df[df.date.between(start,END)]
        exp=int(segment[col].iloc[-1]) if r['metric']=='followers' else int(segment[col].sum())
        checks.append({'period':r['period'],'metric':r['metric'],'which':'current','dashboard':current,'timeline':exp,'difference':current-exp})
        if prev is not None:
            if r['metric']=='followers':exp=int(df.loc[df.date.eq(start-pd.Timedelta(days=1)),col].iloc[0])
            else:exp=int(df.loc[df.date.between(prior_start,prior_end),col].sum())
            checks.append({'period':r['period'],'metric':r['metric'],'which':'previous','dashboard':prev,'timeline':exp,'difference':prev-exp})
pd.DataFrame(rows).to_csv(NORM/'artist_period_dashboard.csv',index=False)
pd.DataFrame(checks).to_csv(NORM/'artist_period_reconciliation.csv',index=False)
assert all(x['difference']==0 for x in checks)

a=json.loads((OUT/'artist_analysis.json').read_text());a['dashboard_periods']=rows;a['dashboard_reconciliation']=checks
for p in a['periods']:
    for r in rows:
        if r['metric']!='listeners':continue
        if p['window']==period_names[r['period']]:
            p['period_unique_listeners']=r['current_value'];p['period_unique_listeners_method']='Direct unique listener total from dashboard period table'
        if p['window']==previous_names.get(r['period']):
            p['period_unique_listeners']=r['previous_value'];p['period_unique_listeners_method']='Direct previous-period unique listener total from dashboard period table'

# Parse source table rows from their actual contents. Do not trust filenames.
specs=[('artist_sources_28day_streams.txt','aggregate','streams'),('artist_sources_detailed_28day_streams.txt','detailed','streams'),('artist_sources_detailed_28day_saves.txt','detailed','listeners')]
categories={
 'Artist profile and catalog':'active',"Listener's own playlists and library":'active','Listener’s queue':'active',
 'Editorial and personalized editorial playlists':'programmed','Personalized playlists, autoplay and mixes':'programmed','Other listeners’ playlists':'programmed',
 'Other':'unidentified','All active sources':'active','All programmed sources':'programmed'}
source_rows=[]
for fn,level,metric in specs:
    content=(CAP/fn).read_text()
    label='Streams' if metric=='streams' else 'Listeners'
    assert f'row "{label} · 28 days Previous Period This Period Change"' in content
    assert re.search(rf"tab \"{label}:.*\[selected\]",content)
    for line in content.splitlines():
        if not line.startswith('      - row "') or 'Previous Period' in line:continue
        text=line[len('      - row "'):-2]
        m=re.match(r'^(.*?) ([\d,]+|—) ([\d,]+|—) ([\d.]+%|—)$',text)
        if not m:raise ValueError((fn,line))
        name,pr,cu,change=m.groups()
        if name.startswith('Listener’s queue '):name='Listener’s queue'
        if name.startswith('Other Data '):name='Other'
        prev,current=number(pr),number(cu)
        row={'entity':'artist','artist_id':'6X14XfGTmB560PF063wXDk','level':level,'metric':metric,'source_category':name,'source_group':categories[name],
           'start_date':'2026-09-23','end_date':'2026-10-20','previous_start_date':'2026-08-26','previous_end_date':'2026-09-22',
           'current_value':current,'previous_value':prev,'current_status':'dashboard_dash' if current is None else 'available','previous_status':'dashboard_dash' if prev is None else 'available',
           'current_raw':cu,'previous_raw':pr,'absolute_change':current-prev if current is not None and prev is not None else None,'percent_change':(current/prev-1)*100 if current is not None and prev else None,
           'current_share_of_total_streams':current/4246 if metric=='streams' and current is not None else None,
           'previous_share_of_total_streams':prev/4011 if metric=='streams' and prev is not None else None,
           'source_file':'captured/'+fn,'metric_filename_mismatch':not fn.endswith(metric+'.txt'),'notes':'Listener counts may overlap across sources; do not add them' if metric=='listeners' else 'Editorial dashes preserved as missing, not silently converted to zero'}
        source_rows.append(row)
sdf=pd.DataFrame(source_rows);sdf.to_csv(NORM/'artist_sources_28day.csv',index=False)
for level in ['aggregate','detailed']:
    for which,total in [('current_value',4246),('previous_value',4011)]:
        assert sdf.loc[(sdf.level==level)&(sdf.metric=='streams'),which].sum()==total
source_ratios=[]
for name in categories:
    streams=sdf[(sdf.level=='detailed')&(sdf.metric=='streams')&(sdf.source_category==name)]
    listeners=sdf[(sdf.level=='detailed')&(sdf.metric=='listeners')&(sdf.source_category==name)]
    if len(streams) and len(listeners):
        sr={'source_category':name,'period_start':'2026-09-23','period_end':'2026-10-20','streams':None,'listeners':None,'streams_per_source_listener':None,'previous_streams_per_source_listener':None,'notes':'Source-specific listener denominator; source audiences overlap'}
        for prefix in ['current','previous']:
            s=streams.iloc[0][prefix+'_value'];l=listeners.iloc[0][prefix+'_value']
            if pd.notna(s) and pd.notna(l) and l:
                if prefix=='current':sr.update(streams=int(s),listeners=int(l),streams_per_source_listener=float(s/l))
                else:sr['previous_streams_per_source_listener']=float(s/l)
        source_ratios.append(sr)
pd.DataFrame(source_ratios).to_csv(NORM/'artist_source_ratios_28day.csv',index=False)

native_anchor={}
for c in ['monthly active listeners','super listeners','followers']:
    first=int(df.loc[df.date.eq('2026-09-23'),c].iloc[0]);before=int(df.loc[df.date.eq('2026-09-22'),c].iloc[0]);last=int(df.loc[df.date.eq(END),c].iloc[0])
    native_anchor[c]={'first_day':first,'before_first_day':before,'last_day':last,'first_to_last_percent':(last/first-1)*100,'before_first_to_last_percent':(last/before-1)*100}
a['source_breakdown']=source_rows;a['source_ratios']=source_ratios;a['snapshot_comparison_anchors']=native_anchor
(OUT/'artist_analysis.json').write_text(json.dumps(a,indent=2,allow_nan=False))
integrated=[]
for p in a['periods']:
    p=p.copy()
    listeners=p['period_unique_listeners']
    p['streams_per_listener']=p['streams']/listeners if listeners else None
    p['saves_per_listener']=p['saves']/listeners if listeners else None
    p['playlist_adds_per_listener']=p['playlist_adds']/listeners if listeners else None
    integrated.append(p)
pd.DataFrame(integrated).to_csv(NORM/'artist_periods_integrated.csv',index=False)
md=(OUT/'artist_analysis.md').read_text()
for p in a['periods']:
    if p['period_unique_listeners'] is not None:
        pattern=rf"(^\| {p['window']} \|.*?\| )Dashboard required( \|$)"
        md=re.sub(pattern,rf"\g<1>{p['period_unique_listeners']:,}\g<2>",md,flags=re.M)
md+='\n## Dashboard integration\n\nDirect period unique-listener totals were integrated from `captured/period_metrics.json`. See `dashboard_and_sources_findings.md` for all44 timeline reconciliations, the YTD comparison distinction, snapshot-date reconciliation, and stream-source analysis.\n'
(OUT/'artist_analysis.md').write_text(md)

lines=['# Dashboard and stream-source reconciliation','',
 '## Period totals','',f"All {len(checks)} dashboard current/prior additive and follower values match the native timeline exactly.",'',
 'The YTD dashboard compares January 1–October 20, 2026 with the immediately preceding 293 days: March 14–December 31, 2025. Its +111.8% streams comparison is not year-over-year YTD growth. Matching January 1–October 20, 2025 gives +154.9%, calculated independently from the timeline.','',
 '## Snapshot comparison anchors','',
 'The native monthly-active and super-listener cards compare the first selected date with the last selected date. The timeline first-day values reproduce both displayed percentages: monthly active September 23 = 789; October 20 = 791 (+0.3%). Super September 23 = 42; October 20 = 47 (+11.9%).',
 'Using the day immediately before the selected window (September 22) gives monthly active 791 to 791 (flat) and super 44 to 47 (+6.8%). Both describe different endpoint comparisons; retain the dates explicitly. Followers instead match September 22 = 1,616 to October 20 = 1,644 (+28; +1.7%).','',
 '## Sources','',
 'The previous 145-stream residual is fully reconciled: the UI explicitly labels 145 as Other, defined as devices where the source cannot be identified. Active 3,746 + programmed 355 + Other 145 = total 4,246. Prior 3,421 + 443 + 147 = 4,011.','',
 '| Source | Current streams | Prior streams | Share of current | Change |','|---|---:|---:|---:|---:|']
for r in source_rows:
    if r['metric']!='streams' or r['level']!='detailed':continue
    vals=[str(r['current_value']),str(r['previous_value']),f"{r['current_share_of_total_streams']:.1%}" if r['current_share_of_total_streams'] is not None else '—',f"{r['percent_change']:+.1f}%" if r['percent_change'] is not None else '—']
    lines.append('| '+r['source_category']+' | '+' | '.join(vals)+' |')
lines +=['','The editorial category displays dashes. These are preserved as `dashboard_dash` with no numeric value even though the other observed stream categories reconcile to the artist total.','',
 'Active sources account for 88.2% of streams, versus 85.3% in the preceding28. Own playlists/libraries contribute 74.7%, versus 73.9%. These are stream-source shares, not listener retention rates.','',
 'Personalized playlists/autoplay/mixes fell by93 streams; artist profile/catalog rose by116 and own playlists/libraries rose by205. This supports an interpretation of stronger intentional listening with weaker programmed discovery, without proving any campaign or content caused the change.','',
 '## Capture naming issues','',
 '`artist_sources_detailed_28day_listeners.txt` actually contains the Streams table and duplicates the streams snapshot. It was excluded from normalization. `artist_sources_detailed_28day_saves.txt` actually contains the Listeners table; the actual selected metric and table header establish this, so it was normalized as listeners and flagged with metric_filename_mismatch=true. No source-level saves were collected in these snapshots.','',
 'Source listener counts overlap and are not additive. Derived source-specific streams/listener ratios use matching categories and28-day periods; they describe listening frequency within each source, not unique-person conversion or causal quality.']
(OUT/'dashboard_and_sources_findings.md').write_text('\n'.join(lines)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':16,'axes.labelsize':11,'axes.edgecolor':'#CBD0D5','axes.labelcolor':'#23272B','text.color':'#23272B','xtick.color':'#4D555D','ytick.color':'#4D555D','figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white'})
plot=sdf[(sdf.level=='detailed')&(sdf.metric=='streams')&sdf.current_value.notna()].sort_values('current_value')
short={"Listener's own playlists and library":'Own playlists and library','Artist profile and catalog':'Artist profile and catalog','Personalized playlists, autoplay and mixes':'Personalized playlists, autoplay, mixes','Listener’s queue':'Listener queue','Other listeners’ playlists':'Other listeners’ playlists','Other':'Other / unidentified source'}
fig,ax=plt.subplots(figsize=(11.5,5))
ax.barh([short[n] for n in plot.source_category],plot.current_value,color='#245987',height=.65)
for y,(_,r) in enumerate(plot.iterrows()):ax.text(r.current_value+35,y,f"{r.current_value:,.0f}  ({r.current_share_of_total_streams:.1%})",va='center',fontsize=10)
ax.set_xlim(0,3900);ax.set_title('Sources of streams, September 23–October 20, 2026',loc='left',pad=18);ax.set_xlabel('Streams')
ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',color='#E7E9EC',lw=.6);ax.set_axisbelow(True)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v,p:f'{v:,.0f}'))
fig.text(.04,.015,'Shares use all 4,246 streams. Editorial category shows dashes and is omitted. Source: captured Spotify for Artists source table.',fontsize=8.7,color='#606971')
fig.tight_layout(rect=[0,.045,1,1]);fig.savefig(CHART/'artist_stream_sources_28day.png',dpi=200);plt.close(fig)
print(json.dumps({'dashboard_rows':len(rows),'reconciliation_checks':len(checks),'source_rows':len(source_rows),'snapshot_anchors':native_anchor,'sources_current_sums':sdf[sdf.metric=='streams'].groupby('level').current_value.sum().to_dict()},indent=2))
