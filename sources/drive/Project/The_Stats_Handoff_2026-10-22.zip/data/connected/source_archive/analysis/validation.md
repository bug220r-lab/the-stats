# Independent validation record

Review date: 22 October 2026. Artist endpoint: 20 October 2026 UTC. The review independently parsed native CSV rows, captured DOM card/table text and rendered chart labels. Existing analysis summaries and reconciliation flags were not used as proof. No account data or analysis dataset was changed. Collection was frozen after the checks below; final song breakdown coverage is recorded in section 7.

## 1. Artist timeline and period cards

**PASS — exact native fidelity.** All 1,024 rows and nine columns in `raw/artist_timeline_2024-01-01_2026-10-20.csv` equal `normalized/artist_daily.csv` after CSV decoding. Dates span 1 January 2024–20 October 2026 with 1,024 distinct dates. Quality recheck found zero missing dates, duplicates, blank metric cells and negative values. Independently summing streams, saves and playlist adds for all 11 integrated periods produced **33/33 exact matches**. Daily listeners and rolling/cumulative stocks were not summed.

| Window | Inclusive dates | Streams | Saves | Playlist adds |
| --- | --- | ---: | ---: | ---: |
| Latest 7 | 14–20 Oct 2026 | 1,186 | 88 | 108 |
| Previous 7 | 7–13 Oct 2026 | 1,106 | 30 | 90 |
| Latest 28 | 23 Sep–20 Oct 2026 | 4,246 | 217 | 362 |
| Previous 28 | 26 Aug–22 Sep 2026 | 4,011 | 129 | 366 |
| Latest 90 | 23 Jul–20 Oct 2026 | 13,775 | 562 | 1,267 |
| Previous 90 | 24 Apr–22 Jul 2026 | 19,832 | 1,108 | 1,752 |
| Latest 12 months | 21 Oct 2025–20 Oct 2026 | 63,957 | 4,290 | 6,643 |
| Previous 12 months | 21 Oct 2024–20 Oct 2025 | 24,087 | 2,751 | 2,838 |
| YTD | 1 Jan–20 Oct 2026 | 58,175 | 3,742 | 5,854 |
| Prior-year same dates | 1 Jan–20 Oct 2025 | 22,825 | 2,694 | 2,760 |
| Available history | 1 Jan 2024–20 Oct 2026 | 101,342 | 7,947 | 10,280 |

**PASS — direct-card extraction.** All **72 current/prior value cells** in `normalized/artist_period_dashboard.csv` match `captured/period_metrics.json`, including missing dashes. All **44 additive/current-prior follower comparisons** were recomputed from the native timeline and match the captured values with zero difference. Direct unique listeners are preserved rather than reconstructed. Latest-28-day net follower change is 1,644−1,616=+28; it is not gross acquisition.

**PASS — comparison arithmetic.** Latest stream changes reproduce +7.2%, +5.9%, −30.5%, +165.5% and matched-date YTD +154.9%. The UI YTD comparator is the preceding 293 days (+111.8%), not prior-year matched YTD. Prior-year matched-YTD unique listeners remain unavailable. March 2026 is the largest full month, 10,538 streams; October 1–20 averages 156.4/day versus September 143.5/day, +9.0%.

**Scope limit — stream sources.** Detailed source counts reconcile to 4,246 current and 4,011 prior. Active 3,746 + programmed 355 + explicitly labeled Other 145 =4,246. Editorial dashes remain missing, not measured zero. Source listener counts overlap. `artist_sources_detailed_28day_saves.txt` actually contains the Listeners table; `artist_sources_detailed_28day_listeners.txt` duplicates Streams. Actual table metric governs normalization; no source-level saves were inferred. Evidence: those captured files and `normalized/artist_sources_28day.csv`.

## 2. Fourteen recordings and deduplicated periods

**PASS — raw catalog extraction.** Independently parsed **112 raw cells**: 14 recordings ×2 periods × streams/listeners/Canvas/saves from `captured/catalog_songs_7day.txt` and `catalog_songs_28day.txt`. All match `normalized/song_catalog_periods.csv`, including blank values for source dashes. For every recording, latest 7- and 28-day daily stream sums match its card, **28/28 exact checks**.

**PASS — recent catalog/artist reconciliation.** Summing unique recording IDs from `song_daily_wide.csv` independently gives:

| Period | 14-song stream sum | Native artist stream sum | Difference |
| --- | ---: | ---: | ---: |
| Latest 7 days | 1,186 | 1,186 | 0 |
| Latest 28 days | 4,246 | 4,246 | 0 |
| Latest 90 days | 13,775 | 13,775 | 0 |
| Latest 12 months | 63,957 | 63,957 | 0 |
| YTD | 58,175 | 58,175 | 0 |

**PASS — membership deduplication.** `song_catalog.csv` has 14 unique recording IDs. `release_song_mapping.csv` has 17 memberships across 7 releases. Funny Guy, Crawl and GOOMH! each appear twice with the same ID; all other IDs appear once. Release-table stream sum 6,343 minus repeated memberships 2,097 = deduplicated 4,246. The two 2023 Lab Tapes recordings have different IDs from their same-titled 2024 album versions. Top-three share independently computes 59.7504%, displayed 59.8%.

**PASS — raw daily evidence fidelity.** Independently loaded all nonempty source paths in `song_daily_coverage.csv`, parsed raw CSV or chart-label observations, and compared by recording/date/metric with `song_daily_wide.csv`: **66,631 observations, zero mismatches**. Four song native exports independently reproduce all 4,096 exported daily stream values. Other daily evidence is rendered chart labels, not native CSV.

**Material coverage limit.** Twelve recordings have full 1,024-day stream history. GOOMH! song streams have 365 observed days. Son! song streams have 730 observations from first 12 months and latest 12 months views, with a gap; its other four metrics have full history. These missing stream days are not zero-filled. Recent five-period catalog reconciliation above is complete, but full-history song-to-artist reconciliation cannot be asserted from the incomplete song series. A full-history card is not a substitute for a missing daily curve.

**Detected and corrected normalization defect.** The initially named Son! `full` snapshot actually displayed 23 September–20 October and 72 streams/26 listeners; it was incorrectly included as full history, creating false discrepancies of+297 saves(307−10) and+335 adds(341−6). Review notified the catalog agent. The raw capture is now retained with `capture_valid=False` and an invalid reason in `song_period_dashboard.csv`. Reinspection of `song_period_canonical.csv` confirms valid full scope 1 January 2024–20 October 2026, **2,142 streams,507 listeners,4.225 streams/listener,341 adds,307 saves**, sourced from valid full metric captures. Selected metric tables take precedence where stale hero cards conflict. The daily stream gap remains disclosed.

**Unresolved counters and anchors.** Funny Guy header 29,786 versus observed daily 30,549 gives header−history−763; Devil header 11,861 versus 11,872 gives−11. The two Lab Tapes headers exceed 2024-onward history (¡La Cocaína!2,559 versus 1,362; Method Acting 2,691 versus 1,423); earlier 2023 history is a possible scope distinction, not a demonstrated explanation. Funny Guy and Crawl first 28/first 12 month presets start 31 May 2024 rather than original 12 April/10 May. Original-release launch metrics must use actual dates.

**Explicit zero versus dash.** Method Acting (Lab Tapes) raw catalog saves remain a dash. Its exact-period song detail explicitly reports zero saves, so the analytical override is supported and labeled in `saves_raw_catalog`/`saves_basis`. Canvas dashes remain missing.

## 3. Seven releases: 28 selected-period comparisons

Independently parsed all seven `captured/agent_release_*_bundle.json` files. All seven full histories have 1,024 daily chart labels; **7,168 raw observations** match `release_daily_streams.csv`. For each release,7-day,28-day,12-month and full-period card streams were compared with date-filtered full history: **28/28 exact matches, zero differences**. **25/28** also expose selected-window chart labels; all 25 sums match their cards. Crawl’s three short-window charts have no labels, so their bounds are explicitly derived from its full-chart endpoint and selected length.

| Release | 7-day | 28-day | 12-month | Jan 2024 onward | All-time header | History−header |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| The Cut | 154 | 539 | 5,294 | 5,294 | 5,294 | 0 |
| [REDACTED] album | 857 | 3,142 | 45,748 | 81,391 | 81,263 | +128 |
| The Devil Wears Docs | 160 | 510 | 11,872 | 11,872 | 11,861 | +11 |
| Lab Tapes | 15 | 55 | 1,043 | 2,785 | 5,250 | −2,465 |
| Crawl | 111 | 399 | 6,342 | 11,579 | 11,579 | 0 |
| Funny Guy | 386 | 1,488 | 21,168 | 30,549 | 29,786 | +763 |
| GOOMH! | 45 | 210 | 3,748 | 7,919 | 8,554 | −635 |

Album+128, Funny Guy+763 and Devil+11 remain unresolved all-time/header conflicts. The 2023 releases have older potential history than the 2024 start. No native release CSV control was exposed; these histories are explicitly rendered chart evidence. Overlapping releases must not be summed to artist totals. Sources: raw bundles; normalized release metadata, periods and daily-stream CSVs.

## 4. Eight release-engagement combinations

**PASS — all eight card/chart combinations.** Independently parsed raw cards and cumulative chart labels and compared with normalized snapshots/daily rows: **224 observations, zero mismatches**; each curve is monotonic, has 28 observations and matches its card endpoint. All cover 24 April–21 May 2026. Cumulative reached people are not summed over days.

| Pre-release tier | Filter | Baseline | Day 28 reached | Displayed rate |
| --- | --- | ---: | ---: | ---: |
| Monthly active | Active | 1,076 | 252 | 23.4% |
| Monthly active | All | 1,076 | 269 | 25.0% |
| Super | Active | 85 | 51 | 60.0% |
| Super | All | 85 | 53 | 62.4% |
| Moderate | Active | 366 | 110 | 30.1% |
| Moderate | All | 366 | 120 | 32.8% |
| Light | Active | 625 | 145 | 23.2% |
| Light | All | 625 | 152 | 24.3% |

**UNRESOLVED — tier versus aggregate.** Independent recomputation finds active tier sums differ from aggregate on 27/28 dates: day 28,51+110+145=306 versus 252, +54. All-source tiers also differ on 27/28 dates:53+120+152=325 versus 269, +56. Baselines reconcile 85+366+625=1,076. Do not combine numerators or invent overlap to explain the conflict.

**UNRESOLVED — cross-view baseline.** Native 23 April 2026 active 957 versus release-panel 1,076 gives+119; native super 77 versus 85 gives+8. Rates retain panel denominators. All−active aggregate is 17 people or 1.5799 percentage points of 1,076; this is descriptive, not causal promotion lift. The current picker has The Cut only and says sixmonths, unlike the documentation’s threemonths. Sources: `release_engagement_*.txt`, matching chart JSONs, native artist timeline and normalized engagement CSVs.

## 5. Audience, geography, artist playlists and feature audit

**PASS — rolling audience stocks.** Parsed 224 stock values directly from `audience_segments_total_history_chart.json` and `audience_segments_active_chart.json`: zero differences from `audience_segment_daily.csv`. Total-audience and active-tier partitions each reconcile on all 28 dates. Latest 791+4,672+6,888=12,351 and 47+230+514=791. Monthly active 791/1,062=74.4821%; the displayed 91% stream share is rounded and distinct from the active-source stream share 88.2%. Activation flow cards 309 reactivated,153 new active and 350 new are not an additive funnel or a retention calculation.

**PASS / source discrepancy retained — demographics.** Parsed all 28 raw age/gender cells; zero differences from normalized cells. Age-cell total 1,063, male subtotal 654 and 18–34 subtotal 739 independently reproduce. Gender counts sum 1,064, including 655 male; artist reach 1,062. Five 65+listeners coexist with displayed 0%. The disagreement is retained without rescaling. Sources: `audience_age_chart.json`, `audience_demographics.txt`, normalized demographics CSVs.

**PASS — artist geographic extraction.** All 23 country and 50 city rows independently match captured names/listener counts and available country active counts. Country listener sum 1,022; city sum 436; reported active-country sum 775. Peru has 4 listeners and missing active count/percentage. U.S.777/1,062=73.1638%; active 637/777=81.9820%, displayed 82%. Ranked tables do not establish an exhaustive, disjoint geographic partition. Sources: `geography_tables.json` and normalized audience location CSVs.

**PASS — artist playlist native-versus-DOM checks.** All 46 native rows independently match DOM title/listener/stream values and normalized rows, zero mismatches. Raw sources are `agent_playlists_*_native.csv` and matching `_tables.json`.

| Selected period | Native/DOM rows | Algorithmic groups | Listener playlists | Algorithmic streams | Listener-playlist streams |
| --- | ---: | ---: | ---: | ---: | ---: |
| 7 days | 6 | 5 | 1 | 81 | 3 |
| 28 days | 9 | 6 | 3 | 263 | 32 |
| 12 months | 31 | 10 | 21 | 9,418 | 913 |

**Playlist limits.** Exact period bounds were not exposed and remain blank. The expanded 12-month view displays 21 listener rows and “Showing 21 of 1.8 k”; the native CSV has the same 21 listener rows plus 10 algorithmic groups. No further pagination was exposed. The 1.8 k footer does not establish 1,800 retrievable rows. All captured rows meet the three-listener threshold. Editorial “No stats” is not zero. Named 28-day algorithmic streams 263 versus artist-source 256 differ+7; listener playlists 32 versus artist-source 99 differ−67. Different surfaces and unknown exact dates prevent forced reconciliation. Slipknot Radio is a listener playlist, distinct from the algorithmic Radio group. Listener sums are not unique reach.

**PASS — Canvas inventory.** Independently counted headings in all seven raw Canvas-view captures:15 named card appearances,12 distinct labels, exactly matching the normalized multiset. Counts are album 10; five single views 1 each; Lab Tapes 0. Repeated labels are not unique asset IDs. Published asset state is unverified because detail inspection reached Confirm your team and was canceled.

**PASS — explicit feature states, with limits.** Raw `agent_features_campaigns.txt` contains “No campaigns yet”; sub-campaigns independently says “No sub-campaigns yet”. Spend, reach, conversion and ROI are unavailable, not measured zero. Raw Artist Message capture contains “Submit before Nov 6 th” and identifies 2026 Wrapped, one video up to 30 seconds. This is an opportunity, not proof of submission or performance. Creation controls do not establish campaign eligibility or expected returns. Canvas inventory and song Canvas-view metrics are separate surfaces. No campaign, upload, team confirmation or account change occurred.

## 6. Report claim and visual checks

Independent report arithmetic checks reproduce artist changes, current stream-source shares, audience stocks, demographic/geographic summaries, recent song totals, catalog concentration and cohort formulas. Recommendations are proposed tests and artist self-benchmarks. No matched peer average, revenue, ROI, manipulation allegation, person-level retention, unique-person conversion probability or causal campaign lift is established.

Visual QA inspected stable report pages 2–10 and 16–20: no clipping, overlapping text, unreadable charts, broken tables or placeholders. Collection-sensitive pages require final rerender and visual inspection. This record does not itself assert completion of final PDF/DOCX/workbook rendering.

## 7. Freeze-stage song breakdown checks

**PASS — all requested identities accounted for, with material gaps.** Catalog IDs=14. Song playlist coverage contains 28 recording/period outcomes:6 loaded tables for 3 recordings and 22 unavailable outcomes for 11 recordings. Song location coverage contains 14 outcomes:7 loaded and 7 site errors. Sources were captured only for The Cut; the other 13 were **not collected**, not proved unavailable and not zero. These three kinds of missing coverage must not be conflated.

**PASS — song playlist extraction.** Independently matched all 52 normalized rows against captured table rank/title/stream/made-by/date-added cells, zero differences. All 11 failed raw song bundles explicitly contain a Spotify “problem on our end” error; normalized metrics are blank. The six successful selected-period row counts and stream sums independently reproduce:

| Recording | Selected period | Captured rows | Streams in captured rows |
| --- | --- | ---: | ---: |
| The Cut | Last 28 days | 4 | 38 |
| The Cut | Last 12 months | 10 | 958 |
| Funny Guy | Last 28 days | 5 | 188 |
| Funny Guy | Last 12 months | 20 | 2,441 |
| The Devil Wears Docs | Last 28 days | 2 | 11 |
| The Devil Wears Docs | Last 12 months | 11 | 4,589 |

Exact playlist bounds remain unexposed. These are thresholded Top rows and contain streams, not song unique listeners. Source:14 `agent_song_playlists_*_bundle.json` files, `song_playlists.csv` and `song_playlist_coverage.csv`.

**PASS — song location extraction.** Independently matched all 488 normalized country/city rows to raw table names and stream counts, zero differences. All seven unavailable raw bundles contain a site error; two identify an unsuccessful reload. Seven available songs each show 50 cities. There are 138 country rows and 350 city rows. The metric is **streams**, distinct from artist-location **listeners**.

| Recording | Country rows | Country stream sum | Song 28-day streams | Country difference | Top 50 city stream sum |
| --- | ---: | ---: | ---: | ---: | ---: |
| Funny Guy | 47 | 1,484 | 1,488 | −4 | 580 |
| The Cut | 19 | 539 | 539 | 0 | 306 |
| The Devil Wears Docs | 24 | 510 | 510 | 0 | 295 |
| Crawl | 17 | 399 | 399 | 0 | 249 |
| GOOMH! | 12 | 210 | 210 | 0 | 145 |
| THIS MACHINE | 9 | 190 | 190 | 0 | 156 |
| Waste Away | 10 | 190 | 190 | 0 | 161 |

Funny Guy’s 4-stream residual remains unexplained and is not assigned to an invented country. Exact reconciliation for the other six does not prove the tables’ general exhaustiveness. Source:14 `agent_song_location_*_bundle.json` files, `song_locations.csv`, `song_location_coverage.csv`.

**PASS — The Cut source extraction, limited collection.** Independently matched all 20 current/prior value cells in its 10 aggregate/detail rows to raw source-table cells, including editorial dashes; zero mismatches. Current active 483 + programmed 42 + Other 14 =539. Prior 457+59+29=545. Detailed current counts 85 profile+374 own-library+24 queue+11 personalized+31 other-listener-playlists+14 Other=539; editorial remains missing. Current own-library 374 versus prior 380 is a decline, despite active aggregate 483 versus 457 rising. Evidence: `song_3HqynH6ObSuDPZM0RMnFxN_sources28.txt`, `_sources_detailed28.txt`, `song_source_comparisons.csv`. Other 13 song sources were not collected.

**PASS — final additive song-period recomputation.** Independently recomputed all 434 rows of `song_periods_from_daily.csv` by recording/date/metric from normalized daily evidence already raw-validated above: zero differences. Final canonical Son! full scope was rechecked after correction; full metrics are 2,142 streams/507 listeners/341 adds/307 saves, with a remaining 730-day stream-chart coverage limit. Last frozen normalization-count check is recorded below.


### Final frozen normalization recheck

The catalog agent signaled its final frozen rerun; the following checks were then repeated independently:

- **66,631** normalized song daily observations; **64 of 70** recording/metric series have full 1,024-day coverage. Twelve recordings have all five full series; Son! has four full series plus 730 stream days; GOOMH! has 365 stream days and no full five-metric history.
- **103** canonical recording/period rows. Exactly **one** invalid raw dashboard capture remains, the stale Son! `full.txt` snapshot. Its source filename is absent from canonical rows. The valid Son! full card is present with 2,142 streams/507 listeners/341 adds/307 saves.
- Independently re-summed raw labels for all **131** chart/card comparisons: **zero differences** from reported hero totals.
- Joined the independently recomputed daily-period values to all **288** valid UI/daily comparison rows: **zero differences**, with no missing period keys. All 434 additive daily-period values had already been independently recomputed.
- Summed the 14 unique recording IDs separately for every day 21 October 2025–20 October 2026: **365/365 daily artist comparisons match exactly**. This claim is restricted to the fully covered latest year.
- Native artist quality recheck: **zero** missing dates, duplicate dates, blank metric cells or negative values.
- Final song source-coverage output explicitly distinguishes The Cut’s observed data from the other 13 uncollected sources. Geographic and playlist page errors remain unavailable observations, not zeros.

**Validation disposition:** arithmetic and source-preservation checks above pass after correction of the detected Son! scope error. The listed dashboard conflicts and collection gaps remain unresolved and are material limitations, not validation failures to conceal. Final deliverable rendering and packaging are handled separately by the report/workbook authors.
