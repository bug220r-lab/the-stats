"""Normalize observed release-engagement DOM/chart captures without reconciling conflicts."""
import csv
import json
import re
from datetime import datetime, timedelta
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
CAP, OUT, CHARTS = ROOT/"captured", ROOT/"normalized", ROOT/"charts"
OUT.mkdir(exist_ok=True); CHARTS.mkdir(exist_ok=True)

def csv_write(name, rows):
    with (OUT/name).open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader();writer.writerows(rows)

snapshots=[]; daily=[]; series={}
for p in sorted(CAP.glob("release_engagement_*.txt")):
    s=p.read_text(); main=s[s.index("- main:"):]
    title=re.search(r'  - heading "(.+)" \[level=3\]',main).group(1)
    release_text,day,status,geo=re.search(r'heading "Released (.+?) • Day (\d+) • (.+?) • (.+?)"',main).groups()
    release_date=datetime.strptime(release_text,"%b %d, %Y").date()
    cohort_date=release_date-timedelta(days=1)
    denominator,segment,engaged,pct,intentional,window=re.search(r'heading "Of your ([\d,]+) (.+?) listeners, ([\d,]+) \(([\d.]+)%\) (intentionally )?streamed this release in the first (\d+) days.',main).groups()
    denominator=int(denominator.replace(",",""));engaged=int(engaged.replace(",",""));pct=float(pct)
    segment={"monthly active":"Monthly active","light":"Light","moderate":"Moderate","super":"Super"}[segment]
    source_filter="Active sources" if intentional else "All sources"
    assert f'button "{source_filter}"' in main
    chart_path=p.with_name(p.stem+"_chart.json")
    labels=json.loads(chart_path.read_text())
    base={"release":title,"release_date":release_date.isoformat(),"cohort_date":cohort_date.isoformat(),"geography":geo,"audience_segment":segment,"source_filter":source_filter,"cohort_listeners":denominator}
    rows=[]
    last=0
    for label in labels:
        dm,value=re.fullmatch(r'Date: (.+), Value: (\d+)',label).groups()
        d=datetime.strptime(f"{dm} {release_date.year}","%b %d %Y").date()
        if d<release_date:d=d.replace(year=d.year+1)
        value=int(value);age=(d-release_date).days+1
        rows.append({**base,"date":d.isoformat(),"release_day":age,"cumulative_engaged_listeners":value,"increment_from_prior_observation":value-last,"cumulative_engagement_pct_calculated":value/denominator*100,"status":"observed_cumulative_chart_label","source":chart_path.name,"definition_source":p.name})
        last=value
    assert len(rows)==int(window)==28
    assert [r["release_day"] for r in rows]==list(range(1,29))
    assert last==engaged
    assert all(r["increment_from_prior_observation"]>=0 for r in rows)
    assert all(0<=r["cumulative_engaged_listeners"]<=denominator for r in rows)
    snapshots.append({**base,"last_release_day":int(day),"period_end":rows[-1]["date"],"engaged_listeners":engaged,"engagement_pct_displayed":pct,"engagement_pct_calculated":100*engaged/denominator,"percent_status":"rounded_displayed","updating_status":status,"source":p.name,"chart_source":chart_path.name})
    daily+=rows;series[(segment,source_filter)]=rows

csv_write("release_engagement_snapshot.csv",snapshots)
csv_write("release_engagement_daily.csv",daily)
by_key={(r["audience_segment"],r["source_filter"]):r for r in snapshots}
active_segments=["Super","Moderate","Light"]
reconciliation=[]
for i,total in enumerate(series[("Monthly active","Active sources")]):
    part=[series[(seg,"Active sources")][i] for seg in active_segments]
    n=sum(r["cumulative_engaged_listeners"] for r in part)
    denom=sum(r["cohort_listeners"] for r in part)
    reconciliation.append({"release":total["release"],"date":total["date"],"release_day":i+1,"source_filter":"Active sources","monthly_active_cohort":total["cohort_listeners"],"sum_subsegment_cohorts":denom,"monthly_active_cumulative_engaged":total["cumulative_engaged_listeners"],"sum_subsegment_cumulative_engaged":n,"subsegment_sum_minus_total":n-total["cumulative_engaged_listeners"],"status":"reconciles" if n==total["cumulative_engaged_listeners"] else "unresolved_source_inconsistency","source":"release_engagement_release_options_chart.json;release_engagement_super_active_chart.json;release_engagement_moderate_active_chart.json;release_engagement_light_active_chart.json"})
csv_write("release_engagement_reconciliation.csv",reconciliation)

comparisons=[]
for segment in ["Monthly active","Moderate","Light","Super"]:
    a=by_key.get((segment,"Active sources"));b=by_key.get((segment,"All sources"))
    if a and b:
        assert a["cohort_listeners"]==b["cohort_listeners"]
        assert all(x["cumulative_engaged_listeners"]<=y["cumulative_engaged_listeners"] for x,y in zip(series[(segment,"Active sources")],series[(segment,"All sources")]))
        comparisons.append({"release":a["release"],"audience_segment":segment,"cohort_listeners":a["cohort_listeners"],"active_sources_engaged":a["engaged_listeners"],"all_sources_engaged":b["engaged_listeners"],"all_minus_active_listeners":b["engaged_listeners"]-a["engaged_listeners"],"all_minus_active_pct_points_calculated":100*(b["engaged_listeners"]-a["engaged_listeners"])/a["cohort_listeners"],"interpretation":"Descriptive set difference; not causal incremental effect of programmed sources","source":a["source"]+";"+b["source"]})
csv_write("release_engagement_source_comparison.csv",comparisons)

monthly_a=by_key[("Monthly active","Active sources")];monthly_all=by_key[("Monthly active","All sources")]
summary={"release":monthly_a["release"],"release_date":monthly_a["release_date"],"cohort_date":monthly_a["cohort_date"],"period_end":monthly_a["period_end"],"cohort_listeners":monthly_a["cohort_listeners"],"status":"Day28;NoLongerUpdating;Worldwide","observed_filter_combinations":len(snapshots),"daily_rows":len(daily),"day28_snapshots":snapshots,"source_comparisons":comparisons,"reconciliation":{"cohort_sum":sum(by_key[(s,"Active sources")]["cohort_listeners"] for s in active_segments),"cohort_total":1076,"active_engaged_subsegments_sum":sum(by_key[(s,"Active sources")]["engaged_listeners"] for s in active_segments),"active_engaged_total":252,"subsegment_sum_minus_total":54,"active_daily_dates_reconciled":sum(r["status"]=="reconciles" for r in reconciliation),"active_daily_dates_inconsistent":sum(r["status"]!="reconciles" for r in reconciliation),"all_sources_moderate_plus_light":by_key[("Moderate","All sources")]["engaged_listeners"]+by_key[("Light","All sources")]["engaged_listeners"],"all_sources_total":269,"status":"Unresolved source inconsistency; keep aggregate and subsegment results separate; do not sum"},"coverage":{"release_menu_label":"Releases from the last 6 months","release_options_observed":[monthly_a["release"]],"unavailable_filters":[],"official_documentation_window":"latest3months in definitions_notes.md; observed menu says last6months","evidence_scope":"Only captured release option and filter combinations; not an exhaustive historical release panel"},"quality_checks":{"all_curves_have_28_consecutive_days":True,"all_curves_monotonic_non_decreasing":True,"all_curve_endpoints_match_displayed_cards":True,"all_matched_all_source_curves_ge_active_source_curves":True},"source_files":sorted({x["source"] for x in snapshots}|{x["chart_source"] for x in snapshots})}
summary["reconciliation"]["all_sources_subsegments_sum"] = sum(by_key[(segment,"All sources")]["engaged_listeners"] for segment in active_segments)
summary["reconciliation"]["all_sources_subsegment_sum_minus_total"] = summary["reconciliation"]["all_sources_subsegments_sum"] - monthly_all["engaged_listeners"]
(ROOT/"analysis/release_engagement_analysis.json").write_text(json.dumps(summary,indent=2)+"\n")

plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"text.color":"#263344","axes.labelcolor":"#263344","xtick.color":"#526273","ytick.color":"#526273","axes.spines.top":False,"axes.spines.right":False,"axes.spines.left":False,"axes.edgecolor":"#BBC4CC","figure.facecolor":"white","savefig.facecolor":"white"})
fig,axs=plt.subplots(1,2,figsize=(13,6),gridspec_kw={"width_ratios":[1,1]})
fig.suptitle("The Cut (Starts Tomorrow) · first 28 days",x=.05,ha="left",fontsize=19,fontweight="bold")
fig.text(.05,.88,"Released April 24, 2026 · April 23 baseline cohort · Worldwide · completed May 21, 2026",fontsize=11,color="#526273")
colors={"Monthly active":"#356C9B","Super":"#356C9B","Moderate":"#B6812E","Light":"#788844"}
for filt,style,color in [("All sources","-","#356C9B"),("Active sources","--","#B6812E")]:
    rows=series[("Monthly active",filt)];y=[r["cumulative_engaged_listeners"] for r in rows]
    axs[0].plot(range(1,29),y,color=color,linestyle=style,linewidth=2.4,label=filt)
    axs[0].text(28.55,y[-1]+(7 if filt=="All sources" else -7),str(y[-1]),color=color,va="center",fontweight="bold")
axs[0].set_title("Monthly-active cohort · 1,076 listeners",loc="left",fontsize=12,pad=14)
axs[0].set_ylabel("Cumulative engaged listeners")
axs[0].set_ylim(0,310)
axs[0].legend(frameon=False,loc="upper left",fontsize=10)
for seg in active_segments:
    rows=series[(seg,"Active sources")];y=[r["cumulative_engagement_pct_calculated"] for r in rows]
    axs[1].plot(range(1,29),y,color=colors[seg],linewidth=2.4,label=f'{seg} (n={rows[0]["cohort_listeners"]})')
    axs[1].text(28.5,y[-1],f'{by_key[(seg,"Active sources")]["engagement_pct_displayed"]:g}%',color=colors[seg],va="center",fontweight="bold")
axs[1].set_title("Active-source engagement by baseline segment",loc="left",fontsize=12,pad=14)
axs[1].set_ylabel("Percent of each pre-release segment")
axs[1].set_ylim(0,70)
axs[1].legend(frameon=False,loc="upper left",fontsize=10)
axs[1].yaxis.set_major_formatter(plt.FuncFormatter(lambda x,pos:f"{x:.0f}%"))
for ax in axs:
    ax.set_xlim(1,32);ax.set_xticks([1,7,14,21,28]);ax.set_xlabel("Release day");ax.grid(axis="y",color="#E8ECF0",linewidth=.7);ax.set_axisbelow(True)
fig.text(.05,.135,"Source conflicts: active subsegments 306 vs aggregate 252; all-source subsegments 325 vs 269. Do not sum the curves.",fontsize=10,color="#526273")
fig.text(.05,.095,"Panel cohort: 1,076; artist timeline on April 23: 957. Rates retain the panel's fixed denominators; discrepancy unresolved.",fontsize=10,color="#526273")
fig.text(.05,.05,"Source: release_engagement_*.txt, *_chart.json and artist_daily.csv. Endpoint percentages are rounded displayed values.",fontsize=9,color="#526273")
fig.subplots_adjust(left=.075,right=.97,top=.78,bottom=.25,wspace=.32)
fig.savefig(CHARTS/"release_engagement.png",dpi=180)
plt.close(fig)

table="\n".join(f'| {r["audience_segment"]} | {r["source_filter"]} | {r["cohort_listeners"]:,} | {r["engaged_listeners"]:,} | {r["engagement_pct_displayed"]:g}% |' for r in snapshots)
md=f'''# Release engagement — captured Spotify for Artists evidence

**The Cut (Starts Tomorrow)**, released **April 24, 2026**, has a completed first-28-day window ending **May 21, 2026**. All captures say **Day 28 · No Longer Updating · Worldwide**. The baseline cohort is the artist's monthly active audience on **April 23**, the day before release, not the current 791 monthly active listeners.

## Observed completed-window results

| Pre-release segment | Listening source filter | Baseline listeners | Engaged listeners | Displayed engagement |
|---|---|---:|---:|---:|
{table}

The aggregate observed active-source reach is **252/1,076 (23.4% displayed)**. Including all sources raises observed cohort reach to **269/1,076 (25%)**, a difference of **17 people and 1.58 percentage points**. That difference is descriptive; it is not an experiment or causal estimate of programmed-source lift. All-source reach includes active listening, so the two counts must not be added.

Active-source engagement within the captured subsegment views is **60% for super**, **30.1% for moderate**, and **23.2% for light** listeners. These use different fixed pre-release denominators: **85, 366, and 625**, respectively. The new super-listener all-source capture reports **53/85 (62.4%)**, versus **51/85 (60%)** from active sources. The pattern is descriptive of this one release and does not establish future conversion or a benchmark for comparable artists.

## Material inconsistency — preserve both views

The three baseline subsegment denominators sum correctly: **85 + 366 + 625 = 1,076**. Their active-source engaged numerators do not: **51 + 110 + 145 = 306**, which exceeds the monthly-active aggregate **252** by **54**. The mismatch is present on **{summary["reconciliation"]["active_daily_dates_inconsistent"]} of 28 chart dates**; only the first day reconciles. All-source subsegment numerators also conflict: **53 super + 120 moderate + 152 light = 325**, exceeding the all-source aggregate **269** by **56**. Even moderate plus light alone total272, above269.

The captures do not establish the cause. Do not adjust counts, invent an overlap explanation, combine subsegment numerators into an overall rate. Report aggregate and subsegment views separately with this warning. Individual curves are internally monotonic, their day-28 endpoints match their cards, and matched all-source curves are never below their active-source counterparts, but those internal checks do not resolve the aggregate-versus-subsegment conflict.

## Timing and coverage

All eight captured filter combinations have **28 consecutive daily cumulative observations**, April 24–May 21. The first day has 40 active-source and 47 all-source aggregate cohort listeners; day 7 has 120 and 130; day 14 has 172 and 187; day 28 has 252 and 269. These are cumulative unique reached members of the original cohort, not daily listeners or streams. Do not sum daily cumulative counts.

The release picker explicitly shows **“Releases from the last 6 months”** and only this single selectable release in the capture. This observed six-month window differs from the official support-page notes saying latest three months. Preserve the observed UI coverage and document the discrepancy; neither statement establishes complete historical release-engagement coverage. All four audience segment choices were captured for both active and all sources, giving eight observed combinations for this one release.

Absence from the reached cohort is not evidence of churn, and this panel does not measure all release listeners. It measures engagement by an already-defined pre-release active cohort. Marketing prompts in the UI are platform recommendations, not evidence of campaign performance. No matched peer benchmark, campaign attribution, revenue estimate, or retention rate is supplied by this panel.

## Evidence and outputs

Definition basis: `analysis/definitions_notes.md`, section 7, and the captured card language. Each CSV row records its exact capture filename.

- `normalized/release_engagement_snapshot.csv` — eight observed source/segment combinations with their fixed baselines and rounded displayed rates.
- `normalized/release_engagement_daily.csv` — 224 daily cumulative observations; dates, release age, denominator and source retained.
- `normalized/release_engagement_reconciliation.csv` — daily aggregate/subsegment diagnostic, preserving the source conflicts.
- `normalized/release_engagement_source_comparison.csv` — matched all-versus-active source descriptive differences.
- `analysis/release_engagement_analysis.json` — machine-readable summary, coverage and quality checks.
- `charts/release_engagement.png` — aggregate cumulative reach and separately denominated active-source subsegment rates.

Reproduction script: `analysis/analyze_release_engagement.py`. These files normalize observed DOM evidence rather than claiming native CSV provenance.
'''
with (OUT/"artist_daily.csv").open() as f:
    cohort_timeline = next(r for r in csv.DictReader(f) if r["date"] == "2026-04-23")
cohort_crosscheck = []
for label, column in [("Monthly active", "monthly active listeners"), ("Super", "super listeners")]:
    panel = by_key[(label, "Active sources")]
    native = int(cohort_timeline[column])
    cohort_crosscheck.append({"release":panel["release"],"expected_cohort_date":panel["cohort_date"],"audience_segment":label,"release_panel_cohort_listeners":panel["cohort_listeners"],"artist_timeline_same_date":native,"panel_minus_timeline":panel["cohort_listeners"]-native,"status":"unresolved_cross_view_mismatch","panel_source":panel["source"],"timeline_source":"normalized/artist_daily.csv;artist_timeline_2024-01-01_2026-10-20.csv","handling":"Preserve panel denominator for displayed engagement; do not recompute against timeline"})
csv_write("release_engagement_cohort_crosscheck.csv",cohort_crosscheck)
summary["cohort_cross_view_reconciliation"] = cohort_crosscheck
(ROOT/"analysis/release_engagement_analysis.json").write_text(json.dumps(summary,indent=2)+"\n")
md=md.replace("The baseline cohort is the artist's monthly active audience on **April 23**, the day before release, not the current 791 monthly active listeners.","Under Spotify's documented definition, this panel's fixed baseline refers to **April 23**, the day before release, rather than current monthly active listeners. The displayed baseline does not match the artist timeline on that date; both are preserved below.")
md=md.replace("## Timing and coverage", """## Cross-view baseline discrepancy

The release panel displays a **1,076** monthly-active baseline and **85** super listeners. The native artist timeline on the documented day-before-release date, **April 23, 2026**, reports **957** monthly active and **77** super listeners — differences of **119** and **8**. The cause is not established. Keep the release panel's displayed denominators when describing its own engagement rates; do not claim the native timeline verifies them, substitute 957 or 77 into the engagement calculations, or treat this as a measured change in the same population. Moderate/light historical timeline stocks are not present in that export, so no additional cross-view denominator checks are invented.

Evidence: `normalized/release_engagement_cohort_crosscheck.csv`, `normalized/artist_daily.csv`, and the per-filter release cards. This discrepancy is separate from the 306-versus-252 engaged-listener conflict.

## Timing and coverage""")
(ROOT/"analysis/release_engagement_analysis.md").write_text(md)
print(json.dumps({k:summary[k] for k in ["release","cohort_listeners","observed_filter_combinations","daily_rows","reconciliation","quality_checks"]},indent=2))
