# Release engagement — captured Spotify for Artists evidence

**The Cut (Starts Tomorrow)**, released **April 24, 2026**, has a completed first-28-day window ending **May 21, 2026**. All captures say **Day 28 · No Longer Updating · Worldwide**. Under Spotify's documented definition, this panel's fixed baseline refers to **April 23**, the day before release, rather than current monthly active listeners. The displayed baseline does not match the artist timeline on that date; both are preserved below.

## Observed completed-window results

| Pre-release segment | Listening source filter | Baseline listeners | Engaged listeners | Displayed engagement |
|---|---|---:|---:|---:|
| Light | Active sources | 625 | 145 | 23.2% |
| Light | All sources | 625 | 152 | 24.3% |
| Moderate | Active sources | 366 | 110 | 30.1% |
| Moderate | All sources | 366 | 120 | 32.8% |
| Monthly active | All sources | 1,076 | 269 | 25% |
| Monthly active | Active sources | 1,076 | 252 | 23.4% |
| Super | Active sources | 85 | 51 | 60% |
| Super | All sources | 85 | 53 | 62.4% |

The aggregate observed active-source reach is **252/1,076 (23.4% displayed)**. Including all sources raises observed cohort reach to **269/1,076 (25%)**, a difference of **17 people and 1.58 percentage points**. That difference is descriptive; it is not an experiment or causal estimate of programmed-source lift. All-source reach includes active listening, so the two counts must not be added.

Active-source engagement within the captured subsegment views is **60% for super**, **30.1% for moderate**, and **23.2% for light** listeners. These use different fixed pre-release denominators: **85, 366, and 625**, respectively. The new super-listener all-source capture reports **53/85 (62.4%)**, versus **51/85 (60%)** from active sources. The pattern is descriptive of this one release and does not establish future conversion or a benchmark for comparable artists.

## Material inconsistency — preserve both views

The three baseline subsegment denominators sum correctly: **85 + 366 + 625 = 1,076**. Their active-source engaged numerators do not: **51 + 110 + 145 = 306**, which exceeds the monthly-active aggregate **252** by **54**. The mismatch is present on **27 of 28 chart dates**; only the first day reconciles. All-source subsegment numerators also conflict: **53 super + 120 moderate + 152 light = 325**, exceeding the all-source aggregate **269** by **56**. Even moderate plus light alone total272, above269.

The captures do not establish the cause. Do not adjust counts, invent an overlap explanation, combine subsegment numerators into an overall rate. Report aggregate and subsegment views separately with this warning. Individual curves are internally monotonic, their day-28 endpoints match their cards, and matched all-source curves are never below their active-source counterparts, but those internal checks do not resolve the aggregate-versus-subsegment conflict.

## Cross-view baseline discrepancy

The release panel displays a **1,076** monthly-active baseline and **85** super listeners. The native artist timeline on the documented day-before-release date, **April 23, 2026**, reports **957** monthly active and **77** super listeners — differences of **119** and **8**. The cause is not established. Keep the release panel's displayed denominators when describing its own engagement rates; do not claim the native timeline verifies them, substitute 957 or 77 into the engagement calculations, or treat this as a measured change in the same population. Moderate/light historical timeline stocks are not present in that export, so no additional cross-view denominator checks are invented.

Evidence: `normalized/release_engagement_cohort_crosscheck.csv`, `normalized/artist_daily.csv`, and the per-filter release cards. This discrepancy is separate from the 306-versus-252 engaged-listener conflict.

## Timing and coverage

All eight captured filter combinations have **28 consecutive daily cumulative observations**, April 24–May 21. The first day has 40 active-source and 47 all-source aggregate cohort listeners; day 7 has 120 and 130; day 14 has 172 and 187; day 28 has 252 and 269. These are cumulative unique reached members of the original cohort, not daily listeners or streams. Do not sum daily cumulative counts.

The release picker explicitly shows **“Releases from the last 6 months”** and only this single selectable release in the capture. This observed six-month window differs from the official support-page notes saying latest three months. Preserve the observed UI coverage and document the discrepancy; neither statement establishes complete historical release-engagement coverage. All four audience segment choices were captured for both active and all sources, giving eight observed combinations for this one release.

Absence from the reached cohort is not evidence of churn, and this panel does not measure all release listeners. It measures engagement by an already-defined pre-release active cohort. Marketing prompts in the UI are platform recommendations, not evidence of campaign performance. No matched peer benchmark, campaign attribution, revenue estimate, or retention rate is supplied by this panel.

## Evidence and outputs

Definition basis: `analysis/definitions_notes.md`, section 7, and the captured card language. Each CSV row records its exact capture filename.

- `normalized/release_engagement_snapshot.csv` — eight observed source/segment combinations with their fixed baselines and rounded displayed rates.
- `normalized/release_engagement_daily.csv` — 224 daily cumulative observations; dates, release age, denominator and source retained.
- `normalized/release_engagement_reconciliation.csv` — daily aggregate/subsegment diagnostic, preserving the source conflicts.
- `normalized/release_engagement_source_comparison.csv` — matched all-versus-active source descriptive differences.
- `analysis/release_engagement_analysis.json` — machine-readable summary, coverage and quality checks.
- `charts/release_engagement.png` — aggregate cumulative reach and separately denominated active-source subsegment rates.

Reproduction script: `analysis/analyze_release_engagement.py`. These files normalize observed DOM evidence rather than claiming native CSV provenance.
