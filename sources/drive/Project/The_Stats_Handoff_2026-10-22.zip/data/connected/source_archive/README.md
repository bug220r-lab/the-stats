# The Stats — source data and audit trail

Prepared for Lewis. Artist name as displayed: [REDACTED]. Spotify artist ID: 6X14XfGTmB560PF063wXDk.
Collected October 22, 2026. Common timeline endpoint: October 20, 2026. Dates are inclusive and use Spotify's UTC reporting basis. Playlist exact bounds were not exposed and have not been invented.

## Start here

The companion PDF explains findings and the 30/60/90-day plan; the DOCX is editable. The XLSX organizes the canonical datasets, formulas, charts and checks. This ZIP retains the underlying evidence and analysis scripts. It is a documented accessible-account audit, not a claim that every requested page or lifetime daily record was obtainable.

Read `coverage_manifest.csv` for exactly what was captured, partially captured, reported as empty, not exposed, or not collected. Read `DATA_DICTIONARY.md` and `analysis/catalog_data_dictionary.md` before aggregating rows. `file_manifest.csv` lists packaged files, byte counts, SHA-256 checksums and CSV row counts. Checksums establish the bytes included in this archive, not an independent guarantee by Spotify.

## Folder guide

- `raw/`: unchanged native artist timeline and four native song-stream CSV downloads.
- `captured/`: rendered page snapshots, chart accessibility labels, source URLs/timestamps and original native playlist CSVs (`agent_playlists_*_native.csv`). These are evidence, not all native exports. Capture bundles can repeat the same data across periods and may include failed/loading captures that canonical tables exclude.
- `normalized/`: cleaned, typed, deduplicated analysis datasets and reconciliation tables. Native files are never overwritten to create these.
- `analysis/`: reproducible normalization and authoring scripts, findings, source definitions and data dictionary. Report-render temporary images are omitted.
- `charts/`: generated analytical figures used in the report.

## Coverage that matters

The native artist timeline covers all 1,024 dates from January 1, 2024 through October 20, 2026. There are 14 distinct recordings across 7 releases. Twelve recordings have complete available-history daily streams, listeners, streams/listener, playlist adds and saves. Son! has complete daily history for the latter 4 metrics, but 730 observed stream days; GOOMH! has 365 observed stream days and no captured daily series for the other 4 metrics. Thus 64 of 70 requested recording-metric series are complete for this history window. Full recording history begins in 2024 even when the original release was in 2023. Seven release stream charts each cover 1,024 days but are a different reporting grain and are not used to silently fill missing song histories.

Every song location and playlist page was checked. Seven song location pages were available (488 geographic rows); seven returned generic Spotify errors. Three song playlist pages supplied 28-day and 12-month Top tables (52 rows); eleven returned errors. Artist playlists have 46 native rows over three selected periods. These Top tables are incomplete representations of all playlist use. Only The Cut has a collected song-source breakdown (latest 28 days and prior 28); the other 13 source breakdowns are not collected. Artist source history is also limited to the latest 28-day comparison.

Campaign and sub-campaign lists are explicitly empty in the inspected views. That is not evidence of zero advertising in every channel. Canvas controls and inventory were captured, but published assets and their performance remain unverified. No campaigns, uploads, settings, playlists or content were changed.

## Rules for using the data

1. Join recordings by Spotify song ID. Funny Guy, Crawl and GOOMH! share song IDs across single and album releases; the two 2023 Lab Tapes versions have distinct IDs from their 2024 album counterparts. Never add release totals into an artist total.
2. Streams, saves and playlist adds can be summed over complete, nonoverlapping daily windows at the same grain. Daily listeners, rolling monthly listeners, monthly active listeners, super listeners and followers cannot. Period unique listeners come from period-level UI values.
3. Followers are an end-date stock. A stock difference is net change, not gross newly acquired followers or person-level retention.
4. Standard windows end October 20:7 days Oct 14–20;28 days Sep 23–Oct 20;90 days Jul 23–Oct 20;12 months Oct 21, 2025–Oct 20, 2026. Prior windows are contiguous as labeled. UI YTD comparison uses the preceding 293 days, not prior-year YTD; separately derived YTD additive comparisons use Jan 1–Oct 20 in each year. Prior-year YTD unique listeners were not captured.
5. Launch presets for Funny Guy and Crawl were anchored to May 31, 2024 album release, not their original single dates. Original-release calculations use separately verified dates and only complete observed windows.
6. Blanks and source dashes mean missing/not reported unless an explicit zero was captured. Method Acting (Lab Tapes) is one documented exception: latest 28-day detail explicitly reports 0 saves while its catalog row shows a dash.
7. Percent-change fields use the scale described in the dictionary. A rate with zero or unavailable denominator is undefined. Saves/listener and adds/listener are activity ratios, not unique-person conversion probabilities. Small samples are unstable.
8. Do not sum source or playlist listeners into unique reach. Artist geography uses listeners, while song geography uses streams. Named playlist rows and aggregate source categories have differing scope and cannot be forced to reconcile.
9. Raw chart captures may have overlapping windows, stale unselected hero cards, or loading/error states. Use canonical normalized tables; selected-metric tables and validated chart labels take precedence over stale cards. In particular, the mislabeled Son full overview is excluded as an invalid full-period capture, while its evidence remains preserved.

## Unresolved source conflicts

- Funny Guy: available-history streams 30,549 versus all-time header 29,786. The Devil Wears Docs: 11,872 versus 11,861. Album: 81,391 versus 81,263. No explanation is proven; both values remain.
- Gender cells total 1,064 and age cells 1,063 versus 1,062 artist listeners; a male cross-tab subtotal also differs by 1. No cell is adjusted.
- The Cut engagement tiers do not sum to the overall engaged count; displayed baseline cohorts also differ from timeline snapshots. All eight curves are retained, and aggregate and tier analyses remain separate.
- Latest 28-day named algorithmic playlist rows total 263 streams versus 256 in the corresponding broad personalized-source category; exact playlist bounds are not exposed. No artificial residual is assigned.
- Funny Guy song-country rows sum 1,484 streams versus 1,488 total; the unexplained gap 4 is retained.

Many captured additive comparisons reconcile exactly, including 44 artist checks, 288 song period checks, 131 song chart-total checks, 28 release period checks and 365 daily catalog-to-artist stream comparisons. These checks validate those comparisons only; they do not resolve the conflicts above or establish causal attribution.

## Reproduction

Python analysis scripts read preserved evidence and emit normalized CSVs and findings; report generation additionally uses python-docx and the document-render runtime. The workbook builder uses the installed artifact-tool JavaScript runtime. For this full dataset, run Node with `--max-old-space-size=8192`; the default heap limit was insufficient for export. Paths may need adjustment outside the supplied workspace. Scripts do not fetch hidden Spotify APIs. Re-running from this archive reconstructs captured data, not a fresh account audit. See the scripts for their explicit local inputs and outputs; the original native files remain the authoritative byte-preserved exports.
