# Dataset inventory and field guide

This inventory lists every normalized CSV, row count and exact field names. Domain-specific interpretation appears in the analysis notes and catalog dictionary.

| Dataset | Rows | Purpose |
|---|---:|---|
| `artist_daily.csv` | 1,024 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_monthly.csv` | 34 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_period_comparisons.csv` | 16 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_period_dashboard.csv` | 36 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_period_reconciliation.csv` | 44 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_periods_from_timeline.csv` | 11 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_periods_integrated.csv` | 11 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_playlist_reconciliation.csv` | 3 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_playlist_summary.csv` | 9 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_playlists.csv` | 46 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_source_ratios_28day.csv` | 7 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `artist_sources_28day.csv` | 17 | Artist-level daily, monthly, period, source or playlist table. Respect period/date and metric grain. |
| `audience_active_subsegments.csv` | 3 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_demographics_age.csv` | 7 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_demographics_age_gender.csv` | 28 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_demographics_gender.csv` | 4 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_development.csv` | 3 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_segment_daily.csv` | 28 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_segment_snapshot.csv` | 3 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_top_cities.csv` | 50 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `audience_top_countries.csv` | 23 | Audience snapshot, rolling segment, demographic or reported geographic table. Counts are not additive across categories unless explicitly reconciled. |
| `canvas_card_inventory.csv` | 15 | Displayed content inventory; repeated release appearances are not unique published assets. |
| `catalog_artist_daily_reconciliation.csv` | 365 | Deduplicated recording comparisons or reconciliation. Residual outside top3 does not establish historical tail membership. |
| `catalog_artist_period_reconciliation.csv` | 8 | Deduplicated recording comparisons or reconciliation. Residual outside top3 does not establish historical tail membership. |
| `catalog_stream_contributions.csv` | 6 | Deduplicated recording comparisons or reconciliation. Residual outside top3 does not establish historical tail membership. |
| `content_feature_status.csv` | 17 | Feature availability and explicit status; missing performance is not zero. |
| `release_catalog.csv` | 7 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_daily_streams.csv` | 7,168 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_detail_reconciliation.csv` | 28 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_engagement_cohort_crosscheck.csv` | 2 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_engagement_daily.csv` | 224 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_engagement_reconciliation.csv` | 28 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_engagement_snapshot.csv` | 8 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_engagement_source_comparison.csv` | 4 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_metadata.csv` | 7 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_periods.csv` | 28 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `release_song_mapping.csv` | 17 | Release-level table keyed by release_id or named release/cohort. Releases overlap recordings and are not artist totals. |
| `song_28day_rankings_ratios.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_alltime_counters.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_assessments.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_canvas_status.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_capture_index.csv` | 182 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_catalog.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_catalog_periods.csv` | 28 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_chart_points.csv` | 81,171 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_chart_quality.csv` | 68 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_chart_total_reconciliation.csv` | 131 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_daily_coverage.csv` | 70 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_daily_long.csv` | 66,631 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_daily_wide.csv` | 13,677 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_dashboard_metric_comparisons.csv` | 158 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_export_quality.csv` | 4 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_first28_daily_streams.csv` | 308 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_launch_summary.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_location_country_comparison_daily.csv` | 588 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_location_coverage.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_locations.csv` | 488 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_monthly_streams.csv` | 447 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_period_canonical.csv` | 103 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_period_comparisons.csv` | 198 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_period_dashboard.csv` | 160 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_period_reconciliation.csv` | 288 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_periods_from_daily.csv` | 434 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_playlist_coverage.csv` | 28 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_playlists.csv` | 52 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_query_errors.csv` | 4 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_source_comparisons.csv` | 10 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |
| `song_source_coverage.csv` | 14 | Recording-level table keyed by song_id. Read catalog_data_dictionary.md and preserve period/date/metric grain. |

## Common fields and units

- `date`, `start_date`, `end_date`: inclusive calendar dates; playlist blanks reflect unexposed exact bounds.
- `song_id`, `release_id`: exact Spotify identity, not title matching.
- `source`, `evidence_file`, `sources`, `source_url`, `collected_at`: provenance, with bundle metadata resolving URLs/timestamps where available.
- `origin`: native download versus rendered-chart extraction.
- `status`, `coverage_note`, `complete`, `standard_history_complete`: explicit validity/coverage; blank values must not be treated as zero.
- `difference`: reported comparison residual; a nonzero value remains unresolved unless a note explicitly explains differing scope.
- `percent_change`: normally0–100 percentage units. Fields ending `_share`/`share_of_...` and `_per_listener` may be fractional ratios; see dataset-specific dictionary and XLSX formatting.
- Rolling snapshots and period unique listeners are not additive. Daily streams/saves/adds are additive only within complete, nonoverlapping windows.
- Repeated evidence tables (especially song_chart_points and song_period_dashboard) are for audit, not totals.

## artist_daily.csv

1,024 data rows. Fields: `date`, `listeners`, `monthly listeners`, `monthly active listeners`, `super listeners`, `streams`, `playlist adds`, `saves`, `followers`.

## artist_monthly.csv

34 data rows. Fields: `month`, `start_date`, `end_date`, `days_observed`, `complete_calendar_month`, `streams`, `saves`, `playlist_adds`, `followers_end`, `monthly_listeners_end`, `monthly_active_listeners_end`, `super_listeners_end`, `streams_per_day`.

## artist_period_comparisons.csv

16 data rows. Fields: `current_window`, `previous_window`, `metric`, `current`, `previous`, `absolute_change`, `percent_change`.

## artist_period_dashboard.csv

36 data rows. Fields: `period`, `metric`, `scope`, `start_date`, `end_date`, `days`, `current_value`, `previous_value`, `current_status`, `previous_status`, `previous_period_start`, `previous_period_end`, `comparison_type`, `absolute_change`, `percent_change`, `dashboard_change_text`, `source_file`, `extraction`, `unit`, `previous_snapshot_date`, `current_snapshot_date`.

## artist_period_reconciliation.csv

44 data rows. Fields: `period`, `metric`, `which`, `dashboard`, `timeline`, `difference`.

## artist_periods_from_timeline.csv

11 data rows. Fields: `window`, `start_date`, `end_date`, `days`, `streams`, `saves`, `playlist_adds`, `followers_end`, `followers_before_start`, `followers_change`, `monthly_listeners_end`, `monthly_listeners_before_start`, `monthly_listeners_change`, `monthly_active_listeners_end`, `monthly_active_listeners_before_start`, `monthly_active_listeners_change`, `super_listeners_end`, `super_listeners_before_start`, `super_listeners_change`, `period_unique_listeners`, `period_unique_listeners_method`, `streams_per_day`, `source`.

## artist_periods_integrated.csv

11 data rows. Fields: `window`, `start_date`, `end_date`, `days`, `streams`, `saves`, `playlist_adds`, `followers_end`, `followers_before_start`, `followers_change`, `monthly_listeners_end`, `monthly_listeners_before_start`, `monthly_listeners_change`, `monthly_active_listeners_end`, `monthly_active_listeners_before_start`, `monthly_active_listeners_change`, `super_listeners_end`, `super_listeners_before_start`, `super_listeners_change`, `period_unique_listeners`, `period_unique_listeners_method`, `streams_per_day`, `source`, `streams_per_listener`, `saves_per_listener`, `playlist_adds_per_listener`.

## artist_playlist_reconciliation.csv

3 data rows. Fields: `period_label`, `native_rows`, `DOM_rows`, `listener_and_stream_cells_match`, `scope_status`.

## artist_playlist_summary.csv

9 data rows. Fields: `period_label`, `category`, `row_count`, `streams_from_captured_rows`, `listener_row_sum_not_unique_reach`, `status`, `footer_displayed`, `coverage`, `source`.

## artist_playlists.csv

46 data rows. Fields: `period_label`, `period_start`, `period_end`, `date_bounds_status`, `category`, `category_rank_displayed`, `native_export_order`, `playlist_title`, `author_displayed`, `author_status`, `listeners`, `streams`, `streams_per_listener_calculated`, `date_added`, `date_added_status`, `song_count_displayed`, `song_info_displayed`, `playlist_url`, `song_url`, `native_source`, `DOM_source`, `coverage`.

## artist_source_ratios_28day.csv

7 data rows. Fields: `source_category`, `period_start`, `period_end`, `streams`, `listeners`, `streams_per_source_listener`, `previous_streams_per_source_listener`, `notes`.

## artist_sources_28day.csv

17 data rows. Fields: `entity`, `artist_id`, `level`, `metric`, `source_category`, `source_group`, `start_date`, `end_date`, `previous_start_date`, `previous_end_date`, `current_value`, `previous_value`, `current_status`, `previous_status`, `current_raw`, `previous_raw`, `absolute_change`, `percent_change`, `current_share_of_total_streams`, `previous_share_of_total_streams`, `source_file`, `metric_filename_mismatch`, `notes`.

## audience_active_subsegments.csv

3 data rows. Fields: `period_start`, `period_end`, `geography`, `segment`, `listeners`, `monthly_active_denominator`, `share_pct_displayed`, `share_pct_calculated`, `streams_per_listener_displayed`, `rounding`, `source`.

## audience_demographics_age.csv

7 data rows. Fields: `period_start`, `period_end`, `geography`, `age_range`, `listeners_from_gender_sum`, `share_pct_displayed`, `percent_status`, `source`.

## audience_demographics_age_gender.csv

28 data rows. Fields: `period_start`, `period_end`, `geography`, `age_range`, `gender`, `listeners`, `status`, `source`.

## audience_demographics_gender.csv

4 data rows. Fields: `period_start`, `period_end`, `geography`, `gender`, `listeners`, `share_pct_displayed`, `percent_status`, `source`.

## audience_development.csv

3 data rows. Fields: `period_start`, `period_end`, `geography`, `metric`, `listeners`, `status`, `note`, `source`.

## audience_segment_daily.csv

28 data rows. Fields: `date`, `total_audience`, `monthly_active_listeners`, `previously_active`, `programmed`, `super_listeners`, `moderate_listeners`, `light_listeners`, `measurement_type`, `source`.

## audience_segment_snapshot.csv

3 data rows. Fields: `as_of_date`, `segment`, `listeners`, `total_audience`, `share_of_total_audience_pct_displayed`, `share_of_total_audience_pct_calculated`, `share_of_28day_streams_pct_displayed`, `stream_share_status`, `audience_window`, `source`.

## audience_top_cities.csv

50 data rows. Fields: `period_start`, `period_end`, `geography`, `rank`, `city`, `country`, `region`, `listeners`, `raw_location_label`, `coverage`, `source`.

## audience_top_countries.csv

23 data rows. Fields: `period_start`, `period_end`, `geography`, `rank`, `country`, `listeners`, `active_pct_displayed`, `active_listeners`, `active_status`, `share_of_artist_monthly_listeners_pct_calculated`, `monthly_listener_denominator`, `coverage`, `source`.

## canvas_card_inventory.csv

15 data rows. Fields: `release`, `release_type`, `release_year`, `card_position`, `track_label`, `status`, `source`, `source_url`, `observed_at`, `note`.

## catalog_artist_daily_reconciliation.csv

365 data rows. Fields: `date`, `metric`, `catalog_total`, `artist_total`, `difference`.

## catalog_artist_period_reconciliation.csv

8 data rows. Fields: `period`, `side`, `metric`, `recordings`, `catalog_total`, `artist_total`, `difference`, `method`.

## catalog_stream_contributions.csv

6 data rows. Fields: `period`, `group`, `current_streams`, `previous_streams`, `absolute_change`, `percent_change`, `share_of_artist_net_change`, `method`, `source`.

## content_feature_status.csv

17 data rows. Fields: `feature`, `entity`, `metric`, `value`, `value_status`, `unit`, `ui_status`, `date_scope`, `observed_at`, `source`, `source_url`, `note`.

## release_catalog.csv

7 data rows. Fields: `release_id`, `release_title`, `release_type`, `streams_28day`, `release_year`, `source`.

## release_daily_streams.csv

7,168 data rows. Fields: `release_id`, `release_title`, `date`, `streams`, `provenance`, `source`.

## release_detail_reconciliation.csv

28 data rows. Fields: `release_id`, `release_title`, `period`, `period_card_streams`, `full_chart_subset_sum`, `difference`, `captured_window_chart_sum`, `status`, `source`.

## release_engagement_cohort_crosscheck.csv

2 data rows. Fields: `release`, `expected_cohort_date`, `audience_segment`, `release_panel_cohort_listeners`, `artist_timeline_same_date`, `panel_minus_timeline`, `status`, `panel_source`, `timeline_source`, `handling`.

## release_engagement_daily.csv

224 data rows. Fields: `release`, `release_date`, `cohort_date`, `geography`, `audience_segment`, `source_filter`, `cohort_listeners`, `date`, `release_day`, `cumulative_engaged_listeners`, `increment_from_prior_observation`, `cumulative_engagement_pct_calculated`, `status`, `source`, `definition_source`.

## release_engagement_reconciliation.csv

28 data rows. Fields: `release`, `date`, `release_day`, `source_filter`, `monthly_active_cohort`, `sum_subsegment_cohorts`, `monthly_active_cumulative_engaged`, `sum_subsegment_cumulative_engaged`, `subsegment_sum_minus_total`, `status`, `source`.

## release_engagement_snapshot.csv

8 data rows. Fields: `release`, `release_date`, `cohort_date`, `geography`, `audience_segment`, `source_filter`, `cohort_listeners`, `last_release_day`, `period_end`, `engaged_listeners`, `engagement_pct_displayed`, `engagement_pct_calculated`, `percent_status`, `updating_status`, `source`, `chart_source`.

## release_engagement_source_comparison.csv

4 data rows. Fields: `release`, `audience_segment`, `cohort_listeners`, `active_sources_engaged`, `all_sources_engaged`, `all_minus_active_listeners`, `all_minus_active_pct_points_calculated`, `interpretation`, `source`.

## release_metadata.csv

7 data rows. Fields: `release_id`, `release_title`, `release_type`, `release_date`, `all_time_streams_displayed`, `observed_history_start`, `observed_history_end`, `history_streams_sum`, `history_minus_all_time`, `all_time_comparison_status`, `native_csv_status`, `source`.

## release_periods.csv

28 data rows. Fields: `release_id`, `release_title`, `period`, `start_date`, `end_date`, `bounds_method`, `streams`, `listeners`, `streams_per_listener_displayed`, `playlist_adds`, `saves`, `previous_period_streams_displayed`, `previous_period_status`, `captured_chart_points`, `source`, `source_url`, `collected_at`.

## release_song_mapping.csv

17 data rows. Fields: `release_id`, `release_title`, `song_id`, `title`, `track_number`, `streams_28day`, `source`.

## song_28day_rankings_ratios.csv

14 data rows. Fields: `song_id`, `title`, `period`, `start_date`, `end_date`, `rank`, `streams`, `listeners`, `canvas_views`, `saves`, `first_released`, `source`, `recording_label`, `saves_raw_catalog`, `saves_basis`, `streams_per_listener`, `saves_per_listener`, `saves_per_100_streams`, `stream_share_artist`, `canvas_views_per_100_streams`.

## song_alltime_counters.csv

14 data rows. Fields: `song_id`, `recording_label`, `all_time_streams`, `source`.

## song_assessments.csv

14 data rows. Fields: `song_id`, `recording_label`, `assessment`.

## song_canvas_status.csv

14 data rows. Fields: `song_id`, `recording_label`, `observed_action`, `source`, `scope`.

## song_capture_index.csv

182 data rows. Fields: `capture`, `bundle_source`, `url`, `collected_at`, `error`.

## song_catalog.csv

14 data rows. Fields: `song_id`, `title`, `first_released`, `recording_label`, `release_memberships`, `canvas_ui_action`.

## song_catalog_periods.csv

28 data rows. Fields: `song_id`, `title`, `period`, `start_date`, `end_date`, `rank`, `streams`, `listeners`, `canvas_views`, `saves`, `first_released`, `source`.

## song_chart_points.csv

81,171 data rows. Fields: `song_id`, `recording_label`, `capture_period`, `date`, `metric`, `value`, `source`.

## song_chart_quality.csv

68 data rows. Fields: `song_id`, `metric`, `source`, `rows`, `status`.

## song_chart_total_reconciliation.csv

131 data rows. Fields: `song_id`, `capture_period`, `metric`, `chart_points`, `chart_total`, `hero_total`, `difference`, `source`.

## song_daily_coverage.csv

70 data rows. Fields: `song_id`, `recording_label`, `metric`, `collected_days`, `start_date`, `end_date`, `covered_days_in_standard_history`, `standard_history_complete`, `origins`, `sources`.

## song_daily_long.csv

66,631 data rows. Fields: `song_id`, `recording_label`, `date`, `metric`, `value`, `source`, `origin`.

## song_daily_wide.csv

13,677 data rows. Fields: `song_id`, `recording_label`, `date`, `listeners`, `playlist_adds`, `saves`, `streams`, `streams_per_listener`.

## song_dashboard_metric_comparisons.csv

158 data rows. Fields: `song_id`, `recording_label`, `period`, `metric`, `displayed_period`, `current`, `previous`, `absolute_change`, `percent_change`, `comparison_basis`, `capture_valid`, `source`.

## song_export_quality.csv

4 data rows. Fields: `source`, `song_id`, `rows`, `start_date`, `end_date`, `metrics`, `sha256`, `duplicate_dates`, `missing_dates`, `null_values`, `negative_values`.

## song_first28_daily_streams.csv

308 data rows. Fields: `song_id`, `recording_label`, `release_date`, `date`, `day`, `streams`, `cumulative_streams`, `source`.

## song_launch_summary.csv

14 data rows. Fields: `song_id`, `recording_label`, `original_release_date`, `history_start_date`, `history_end_date`, `first_7_days_complete`, `first_7_days_streams`, `first_28_days_complete`, `first_28_days_streams`, `first_90_days_complete`, `first_90_days_streams`, `first_365_days_complete`, `first_365_days_streams`, `available_history_peak_date`, `available_history_peak_daily_streams`, `launch_scope_note`.

## song_location_country_comparison_daily.csv

588 data rows. Fields: `song_id`, `recording_label`, `title`, `first_released`, `period_start`, `period_end`, `metric`, `source`, `source_url`, `collected_at`, `date`, `country`, `series_position`, `streams`, `country_label_status`, `scope`, `raw_chart_label`.

## song_location_coverage.csv

14 data rows. Fields: `song_id`, `recording_label`, `title`, `first_released`, `period_start`, `period_end`, `metric`, `source`, `source_url`, `collected_at`, `status`, `country_rows_captured`, `city_rows_captured`, `country_stream_sum`, `city_stream_sum`, `song_28day_streams`, `song_total_source`, `country_sum_minus_song_total`, `country_total_reconciles`, `comparison_chart_days_captured`, `top_country`, `top_country_streams`, `top_city`, `top_city_streams`, `note`.

## song_locations.csv

488 data rows. Fields: `song_id`, `recording_label`, `title`, `first_released`, `period_start`, `period_end`, `metric`, `source`, `source_url`, `collected_at`, `location_type`, `rank`, `country`, `city`, `region`, `streams`, `value_status`, `raw_location_label`, `active_count`, `active_count_status`, `coverage`.

## song_monthly_streams.csv

447 data rows. Fields: `song_id`, `recording_label`, `month`, `streams`, `days`, `complete_calendar_month`, `source`.

## song_period_canonical.csv

103 data rows. Fields: `song_id`, `recording_label`, `period`, `displayed_period`, `chart_start_date`, `chart_end_date`, `streams`, `listeners`, `streams_per_listener`, `playlist_adds`, `saves`, `capture_valid`, `invalid_reason`, `selected_metric`, `selected_table_value`, `hero_selected_value`, `source`, `metric_table_sources`.

## song_period_comparisons.csv

198 data rows. Fields: `song_id`, `recording_label`, `current_period`, `previous_period`, `metric`, `current`, `previous`, `absolute_change`, `percent_change`, `method`, `source`.

## song_period_dashboard.csv

160 data rows. Fields: `song_id`, `recording_label`, `period`, `displayed_period`, `chart_start_date`, `chart_end_date`, `streams`, `listeners`, `streams_per_listener`, `playlist_adds`, `saves`, `capture_valid`, `invalid_reason`, `selected_metric`, `selected_table_value`, `hero_selected_value`, `source`.

## song_period_reconciliation.csv

288 data rows. Fields: `song_id`, `period`, `metric`, `ui_value`, `daily_value`, `difference`, `ui_source`.

## song_periods_from_daily.csv

434 data rows. Fields: `song_id`, `recording_label`, `period`, `start_date`, `end_date`, `metric`, `value`, `method`, `source`.

## song_playlist_coverage.csv

28 data rows. Fields: `song_id`, `song_title`, `first_released`, `period_label`, `period_start`, `period_end`, `bounds_status`, `metric`, `evidence_file`, `status`, `displayed_rows`, `reported_playlist_count`, `displayed_streams`, `coverage_note`, `source_url`, `collected_at`.

## song_playlists.csv

52 data rows. Fields: `song_id`, `song_title`, `first_released`, `period_label`, `period_start`, `period_end`, `bounds_status`, `metric`, `evidence_file`, `rank`, `playlist_title`, `playlist_uri`, `made_by`, `made_by_raw`, `made_by_status`, `streams`, `streams_status`, `date_added`, `date_added_raw`, `date_added_status`, `source_url`, `collected_at`.

## song_query_errors.csv

4 data rows. Fields: `song_id`, `recording_label`, `capture_scope`, `error_text`, `source`, `interpretation`.

## song_source_comparisons.csv

10 data rows. Fields: `song_id`, `recording_label`, `capture_scope`, `metric`, `displayed_period`, `stream_source`, `previous`, `current`, `absolute_change`, `percent_change`, `displayed_change_text`, `source`.

## song_source_coverage.csv

14 data rows. Fields: `song_id`, `recording_label`, `status`, `collected_scope`, `limitation`.
