"""Read-only audit against the exact pre-capture logical hash specification."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
REFERENCE = Path(__file__).with_name('app_preflight.json')
OUTPUT = Path(__file__).with_name('post_social_verification.json')


def digest_query(connection, spec, sql=None, parameters=None):
    sql = sql or spec['sql']
    parameters = spec.get('parameters', []) if parameters is None else parameters
    cursor = connection.execute(sql, parameters)
    columns = [item[0] for item in cursor.description]
    digest = hashlib.sha256()
    def encode(value):
        return (json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
    digest.update(encode(columns))
    count = 0
    for row in cursor:
        digest.update(encode(list(row)))
        count += 1
    actual = digest.hexdigest()
    return {'sha256': actual, 'expected_sha256': spec['sha256'], 'rows': count,
            'expected_rows': spec['rows'], 'columns': columns,
            'expected_columns': spec['columns'], 'sql': sql, 'parameters': parameters,
            'unchanged': actual == spec['sha256'] and count == spec['rows'] and columns == spec['columns']}


def run():
    reference = json.loads(REFERENCE.read_text())
    database = Path(reference['database_path'])
    connection = sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)
    connection.execute('PRAGMA query_only=ON')
    connection.execute('BEGIN')
    report = {
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'reference_path': str(REFERENCE), 'database_path': str(database),
        'database_access': 'sqlite3 URI mode=ro, query_only=ON, explicit read transaction; no Store initialization or migrations',
        'hash_method': reference['hash_method'], 'quick_check': connection.execute('PRAGMA quick_check').fetchone()[0],
        'preservation_checks': {}, 'original_snapshots': [],
    }
    checks = report['preservation_checks']
    checks['schema'] = digest_query(connection, reference['schema_sha256'])
    for name in ['annotations', 'collection_queue', 'mappings', 'schema_migrations']:
        checks[name] = digest_query(connection, reference['tables'][name])
    for original in reference['snapshots']:
        snapshot_id = original['id']
        snapshot_checks = {}
        for key in ['observation_values', 'membership', 'observations_complete', 'imports_complete', 'source_references_complete']:
            snapshot_checks[key] = digest_query(connection, original[key])
        # The preflight contained only the archive snapshot. Preserve its exact full metadata row.
        if len(reference['snapshots']) == 1:
            metadata_spec = reference['tables']['snapshots']
            sql = metadata_spec['sql'].replace(' ORDER BY', ' WHERE id=? ORDER BY')
            snapshot_checks['metadata_complete'] = digest_query(connection, metadata_spec, sql, [snapshot_id])
            issue_spec = reference['tables']['validation_issues']
            sql = issue_spec['sql'].replace(' ORDER BY', ' WHERE import_id IN (SELECT id FROM imports WHERE snapshot_id=?) ORDER BY')
            snapshot_checks['validation_issues_complete'] = digest_query(connection, issue_spec, sql, [snapshot_id])
        archive_files = []
        for import_id, filename, source_path, expected_hash in connection.execute('SELECT id,filename,source_path,file_hash FROM imports WHERE snapshot_id=? ORDER BY id', [snapshot_id]):
            path = Path(source_path)
            actual_hash = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
            archive_files.append({'import_id': import_id, 'filename': filename, 'source_path': source_path,
                                  'expected_sha256': expected_hash, 'sha256': actual_hash, 'unchanged': actual_hash == expected_hash})
        report['original_snapshots'].append({'snapshot_id': snapshot_id, 'checks': snapshot_checks,
                                              'archived_source_files': archive_files,
                                              'unchanged': all(item['unchanged'] for item in snapshot_checks.values()) and all(item['unchanged'] for item in archive_files)})
    connection.row_factory = sqlite3.Row
    report['snapshot_inventory'] = [dict(row) for row in connection.execute('SELECT s.*,COUNT(o.id) AS observation_count,SUM(CASE WHEN o.active=1 THEN 1 ELSE 0 END) AS active_observations FROM snapshots s LEFT JOIN observations o ON o.snapshot_id=s.id GROUP BY s.id ORDER BY s.id')]
    report['platform_counts'] = [dict(row) for row in connection.execute('SELECT snapshot_id,platform,active,COUNT(*) AS observations,COUNT(DISTINCT account_id) AS accounts,MIN(period_start) AS period_start,MAX(period_end) AS period_end FROM observations GROUP BY snapshot_id,platform,active ORDER BY snapshot_id,platform,active')]
    report['new_capture_imports'] = [dict(row) for row in connection.execute('SELECT id,snapshot_id,filename,file_hash,imported_at,retired,counts_json FROM imports WHERE snapshot_id NOT IN (' + ','.join('?' for _ in reference['snapshots']) + ') ORDER BY id', [item['id'] for item in reference['snapshots']])]
    report['all_preservation_checks_passed'] = report['quick_check'] == 'ok' and all(item['unchanged'] for item in checks.values()) and all(item['unchanged'] for item in report['original_snapshots'])
    report['baseline_identified'] = any(row['is_baseline'] for row in report['snapshot_inventory'])
    connection.rollback()
    connection.close()
    OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'output': str(OUTPUT), 'all_preservation_checks_passed': report['all_preservation_checks_passed'], 'platform_counts': report['platform_counts'], 'new_capture_imports': len(report['new_capture_imports'])}, indent=2))
    return report


if __name__ == '__main__':
    run()
