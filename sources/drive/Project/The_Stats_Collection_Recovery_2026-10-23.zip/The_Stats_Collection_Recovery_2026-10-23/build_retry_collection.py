import csv, json, re, shutil, zipfile, hashlib
from pathlib import Path
from datetime import datetime, date, timedelta
from collections import Counter, defaultdict
from urllib.parse import urlparse, parse_qs

ROOT=Path(__file__).parent
OUT=ROOT/'The_Stats_Collection_Recovery_2026-10-23'
for sub in ['raw','normalized']:(OUT/sub).mkdir(parents=True,exist_ok=True)
captures=json.loads((ROOT/'retry_checkpoint_final.json').read_text())
bylabel={c['label']:c for c in captures}
old=ROOT/'The_Stats_Collection_Supplement_2026-10-22/normalized'
catalog=list(csv.DictReader(open(ROOT/'baseline/normalized/song_catalog.csv')))
names={r['song_id']:r['recording_label'] for r in catalog}
artist='6X14XfGTmB560PF063wXDk'
sources=['All active sources','Artist profile and catalog',"Listener's own playlists and library",'Listener’s queue','All programmed sources','Editorial and personalized editorial playlists','Personalized playlists, autoplay and mixes','Other listeners’ playlists','Other']
def num(s):
    if s in ('','—','-',None):return None
    f=float(str(s).replace(',','').replace('%',''))
    return int(f) if f.is_integer() else f
def csvread(p):return list(csv.DictReader(open(p)))
def writecsv(fn,headers,rows):
    with open(OUT/'normalized'/fn,'w',newline='') as f:
        w=csv.writer(f);w.writerow(headers);w.writerows(rows)
def chartdate(s):
    m=re.match(r'^([A-Za-z]+) (\d{1,2}),? (\d{4})',s);assert m,s
    return datetime.strptime(f'{m[1][:3]} {m[2]} {m[3]}','%b %d %Y').date().isoformat(),m.end()
def dates(c):return [chartdate(s)[0] for s in c['chartLabels']]
def sidof(c):return re.search(r'/song/([^/]+)/',c['url'])[1]
def basis(end):return 'baseline supplement' if end<='2026-10-20' else 'newer snapshot'
def sourcekey(r):return tuple(r[i] for i in (0,2,3,5,6,9,10))
validation=[]

# Add only previously missing observed daily values. Retain original rows unchanged.
baseline=csvread(ROOT/'baseline/normalized/song_daily_long.csv')
canonical={(r['song_id'],r['metric'],r['date']):r for r in baseline}
assert len(canonical)==len(baseline)
newdaily=[]; dailychecks=[]
daily_headers=['Spotify ID','Recording','Date','Metric','Value','Reporting basis','Collected UTC','Evidence','Source URL','Origin','Baseline end']
for label in ['goomh_baseline_full_streams','goomh_baseline_full_listeners','goomh_baseline_full_streams_per_listener','goomh_baseline_full_playlist_adds','goomh_baseline_full_saves_confirmed','son_baseline_full_streams']:
    c=bylabel[label];sid=sidof(c);q=parse_qs(urlparse(c['url']).query);metric=q['metric'][0]
    ds=dates(c);assert len(ds)==1024 and len(set(ds))==1024 and min(ds)=='2024-01-01' and max(ds)=='2026-10-20'
    assert 'sourceOfStreams' not in q
    values=[]; added=0;overlap=0
    for raw,d in zip(c['chartLabels'],ds):
        tail=raw[chartdate(raw)[1]:].lstrip(', ');m=re.match(r'([\d,.]+) ',tail);assert m,raw
        v=num(m[1]); values.append(v);key=(sid,metric,d)
        if key in canonical:
            assert abs(float(canonical[key]['value'])-v)<.0011,(key,canonical[key]['value'],v)
            overlap+=1
        else:
            row={'song_id':sid,'recording_label':names[sid],'date':d,'metric':metric,'value':v,'source':label+'.json','origin':'rendered_chart_labels'}
            canonical[key]=row;newdaily.append([sid,names[sid],d,metric,v,'baseline supplement',c['collected_at'],label,c['url'],'rendered_chart_labels','2026-10-20']);added+=1
    table_total=num(c['tables'][0][1][2])
    if metric in ('streams','playlist_adds','saves'):assert sum(values)==table_total,(label,sum(values),table_total)
    dailychecks.append([sid,names[sid],metric,added,overlap,1024,table_total,sum(values) if metric in ('streams','playlist_adds','saves') else None,'PASS: overlap and additive totals match; listeners and ratios not summed'])
assert len(newdaily)==5049
merged=sorted(canonical.values(),key=lambda r:(r['song_id'],r['date'],r['metric']))
baseheaders=list(baseline[0])
writecsv('song_daily_long_complete_baseline.csv',baseheaders,[[r[h] for h in baseheaders] for r in merged])
coverage=[]
wide={}
for sid,name in names.items():
    for metric in ['streams','listeners','streams_per_listener','playlist_adds','saves']:
        rows=[r for r in merged if r['song_id']==sid and r['metric']==metric]
        ds={r['date'] for r in rows};assert len(ds)==1024,(sid,metric,len(ds))
        coverage.append([sid,name,metric,len(ds),min(ds),max(ds),'Complete','Original baseline + recovered observed daily rows; no gap filling'])
for r in merged:wide.setdefault((r['song_id'],r['date']),{})[r['metric']]=r['value']
wm=['listeners','playlist_adds','saves','streams','streams_per_listener']
writecsv('song_daily_wide_complete_baseline.csv',['song_id','recording_label','date',*wm],[[sid,names[sid],d,*[v[m] for m in wm]]for (sid,d),v in sorted(wide.items())])
writecsv('daily_recovery_validation.csv',['song_id','recording','metric','added_days','overlap_days','captured_days','period_metric','additive_daily_sum','validation'],dailychecks)

# Recompute the same additive periods from the now complete historical observations.
oldperiods=csvread(ROOT/'baseline/normalized/song_periods_from_daily.csv')
perioddefs=sorted(set((r['period'],r['start_date'],r['end_date']) for r in oldperiods))
oldp={(r['song_id'],r['period'],r['metric']):r for r in oldperiods}
periodnew=[];periodall=[]
ph=['song_id','recording_label','period','start_date','end_date','metric','value','method','source']
for sid,name in names.items():
    for period,start,end in perioddefs:
        for metric in ('streams','playlist_adds','saves'):
            rr=[r for r in merged if r['song_id']==sid and r['metric']==metric and start<=r['date']<=end]
            assert len(rr)==(date.fromisoformat(end)-date.fromisoformat(start)).days+1
            value=sum(float(r['value']) for r in rr)
            row=[sid,name,period,start,end,metric,int(value),'sum of observed daily additive counts','song_daily_long_complete_baseline.csv']
            periodall.append(row)
            if (sid,period,metric) in oldp:assert float(oldp[(sid,period,metric)]['value'])==value
            else:periodnew.append(row)
writecsv('song_periods_complete_baseline.csv',ph,periodall)

# Combine prior successful source collection with newly retained captures.
pr_headers=['Scope','Recording','Spotify ID','Population','Reporting basis','Period start','Period end','Previous start','Previous end','Metric','Source','Hierarchy level','Current value','Previous value','Displayed change','Calculated signed change','Collected UTC','Evidence','Source URL']
pr={}
for r in csvread(old/'recovered_source_periods.csv'):
    row=[r['Scope'],r['Recording'],r['Spotify ID'],'Worldwide',r['Reporting basis'],r['Period start'],r['Period end'],r['Previous start'],r['Previous end'],r['Metric'],r['Source'],r['Hierarchy level'],num(r['Current value']),num(r['Previous value']),r['Displayed change'],num(r['Calculated signed change']),r['Collected UTC'],'prior_pass/'+r['Evidence'],r['Source URL']];pr[sourcekey(row)]=row
sd_headers=['Scope','Recording','Spotify ID','Population','Reporting basis','Window start','Window end','Date','Metric',*sources,'Collected UTC','Evidence']
sd={}
def sdkey(r):return tuple(r[i] for i in (0,2,3,5,6,7,8))
for r in csvread(old/'source_daily_supplement.csv'):
    row=['song',r['Recording'],r['Spotify ID'],'Worldwide',r['Reporting basis'],r['Window start'],r['Window end'],r['Date'],r['Metric'],*[num(r[s]) for s in sources],r['Collected UTC'],'prior_pass/'+r['Evidence']];sd[sdkey(row)]=row
reconc=[];selected={};source_skips=[]
for c in captures:
    if 'sources' not in c['label'] or not c['tables'] or not c['chartLabels']:continue
    t=c['tables'][0]
    if len(t)!=10:source_skips.append([c['label'],'Source table does not contain all nine categories']);continue
    q=parse_qs(urlparse(c['url']).query);metric=q.get('metric',['streams'])[0]
    expected={'streams':'Streams','listeners':'Listeners','streams_per_listener':'Streams / Listener'}[metric]
    assert t[0][0].startswith(expected+' ·'),(c['label'],t[0][0],metric)
    ds=dates(c);start,end=min(ds),max(ds);days=(date.fromisoformat(end)-date.fromisoformat(start)).days+1
    assert len(ds)==days and len(set(ds))==days
    assert q.get('fromDate',[start])[0]==start and q.get('toDate',[end])[0]==end
    scope='release' if '/release/' in c['url'] else 'song' if '/song/' in c['url'] else 'artist'
    sid=re.search('/'+scope+r'/([^/?]+)',c['url'])[1] if scope!='artist' else artist
    name=names[sid] if scope=='song' else 'The Cut (Starts Tomorrow)' if scope=='release' else '[REDACTED]'
    country=q.get('country',['Worldwide'])[0];country='United States' if country=='US' else country
    key=(scope,sid,country,start,end,metric);selected[key]=c
for (scope,sid,country,start,end,metric),c in selected.items():
    name=names[sid] if scope=='song' else 'The Cut (Starts Tomorrow)' if scope=='release' else '[REDACTED]'
    days=(date.fromisoformat(end)-date.fromisoformat(start)).days+1
    pe=(date.fromisoformat(start)-timedelta(days=1)).isoformat();ps=(date.fromisoformat(start)-timedelta(days=days)).isoformat()
    currents={}
    for raw in c['tables'][0][1:]:
        src=next((s for s in sources if raw[0].startswith(s)),None);assert src,raw
        a,b=num(raw[1]),num(raw[2]);currents[src]=b
        row=[scope,name,sid,country,basis(end),start,end,ps,pe,metric,src,'aggregate' if src.startswith('All ') else 'standalone' if src=='Other' else 'detail',b,a,raw[3],(b-a)/a if a not in (None,0) and b is not None else None,c['collected_at'],c['label'],c['url']]
        k=sourcekey(row)
        if k in pr:assert row[12:14]==pr[k][12:14],('conflicting duplicate source',k,row[12:14],pr[k][12:14])
        pr[k]=row
    totals=Counter()
    for raw in c['chartLabels']:
        day,_=chartdate(raw);vv=[]
        for src in sources:
            m=re.search(re.escape(src)+r' ([\d,.]+) '+re.escape(metric)+r'(?:,|\s|$)',raw);assert m,(c['label'],src,raw)
            vv.append(num(m[1]));totals[src]+=num(m[1])
        row=[scope,name,sid,country,basis(end),start,end,day,metric,*vv,c['collected_at'],c['label']];sd[sdkey(row)]=row
    if metric=='streams':
        for src in sources:
            match=currents[src]==totals[src] or (currents[src] is None and totals[src]==0)
            assert match,(c['label'],src,currents[src],totals[src])
            reconc.append([scope,sid,country,start,end,src,currents[src],totals[src],'match' if currents[src] is not None else 'table unavailable; chart explicitly zero'])
source_rows=sorted(pr.values(),key=sourcekey);sd_rows=sorted(sd.values(),key=sdkey)
writecsv('source_stream_reconciliation.csv',['scope','id','population','start','end','source','table_streams','daily_stream_sum','result'],reconc)

# Newer snapshot tables. Exact unexposed playlist bounds remain blank.
snap_headers=['Dataset','Recording','Spotify ID','Reporting basis','Period start','Period end','Selected period','Rank','Dimension','Metric','Value','Creator','Date added','Collected UTC','Coverage note','Evidence','Source URL']
snap=[];availability=[]
for c in captures:
    if 'playlists_latest' not in c['label']:continue
    sid=sidof(c);period='Last 12 months' if 'latest12' in c['label'] else 'Last 28 days'
    if c['tables']:
        for t in c['tables']:
            if len(t[0])!=5:continue
            top=re.search(r'Top \d+ of [\d,]+ playlists for this song',c['snapshot'])
            note=(top[0] if top else 'Displayed rows only')+'; exact period bounds not exposed; not an exhaustive playlist list'
            for rank,title,creator,streams,added in t[1:]:snap.append(['playlist',names[sid],sid,'newer snapshot; bounds unexposed','','',period,num(rank),title,'streams',num(streams),creator,added,c['collected_at'],note,c['label'],c['url']])
        if all(len(t)==1 for t in c['tables']):availability.append(['playlist',names[sid],sid,period,'No displayed stats',None,'An empty table/no-stats message is not zero total song activity',c['collected_at'],c['label'],c['url']])
    else:availability.append(['playlist',names[sid],sid,period,'Error or unresolved page',None,'No numeric data inferred',c['collected_at'],c['label'],c['url']])
geo_rows=[]
geo_headers=['Recording','Spotify ID','Reporting basis','Date','Country','Streams','Window start','Window end','Method','Collected UTC','Evidence','Raw chart label']
for c in captures:
    if not c['label'].endswith('_geography_fresh'):continue
    sid=sidof(c);ds=dates(c);assert len(ds)==28 and min(ds)=='2026-09-24' and max(ds)=='2026-10-21'
    for ti,t in enumerate(c['tables']):
        for rank,loc,streams in t[1:]:snap.append(['country' if ti==0 else 'city',names[sid],sid,'newer snapshot',min(ds),max(ds),'Last 28 days',num(rank),loc.replace('\n',', '),'streams',num(streams),'','',c['collected_at'],'All displayed rows retained; city display can be capped at 50; comparison is selected countries only',c['label'],c['url']])
    first=c['chartLabels'][0];tail=first[chartdate(first)[1]:].lstrip(', ')
    pairs=re.findall(r'(.*?) ([\d,.]+) streams?(?:, |$)',tail);countries=[p[0] for p in pairs];assert all(countries)
    totals=Counter()
    for raw,d in zip(c['chartLabels'],ds):
        tail=raw[chartdate(raw)[1]:].lstrip(', ');vals=re.findall(r'([\d,.]+) streams?(?:, |$)',tail);assert len(vals)==len(countries),(raw,countries)
        for country,v in zip(countries,vals):
            totals[country]+=num(v);geo_rows.append([names[sid],sid,'newer snapshot',d,country,num(v),min(ds),max(ds),'Country order from first fully labelled point; subsequent blank labels mapped positionally',c['collected_at'],c['label'],raw])
    country_totals={r[1]:num(r[2]) for r in c['tables'][0][1:]}
    for country,total in totals.items():assert total==country_totals[country],(sid,country,total,country_totals[country])
for label in ['catalog_24hours_canvas_check']:
    c=bylabel[label];ids=re.findall(r'/song/([^/]+)/stats',c['snapshot']);rows=[r for r in c['tables'][0][1:] if r[0].isdigit()];assert len(ids)==len(rows)
    seen=set()
    assert 'October 21' in c['snapshot']
    for sid,r in zip(ids,rows):
        if sid in seen:continue
        seen.add(sid)
        for metric,j in [('streams',3),('listeners',4),('canvas_views',5),('saves',6)]:snap.append(['catalog',names[sid],sid,'newer snapshot','2026-10-21','2026-10-21','24 hours / October 21',None,'Worldwide',metric,num(r[j]),'','',c['collected_at'],'Date shown as October 21; year from 2026 collection context. Dash remains unavailable.',label,c['url']])
    assert len(seen)==14

# Content verification and Spotify event reporting are newer point-in-time observations.
content_headers=['Dataset','Recording or entity','Spotify ID','Selected scope','Observation','Value','Coverage note','Collected UTC','Evidence','Source URL']
content=list(availability)
assetmap={'cut':None,'funny':'3QVtuSBGLC9fTmLfF6qP7Z','crawl':'6k07tSrPUEgdDoKZiLze3z','goodnight':'3Bmzrteo6IStTEPm13a1zZ','waste':'7sxshBNh4Ab16Pwf9OJf58','method_album':'1CczfJ6sfBFVohNwW7T0nA','cocaina_album':'54PvxNbXvtB1WXjVgJxNAk','goomh':'2P8H7ld0z758kLik5WHpaK','machine':'7Ji4wGBDl0wgLpV9ZNwa6r','john':'6qzVbJkXPRZNxX5rGCfCNj','son':'2PWQKZvFk6wRGZmcgBzWRy','devil':'7ARwqXOE4Hoi53M8TIra5P'}
assetmap['cut']=next(r['song_id'] for r in catalog if r['title']=='The Cut (Starts Tomorrow)')
for key,sid in assetmap.items():
    label='canvas_cut_detail' if key=='cut' else 'canvas_'+key+'_detail_confirmed';c=bylabel[label];assert 'Remove Canvas' in c['snapshot'] and 'Pause Video' in c['snapshot']
    content.append(['Canvas asset',names[sid],sid,'Newer asset snapshot','Existing playable Canvas preview verified',None,'Preview and Remove Canvas control observed; no publish timestamp inferred; asset not changed',c['collected_at'],label,c['url']])
c=bylabel['canvas_lab_inventory']
for sid in ('6ZGIMyU6p94qLhzLB7kmWV','5SznyhiUBgOGjdMKZq8kye'):content.append(['Canvas asset',names[sid],sid,'Lab Tapes inventory','No track asset listed',None,'No asset listed in selected release; not proof of zero historical Canvas views',c['collected_at'],c['label'],c['url']])
c=bylabel['video_reporting_availability'];content.append(['Video reporting','[REDACTED]',artist,'Video & Visuals','Your Artist Message and Canvas shown',None,'No separate Clips or music-video analytics exposed on inspected account surface; no zero-activity inference',c['collected_at'],c['label'],c['url']])
c=bylabel['merch_availability']
for metric,value in [('Store items',1),('Pinned items',1),('Tagged items',0),('Out of stock items',0),('Couch T-Shirt price USD',24.99)]:content.append(['Merch','[REDACTED] Couch T-Shirt',artist,'Newer inventory snapshot',metric,value,'Spotify merch surface; Shopify connected; sales or conversion totals not exposed',c['collected_at'],c['label'],c['url']])
eventfacts=[('caravela_2026_06_05','2026-06-05','Caravela Cultural, Centro, BR',None,None),('rialto_2026_05_30','2026-05-30','The Rialto Theatre, Akron, OH, US',34,4),('ziggys_2026_05_15','2026-05-15',"Ziggy’s, Ypsilanti, MI, US",22,3),('winchester_2026_05_14','2026-05-14','The Winchester, Lakewood, OH, US',21,3),('musica_2026_04_02','2026-04-02','Musica, Akron, OH, US',34,3),('rialto_2025_12_20','2025-12-20','The Rialto Theatre, Akron, OH, US',11,2)]
eventrows=[]
for label,d,venue,views,saves in eventfacts:
    c=bylabel['event_'+label+'_detail'];eid=c['url'].split('/')[-1]
    note='Spotify-listed event; metrics as captured, reporting window not exposed; not ticket sales'
    if label.startswith('caravela'):note+='; artist attribution unverified; displayed dashes remain unavailable'
    for metric,v in [('event_views',views),('event_saves',saves)]:content.append(['Live event',venue,eid,'Event date '+d,metric,v,note,c['collected_at'],'live_events_past + '+c['label'],c['url']])
    eventrows.append([eid,d,venue,views,saves,note,c['collected_at'],c['url']])
c=bylabel['live_events_availability']
for metric,v in [('Upcoming events',0),('Past events',6)]:content.append(['Live events','[REDACTED]',artist,'Newer inventory snapshot',metric,v,'All six past events inspected',c['collected_at'],c['label'],c['url']])
writecsv('event_reporting.csv',['event_id','event_date','venue','event_views','event_saves','coverage_note','collected_utc','source_url'],eventrows)

# Every queue item receives a result and a concrete remaining action.
queue=json.loads((ROOT/'retry_queue_start.json').read_text());outcomes={}
def status(row,s,e,n):
    q=next(q for q in queue if q['row']==row);v=q['values'];v[5]=s;v[6]=n;v[8]+=' | Retry 2026-10-23 UTC: '+e
    outcomes[row]=[row,v[1],v[2],v[3],s,e,n,v[7]]
for row in range(6,19):
    q=next(q for q in queue if q['row']==row);sid=q['values'][3]
    periods={p:sorted({r[9] for r in source_rows if r[0]=='song' and r[2]==sid and r[3]=='Worldwide' and r[5]==start and r[6]=='2026-10-20'}) for p,start in [('28-day','2026-09-23'),('12-month','2025-10-21')]}
    ev='; '.join(k+': '+(', '.join(v) if v else 'not retained') for k,v in periods.items())+'. Source comparisons and daily points retained for listed metrics.'
    if all(len(v)==3 for v in periods.values()):status(row,'Complete — available scope',ev,'Collected baseline 28-day and 12-month scopes. Country extensions tracked in row 43.')
    elif any(periods.values()):status(row,'Partial — source metrics collected',ev+' Remaining metrics did not resolve in this browser.','Retry only missing source metrics listed in evidence; preserve completed historical windows.')
    else:status(row,'Blocked — Spotify view failed',ev+' Attempts returned errors or unresolved loading; several views inconsistently said not in catalog.','Retry from the catalog when the affected Spotify view recovers; do not infer removal or zero activity.')
pl_complete={20,22,23,24,25,26,27}
for row in range(19,30):
    q=next(q for q in queue if q['row']==row);sid=q['values'][3]
    rows=[r for r in snap if r[0]=='playlist' and r[2]==sid]
    detail='; '.join(f'{p}: {sum(r[6]==p for r in rows)} displayed rows saved' for p in ['Last 28 days','Last 12 months'])
    if row==27:detail='Prior pass retained six of 232 displayed 12-month playlists; 28-day no-stats state verified.'
    if row in pl_complete:status(row,'Complete — displayed scope',detail+' Empty/no-stats views recorded separately. Exact bounds not exposed.','Collected visible scope; top rows are not the full playlist population. Native exports tracked in row 47.')
    elif row==29:status(row,'Blocked — Spotify view failed','Both playlist periods failed in retry; earlier visible-but-unsaved values remain excluded.','Retry both playlist periods and save displayed values immediately.')
    else:status(row,'Partial — one playlist window',detail+'. Other window returned error.','Retry '+('12 months' if row==28 else '28 days')+' only; preserve saved window and no-stats evidence.')
for row in range(30,37):
    q=next(q for q in queue if q['row']==row);sid=q['values'][3];rr=[r for r in snap if r[2]==sid and r[0] in ('country','city')]
    status(row,'Complete — displayed scope',f"Saved {sum(r[0]=='country' for r in rr)} countries, {sum(r[0]=='city' for r in rr)} cities, and 28 days of selected-country chart data for Sep 24–Oct 21, 2026. Daily comparison sums match country tables.",'Collected newer snapshot; keep separate from October 20 baseline. City tables may be capped at 50.')
for row,metric in [(37,'streams'),(38,'listeners'),(39,'streams_per_listener'),(40,'playlist_adds'),(41,'saves'),(42,'streams')]:
    sid=next(q for q in queue if q['row']==row)['values'][3];n=sum(r[0]==sid and r[3]==metric for r in newdaily)
    status(row,'Complete — historical gap filled',f'Added {n} previously missing observed {metric} dates. Full Jan 1 2024–Oct 20 2026 series has 1,024 dates; overlapping observations agree with original collection.','Collected in Recovered song daily; complete canonical baseline CSV included. Original source files preserved.')
status(43,'Partial — expanded source scope','Saved worldwide and US artist 12-month sources, additional song 12-month sources, and The Cut release worldwide/US 12-month sources. All retained views include comparisons and daily points.','Additional releases and song-country combinations remain uncollected; affected source metrics listed in rows 6–18. Do not generalize captured US scope to other countries.')
status(44,'Complete — available reporting','Verified 12 existing playable Canvas previews; Lab Tapes lists no track assets. Captured Oct 21 daily catalog Canvas view counts; prior 7/28-day collections retained. No longer Canvas timeline exposed on inspected surfaces.','Available scope collected. No asset edits made; no inferred publication date or zero historical views.')
status(45,'Complete — availability checked','Video & Visuals exposes Your Artist Message and Canvas; no separate Clips/music-video reporting was exposed in the inspected artist account.','No further accessible reporting found; this is an availability result, not zero activity.')
status(46,'Complete — collected','Prior pass filled 3,077 direct unique listeners for Jan 1–Oct 20 2025 in Artist periods!T59.','Retain direct period total; never sum daily listeners to unique period listeners.')
status(47,'Blocked — native download failed','Visible enabled CSV download was retried, but no download path/file returned. Four original native song exports remain; zero new native CSV exports claimed.','Retry native exports one at a time after download handling recovers; chart-derived CSVs are labelled separately.')
status(48,'Complete — available reporting','Saved merch inventory and price, zero upcoming/six past events, all six event detail pages, and exposed event view/save totals. Sales/conversion analytics were not exposed in Spotify.','Available Spotify reporting collected; Brazil event attribution remains unverified. External Shopify/Bandsintown sales not inferred.')
assert len(outcomes)==43
counts=Counter(r[4].split(' — ')[0] for r in outcomes.values())
datasets=[
 ('recovered_song_daily.csv','Recovered song daily',daily_headers,newdaily),
 ('source_collection.csv','Source recovery',pr_headers,source_rows),
 ('source_daily_collection.csv','Source history',sd_headers,sd_rows),
 ('newer_snapshots.csv','Snapshot recovery',snap_headers,snap),
 ('geography_comparison_daily.csv','Geography history',geo_headers,geo_rows),
 ('content_event_reporting.csv','Content recovery',content_headers,content),
 ('song_daily_coverage_complete.csv','Recovery coverage',['Spotify ID','Recording','Metric','Observed days','Start','End','Status','Method'],coverage),
 ('recovered_song_periods.csv','Recovered song periods',ph,periodnew),
 ('collection_log_retry.csv','Collection log',['Queue row','Data','Recording','Spotify ID','Status','Latest evidence','Next action','Source URL'],[outcomes[r] for r in sorted(outcomes)])]
for fn,title,h,rows in datasets:writecsv(fn,h,rows)
shutil.copy2(ROOT/'retry_checkpoint_final.json',OUT/'raw/retained_browser_captures.json')
shutil.copy2(ROOT/'retry_queue_start.json',OUT/'raw/queue_before_retry.json')
shutil.copy2(ROOT/'baseline/normalized/song_catalog.csv',OUT/'raw/original_song_catalog.csv')
shutil.copy2(ROOT/'baseline/normalized/song_daily_long.csv',OUT/'raw/original_song_daily_long.csv')
shutil.copy2(ROOT/'baseline/normalized/song_periods_from_daily.csv',OUT/'raw/original_song_periods_from_daily.csv')
shutil.copytree(ROOT/'The_Stats_Collection_Supplement_2026-10-22',OUT/'prior_pass',dirs_exist_ok=True)
(OUT/'updated_queue.json').write_text(json.dumps(queue,ensure_ascii=False,indent=2))
manifest={'baseline_end':'2026-10-20','captured_utc_date':'2026-10-23','artist_id':artist,'artist_name':'[REDACTED]','browser_access_verified':True,'sign_in_needed':False,'raw_captures_this_pass':len(captures),'native_exports_added':0,'historical_daily_rows_added':len(newdaily),'canonical_daily_rows':len(merged),'complete_recording_metric_series':len(coverage),'new_additive_period_rows':len(periodnew),'status_counts':dict(counts),'datasets':[{'file':fn,'sheet':title,'rows':len(rows),'columns':len(h)} for fn,title,h,rows in datasets],'source_stream_reconciliation':dict(Counter(r[-1] for r in reconc)),'source_captures_excluded':source_skips}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(OUT/'README.md').write_text(f'''# The Stats collection recovery — October 23, 2026 (UTC)

Artist: [REDACTED] ({artist}). Correct artist session verified; no sign-in needed.

The original reporting baseline remains **October 20, 2026**. Recovered historical windows end on that date. New geography and daily catalog data ends **October 21** and is labelled newer snapshot. Playlist bounds were not displayed and remain blank. Event metrics and asset/inventory observations are current snapshots; event dates are not reporting windows.

This pass adds **{len(newdaily):,} missing observed daily values** and completes all **70 recording × metric series** (14 recordings, five metrics, 1,024 dates each) for January 1, 2024–October 20, 2026. Existing observations were retained and overlapping chart values matched within display precision. Additive full-window streams, saves and playlist adds reconcile to dashboard totals. All 434 previously retained additive song periods agree; {len(periodnew)} formerly missing periods are recovered. No inferred zero filling was used. Direct period listeners remain distinct from daily listener counts.

The complete canonical daily CSVs and period CSV are in normalized/. Workbook original Song daily/period tables remain original evidence; use their union with recovery tabs, or the complete CSVs, for updated coverage. The prior supplement is included under prior_pass/ for provenance. Source recovery and Source history combine prior successful captures with this pass, deduplicated by exact scope, ID, country, window, metric and source. Do not append those master source tables to the previous supplement without deduplication.

Queue outcomes: **{dict(counts)}** across all 43 tasks. “Complete — displayed/available scope” records everything exposed in the inspected view, not an exhaustive playlist population or unseen reporting product. Source metrics and country/release extensions still missing are specifically tracked. Native downloads returned no file: four original native exports remain, with zero new native exports. Generated CSVs derived from visible charts are labelled accordingly.

Seven queued geography views are saved with every displayed country/city row and 28-day selected-country chart data. The accessibility chart names countries fully only on its first point; subsequent unnamed vectors were mapped by that observed order and validated by summing back to each country table total. City tables can stop at 50 rows.

Twelve Canvas previews are verified by playable video and a Remove Canvas control; no assets were modified. No Lab Tapes track assets were listed. Daily October 21 Canvas counts and prior 7/28-day data are retained. No longer Canvas timeline or separate Clips/music-video analytics was exposed on inspected surfaces. Merch inventory and six past-event details/view-save figures are captured; neither measures external sales. The Brazil event is Spotify-listed but artist attribution is unverified.

Active/programmed source aggregates overlap their detail rows. Do not sum both. Listener sources overlap and daily listeners cannot be summed to period unique listeners. Source change percentages may omit a sign; calculated signed changes are separate. Dashes stay unavailable, even if a daily chart explicitly shows zero. Every row retains capture provenance and reporting basis. Errors/loading screens do not imply permanent unavailability or zero activity.
''')
shutil.copy2(__file__,OUT/'build_retry_collection.py')
(ROOT/'retry_workbook_payload.json').write_text(json.dumps({'datasets':[{'file':fn,'title':title,'headers':h,'rows':rows} for fn,title,h,rows in datasets],'queue':queue,'manifest':manifest},ensure_ascii=False))
hashes={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file() and p.name!='sha256.json'}
(OUT/'sha256.json').write_text(json.dumps(hashes,indent=2))
with zipfile.ZipFile(ROOT/(OUT.name+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(ROOT))
print(json.dumps(manifest,indent=2));print('ZIP bytes', (ROOT/(OUT.name+'.zip')).stat().st_size)
