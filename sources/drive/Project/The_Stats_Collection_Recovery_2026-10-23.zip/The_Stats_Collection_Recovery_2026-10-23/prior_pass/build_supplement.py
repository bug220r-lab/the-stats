import csv,json,re,shutil,zipfile,hashlib
from pathlib import Path
from datetime import datetime,date,timedelta
from collections import Counter

ROOT=Path(__file__).parent
OUT=ROOT/'The_Stats_Collection_Supplement_2026-10-22'
OUT.mkdir(exist_ok=True)
(OUT/'raw').mkdir(exist_ok=True)
(OUT/'normalized').mkdir(exist_ok=True)
capture_input=ROOT/'collected_checkpoint2.json'
if not capture_input.exists():capture_input=ROOT/'raw/retained_browser_captures.json'
queue_input=ROOT/'queue_original.json'
if not queue_input.exists():queue_input=ROOT/'raw/original_queue.json'
catalog_input=ROOT/'baseline/normalized/song_catalog.csv'
if not catalog_input.exists():catalog_input=ROOT/'raw/original_song_catalog.csv'
captures=json.loads(capture_input.read_text())
queue=json.loads(queue_input.read_text())
catalog=list(csv.DictReader(open(catalog_input)))
names={r['song_id']:r['recording_label'] for r in catalog}
artist='6X14XfGTmB560PF063wXDk'
base=f'https://artists.spotify.com/c/artist/{artist}'
sources=['All active sources','Artist profile and catalog',"Listener's own playlists and library",'Listener’s queue','All programmed sources','Editorial and personalized editorial playlists','Personalized playlists, autoplay and mixes','Other listeners’ playlists','Other']
def numeric(s):
    if s in ('','—',None):return None
    f=float(str(s).replace(',','').replace('%',''))
    return int(f) if f.is_integer() else f
def dt(s):return datetime.strptime(s,'%b %d, %Y').date().isoformat()
def writecsv(name,headers,rows):
    with open(OUT/'normalized'/name,'w',newline='') as f:
        w=csv.writer(f);w.writerow(headers);w.writerows(rows)
def bounds(c):
    dates=[dt(re.match(r'^([A-Z][a-z]{2} \d{1,2}, \d{4}) ',s).group(1)) for s in c['chartLabels']]
    return min(dates),max(dates)
def period_kind(end):return 'baseline supplement' if end<='2026-10-20' else 'newer snapshot'

period_rows=[]; daily_rows=[];seen={};reconciliations=[]
for c in captures:
    if not c['tables'] or not c['chartLabels'] or 'sources' not in c['label']:continue
    table=c['tables'][0]
    if len(table)!=10:continue
    sid=re.search(r'/song/([^/]+)/',c['url']).group(1)
    metric='streams_per_listener' if 'streams_per_listener' in c['label'] else 'listeners' if 'listeners' in c['label'] else 'streams'
    start,end=bounds(c);days=(date.fromisoformat(end)-date.fromisoformat(start)).days+1
    assert len(c['chartLabels'])==days
    key=(sid,metric,start,end)
    if key in seen:
        assert seen[key]['tables']==c['tables'];continue
    seen[key]=c
    prevend=(date.fromisoformat(start)-timedelta(days=1)).isoformat()
    prevstart=(date.fromisoformat(start)-timedelta(days=days)).isoformat()
    for r in table[1:]:
        src,prev,cur,change=r
        assert src in sources
        a,b=numeric(prev),numeric(cur)
        signed=(b-a)/a if a not in (None,0) and b is not None else None
        level='aggregate' if src.startswith('All ') else 'standalone' if src=='Other' else 'detail'
        period_rows.append(['song',names[sid],sid,period_kind(end),start,end,prevstart,prevend,metric,src,level,b,a,change,signed,c['collected_at'],c['label'],c['url']])
    vals=[]
    for label in c['chartLabels']:
        day=dt(re.match(r'^([A-Z][a-z]{2} \d{1,2}, \d{4}) ',label).group(1))
        values=[]
        for src in sources:
            match=re.search(re.escape(src)+r' ([\d,.]+) '+metric+r'(?:,|\s|$)',label)
            assert match,(src,label)
            values.append(numeric(match.group(1)))
        vals.append(values)
        daily_rows.append([names[sid],sid,period_kind(end),start,end,day,metric,*values,c['collected_at'],c['label']])
    if metric=='streams':
        for j,r in enumerate(table[1:]):
            total=sum(v[j] for v in vals);reported=numeric(r[2])
            reconciliations.append([sid,start,end,sources[j],reported,total,'dashboard unavailable; chart explicitly zero' if reported is None and total==0 else 'match' if total==reported else 'difference retained'])

# These values were printed from the visible dashboard after the raw checkpoint.
# Their evidence is a direct table transcription; full DOM/daily labels were not saved.
artist_values={
 'streams':[(21506,52590),(10687,11908),(9479,38400),(1340,2282),(2211,9443),(None,None),(1352,8152),(859,1291),(370,1924)],
 'listeners':[(2322,3734),(1535,1647),(797,2435),(472,586),(1056,5588),(None,None),(642,5122),(423,493),(223,1400)],
 'streams_per_listener':[(9.262,14.084),(6.962,7.23),(11.893,15.77),(2.839,3.894),(2.094,1.69),(None,None),(2.106,1.592),(2.031,2.619),(1.659,1.374)]
}
artist_changes={'streams':['144.5%','11.4%','305.1%','70.3%','327.1%','—','503.0%','50.3%','420.0%'],'listeners':['60.8%','7.3%','205.5%','24.2%','429.2%','—','697.8%','16.5%','527.8%'],'streams_per_listener':['52.1%','3.8%','32.6%','37.2%','19.3%','—','24.4%','29.0%','17.2%']}
manual={'capture_date_utc':'2026-10-23','reporting_baseline_end':'2026-10-20','evidence_type':'manual transcription of table values printed by the browser tool; full raw DOM not retained','artist_id':artist,'artist_name':'[REDACTED]','artist_sources_12months':artist_values,'prior_ytd_unique_listeners':{'from':'2025-01-01','to':'2025-10-20','value':3077,'displayed_previous_period':2921,'displayed_change':'5.3%','source_url':base+'/audience/stats?fromDate=2025-01-01&toDate=2025-10-20&metric=listeners'},'daily_chart_transfer':'GOOMH and Son missing-date charts were visible but their point values were not retained. No new canonical song daily rows are claimed.'}
(OUT/'raw/manual_table_transcriptions.json').write_text(json.dumps(manual,ensure_ascii=False,indent=2))
for metric,pairs in artist_values.items():
    for j,(a,b) in enumerate(pairs):
        src=sources[j]
        period_rows.append(['artist','[REDACTED]',artist,'baseline supplement','2025-10-21','2026-10-20','2024-10-21','2025-10-20',metric,src,'aggregate' if src.startswith('All ') else 'standalone' if src=='Other' else 'detail',b,a,artist_changes[metric][j],(b-a)/a if a not in (None,0) and b is not None else None,'2026-10-23 (UTC date only)','manual_table_transcriptions.json',base+f'/audience/stats?fromDate=2025-10-21&toDate=2026-10-20&metric={metric}'])

snapshot_rows=[]
c=captures[30]
for r in c['tables'][0][1:]:
    rank,title,creator,streams,added=r
    snapshot_rows.append(['playlist','John Doe','6qzVbJkXPRZNxX5rGCfCNj','newer snapshot; bounds unexposed','','','Last 12 months',numeric(rank),title,'streams',numeric(streams),creator,added,c['collected_at'],'Top 6 of 232 playlists; displayed rows only',c['label'],c['url']])
c=captures[31]
for ti,t in enumerate(c['tables']):
    for rank,loc,streams in t[1:]:
        snapshot_rows.append(['country' if ti==0 else 'city','John Doe','6qzVbJkXPRZNxX5rGCfCNj','newer snapshot','2026-09-24','2026-10-21','Last 28 days',numeric(rank),loc.replace('\n',', '),'streams',numeric(streams),'','',c['collected_at'],'Top displayed locations; comparison timeline not retained',c['label'],c['url']])
c=captures[16];ids=re.findall(r'/song/([^/]+)/stats',c['snapshot']);rows=[r for r in c['tables'][0][1:] if r[0].isdigit()]
assert len(ids)==len(rows)
catalogseen=set()
for sid,r in zip(ids,rows):
    if sid in catalogseen:continue
    catalogseen.add(sid)
    for metric,j in [('streams',3),('listeners',4),('canvas_views',5),('saves',6)]:
        snapshot_rows.append(['catalog',names[sid],sid,'newer snapshot; bounds unexposed','','','Last 28 days',None,'Worldwide',metric,numeric(r[j]),'','',c['collected_at'],'Selected 28-day view; catalog did not expose exact dates. Dash remains blank. Canvas totals do not verify asset status.',c['label'],c['url']])

def setstatus(row,status,evidence,nextaction):
    q=next(q for q in queue if q['row']==row)
    v=q['values'];v[5]=status;v[6]=nextaction;v[8]=v[8]+' | Resume 2026-10-22 ET / 2026-10-23 UTC: '+evidence
    outcomes[row]=[row,v[1],v[2],v[3],status,evidence,nextaction,v[7]]
outcomes={}
for row in range(6,49):setstatus(row,'Open — browser unavailable','Not fully collected before browser access ended. No missing values converted to zero.','Resume this scope when browser access is restored; the artist account was already signed in.')
for row,name in [(6,'Funny Guy'),(7,'The Devil Wears Docs'),(8,'Crawl')]:
    extra=' Latest Sep 24–Oct 21 streams also retained.' if row in (6,8) else ''
    setstatus(row,'Partial — baseline collected','All 3 source metrics and 9 source rows retained for Sep 23–Oct 20, with Aug 26–Sep 22 comparison and 28 daily source points per metric.'+extra,'Collect available longer windows; complete newer-snapshot metrics only if needed. See Recovered sources and Source daily supplement.')
setstatus(9,'Blocked — Spotify error','Baseline and latest source-stat views returned Spotify errors; no source rows retained.','Retry source-filtered stats after the site recovers.')
setstatus(10,'Blocked — Spotify error','Direct and Music catalog links reported the recording was not part of the catalog, although Music visibly listed it. This is not evidence of removal.','Retry from the Music catalog and retain any error separately.')
setstatus(11,'Open — page not resolved','Retained attempts show a loading screen, not a conclusive unavailable result.','Wait for a resolved page and capture source metrics; do not classify loading as unavailability.')
setstatus(12,'Blocked — Spotify error','Source-stat page displayed a Spotify problem-on-our-end error.','Retry source-filtered stats.')
setstatus(13,'Complete — available scope','Retained all 3 metrics × 9 sources for baseline 28 days, latest Sep 24–Oct 21, and baseline 12 months Oct 21 2025–Oct 20 2026, each with prior comparison and daily source points.','Collected. Keep baseline and newer snapshots separate; country-specific extensions remain in row 43.')
for row in (14,15,16,17,18):setstatus(row,'Open — browser unavailable','No complete new source dataset retained for this recording.','Collect all 3 source metrics for baseline Sep 23–Oct 20 and available longer periods.')
play={19:('Blocked — Spotify error','28-day and 12-month pages returned errors.'),20:('Partial — availability observed','28-day page reported no stats; 12-month page returned error.'),21:('Partial — capture not saved','28-day error; 12-month page showed 2 data rows, but raw row values were not saved.'),22:('Partial — availability observed','28-day page reported no stats; 12-month page returned error.'),23:('Partial — capture not saved','28-day error retained; 12-month retry showed 7 data rows whose raw values were not saved.'),24:('Partial — capture not saved','28-day page reported no stats; 12-month page showed 5 data rows whose raw values were not saved.'),25:('Partial — capture not saved','28-day error; 12-month page showed 3 data rows whose raw values were not saved.'),26:('Partial — capture not saved','28-day page showed 1 data row whose raw values were not saved; 12-month error.'),28:('Blocked — Spotify error','28-day page error; 12-month view not completed.'),29:('Partial — capture not saved','28-day page reported no stats; 12-month page showed 7 data rows whose raw values were not saved.')}
for row,(s,e) in play.items():setstatus(row,s,e,'Revisit both periods; save displayed rows immediately. Keep unexposed date bounds blank; no-stats is not zero total streams.')
setstatus(27,'Complete — available scope','28-day page explicitly reported no stats. All 6 displayed 12-month playlist rows retained (Top 6 of 232). Exact date bounds were not exposed.','Collected displayed scope; native-export support remains tracked in row 47. Do not interpret 6 rows as all 232 playlists.')
for row,nc,nci in [(30,5,39),(31,3,35),(34,4,20)]:setstatus(row,'Partial — capture not saved',f'Observed {nc} countries, {nci} cities and a 28-day comparison chart; raw values were not saved before browser became unavailable.','Re-collect and save country/city rows and comparison-country daily chart.')
for row in (32,33,35):setstatus(row,'Blocked — Spotify error','Latest geography surface returned Spotify errors.','Retry countries, cities, and comparison timeline; preserve exact dates and top-table limits.')
setstatus(36,'Partial — tables collected','Retained 10 countries and 50 cities for Sep 24–Oct 21. Country streams sum to 177. Comparison daily chart was not retained.','Collect comparison-country timeline; tables are in Resume snapshots.')
for row,description in [(37,'659 missing stream dates, Jan 1 2024–Oct 20 2025'),(38,'1024 listener dates, Jan 1 2024–Oct 20 2026'),(39,'1024 streams-per-listener dates, Jan 1 2024–Oct 20 2026'),(42,'294 missing stream dates: Jan 1–May 30 2024 and May 31–Oct 20 2025')]:
    setstatus(row,'Partial — capture not saved',description+' were exposed by the chart, but point values were not saved. Original daily coverage remains unchanged.','Re-collect these exact windows and persist immediately; merge only observed song/metric/date values. Never fill gaps with zero.')
for row in (40,41):setstatus(row,'Open — browser unavailable','Full daily history was not captured; no new canonical daily rows retained.','Collect Jan 1 2024–Oct 20 2026 daily history and any native CSV.')
setstatus(43,'Partial — longer tables collected','Worldwide artist 12-month source tables retained by manual table transcription; album ¡La Cocaína! 12-month tables and daily points retained. US artist views were visible but not saved. Release-source availability remains unverified.','Re-collect US tables/daily points; inspect additional song and release periods and country filters.')
setstatus(44,'Partial — newer totals collected','New catalog 28-day totals retained for 14 recordings (12 numeric Canvas totals; 2 dashes). Published assets and additional daily/longer history remain unverified.','Verify assets read-only and collect longer history. Manage Canvas/Add Canvas buttons alone do not prove publication.')
setstatus(45,'Partial — availability checked','Video & Visuals showed Your Artist Message and Canvas; the inspected view exposed no separate music-video/Clips analytics. No zero-activity inference made.','Confirm whether other account views expose video/Clips reporting when browser is restored.')
setstatus(46,'Complete — collected','Direct unique listeners: 3,077 for Jan 1–Oct 20 2025. Dashboard table transcription retained; daily listener counts were not summed.','Collected; filled Artist periods!T59 and related ratios without shifting baseline dates.')
setstatus(47,'Blocked — download interrupted','Native GOOMH download attempt timed out; no new CSV file was returned. The original four native song exports are unchanged.','Retry native downloads one at a time; save returned file before continuing and reconcile with chart data.')
setstatus(48,'Open — browser unavailable','Merch & Events navigation was present, but reporting views were not inspected before browser access ended.','Inspect merch and event reporting read-only; distinguish Spotify reporting from linked external providers.')

period_headers=['Scope','Recording','Spotify ID','Reporting basis','Period start','Period end','Previous start','Previous end','Metric','Source','Hierarchy level','Current value','Previous value','Displayed change','Calculated signed change','Collected UTC','Evidence','Source URL']
daily_headers=['Recording','Spotify ID','Reporting basis','Window start','Window end','Date','Metric',*sources,'Collected UTC','Evidence']
snap_headers=['Dataset','Recording','Spotify ID','Reporting basis','Period start','Period end','Selected period','Rank','Dimension','Metric','Value','Creator','Date added','Collected UTC','Coverage note','Evidence','Source URL']
log_headers=['Queue row','Data','Recording','Spotify ID','Status','New evidence','Next action','Source URL']
metric_rows=[['artist','[REDACTED]',artist,'baseline supplement','2025-01-01','2025-10-20','period_unique_listeners',3077,'Worldwide','2026-10-23 (UTC date only)','Direct dashboard period total; manually transcribed, not a sum of daily listeners','manual_table_transcriptions.json',manual['prior_ytd_unique_listeners']['source_url']]]
metric_headers=['Scope','Recording','Spotify ID','Reporting basis','Period start','Period end','Metric','Value','Population','Collected UTC','Method','Evidence','Source URL']
datasets=[('recovered_source_periods.csv','Recovered sources',period_headers,period_rows),('source_daily_supplement.csv','Source daily supplement',daily_headers,daily_rows),('resume_snapshots.csv','Resume snapshots',snap_headers,snapshot_rows),('recovered_artist_metrics.csv','Recovered metrics',metric_headers,metric_rows),('collection_log.csv','Collection log',log_headers,[outcomes[r] for r in sorted(outcomes)])]
for name,title,headers,rows in datasets:writecsv(name,headers,rows)
writecsv('source_daily_reconciliation.csv',['song_id','period_start','period_end','source','dashboard_streams','daily_sum','result'],reconciliations)
(OUT/'raw/retained_browser_captures.json').write_text(json.dumps(captures,ensure_ascii=False,indent=2))
(OUT/'raw/original_queue.json').write_text(queue_input.read_text())
shutil.copy2(catalog_input,OUT/'raw/original_song_catalog.csv')
(OUT/'updated_queue.json').write_text(json.dumps(queue,ensure_ascii=False,indent=2))
counts=Counter(r[4].split(' — ')[0] for r in outcomes.values())
manifest={'baseline_end':'2026-10-20','resume_date_eastern':'2026-10-22','capture_date_utc':'2026-10-23','artist_id':artist,'artist_name':'[REDACTED]','account_verified':True,'sign_in_required':False,'retained_raw_captures':len(captures),'status_counts':dict(counts),'datasets':[{ 'file':n,'sheet':t,'rows':len(r),'columns':len(h)}for n,t,h,r in datasets],'native_exports_added':0,'canonical_song_daily_rows_added':0,'source_daily_stream_reconciliation':dict(Counter(r[-1] for r in reconciliations))}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
readme=f'''# The Stats collection supplement — October 22, 2026

Artist: [REDACTED] (`{artist}`). The existing signed-in artist account was verified; no sign-in was needed. Capture timestamps use UTC (October 23); the review date is October 22 in America/New_York.

The original reporting baseline ends **October 20, 2026**. Historical date windows retained here are labelled `baseline supplement`. Newer windows are labelled `newer snapshot`. Do not replace baseline figures with latest-window values. Catalog and playlist selectors did not expose exact date bounds; those bounds remain blank.

## Retained results

- {len(period_rows)} source comparison rows, with current and prior values; {len(daily_rows)} daily source observations in wide format (nine source columns each).
- Four recordings have all three baseline 28-day source metrics. Album ¡La Cocaína! also has baseline 12-month and newer 28-day source metrics. Worldwide artist 12-month source tables were transcribed from visible table output.
- John Doe: all six displayed 12-month playlist rows (Top 6 of 232), ten countries and fifty cities. Its 28-day playlist page explicitly reported no stats.
- New 28-day catalog snapshot: fourteen distinct recordings; twelve numeric Canvas totals. Canvas counts do not verify publication of assets.
- **3,077 unique listeners** for January 1–October 20, 2025, read directly from the selected-period dashboard table. This fills the missing matching-date prior-year YTD metric.
- Queue outcomes: {dict(counts)}. All 43 items have a specific status and next action.

## Remaining work and evidence limits

The browser tool became unavailable during a native-export attempt. The last complete raw checkpoint contains 43 page captures. Later chart data for missing GOOMH and Son! daily histories was visible, but its point values were not persisted; therefore **zero new canonical song daily rows and zero new native CSV files are claimed**. Re-collect the exact windows in collection_log.csv. Some later table summaries survive only as observations, explicitly marked capture-not-saved. Do not reconstruct their values.

Several Spotify pages returned temporary errors or an inconsistent not-in-catalog error. Loading screens and page errors do not establish permanent unavailability or zero activity. Source work for several recordings, some playlist/geography views, Canvas asset/history, country filters, release sources and merch/event reporting remains open.

## Interpretation

Active/programmed aggregate rows overlap their detailed children. Never sum aggregates and children together. Listener groups overlap, and daily listeners cannot be summed to unique period listeners. Daily streams can be summed within a source and selected period. The source comparison table's displayed change may lack direction; calculated signed change is stored separately. A dashboard dash remains blank, even if a daily chart explicitly shows zero. Top playlist/location tables are not exhaustive populations.

Raw capture labels link every normalized row to retained evidence. manual_table_transcriptions.json identifies values transcribed from visible tool output for which full DOM was not retained. The original source ZIP and workbook baseline tables remain the historical record. The only existing analytical cell addition is the missing prior-year YTD listener value in Artist periods!T59, its method and ratios; all other collection data is on new supplement tabs.
'''
(OUT/'README.md').write_text(readme)
shutil.copy2(__file__,OUT/'build_supplement.py')
book={'datasets':[{'file':n,'title':t,'headers':h,'rows':r} for n,t,h,r in datasets],'queue':queue,'manifest':manifest}
(ROOT/'workbook_payload.json').write_text(json.dumps(book,ensure_ascii=False))
assert len(outcomes)==43 and len(catalogseen)==14
assert sum(r[10] for r in snapshot_rows if r[0]=='country')==177
assert len([r for r in period_rows if r[0]=='song'])==len(seen)*9
assert not any(r[-1]=='difference retained' for r in reconciliations),reconciliations
zip_path=ROOT/(OUT.name+'.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(ROOT))
print(json.dumps(manifest,indent=2))
print('ZIP',zip_path,zip_path.stat().st_size)
