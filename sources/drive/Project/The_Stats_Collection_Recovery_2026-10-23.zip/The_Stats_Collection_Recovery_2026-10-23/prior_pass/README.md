# The Stats collection supplement — October 22, 2026

Artist: [REDACTED] (`6X14XfGTmB560PF063wXDk`). The existing signed-in artist account was verified; no sign-in was needed. Capture timestamps use UTC (October 23); the review date is October 22 in America/New_York.

The original reporting baseline ends **October 20, 2026**. Historical date windows retained here are labelled `baseline supplement`. Newer windows are labelled `newer snapshot`. Do not replace baseline figures with latest-window values. Catalog and playlist selectors did not expose exact date bounds; those bounds remain blank.

## Retained results

- 207 source comparison rows, with current and prior values; 1571 daily source observations in wide format (nine source columns each).
- Four recordings have all three baseline 28-day source metrics. Album ¡La Cocaína! also has baseline 12-month and newer 28-day source metrics. Worldwide artist 12-month source tables were transcribed from visible table output.
- John Doe: all six displayed 12-month playlist rows (Top 6 of 232), ten countries and fifty cities. Its 28-day playlist page explicitly reported no stats.
- New 28-day catalog snapshot: fourteen distinct recordings; twelve numeric Canvas totals. Canvas counts do not verify publication of assets.
- **3,077 unique listeners** for January 1–October 20, 2025, read directly from the selected-period dashboard table. This fills the missing matching-date prior-year YTD metric.
- Queue outcomes: {'Partial': 22, 'Blocked': 9, 'Open': 9, 'Complete': 3}. All 43 items have a specific status and next action.

## Remaining work and evidence limits

The browser tool became unavailable during a native-export attempt. The last complete raw checkpoint contains 43 page captures. Later chart data for missing GOOMH and Son! daily histories was visible, but its point values were not persisted; therefore **zero new canonical song daily rows and zero new native CSV files are claimed**. Re-collect the exact windows in collection_log.csv. Some later table summaries survive only as observations, explicitly marked capture-not-saved. Do not reconstruct their values.

Several Spotify pages returned temporary errors or an inconsistent not-in-catalog error. Loading screens and page errors do not establish permanent unavailability or zero activity. Source work for several recordings, some playlist/geography views, Canvas asset/history, country filters, release sources and merch/event reporting remains open.

## Interpretation

Active/programmed aggregate rows overlap their detailed children. Never sum aggregates and children together. Listener groups overlap, and daily listeners cannot be summed to unique period listeners. Daily streams can be summed within a source and selected period. The source comparison table's displayed change may lack direction; calculated signed change is stored separately. A dashboard dash remains blank, even if a daily chart explicitly shows zero. Top playlist/location tables are not exhaustive populations.

Raw capture labels link every normalized row to retained evidence. manual_table_transcriptions.json identifies values transcribed from visible tool output for which full DOM was not retained. The original source ZIP and workbook baseline tables remain the historical record. The only existing analytical cell addition is the missing prior-year YTD listener value in Artist periods!T59, its method and ratios; all other collection data is on new supplement tabs.
