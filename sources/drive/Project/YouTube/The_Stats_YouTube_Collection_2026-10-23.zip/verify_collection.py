"""Independent, read-only checks of native ZIPs against convenience CSV outputs."""
import csv
import hashlib
import io
import json
import zipfile
from collections import Counter
from decimal import Decimal
from pathlib import Path

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'report_manifest.json').read_text('utf-8'))
reports={r['report_id']:r for r in manifest['reports']}
def rows(name):
    with (ROOT/'normalized'/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
def native(report_id, member):
    r=reports[report_id]
    with zipfile.ZipFile(ROOT/r['original_path']) as z:
        return list(csv.DictReader(io.StringIO(z.read(member).decode('utf-8-sig'))))

for r in reports.values():
    assert hashlib.sha256((ROOT/r['original_path']).read_bytes()).hexdigest()==r['sha256']
views={}; engaged={}; repeats=Counter()
for prefix,field,dest in [('annual_video_views_batch','Views',views),('annual_video_engaged_batch','Engaged views',engaged)]:
    for report_id in sorted(r for r in reports if r.startswith(prefix)):
        for row in native(report_id,'Chart data.csv'):
            key=(row['Content'],row['Date'])
            value=Decimal(row[field])
            if key in dest:
                assert dest[key]==value, (report_id,key,'overlap conflict')
                repeats[field]+=1
            dest[key]=value
assert len(views)==len(engaged)==27*365
assert set(views)==set(engaged)
assert set(Counter(k[0] for k in views).values())=={365}
summary=native('annual_content','Table data.csv')
for row in summary:
    video=row['Content']
    if video=='Total': continue
    assert sum(v for (vid,day),v in views.items() if vid==video)==Decimal(row['Views'])
    assert sum(v for (vid,day),v in engaged.items() if vid==video)==Decimal(row['Engaged views'])
wide=rows('video_daily_wide_365.csv')
assert len(wide)==9855
for row in wide:
    key=(row['video_id'],row['activity_date'])
    assert Decimal(row['views'])==views[key]
    assert Decimal(row['engaged_views'])==engaged[key]
inventory=rows('video_inventory.csv')
assert len(inventory)==27
formats=Counter(r['content_format'] for r in inventory)
assert formats=={'videos':19,'shorts':8}
assert all(r['publication_date'] and r['duration_seconds'] for r in inventory)
canonical=rows('canonical_observations.csv')
assert all(r['source_conflict']=='false' for r in canonical)
assert all(r['source_export_url'] for r in canonical)
for row in canonical:
    if row['metric'] in {'views_share_percentage','watch_time_share_percentage'}:
        assert row['unit']=='percent_0_100'
    if row['metric']=='average_percentage_viewed':
        assert row['unit']=='percent'
    if row['metric']=='new_viewers' and row['period_kind'] in {'last90_current','last28_current'}:
        assert row['value']=='' and row['value_status']=='unavailable'
    if row['report_id']=='lifetime_livestream':
        assert row['value']=='' and row['value_status']=='unavailable'
publish={r['video_id']:r['publication_date'] for r in inventory}
prepublication=[r for r in canonical if r['video_id'] and r['activity_date'] and r['activity_date']<publish[r['video_id']]]
assert all('prepublication_source_value' in r['quality_notes'] for r in prepublication)
checks=rows('validation_checks.csv')
assert not any(r['status']=='fail' for r in checks)
assert not any(r['status']=='review' and not r['check'].startswith('table_sum:') for r in checks)
result={'result':'pass','scope':'40 native Advanced Mode ZIP reports; supplementary retention checked separately',
        'source_zip_hashes_verified':len(reports),'annual_video_day_keys':len(views),
        'annual_daily_metrics':['views','engaged_views'],'videos':27,'days_per_video':365,
        'duplicate_chart_observations_agreed':dict(repeats),'video_formats':dict(formats),
        'prepublication_observations_flagged':len(prepublication),
        'average_percentage_viewed_unit':'percent; values above 100 retained',
        'source_overlap_conflicts':0,'hard_validation_failures':0,
        'review_reason':'Native table detail does not always sum to aggregate; all review checks retained with precise differences.'}
(ROOT/'independent_validation.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
print(json.dumps(result,indent=2))
