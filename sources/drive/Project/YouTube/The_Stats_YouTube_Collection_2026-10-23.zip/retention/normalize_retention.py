"""Normalize native Studio retention exports without combining overlapping segments."""
from pathlib import Path
import csv, json, hashlib
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation

ROOT=Path(__file__).resolve().parent
STAGING=ROOT.parent
MANIFEST=ROOT/'retention_manifest.json'
payload=json.loads(MANIFEST.read_text(encoding='utf-8'))
reports=payload['reports']
def writecsv(path,rows,fields=None):
    rows=list(rows);fields=fields or list(rows[0])
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def number(raw):
    if raw.strip() in ('','—','–','-'):return '', 'unavailable'
    val=Decimal(raw)
    assert val.is_finite(),raw
    return str(val), 'zero' if val==0 else 'reported'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

metrics={
 'Absolute audience retention (%)':('absolute_audience_retention','percent','Percentage of views at the given video position, as exported. Replays can produce values above 100; do not clamp or sum positions/segments.'),
 'Compared to other videos (%)':('compared_to_other_videos','percent','Source comparison with YouTube videos of similar length. Preserve signed source percentages; do not reinterpret as a ratio or derive absolute retention from this field.'),
 'Started watching':('started_watching','count','Source detailed-activity count at this position; blank means unavailable, not zero.'),
 'Stopped watching':('stopped_watching','count','Source detailed-activity count at this position; blank means unavailable, not zero.'),
 'Number of times each moment was seen':('moment_seen_count','count','Source count of times the moment was seen; not a unique-viewer count.'),
}
dimensions={'New and Returning Viewers','Subscription status','Audience type','Audience by watch behavior'}
records=[];files=[];checks=[];counts=Counter();all_hashes=[];allpoints=0
for report in reports:
    rid=report['report_id'];base=ROOT/'extracted'/rid
    members=sorted(base.glob('*.csv'));assert len(members)==9,(rid,len(members))
    report_rows=0;report_observations=0;header_only=0
    for path in members:
        with path.open(encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f);headers=reader.fieldnames;rows=list(reader)
        assert headers[0]=='Video position (%)',(path,headers)
        metric_headers=[h for h in headers if h in metrics]
        dimension_headers=[h for h in headers if h in dimensions]
        assert len(metric_headers)+len(dimension_headers)+1==len(headers),(path,headers)
        assert len(dimension_headers)<=1
        status='unavailable' if not rows else 'complete'
        header_only+=not rows;report_rows+=len(rows);counts[path.name]+=len(rows)
        files.append(dict(report_id=rid,video_id=report['video_id'],source_file=path.relative_to(STAGING).as_posix(),member_name=path.name,headers=json.dumps(headers),native_row_count=len(rows),metric_observation_count=len(rows)*len(metric_headers),file_status=status,unavailable_reason='native_export_header_only; reason_not_exposed' if not rows else '',sha256=sha(path)))
        positions=[]
        for rownum,row in enumerate(rows,2):
            position=Decimal(row['Video position (%)']);assert 0<=position<100,(path,position)
            positions.append(position)
            segment_dimension=dimension_headers[0] if dimension_headers else 'member_scope'
            segment=row[dimension_headers[0]] if dimension_headers else path.stem
            for column in metric_headers:
                metric,unit,_=metrics[column];raw=row[column];value,value_status=number(raw)
                record={k:report[k] for k in ('report_id','channel_id','video_id','title','content_format','reporting_start','reporting_end','source_timezone','report_scope','period','selected_segment','retrieved_at_utc','retrieval_timestamp_basis','export_method')}
                record.update(member_name=path.name,segment_dimension=segment_dimension,segment_value=segment,video_position_percent=str(position),video_position_raw=row['Video position (%)'],metric=metric,source_metric=column,value=value,value_raw=raw,unit=unit,value_status=value_status,quality_note='source_blank_or_dash; unavailable_reason_not_exposed' if value_status=='unavailable' else '',source_file=path.relative_to(STAGING).as_posix(),source_row_number=rownum)
                records.append(record);report_observations+=1
        if path.name=='All.csv':
            assert positions==[Decimal(i) for i in range(100)],(rid,positions)
            assert len(rows)==100
            allpoints+=len(rows);all_hashes.append(sha(path))
            checks.append(dict(report_id=rid,check='all_curve_positions',status='pass',detail='100 ordered positions 0-99; complete native percentage bins, not calendar dates'))
    report.update(native_csv_count=len(members),native_row_count=report_rows,metric_observation_count=report_observations,all_curve_points=100,header_only_members=header_only)
    original=STAGING/report['original_path']
    assert sha(original)==report['sha256']
    checks.append(dict(report_id=rid,check='original_zip_hash',status='pass',detail='Original copy agrees with recorded download SHA256'))

assert len({r['video_id'] for r in reports})==27
assert Counter(r['content_format'] for r in reports)=={'videos':19,'shorts':8}
assert len(set(all_hashes))==27
checks.extend([
 dict(report_id='all',check='video_inventory_coverage',status='pass',detail='27 unique video IDs: 19 regular videos and 8 Shorts'),
 dict(report_id='all',check='all_curve_distinct_hashes',status='pass',detail='27 distinct All.csv hashes; no exact duplicated curve exports'),
 dict(report_id='all',check='native_members',status='pass',detail='27 ZIPs x 9 CSV members = 243 native CSVs'),
])

uploads=ROOT/'retention_upload_index.json'
if uploads.exists():
    entries=json.loads(uploads.read_text(encoding='utf-8-sig'))
    if isinstance(entries,dict):entries=entries.get('reports',entries.get('uploads',entries))
    for entry in entries:
        result=entry.get('result',entry)
        result=result.get('structuredContent',result)
        result=result.get('structuredContent',result)
        url=result.get('url',entry.get('url',''))
        for report in reports:
            if report['report_id']==entry.get('report_id'):report['export_url']=url

ui=json.loads((STAGING/'retention_ui_observations.json').read_text(encoding='utf-8'))
by_id={r['video_id']:r for r in reports};summaries=[]
for item in ui['rows']:
    source=by_id[item['video_id']]
    assert item['reporting_start']==source['reporting_start']
    duration=item['average_view_duration_display'];parts=[int(p) for p in duration.split(':')]
    seconds=sum(v*60**i for i,v in enumerate(reversed(parts)))
    summaries.append(dict(channel_id=source['channel_id'],video_id=item['video_id'],title=source['title'],content_format=source['content_format'],reporting_start=item['reporting_start'],reporting_end=ui['reporting_end'],source_timezone=ui['source_timezone'],period='since_uploaded_lifetime',report_scope=source['report_scope'],selected_segment='All',average_view_duration_display=duration,average_view_duration_seconds=seconds,average_percentage_viewed_pct=item['average_percentage_viewed_pct'],stayed_to_watch_pct=item['stayed_to_watch_pct'],stayed_to_watch_status=item['stayed_to_watch_status'],collection_method=ui['method'],retrieval_date=ui['retrieval_date'],related_native_export_retrieved_at_utc=source['retrieved_at_utc'],retrieval_timestamp_note=ui['retrieval_timestamp_note'],source_file='retention_ui_observations.json',quality_note='Rounded UI summaries; related download timestamp is a proxy, not exact UI reading time.'))
assert len(summaries)==27

writecsv(ROOT/'retention_observations.csv',records)
writecsv(ROOT/'retention_ui_summary.csv',summaries)
writecsv(ROOT/'retention_source_files.csv',files)
writecsv(ROOT/'retention_validation_checks.csv',checks)
writecsv(ROOT/'retention_collection_index.csv',reports)
MANIFEST.write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
dictionary=[dict(field='video_position_percent',unit='percent_0_to_100',definition='Elapsed-video position in source percentage bins 0-99; not a reporting date. No fabricated endpoint at 100.',additivity='Do not sum positions'),dict(field='segment_dimension / segment_value / member_name',unit='category',definition='Native member and audience or traffic segment identifiers. These scopes overlap and must remain separate.',additivity='Do not add overlapping segments'),dict(field='value_status',unit='category',definition='reported = numeric nonzero; zero = explicit source numeric zero; unavailable = source blank or dash. Header-only files are recorded in retention_source_files.csv.',additivity='Not applicable')]
for source,(metric,unit,definition) in metrics.items():dictionary.append(dict(field=metric,unit=unit,definition=definition,additivity='Nonadditive across retention positions, videos, or overlapping segments'))
dictionary.extend([
 dict(field='average_view_duration_seconds',unit='seconds',definition='Derived only by parsing the manually transcribed rounded UI duration string; raw display preserved. Separate method from native CSV curves.',additivity='Do not sum or take unweighted averages'),
 dict(field='average_percentage_viewed_pct',unit='percent',definition='Rounded manual UI average percentage viewed; values above 100 may occur due to replay.',additivity='Do not sum or take unweighted averages'),
 dict(field='stayed_to_watch_pct',unit='percent',definition='Rounded Shorts UI Stayed to watch percentage; regular-video absence marked not_applicable.',additivity='Do not sum or take unweighted averages'),
 dict(field='retrieved_at_utc',unit='ISO8601 UTC timestamp',definition='Download file LastWriteTimeUtc proxy, separate from source reporting dates. Exact click timestamp was not retained.',additivity='Not applicable'),
 dict(field='reporting_start / reporting_end',unit='Pacific calendar date',definition='Since uploaded lifetime bounds, inclusive. Filename end is exclusive and converted to inclusive end. Upload date may precede public publication date.',additivity='Overlapping periods must remain separate'),
])
writecsv(ROOT/'retention_data_dictionary.csv',dictionary)
summary=dict(native_zip_count=len(reports),native_csv_count=len(files),video_count=27,regular_video_count=19,shorts_count=8,native_row_count=sum(counts.values()),normalized_metric_observations=len(records),all_curve_points=allpoints,all_curve_position_bins='0-99 inclusive; 100 bins per video',native_rows_by_member=dict(counts),header_only_members=sum(f['file_status']=='unavailable' for f in files),manual_ui_summary_rows=len(summaries),manual_shorts_stayed_to_watch_values=sum(s['stayed_to_watch_status']=='reported' for s in summaries),validation_checks=len(checks),validation_failures=0,numeric_value_status_counts=dict(Counter(r['value_status'] for r in records)),caveats=['Native viewer, subscriber, traffic, All and Organic scopes overlap; do not sum them.','Absolute retention and average percentage viewed may exceed 100%; compared-to-other-videos source percentages may be negative.','Header-only CSV members and source blank cells remain unavailable; no claim of zero activity or a specific suppression cause.','27 UI averages and 8 Shorts Stayed-to-watch values are manually transcribed and labeled separately from native exports.','Positions 0-99 are elapsed-video percentage bins, not dates; the export supplies no position 100.'])
(ROOT/'retention_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
handoff='RETENTION ADDENDUM\n'+json.dumps(summary,indent=2)+'\n\nLoad retention/retention_observations.csv for native segment curves and activity. Keep report_id, video_id, member_name, segment_dimension, segment_value, video_position_percent and metric in the key. Join video_id to normalized/video_inventory.csv. Use retention/retention_ui_summary.csv only for the separately labeled manual UI summaries. Originals and native CSV members are preserved under retention/originals and retention/extracted. retention_collection_index.csv records periods, source methods and direct original-export URLs. retention_source_files.csv identifies header-only members.\n'
(STAGING/'retention_handoff.txt').write_text(handoff,encoding='utf-8')
print(json.dumps(summary))
