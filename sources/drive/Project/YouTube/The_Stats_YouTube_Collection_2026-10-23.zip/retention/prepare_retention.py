from pathlib import Path
import csv, json, re, shutil, hashlib, unicodedata, zipfile
from datetime import datetime, timezone, date, timedelta

ROOT=Path(__file__).resolve().parent
STAGING=ROOT.parent
DOWNLOADS=Path(r'C:\Users\jlewi\Downloads')
inventory=list(csv.DictReader((STAGING/'normalized/video_inventory.csv').open(encoding='utf-8-sig',newline='')))
def key(s):
    return ''.join(c for c in unicodedata.normalize('NFKC',s).casefold() if c.isalnum())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def writecsv(path, rows, fields=None):
    rows=list(rows)
    fields=fields or list(rows[0])
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)

reports=[]
for source in sorted(DOWNLOADS.glob('Audience retention*.zip')):
    match=re.fullmatch(r'Audience retention (\d{4}-\d{2}-\d{2})_(\d{4}-\d{2}-\d{2}) (.+)\.zip',source.name)
    assert match,source.name
    start,end_exclusive,title=match.groups()
    candidates=[v for v in inventory if key(v['title'])==key(title)]
    assert len(candidates)==1,(title,candidates)
    video=candidates[0];vid=video['video_id'];rid='retention_'+vid
    dest=ROOT/'originals'/rid/source.name
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    assert sha(source)==sha(dest)
    extract=ROOT/'extracted'/rid;extract.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        assert all(Path(n).name==n for n in z.namelist()),z.namelist()
        z.extractall(extract)
    reports.append(dict(report_id=rid,channel_id=video['channel_id'],video_id=vid,title=video['title'],content_format=video['content_format'],duration_seconds=video['duration_seconds'],report_name='Audience retention',reporting_start=start,reporting_end=(date.fromisoformat(end_exclusive)-timedelta(days=1)).isoformat(),filename_end_exclusive=end_exclusive,source_timezone='America/Los_Angeles',report_scope='channel_owned_selected_video',period='since_uploaded_lifetime',selected_segment='All',filters='selected video; all formats applicable to that video; since uploaded; selected All segment',export_method='YouTube Studio Advanced Mode native CSV ZIP export',retrieved_at_utc=datetime.fromtimestamp(source.stat().st_mtime,timezone.utc).isoformat(),retrieval_timestamp_basis='native_download_LastWriteTimeUtc_proxy',original_filename=source.name,original_path=dest.relative_to(STAGING).as_posix(),absolute_path=str(dest),sha256=sha(dest),export_url='',status='complete',note='Native ZIP includes All and available additional segments; header-only members remain unavailable, not zero.'))
assert len(reports)==27 and len({r['video_id'] for r in reports})==27
(ROOT/'retention_manifest.json').write_text(json.dumps({'reports':reports},indent=2,ensure_ascii=False),encoding='utf-8')
writecsv(ROOT/'retention_collection_index.csv',reports)
(ROOT/'retention_upload_list.json').write_text(json.dumps([{'report_id':r['report_id'],'absolute_path':r['absolute_path'],'upload_filename':r['report_id']+'.zip','sha256':r['sha256']} for r in reports],indent=2),encoding='utf-8')
print(json.dumps({'reports':len(reports),'originals_ready':True,'upload_list':str(ROOT/'retention_upload_list.json')}))
