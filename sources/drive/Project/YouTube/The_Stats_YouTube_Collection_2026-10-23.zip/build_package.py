"""Build the collection bundle from explicitly selected deliverables only."""
from pathlib import Path
import hashlib, json, zipfile

root = Path(__file__).resolve().parent
target = root / 'The_Stats_YouTube_Collection_2026-10-23.zip'
selected = []
for name in ('originals', 'extracted', 'normalized', 'retention'):
    directory = root / name
    if directory.exists():
        selected.extend(p for p in directory.rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix != '.pyc')
selected.extend(p for p in root.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.txt') and p.name not in ('package_manifest.json', 'library_upload_result.json'))
selected = sorted(set(selected), key=lambda p: str(p.relative_to(root)))
manifest = {
    'channel_id': 'UCkSoRiC9Pz9hEbJOOTYaq_w',
    'retrieval_date': '2026-10-23',
    'notes': 'Original ZIPs and extracted native CSVs unchanged. Reporting dates and retrieval timestamps are separate. Native Google Sheets collection index is linked in delivery_links.json.',
    'files': [{'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected],
}
(root / 'package_manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
selected.append(root / 'package_manifest.json')
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in selected:
        archive.write(path, path.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None, 'Corrupt ZIP member'
    assert len(archive.namelist()) == len(selected)
print(json.dumps({'path':str(target),'file_count':len(selected),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
