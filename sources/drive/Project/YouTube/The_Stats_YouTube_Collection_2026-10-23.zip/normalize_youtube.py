"""Normalize native YouTube Studio ZIP exports without changing source bytes.

Uses Python standard library only. Register confirmed downloads with `add`, then
run `build`. Source rows and raw values remain available in observations.csv.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import shutil
import zipfile
from collections import defaultdict
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'report_manifest.json'
CHANNEL = {'channel_id':'UCkSoRiC9Pz9hEbJOOTYaq_w', 'channel_name':'[REDACTED] TV',
           'channel_handle':'@redactedbandoh', 'channel_type':'standard_channel',
           'report_scope':'channel_owned', 'source_timezone':'America/Los_Angeles'}
# name: normalized key, unit, aggregation, meaning
METRICS = {
 'Views': ('views','count','additive','Source-reported views. Shorts changed to starts/replays on 2025-03-31. Official all-format first-frame counting rollout announced starting 2026-08-24; this channel retention UI explicitly says views counted differently from 2026-08-27. Preserve both evidence dates; do not impose a single inferred historical breakpoint.'),
 'Engaged views': ('engaged_views','count','additive','Source-reported engaged views; click/tap to watch or playback beyond initial seconds. Keep separate from total views.'),
 'Watch time (hours)': ('watch_time_hours','hours','additive','Source watch time in hours. Retained without silently changing units.'),
 'Average view duration': ('average_view_duration_seconds','seconds','nonadditive','Duration parsed from the native h:mm:ss value. Core average uses engaged metrics. Do not average row averages.'),
 'Average percentage viewed (%)': ('average_percentage_viewed','percent','nonadditive','Source average percentage viewed in percentage points, not a fraction. Replay can make this exceed 100%; retain the reported value without capping. Do not add or average unweighted.'),
 'Subscribers': ('subscribers_net','count','additive','Source net subscriber change over the selected period, not subscriber balance.'),
 'Subscribers gained': ('subscribers_gained','count','additive','Source subscriber gains over the selected period.'),
 'Subscribers lost': ('subscribers_lost','count','additive','Source subscriber losses over the selected period; positive number of losses.'),
 'Likes': ('likes','count','additive','Source likes metric for the selected reporting period.'),
 'Dislikes': ('dislikes','count','additive','Source dislikes metric for the selected reporting period.'),
 'Shares': ('shares','count','additive','Source shares metric for the selected reporting period.'),
 'Comments added': ('comments_added','count','additive','Source comments added metric for the selected reporting period.'),
 'Thumbnail impressions': ('thumbnail_impressions','count','additive','Eligible thumbnail impressions, not total video exposure across every surface.'),
 'Thumbnail click-through rate (%)': ('thumbnail_ctr','percent_0_100','nonadditive','Source thumbnail CTR in percent units. Preserve reported denominator/scope; do not derive from all views.'),
 'Unique viewers': ('unique_viewers','estimated_people','nonadditive','Estimated distinct audience within this exact report window (up to 90 days). Do not sum across videos, dates, or overlapping scopes.'),
 'Returning viewers': ('returning_viewers','estimated_people','nonadditive','Source estimated returning viewers in the selected reporting window.'),
 'New viewers': ('new_viewers','estimated_people','nonadditive','Source estimated new viewers in the selected reporting window.'),
 'Average views per viewer': ('average_views_per_viewer','ratio','nonadditive','Source-reported average views per viewer. Preserve source numerator definition; do not infer unique people from view-segment counts.'),
 'Views (%)': ('views_share_percentage','percent_0_100','nonadditive','Source percentage distribution of views within the report population.'),
 'Watch time (hours) (%)': ('watch_time_share_percentage','percent_0_100','nonadditive','Source percentage distribution of watch time within the report population.'),
}
META = {'Content','Video title','Video publish time','Duration','Date'}
SONG_CATALOG = {
 'the_cut_starts_tomorrow': ('The Cut (Starts Tomorrow)', ['3HqynH6ObSuDPZM0RMnFxN']),
 'the_devil_wears_docs': ('The Devil Wears Docs', ['7ARwqXOE4Hoi53M8TIra5P']),
 'goomh': ('GOOMH!', ['2P8H7ld0z758kLik5WHpaK']),
 'crawl': ('Crawl', ['6k07tSrPUEgdDoKZiLze3z']),
 'funny_guy': ('Funny Guy', ['3QVtuSBGLC9fTmLfF6qP7Z']),
 'john_doe': ('John Doe', ['6qzVbJkXPRZNxX5rGCfCNj']),
 'this_machine': ('THIS MACHINE', ['7Ji4wGBDl0wgLpV9ZNwa6r']),
 'method_acting': ('Method Acting', ['1CczfJ6sfBFVohNwW7T0nA','6ZGIMyU6p94qLhzLB7kmWV']),
 'la_cocaina': ('¡La Cocaína!', ['54PvxNbXvtB1WXjVgJxNAk','5SznyhiUBgOGjdMKZq8kye']),
 'goodnight_mrs_henderson': ('Goodnight Mrs. Henderson', ['3Bmzrteo6IStTEPm13a1zZ']),
 'waste_away': ('Waste Away', ['7sxshBNh4Ab16Pwf9OJf58']),
 'son': ('Son! (Hidden Track)', ['2PWQKZvFk6wRGZmcgBzWRy']),
 'my_own_summer_deftones': ('My Own Summer (Deftones cover)', []),
}
# Explicit title-evidence mapping; generic promotional titles intentionally absent.
VIDEO_SONG = {
 'oSYx8uSfRN4':'the_cut_starts_tomorrow','FeGqXlx4tHk':'the_cut_starts_tomorrow',
 'No0vwfv9EBQ':'the_cut_starts_tomorrow','YfSpDkjlKzc':'the_cut_starts_tomorrow',
 'WWCF470Tk8Y':'the_cut_starts_tomorrow','bb_7H8ECfv0':'the_cut_starts_tomorrow',
 'Fa4_SW2eB6o':'the_devil_wears_docs','ki7nlIXrcJM':'the_devil_wears_docs','EN6tkiqrL1o':'the_devil_wears_docs',
 'QdmsmOHtt8s':'goomh','KciP8jscymA':'crawl','mK_jceuq6B8':'funny_guy','7tW8CxyzeHY':'funny_guy',
 'C6UXnRUTVvY':'john_doe','UCTdXvNroMY':'this_machine','AYb-FnxQ7xo':'this_machine',
 'IQJqJxj6KRM':'method_acting','cFcKyVcQCng':'la_cocaina','mRHxcD7-IrE':'la_cocaina',
 'jf-i9HbqVc0':'goodnight_mrs_henderson','fvhinu1Ovwc':'waste_away','ZXoXCeDg154':'son',
 'YnRQhj1hcTM':'my_own_summer_deftones',
}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def write_csv(name: str, rows: list[dict], fieldnames=None):
    path = ROOT / 'normalized' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = fieldnames or list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)

def load_manifest():
    return json.loads(MANIFEST.read_text('utf-8')) if MANIFEST.exists() else {'channel':CHANNEL,'reports':[]}

def apply_collection_status_overrides(rows, overrides):
    """Update existing queue items and append complete, newly recorded items."""
    result=[{**row,**overrides.get(row['collection_item'],{})} for row in rows]
    known={row['collection_item'] for row in result}
    for item, override in overrides.items():
        if item not in known:
            added={'collection_item':item,**override}
            if added['collection_item']!=item or not all(k in added for k in ('status','coverage','limitation')):
                raise ValueError('New collection status override must provide a complete matching item: '+item)
            result.append(added)
            known.add(item)
    return result


def add_report(args):
    source = Path(args.file)
    data = source.read_bytes()
    manifest = load_manifest()
    existing = next((r for r in manifest['reports'] if r['report_id']==args.report_id), None)
    if existing:
        if existing['sha256'] != sha(data):
            raise ValueError('Existing report ID has different bytes; use a new report ID.')
        print(json.dumps({'already_registered':args.report_id}))
        return
    destination = ROOT/'originals'/args.report_id/source.name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    stamp=datetime.fromtimestamp(source.stat().st_mtime, timezone.utc).isoformat().replace('+00:00','Z')
    report={'report_id':args.report_id,'original_path':destination.relative_to(ROOT).as_posix(),
      'original_download_filename':source.name,'sha256':sha(data),'byte_count':len(data),
      'reporting_start':args.start or '', 'reporting_end':args.end or '',
      'period_kind':args.period_kind,'snapshot_class':args.snapshot_class,
      'breakdown':args.breakdown,'report_content_format':args.format,
      'filters_json':args.filters,
      'report_scope':'channel_owned','source_timezone':'America/Los_Angeles',
      'source_url':'https://studio.youtube.com/channel/'+CHANNEL['channel_id']+'/analytics',
      'source_url_kind':'stable_channel_analytics_entrypoint; exact dynamic report URL not retained',
      'retrieved_at_utc':stamp, 'retrieved_at_basis':'download_file_LastWriteTimeUtc_proxy; browser click timestamp not retained',
      'observed_download_completed_at_utc':stamp,
      'export_method':'native_youtube_studio_zip','priority':args.priority,
      'status':args.status,'status_note':args.status_note or '',
      'unavailable_metrics':args.unavailable_metrics.split(',') if args.unavailable_metrics else [],
      'date_boundary_note':args.note or '', 'report_name':args.report_name or args.breakdown}
    manifest['reports'].append(report)
    MANIFEST.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(report,ensure_ascii=False))

def parse_number(raw, metric):
    val=raw.strip()
    if not val:
        return '', 'unavailable', ''
    if val.lower() in {'n/a','not applicable'}:
        return '', 'not_applicable', ''
    if val.lower() in {'suppressed','privacy threshold'}:
        return '', 'suppressed', ''
    if val in {'—','–','-'}:
        return '', 'unavailable', 'source_dash; no suppression reason inferred'
    try:
        if metric=='average_view_duration_seconds' and ':' in val:
            parts=[Decimal(p) for p in val.split(':')]
            number=sum(p*(60**i) for i,p in enumerate(reversed(parts)))
        else:
            number=Decimal(val.replace(',','').removesuffix('%'))
        return format(number,'f'), 'zero' if number==0 else 'observed', ''
    except InvalidOperation:
        return '', 'unavailable', 'unparsed_source_value'

def iso_publish(raw):
    if not raw: return ''
    for fmt in ('%b %d, %Y','%Y-%m-%d','%B %d, %Y'):
        try: return datetime.strptime(raw,fmt).date().isoformat()
        except ValueError: pass
    return ''

def build():
    manifest=load_manifest()
    all_rows=[]; files=[]; checks=[]; inventory=[]; metrics=dict(METRICS)
    def check(report_id, name, status, detail):
        checks.append({'report_id':report_id,'check':name,'status':status,'detail':detail})
    for report in manifest['reports']:
        rid=report['report_id']; data=(ROOT/report['original_path']).read_bytes()
        assert sha(data)==report['sha256'], f'Source bytes changed: {rid}'
        check(rid,'original_sha256','pass',report['sha256'])
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for member in z.infolist():
                if member.is_dir(): continue
                if Path(member.filename).name!=member.filename:
                    raise ValueError(f'Unexpected nested archive member: {member.filename}')
                raw=z.read(member)
                path=ROOT/'extracted'/rid/member.filename
                path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(raw)
                if path.suffix.lower()!='.csv': continue
                reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
                source_rows=list(reader); headers=reader.fieldnames or []
                files.append({'report_id':rid,'member':member.filename,'source_path':path.relative_to(ROOT).as_posix(),
                    'sha256':sha(raw),'bytes':len(raw),'source_rows':len(source_rows),
                    'dated_source_rows':sum(bool(re.fullmatch(r'\d{4}-\d{2}-\d{2}',r.get('Date',''))) for r in source_rows),
                    'headers_json':json.dumps(headers,ensure_ascii=False)})
                check(rid,'csv_row_width:'+member.filename,'pass' if all(None not in row for row in source_rows) else 'fail',f'{len(source_rows)} data rows')
                if len(source_rows)>=500 and member.filename=='Table data.csv':
                    check(rid,'native_row_limit','review','Table has at least 500 rows; examine possible truncation')
                dimension_fields=[h for h in headers if h not in META and h not in metrics]
                # A report breakdown is a dimension, while other unknown numeric headers remain unclassified metrics.
                for field in list(dimension_fields):
                    if field not in headers[:2] and any(re.fullmatch(r'-?\d+(\.\d+)?',r.get(field,'').strip()) for r in source_rows[:8]):
                        metrics[field]=(re.sub('[^a-z0-9]+','_',field.lower()).strip('_'),'source_unit_unverified','nonadditive','Unclassified native numeric metric; definition requires verification.')
                        dimension_fields.remove(field)
                is_chart=member.filename=='Chart data.csv'
                is_totals=member.filename=='Totals.csv'
                total_count=0
                for rownum,row in enumerate(source_rows,2):
                    if None in row: raise ValueError(f'Misaligned CSV row {rid}/{member.filename}:{rownum}')
                    is_total=any(v=='Total' for v in list(row.values())[:1])
                    total_count+=int(is_total)
                    activity=row.get('Date','')
                    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',activity): activity=''
                    video=row.get('Content','') if not is_total else ''
                    # Dimension labels in Content (e.g. Total) are not a stable video ID.
                    if video and not re.fullmatch(r'[A-Za-z0-9_-]{11}',video):
                        check(rid,'video_id_shape','review',f'{member.filename}:{rownum} content={video!r}')
                    title=row.get('Video title','')
                    publish=iso_publish(row.get('Video publish time',''))
                    if video:
                        inventory.append({**manifest['channel'],'video_id':video,'video_url':'https://www.youtube.com/watch?v='+video,
                           'title':title,'publication_date':publish,'publication_date_raw':row.get('Video publish time',''),
                           'duration_seconds':row.get('Duration',''),'content_format':report['report_content_format'] if report['report_content_format']!='all' else 'unverified',
                           'source_report_id':rid,'source_file':path.relative_to(ROOT).as_posix(),'source_row_number':rownum})
                    dimension={h:row.get(h,'') for h in dimension_fields} if not is_total else {}
                    grain=('video_daily' if video else 'dimension_daily' if dimension else 'channel_daily') if activity else ('video_period' if video else 'dimension_period' if dimension else 'channel_period')
                    for field in headers:
                        if field not in metrics: continue
                        metric,unit,aggregation,_=metrics[field]
                        value,status,note=parse_number(row.get(field,''),metric)
                        quality=[]
                        if note: quality.append(note)
                        if metric in report.get('unavailable_metrics',[]):
                            quality.append('source_UI_dash_with_export_zero_or_blank; raw representation retained; numeric value unavailable')
                            value=''; status='unavailable'
                        if activity and publish and activity<publish:
                            quality.append('prepublication_source_value')
                        if is_chart: quality.append('selected_chart_series_only')
                        if unit=='source_unit_unverified': quality.append('metric_definition_unverified')
                        all_rows.append({**manifest['channel'], 'report_id':rid,'grain':grain,
                           'snapshot_class':report['snapshot_class'],'period_kind':report['period_kind'],
                           'reporting_start':report['reporting_start'],'reporting_end':report['reporting_end'],
                           'activity_date':activity,'report_content_format':report['report_content_format'],
                           'filters_json':report.get('filters_json','{}'),'report_breakdown':report['breakdown'],
                           'video_id':video,'video_title':title,'dimension_json':json.dumps(dimension,ensure_ascii=False,sort_keys=True) if dimension else '',
                           'metric':metric,'value':value,'value_status':status,'unit':unit,'aggregation':aggregation,
                           'source_field':field,'source_value_raw':row.get(field,''),'source_file':path.relative_to(ROOT).as_posix(),
                           'source_row_number':rownum,'source_table_role':'selected_chart_series' if is_chart else 'chart_total_daily' if is_totals else 'table',
                           'retrieved_at_utc':report['retrieved_at_utc'],'retrieved_at_basis':report['retrieved_at_basis'],
                           'observed_download_completed_at_utc':report['observed_download_completed_at_utc'],
                           'source_url':report.get('source_url','https://studio.youtube.com/channel/'+CHANNEL['channel_id']+'/analytics'),
                           'source_export_url':report.get('source_export_url',''),
                           'quality_notes':'; '.join(quality),'priority':report['priority']})
                check(rid,'member_rows:'+member.filename,'info',f'{len(source_rows)} rows; {total_count} Total rows; {len(source_rows)-total_count} detail rows; fields='+', '.join(headers))
                if member.filename=='Table data.csv':
                    total_rows=[r for r in source_rows if list(r.values())[0]=='Total']
                    detail_rows=[r for r in source_rows if list(r.values())[0]!='Total']
                    check(rid,'table_row_cap','review' if len(detail_rows)>=500 else 'pass',f'{len(detail_rows)} detail rows; native table cap 500. Below cap does not establish unrestricted population coverage.')
                    if total_rows:
                        for field in headers:
                            if field not in metrics or metrics[field][2]!='additive': continue
                            metric,unit,_,_=metrics[field]
                            total,_,_=parse_number(total_rows[0].get(field,''),metric)
                            detail_values=[parse_number(r.get(field,''),metric)[0] for r in detail_rows]
                            if total=='': continue
                            detail_sum=sum(Decimal(v) for v in detail_values if v!='')
                            delta=detail_sum-Decimal(total)
                            tolerance=Decimal('0.0001')*len(detail_rows) if unit=='hours' else Decimal(0)
                            check(rid,'table_sum:'+metric,'pass' if abs(delta)<=tolerance else 'review',f'detail sum={detail_sum}; native Total={total}; difference={delta}; missing numeric detail={detail_values.count("")}; tolerance={tolerance}. Retain native total and row coverage; do not force reconciliation.')
    inv={}
    for row in inventory:
        if row['video_id'] not in inv or (row['content_format']!='unverified' and inv[row['video_id']]['content_format']=='unverified'):
            inv[row['video_id']]=row
    for row in all_rows:
        row['content_format']=inv[row['video_id']]['content_format'] if row['video_id'] else row['report_content_format']
        row['canonical_content_format']=row['content_format']
        # Chart CSVs omit publication metadata. Join the native inventory only to label padding.
        publish=inv.get(row['video_id'],{}).get('publication_date','')
        if row['activity_date'] and publish and row['activity_date']<publish and 'prepublication_source_value' not in row['quality_notes']:
            row['quality_notes']+='; prepublication_source_value; publication date joined from native inventory'
    write_csv('observations.csv',all_rows)
    # Every reporting window remains independent, even when daily dates overlap.
    key_fields=['channel_id','report_scope','snapshot_class','period_kind','reporting_start','reporting_end','canonical_content_format','filters_json','grain','activity_date','video_id','dimension_json','metric']
    groups=defaultdict(list)
    for row in all_rows: groups[tuple(row[k] for k in key_fields)].append(row)
    canonical=[]
    for key,rows in groups.items():
        usable=[r for r in rows if r['value_status'] in {'zero','observed'}]
        pool=usable or rows
        chosen=max(pool,key=lambda r:(r['priority'],r['retrieved_at_utc'],r['source_table_role']=='table'))
        chosen=dict(chosen)
        chosen['source_observation_count']=len(rows)
        chosen['source_reports']=';'.join(sorted(set(r['report_id'] for r in rows)))
        chosen['source_conflict']='true' if len({r['value'] for r in usable})>1 else 'false'
        canonical.append(chosen)
        if chosen['source_conflict']=='true':
            check(chosen['report_id'],'overlap_value_agreement','review',json.dumps(dict(zip(key_fields,key)),ensure_ascii=False)+' values='+str(sorted({r['value'] for r in usable})))
    canonical.sort(key=lambda r:tuple(str(r[k]) for k in key_fields))
    fields=list(all_rows[0]) + ['source_observation_count','source_reports','source_conflict'] if all_rows else key_fields
    write_csv('canonical_observations.csv',canonical,fields)
    for grain in ['channel_daily','channel_period','video_daily','video_period','dimension_daily','dimension_period']:
        write_csv(grain+'.csv',[r for r in canonical if r['grain']==grain],fields)
    # Convenience pivots preserve the complete scope/window key. Long files retain every lineage field.
    wide_key=['channel_id','report_scope','source_timezone','snapshot_class','period_kind','reporting_start',
              'reporting_end','canonical_content_format','filters_json','activity_date','video_id']
    def make_wide(rows, filename, selected_metrics=None):
        metric_keys=selected_metrics or sorted({r['metric'] for r in rows})
        grouped=defaultdict(dict)
        for r in rows:
            if r['metric'] in metric_keys:
                key=tuple(r[k] for k in wide_key)
                assert r['metric'] not in grouped[key], 'Pivot would combine conflicting scope keys'
                grouped[key][r['metric']]=r
        pivot=[]
        for key,vals in sorted(grouped.items()):
            row=dict(zip(wide_key,key))
            for m in metric_keys:
                source=vals.get(m,{})
                row[m]=source.get('value','')
                row[m+'_status']=source.get('value_status','unavailable')
                row[m+'_source_report_id']=source.get('report_id','')
            row['missing_metric_note']='Blank metric with no source report ID means no native observation for that date/scope; not imputed to zero.'
            pivot.append(row)
        write_csv(filename,pivot)
        return len(pivot)
    wide_channel_rows=make_wide([r for r in canonical if r['grain']=='channel_daily'],'channel_daily_wide.csv')
    wide_video_rows=make_wide([r for r in canonical if r['grain']=='video_daily' and r['period_kind']=='annual_current'
        and r['filters_json']=='{}'],'video_daily_wide_365.csv',['views','engaged_views'])
    write_csv('video_inventory.csv',list(inv.values()),list(inventory[0]) if inventory else ['channel_id','video_id','title','content_format'])
    song_maps=[]
    for video,item in inv.items():
        song=VIDEO_SONG.get(video,''); title, candidates=SONG_CATALOG.get(song,('',[]))
        live='live from' in item['title'].lower()
        recording_status=('external_cover' if song=='my_own_summer_deftones' else 'live_performance_not_studio_recording' if live else
                          'ambiguous_recording_versions' if len(candidates)>1 else 'single_catalog_candidate_unverified_audio' if candidates else 'unmapped')
        song_maps.append({'channel_id':CHANNEL['channel_id'],'video_id':video,'video_title':item['title'],'content_format':item['content_format'],
            'song_work_id':'song:'+song if song else '', 'song_title':title,
            'song_mapping_status':'clear_title_relationship' if song else 'unresolved',
            'song_mapping_evidence':'Explicit native video title; relationship is to song, not proof of identical audio recording.' if song else 'Native title does not clearly identify a catalog song.',
            'performance_type':'live_performance' if live else 'not_specified','spotify_recording_id':'',
            'candidate_spotify_recording_ids':';'.join(candidates),'recording_mapping_status':recording_status,
            'catalog_source':'The Stats Workbook Catalog!A59:F73, retrieved 2026-10-23',
            'source_report_id':item['source_report_id'],'source_file':item['source_file'],'source_row_number':item['source_row_number']})
    write_csv('video_song_mapping.csv',song_maps)
    # Actual date coverage and additive sum reconciliation: observed rows only, never fill absent dates.
    coverage_groups=defaultdict(list)
    coverage_fields=['channel_id','report_scope','snapshot_class','period_kind','reporting_start','reporting_end','canonical_content_format','filters_json','grain','video_id','dimension_json','metric','unit']
    for row in canonical:
        if row['activity_date']: coverage_groups[tuple(row[k] for k in coverage_fields)].append(row)
    coverage=[]
    for key,rows in coverage_groups.items():
        base=dict(zip(coverage_fields,key)); dates={r['activity_date'] for r in rows}
        start=base['reporting_start']; end=base['reporting_end']; expected=[]
        if start and end:
            d=date.fromisoformat(start)
            while d<=date.fromisoformat(end): expected.append(d.isoformat()); d+=timedelta(days=1)
        missing=sorted(set(expected)-dates)
        coverage.append({**base,'observed_dates':len(dates),'numeric_dates':sum(r['value_status'] in {'zero','observed'} for r in rows),
             'first_observed_date':min(dates),'last_observed_date':max(dates),'expected_dates':len(expected),
             'missing_dates_count':len(missing),'missing_dates_json':json.dumps(missing),
             'date_coverage_status':'complete' if expected and not missing else 'partial' if expected else 'bounds_unavailable'})
        if rows[0]['aggregation']=='additive':
            totals=[r for r in canonical if r['grain']==base['grain'].replace('_daily','_period') and all(r[k]==base[k] for k in coverage_fields if k!='grain')]
            if totals:
                observed_sum=sum(Decimal(r['value']) for r in rows if r['value']!='')
                total=totals[0]
                if total['value']!='':
                    diff=observed_sum-Decimal(total['value'])
                    tolerance=Decimal('0.0001')*len(rows) if base['unit']=='hours' else Decimal(0)
                    check(total['report_id'],'daily_sum:'+base['metric'],'pass' if abs(diff)<=tolerance else 'review',f'grain={base["grain"]}; video={base["video_id"]}; dimension={base["dimension_json"]}; observed sum={observed_sum}; report total={total["value"]}; difference={diff}; missing dates={len(missing)}; tolerance={tolerance}; missing dates not imputed')
    write_csv('daily_coverage.csv',coverage)
    write_csv('source_files.csv',files)
    write_csv('validation_checks.csv',checks)
    report_index=[]
    for report in manifest['reports']:
        own_files=[f for f in files if f['report_id']==report['report_id']]
        own_rows=[r for r in all_rows if r['report_id']==report['report_id']]
        report_index.append({**report,'native_csv_members':len(own_files),'native_rows':sum(f['source_rows'] for f in own_files),
            'source_metric_observations':len(own_rows),'video_ids_in_export':len({r['video_id'] for r in own_rows if r['video_id']}),
            'observed_daily_dates':len({r['activity_date'] for r in own_rows if r['activity_date']}),
            'status':report.get('status','collected_pending_scope_review'),
            'status_note':report.get('status_note','Original native ZIP and all member CSVs preserved. See validation and daily coverage.')})
    write_csv('collection_index.csv',report_index)
    collection_status=[
      {'collection_item':'Channel identity and account scope','status':'complete','coverage':'Verified channel ID, name, handle; standard channel, channel_owned scope.','limitation':'No Official Artist Channel controls or public artist badge observed.'},
      {'collection_item':'Annual channel daily core metrics','status':'partial','coverage':'2025-10-22 through 2026-10-21; Views and Engaged views cover all 365 dates; 14 metrics exported.','limitation':'Native Date table includes 243 of 365 dates for full 14 metrics; other absent daily rows remain missing, never zero-filled.'},
      {'collection_item':'Lifetime channel and video summaries','status':'complete','coverage':'2024-01-25 through 2026-10-21; 27 videos and 1001 daily channel Views.','limitation':'Six default summary metrics; unavailable live-only UI values not treated as zero.'},
      {'collection_item':'Annual video inventory and performance','status':'complete','coverage':'27 stable video IDs with titles, URLs, publication dates, duration, verified format; 14 performance metrics.','limitation':'Some source aggregate totals differ from sums of video-attributed rows; preserve both.'},
      {'collection_item':'Annual per-video daily Views and Engaged views','status':'complete','coverage':'27 videos by 365 dates; 9855 rows per metric, 19710 numeric observations; batched charts cover all IDs.','limitation':'Other per-video daily metrics not collected. Source chart zero padding before publication retained and flagged.'},
      {'collection_item':'Content format summaries','status':'complete','coverage':'19 regular videos and 8 Shorts identified from explicit native format filters.','limitation':'Lifetime livestream scope has no content rows and UI dashes; no numeric activity conclusion.'},
      {'collection_item':'Attention summaries','status':'complete','coverage':'Average view duration and average percentage viewed in annual per-video 14-metric export.','limitation':'Nonadditive averages; source durations parsed seconds.'},
      {'collection_item':'Audience retention curves','status':'not_yet_collected','coverage':'Pending independent retention collection.','limitation':'No curve data inferred from average duration.'},
      {'collection_item':'Traffic sources and discovery','status':'partial','coverage':'Annual traffic sources, thumbnail impressions/CTR, 34 search terms, 9 external-source rows.','limitation':'Search detail 47 of 239 Views; external detail 33 of 42 Views. Detail not exhaustive even below 500 table-row cap.'},
      {'collection_item':'Audience geography','status':'partial','coverage':'Annual 9 countries; 90-day 2 countries; 28-day total with no country rows.','limitation':'Source suppressed/limited detail does not cover aggregate Views; missing countries not zero.'},
      {'collection_item':'Audience age and gender','status':'partial','coverage':'Annual 6 age groups and 2 gender groups; native percentages retained.','limitation':'28/90-day reports header-only with explicit insufficient-data message. Missing 65+ and unspecified-gender rows not zero.'},
      {'collection_item':'Audience unique and returning viewers','status':'partial','coverage':'90-day 2026-07-24 to 2026-10-21 and 28-day 2026-09-24 to 2026-10-21; unique 77/19 and returning 17/5.','limitation':'New viewers UI dash conflicts with native Total 0; normalized unavailable. Counts nonadditive across reports.'},
      {'collection_item':'Subscriber versus non-subscriber viewing','status':'complete','coverage':'28-day and 90-day native subscription-status breakdowns.','limitation':'View counts are not counts of subscribers or unique people.'},
      {'collection_item':'YouTube Music product reporting','status':'complete','coverage':'Annual YouTube and YouTube Music Views/watch time breakdown.','limitation':'Channel-owned product scope, not artist-wide reach or every use of band music.'},
      {'collection_item':'OAC song rollups, Other Channels and Total Reach','status':'not_applicable','coverage':'Selected account is a standard channel.','limitation':'Artist reporting controls not exposed; no overlapping artist scopes added.'},
      {'collection_item':'Native Art Track analytics','status':'blocked','coverage':'No Art Track reporting exposed for this selected standard-channel scope.','limitation':'No access to label/distributor-owned or other-channel analytics was granted.'},
      {'collection_item':'Song relationship mapping','status':'partial','coverage':'23 clear title-to-song relationships, 4 unresolved videos; multiple videos per song allowed.','limitation':'No exact Spotify audio recording match asserted; remaster/live ambiguity retained.'},
      {'collection_item':'October 20 baseline-compatible historical period','status':'complete','coverage':'2025-10-21 through 2026-10-20 content summary and 365 daily Views.','limitation':'Newly retrieved historical report on 2026-10-23, not original October 20 snapshot.'},
      {'collection_item':'API future option','status':'not_yet_collected','coverage':'No new API application or access grant created.','limitation':'Future authorized API could extend unsupported detail; native collection used existing signed-in access.'},
    ]
    override_path=ROOT/'collection_status_overrides.json'
    if override_path.exists():
        overrides=json.loads(override_path.read_text('utf-8'))
        collection_status=apply_collection_status_overrides(collection_status,overrides)
    write_csv('collection_status.csv',collection_status)
    dictionary=[{'source_field':k,'metric':v[0],'unit':v[1],'aggregation':v[2],'definition':v[3]} for k,v in metrics.items()]
    write_csv('metric_dictionary.csv',dictionary)
    field_definitions={
      'channel_id':'Stable YouTube channel ID; primary account key.',
      'channel_name':'Observed display name, descriptive only.',
      'channel_handle':'Observed handle, descriptive and mutable.',
      'channel_type':'Verified account type. Standard channel; not an Official Artist Channel in observed UI.',
      'report_scope':'Account ownership population; channel_owned for these exports. Further filters still apply.',
      'source_timezone':'Platform daily calendar timezone; America/Los_Angeles. Dates are not shifted to UTC.',
      'report_id':'Stable capture identifier joining report_manifest.json and collection_index.csv.',
      'grain':'channel_daily,channel_period,video_daily,video_period,dimension_daily,or dimension_period.',
      'snapshot_class':'current_retrieval or newly_retrieved_historical. No file is an original October20 snapshot.',
      'period_kind':'Named reporting window. Distinct windows remain separate even when dates overlap.',
      'reporting_start':'Inclusive reporting start from Studio UI, ISO date.',
      'reporting_end':'Inclusive reporting end from Studio UI. Native ZIP end date is exclusive for these files.',
      'activity_date':'Native Pacific calendar date for daily data. Blank for period/lifetime summary.',
      'report_content_format':'Content filter used for this report, or all. Distinct from verified format of a single video.',
      'content_format':'Video/Short/livestream classification from explicit source filter; channel rows retain report format.',
      'canonical_content_format':'Canonical grouping format. Video IDs use verified intrinsic format so repeated all-format and filtered exports do not double-count.',
      'filters_json':'JSON of observed report filters, always part of canonical key. Empty object means no additional filter.',
      'report_breakdown':'Dimension selected in source report. Chart checkboxes are series selection, not report filters.',
      'video_id':'Stable YouTube video key. Blank for channel and non-video dimension rows.',
      'video_title':'Source video title, descriptive only; source encoding retained.',
      'dimension_json':'JSON object of native dimension names/values, such as Geography or Traffic source. Do not merge different dimensions.',
      'metric':'Normalized metric key joining metric_dictionary.csv.',
      'value':'Numeric value in unit column; blank when unavailable/suppressed/not applicable. Never fill blank with zero.',
      'value_status':'observed,zero,unavailable,suppressed,or not_applicable; see value_status_dictionary.csv.',
      'unit':'Explicit normalized unit. percent_0_100 denotes percentage-point proportions such as CTR or demographic shares. percent denotes percentage points without a 100% upper bound, used for average percentage viewed because replay can exceed 100%. Neither percentage unit is a fraction.',
      'aggregation':'Additive within compatible complete scope, or nonadditive. Never add overlapping reporting windows.',
      'source_field':'Unchanged native CSV header.',
      'source_value_raw':'Original CSV cell representation. Preserved even when UI evidence makes normalized numeric value unavailable.',
      'source_file':'Relative path of unchanged extracted native CSV within this package.',
      'source_url':'Stable YouTube Studio channel analytics entrypoint. Exact dynamic report URL was not retained; filters and report context are separate columns.',
      'source_export_url':'Saved original native ZIP URL, if publication has completed; source bytes remain unchanged.',
      'source_row_number':'One-based CSV logical record number including header as row1; not physical text line for multiline cells.',
      'source_table_role':'table,chart_total_daily,or selected_chart_series. Default chart selection need not cover all videos.',
      'retrieved_at_utc':'Acquisition timestamp proxy from downloaded file LastWriteTimeUtc, not exact browser click time.',
      'retrieved_at_basis':'Explicit evidence basis for acquisition timestamp.',
      'observed_download_completed_at_utc':'Observed downloaded file timestamp in UTC; same file-metadata proxy, not independent server retrieval time.',
      'quality_notes':'Source limitations such as prepublication chart padding or UI/export mismatch; no inferred correction of source bytes.',
      'priority':'Deterministic canonical preference; full metric source preferred to redundant initial export.',
      'source_observation_count':'Count of source observations represented by canonical row.',
      'source_reports':'Semicolon-separated report IDs contributing matching canonical observations.',
      'source_conflict':'true when nonmissing numeric source observations disagree within one canonical key. Sources remain in observations.csv.',
    }
    write_csv('field_dictionary.csv',[{'field':k,'definition':v} for k,v in field_definitions.items()])
    write_csv('value_status_dictionary.csv',[
       {'status':'observed','meaning':'Native numeric value other than zero, retained at source precision.'},
       {'status':'zero','meaning':'Explicit native numeric zero, unless independent UI evidence indicates unavailable.'},
       {'status':'unavailable','meaning':'Blank/dash, unparsed value, or documented UI/export contradiction. Numeric value remains blank.'},
       {'status':'suppressed','meaning':'Source explicitly identifies insufficient or suppressed data; header-only reports are recorded at report level without fabricated metric rows.'},
       {'status':'not_applicable','meaning':'Source explicitly says metric does not apply; never inferred merely from a missing row.'},
       {'status':'not_yet_collected','meaning':'Collection queue only, for requested information not collected. No invented numeric observations.'},
    ])
    summary={'reports':len(manifest['reports']),'native_csv_files':len(files),'raw_metric_observations':len(all_rows),
        'canonical_metric_observations':len(canonical),'distinct_videos':len(inv),
        'native_daily_rows_including_overlapping_exports':sum(f['dated_source_rows'] for f in files),
        'distinct_calendar_dates_with_any_daily_observation':len({r['activity_date'] for r in all_rows if r['activity_date']}),
        'rows_by_grain':{g:sum(r['grain']==g for r in canonical) for g in sorted({r['grain'] for r in canonical})},
        'checks':{s:sum(c['status']==s for c in checks) for s in sorted({c['status'] for c in checks})},
        'review_checks_by_type':{n:sum(c['status']=='review' and c['check']==n for c in checks) for n in sorted({c['check'] for c in checks if c['status']=='review'})},
        'video_daily_wide_365_rows':wide_video_rows,'channel_daily_wide_rows':wide_channel_rows}
    (ROOT/'validation_summary.json').write_text(json.dumps(summary,indent=2)+'\n','utf-8')
    upload_plan={'originals':[{'report_id':r['report_id'],'absolute_path':str(ROOT/r['original_path']),
          'upload_filename':r['report_id']+'.zip','sha256':r['sha256']} for r in manifest['reports']],
          'normalized':[{'filename':p.name,'absolute_path':str(p)} for p in sorted((ROOT/'normalized').glob('*.csv'))]}
    (ROOT/'upload_file_list.json').write_text(json.dumps(upload_plan,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(summary,indent=2))

def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('add')
    a.add_argument('--file',required=True); a.add_argument('--report-id',required=True)
    a.add_argument('--start'); a.add_argument('--end')
    a.add_argument('--period-kind',default='annual_current')
    a.add_argument('--snapshot-class',default='current_retrieval')
    a.add_argument('--breakdown',default='content'); a.add_argument('--format',default='all')
    a.add_argument('--priority',type=int,default=10); a.add_argument('--note'); a.add_argument('--report-name')
    a.add_argument('--filters',default='{}',help='JSON object of observed filters; part of every canonical key')
    a.add_argument('--status',default='collected_pending_scope_review')
    a.add_argument('--status-note')
    a.add_argument('--unavailable-metrics',default='',help='Comma-separated metrics with independent UI evidence that export zero is not reliable')
    sub.add_parser('build')
    args=p.parse_args()
    add_report(args) if args.command=='add' else build()

if __name__=='__main__': main()
